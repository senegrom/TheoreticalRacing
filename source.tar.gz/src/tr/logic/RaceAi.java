package tr.logic;

import java.util.BitSet;

/**
 * The vector-racing AI extracted from {@link RaceGame}: move selection (the
 * AI1 and AI2 kinds are two labels for one promoted policy since round 222;
 * an experiment gates one kind while it is being measured), opponent
 * prediction, box-seal detection, brake-proof pace discipline and the N-ply
 * escape-headroom search. Reads the reachability maps and its host's
 * legality/geometry predicates through back-refs; returns the chosen move.
 */
final class RaceAi {
	private final RaceGame game;
	private final Reachability reach;
	private final RaceAiPrivateLane privateLane;
	/** Cached because the compiler-generated values() method clones on every call. */
	private static final Direction[] DIRECTIONS = Direction.values();
	/** Scratch storage is instance-owned: one RaceAi drives one single-threaded game. */
	private TwoRoundWorkspace twoRoundWorkspace;
	/** Nested-scorer reference world. A scorer's candidate landing is the sole
	 *  varying blocker in the first projected opponent round, so candidates that
	 *  do not hit any reference landing can reuse both projected rounds exactly. */
	private TwoRoundWorkspace nestedScorerTwoRoundReferenceWorkspace;
	private PredictionWorkspace predictionWorkspace;
	private RolloutWorkspace[] rolloutsByDepth = new RolloutWorkspace[4];
	private final int[] sealEscapes = new int[DIRECTIONS.length * 2];
	private final int[] sealCover = new int[DIRECTIONS.length];
	private final int[] sealMatch = new int[Integer.SIZE];
	private final int[] mobilityMove = new int[4];
	private MobilitySearch outerMobilityWorkspace;
	private MobilitySearch nestedMobilityWorkspace;
	private byte[] liveOccupancy;
	private int[] liveOccupancyTouched;
	private int liveOccupancyTouchedCount;
	private final long[] rolloutFieldCost = new long[1];
	/** Candidate rows per rollout depth. A decision's rows must stay live while
	 *  the rollouts it runs invoke nested scorers for rivals -- and an
	 *  unsuppressed (true-rival) nested scorer used to take the OUTER rows,
	 *  because it runs with inScorerSim off, wiping the decision still reading
	 *  them (round 223). Keyed by simDepth, every compute owns its level. */
	private CandidateWorkspace[] candidatesByDepth = new CandidateWorkspace[4];

	private static final class CandidateWorkspace {
		final double[] trapByDirection = new double[DIRECTIONS.length];
		final double[] scoreWithoutSpread = new double[DIRECTIONS.length];
		final int[] turnsByDirection = new int[DIRECTIONS.length];
		final double[] scoreByDirection = new double[DIRECTIONS.length];
		final double[] uncertaintyByDirection = new double[DIRECTIONS.length];

		void reset() {
			java.util.Arrays.fill(trapByDirection, 0.0);
			java.util.Arrays.fill(scoreWithoutSpread, Double.MAX_VALUE);
			java.util.Arrays.fill(turnsByDirection, Integer.MAX_VALUE);
			java.util.Arrays.fill(scoreByDirection, Double.MAX_VALUE);
			java.util.Arrays.fill(uncertaintyByDirection, 0.0);
		}

		void copyFrom(final CandidateWorkspace source) {
			System.arraycopy(source.trapByDirection, 0, trapByDirection, 0, DIRECTIONS.length);
			System.arraycopy(source.scoreWithoutSpread, 0, scoreWithoutSpread, 0,
					DIRECTIONS.length);
			System.arraycopy(source.turnsByDirection, 0, turnsByDirection, 0, DIRECTIONS.length);
			System.arraycopy(source.scoreByDirection, 0, scoreByDirection, 0, DIRECTIONS.length);
			System.arraycopy(source.uncertaintyByDirection, 0, uncertaintyByDirection, 0,
					DIRECTIONS.length);
		}
	}

	/** One candidate-row snapshot per permitted faithful-confirm nesting level. */
	private final CandidateWorkspace[] trueConfirmCandidateSnapshots =
			newTrueConfirmCandidateSnapshots();

	private static CandidateWorkspace[] newTrueConfirmCandidateSnapshots() {
		final CandidateWorkspace[] snapshots =
				new CandidateWorkspace[AI1_TRUE_CONFIRM_MAXDEPTH];
		for (int i = 0; i < snapshots.length; i++)
			snapshots[i] = new CandidateWorkspace();
		return snapshots;
	}

	/** Exact touched-cell occupancy counts for one projected board. Counts,
	 * rather than booleans, preserve duplicate-cell semantics while allowing
	 * O(1) successor tests and O(1) mover removal/reinsertion. */
	static final class CellOccupancy {
		final byte[] counts;
		final int[] touched;
		final long[] recorded;	// cells already listed in touched during this clear epoch
		final int width;
		final int height;
		int touchedCount;

		CellOccupancy(final int width, final int height) {
			this.width = width;
			this.height = height;
			counts = new byte[width * height];
			touched = new int[width * height];
			recorded = new long[(width * height + 63) >>> 6];
		}

		void clear() {
			for (int i = 0; i < touchedCount; i++) {
				final int index = touched[i];
				counts[index] = 0;
				recorded[index >>> 6] &= ~(1L << (index & 63));
			}
			touchedCount = 0;
		}

		void rebuild(final int[][] cells) {
			clear();
			for (final int[] cell : cells)
				if (cell != null)
					add(cell[0], cell[1]);
		}

		void add(final int x, final int y) {
			if (x < 0 || y < 0 || x >= width || y >= height)
				return;
			final int index = x * height + y;
			if (counts[index] == 0) {
				final int word = index >>> 6;
				final long mask = 1L << (index & 63);
				if ((recorded[word] & mask) == 0) {
					recorded[word] |= mask;
					touched[touchedCount++] = index;
				}
			}
			counts[index]++;
		}

		void remove(final int x, final int y) {
			if (x < 0 || y < 0 || x >= width || y >= height)
				return;
			final int index = x * height + y;
			if (counts[index] != 0)
				counts[index]--;
		}

		boolean contains(final int x, final int y) {
			return x >= 0 && y >= 0 && x < width && y < height
					&& counts[x * height + y] != 0;
		}
	}

	private static final class TwoRoundWorkspace {
		final int[][] current;
		final int[][] world1;
		final int[][] simulatedVelocity;
		final int[][] round1Position;
		final int[][] round2Position;
		final int[][] round1Velocity;
		final int[][] round2Velocity;
		final byte[] aheadOccupancy;
		final int[] aheadTouched;
		final CellOccupancy blockedOccupancy;
		final CellOccupancy world1Occupancy;
		int aheadTouchedCount;

		TwoRoundWorkspace(final int players, final int width, final int height) {
			current = new int[players][];
			world1 = new int[players][];
			simulatedVelocity = new int[players][];
			round1Position = new int[players][2];
			round2Position = new int[players][2];
			round1Velocity = new int[players][2];
			round2Velocity = new int[players][2];
			aheadOccupancy = new byte[width * height];
			aheadTouched = new int[players];
			blockedOccupancy = new CellOccupancy(width, height);
			world1Occupancy = new CellOccupancy(width, height);
		}
	}

	private static final class PredictionWorkspace {
		final int[][][] result;
		final int[][][] cells;
		final CellOccupancy[] occupancy;

		PredictionWorkspace(final int steps, final int players,
				final int width, final int height) {
			result = new int[steps][players][];
			cells = new int[steps][players][2];
			occupancy = new CellOccupancy[steps];
			for (int step = 0; step < steps; step++)
				occupancy[step] = new CellOccupancy(width, height);
		}
	}

	private static final class ScorerWorkspace {
		final int[][] originalPosition;
		final int[][] originalVelocity;
		final int[][] simulatedPosition;
		final int[][] simulatedVelocity;
		final int[] finishedPlace;
		final int[][] originalLapState;
		final int[] frameGate;
		final int[] frameRemaining;
		final boolean[] frameLapAware;

		ScorerWorkspace(final int players) {
			originalPosition = new int[players][];
			originalVelocity = new int[players][];
			simulatedPosition = new int[players][2];
			simulatedVelocity = new int[players][2];
			finishedPlace = new int[players];
			originalLapState = new int[players][];
			frameGate = new int[players];
			frameRemaining = new int[players];
			frameLapAware = new boolean[players];
		}
	}

	private static final class RolloutWorkspace {
		final int[] laps;
		final int[] gates;
		final int[] remaining;
		final boolean[] lapAware;
		int turns;
		final int[] px;
		final int[] py;
		final int[] vx;
		final int[] vy;
		final boolean[] alive;
		final boolean[] scorerSet;
		final int[] projectedMoves;
		final boolean[] faithfulOriginallyLiveRival;
		final long[] faithfulChosenRivalCost;
		final long[] faithfulCandidateRivalCost;
		final int[] move = new int[4];
		final int[] finalTier = new int[1];
		final ScorerWorkspace scorer;

		RolloutWorkspace(final int players) {
			laps = new int[players];
			gates = new int[players];
			remaining = new int[players];
			lapAware = new boolean[players];
			px = new int[players];
			py = new int[players];
			vx = new int[players];
			vy = new int[players];
			alive = new boolean[players];
			scorerSet = new boolean[players];
			projectedMoves = new int[players];
			faithfulOriginallyLiveRival = new boolean[players];
			faithfulChosenRivalCost = new long[players];
			faithfulCandidateRivalCost = new long[players];
			scorer = new ScorerWorkspace(players);
		}
	}

	RaceAi(final RaceGame game) {
		this.game = game;
		this.reach = game.reach;
		privateLane = new RaceAiPrivateLane(game);
	}

	private CandidateWorkspace candidateWorkspace() {
		if (simDepth >= candidatesByDepth.length)
			candidatesByDepth = java.util.Arrays.copyOf(candidatesByDepth, simDepth + 4);
		CandidateWorkspace workspace = candidatesByDepth[simDepth];
		if (workspace == null)
			workspace = candidatesByDepth[simDepth] = new CandidateWorkspace();
		workspace.reset();
		return workspace;
	}

	/** The move for the player to move. Every AI kind runs the one promoted
	 * body; an experiment must add an explicit kind gate to keep a control. */
	Direction computeAiMove() {
		reach.ensureReachabilityReady();
		// Round 175: retire per-compute memo entries (the hold-overspeed
		// verdict depends on the board, which is fixed only within one
		// compute). Mobility searches take their own fresh epoch at build,
		// so their entries are unaffected beyond correct retirement.
		fmMemoEpoch++;
		final Player p = game.players[game.subgamestate];
		final int[] vel = p.getVelocity();
		final int[] pos = p.getPosition();
		final int playerNum = p.getNumber();
		return optimalMoveAI1(pos, vel, playerNum);
	}

	/**
	 * Pure min-turns lookup, no opponent reasoning. Used internally to predict
	 * opponent moves; we DON'T want recursion through the smart AI variants.
	 */
	private Direction pureMinTurnsMove(final int x, final int y, final int vx, final int vy,
			final int playerNum) {
		// Round 223: this player's own lap frame, not the mover's.
		final int idx = playerNum - 1;
		final boolean scanLapAware = frameLapAware[idx];
		final int scanGate = frameGate[idx];
		Direction best = null;
		int bestTurns = Integer.MAX_VALUE;
		int fallbackLegalMask = 0;
		int fallbackIllegalMask = 0;
		final int sm = succMask(x, y, vx, vy);
		for (final Direction d : DIRECTIONS) {
			final int bit = 1 << d.ordinal();
			final int newVx = vx + d.dx;
			final int newVy = vy + d.dy;
			if ((sm & bit << 16) == 0)
				continue;
			final int newX = x + newVx;
			final int newY = y + newVy;
			if (game.crossesFinishLegally(x, y, newX, newY)) {
				// Multi-lap: a non-final crossing keeps its precedence only when
				// survivable (legal edge, no body, alive landing beyond the line)
				// AND shedable -- the map prices every crossing at turns=1
				// regardless of landing speed, so hot arrivals must not count.
				if (!scanLapAware && game.onFinalLap(playerNum) || scanGate == 0 && ((sm & bit) != 0
						&& !game.isCrashingPlayer(newX, newY, playerNum)
						&& reach.shedableLanding(newX, newY, newVx, newVy)
						&& reach.turnsToGate(1, newX, newY, newVx, newVy) != Integer.MAX_VALUE
						&& needleHeadway(newX, newY, newVx, newVy, playerNum, 1))) {
					if (AI_DEBUG_PLAYER == playerNum && !inScorerSim)
						System.err.println("AIDBG SCAN-CROSS p=" + playerNum + " chosen=" + d);
					return d;
				}
				// Stray or unshedable crossing: an ordinary legal move (cars
				// spawn BEHIND the line -- excluding these walls them in).
			}
			// Checkpoint touch precedence: the post-touch landing prices a
			// full lap on the CURRENT gate map, so slow approaches would bob
			// one cell before the line forever (the gate-0 stall, at the CPs).
			// A touch with a continuing landing is progress -- take it. In
			// traffic the landing must also hold needle headway: without it
			// the precedence rams the car into an occupied one-cell pocket
			// at unstoppable speed (the scorer then prices the wait instead,
			// and the touch fires the moment the queue clears).
			if (scanLapAware && scanGate != 0 && (sm & bit) != 0
					&& game.touchesGate(scanGate, x, y, newX, newY)
					&& !game.isCrashingPlayer(newX, newY, playerNum)
					&& reach.isAlive(newX, newY, newVx, newVy)
					&& reach.turnsToGate(scanGate == 1 ? 2 : 0, newX, newY, newVx, newVy)
							!= Integer.MAX_VALUE
					&& needleHeadway(newX, newY, newVx, newVy, playerNum, scanGate == 1 ? 2 : 0)) {
				if (AI_DEBUG_PLAYER == playerNum && !inScorerSim)
					System.err.println("AIDBG SCAN-CP p=" + playerNum + " gate=" + scanGate + " chosen=" + d);
				return d;
			}
			if ((sm & bit) == 0) {
				fallbackIllegalMask |= bit;
				continue;
			}
			if (game.isCrashingPlayer(newX, newY, playerNum))
				continue;
			fallbackLegalMask |= bit;
			final int turns = ttfFor(idx, newX, newY, newVx, newVy);
			if (turns < bestTurns) {
				bestTurns = turns;
				best = d;
			}
		}
		if (best != null) {
			if (AI_DEBUG_PLAYER == playerNum && !inScorerSim)
				System.err.println("AIDBG scan1 p=" + playerNum + " pos=(" + x + "," + y
						+ ") vel=(" + vx + "," + vy + ") chosen=" + best + " t=" + bestTurns
						+ " gate=" + lapGate);
			return best;
		}
		if (AI_DEBUG_PLAYER == playerNum && !inScorerSim)
			System.err.println("AIDBG scan1-FB p=" + playerNum + " pos=(" + x + "," + y
					+ ") vel=(" + vx + "," + vy + ") legal=" + fallbackLegalMask
					+ " illegal=" + fallbackIllegalMask + " gate=" + lapGate);
		return scoreMinTurnsFallback(x, y, vx, vy,
				fallbackLegalMask, fallbackIllegalMask, Direction.NONE);
	}

	/** Score-only terminal tier shared by the live, smart, and simulated
	 *  min-turns choosers. Candidate masks capture the original pass so nested
	 *  simulations cannot make the fallback re-read occupancy or legality. */
	private Direction scoreMinTurnsFallback(final int x, final int y,
			final int vx, final int vy, final int legalMask,
			final int illegalMask, final Direction emptyFallback) {
		Direction bestAlive = null;
		double bestAliveScore = Double.MAX_VALUE;
		Direction bestLegal = null;
		double bestLegalScore = Double.MAX_VALUE;
		Direction fallback = emptyFallback;
		double fallbackScore = Double.MAX_VALUE;
		final int candidateMask = legalMask | illegalMask;
		for (final Direction d : DIRECTIONS) {
			final int bit = 1 << d.ordinal();
			if ((candidateMask & bit) == 0)
				continue;
			final int newVx = vx + d.dx;
			final int newVy = vy + d.dy;
			final double sc = reach.scorePos(x + newVx, y + newVy, newVx, newVy);
			if ((legalMask & bit) != 0) {
				// Round 198: lap traffic blanks every finite candidate far
				// more often than laps=1 ever did, and this last resort must
				// not steer into a legal-but-doomed spur while an alive
				// landing exists (rand2 (110,8)v(-3,-1): entered legal,
				// selfAlive=false, all nine successors illegal). laps=1
				// keeps the legacy tiering byte-for-byte.
				if (game.lapGates != null && sc < bestAliveScore
						&& reach.isAlive(x + newVx, y + newVy, newVx, newVy)) {
					bestAliveScore = sc;
					bestAlive = d;
				}
				if (sc < bestLegalScore) {
					bestLegalScore = sc;
					bestLegal = d;
				}
			} else if (sc < fallbackScore) {
				fallbackScore = sc;
				fallback = d;
			}
		}
		if (bestAlive != null)
			return bestAlive;
		return bestLegal != null ? bestLegal : fallback;
	}

	/** Explicit search depth for the soft depth-2 search
	 *  ({@link #searchMinTurnsCountedSoft3}) -- my next TWO moves are searched
	 *  explicitly, each ply priced against its own simulated opponent round
	 *  (world1 at stepIdx 0, world2 at stepIdx 1) before the opponent-blind
	 *  map takes over. */
	private final static int		AI1_DEEP_LOOKAHEAD	= 2;

	/** Shared champion frontier: soft price for landing, at the second explicit search
	 *  ply (stepIdx 1), on a round-2-simulated body -- applied in OPEN RUNNING
	 *  only (v4): with any rival within squared distance 36 of my current cell
	 *  the price is disabled for the move (occupancy2 = null), because a
	 *  two-rounds-out detour ceded while a rival is close enough to take the
	 *  vacated line converts saved time into lost PLACES (h2h forensics:
	 *  price-all lost 4.540/4.460, ahead-only lost harder 4.597/4.403 -- a
	 *  coordination asymmetry, since in all-frontier fields the collective
	 *  spreading is what buys the pace). Probes proved the price LEVEL is a
	 *  dead knob (2.0 == 3.0 bench-identical; 0.0 reverts to the exact frozen
	 *  baseline -- the entire depth-2 gain flows through this pricing), so the
	 *  structure, not the level, carries the design. */
	private final static double	AI1_PLY2_PRICE	= 3.0;
	private final static int		AI1_SEAL_MAXRIVALS	= 3;	// endgame seal fires when <= this many rivals remain
	private final static double	AI1_PACE_FLOOR	= 0.60;	// min poRoom to take an unsealable faster move (sparse field only)
	private final static int		AI1_SPARSE_RIVALS	= 3;
	private final static int		AI1_DJS_ROUNDS	= 3;
	private final static int		AI1_TRUE_CONFIRM_ROUNDS	= 4;	// round 99: horizon for the true-rival confirm; round 100: 4 -- the s74 box seals at round index 3 (s32 sealed at 2); every extra round multiplies full-champion rival computes and widens the false-kill window
	// danger joint search: rollout depth in rounds	// aggressive pace floor applies only when <= this many rivals remain
	private final static int		AI1_DJS_FAST_FRAGILE_ROUNDS	= 4;	// round 93: faithful-rival recheck for fast L2 landings that are already fragile after the normal 3-round screen
	private final static int		AI1_DJS_SPD2	= 49;	// round 55 (AI1): DJS also fires at landing speed^2 >= this -- the ancestral speed-7-10 corner-entry class keeps the trap ladder at 0 until every alternative is dead, so the trap gate alone triggers too late
	private final static int		AI1_DJS_SLOW_ROUNDS	= 5;	// round 59: rollout horizon for slow-class fires (landing spd^2 < AI1_DJS_SPD2) -- the slow queue dooms commit 3-5 rounds out (lemans-s4 start funnel, oracle-measured)
	private final static int		AI1_DJS_SLOW_L1_ROUNDS	= 6;	// round 70 frontier: L1 slow traps get one extra round; interlagos 4-car s3/s4 dies exactly beyond the 5-round verdict
	private final static int		AI1_SCORER_NEAR	= 10;	// round 59: Chebyshev radius for real-scorer rivals in slow-class rollouts
	private final static int		AI1_SCORER_MAXRIVALS	= 3;	// round 59: at most this many nearest real-scorer rivals per rollout (cost bound; the box formers are always adjacent)
	private final static int		AI1_TRAP_SOLO_R	= 16;	// round 61: trap relief radius -- L1/L2 threads are only dangerous if a rival can contest them; no live rival within this Chebyshev range of the landing = the map's own certification suffices (max per-axis closure is |v|+1 <= 13 per round)
	private final static int		AI1_ROBUST_RANGE	= 12;	// round 210: a live rival AHEAD or beside within this Chebyshev radius turns the needle surcharge on (only such a rival can reach my one cell)
	private final static int		AI1_ROBUST_KIN_CAP	= 24;	// round 212: the needle gate reaches as far as my stopping distance s(s+1)/2, capped here -- the rand6 long needle was entered at speed 7 with the parked pack 13 cells ahead, one outside the fixed radius
	private final static int		AI1_ROBUST_SURCHARGE	= 12;	// round 210: turns a needle state (no 1-fault-tolerant path to the gate) costs on top of its plain value in traffic
	private final static int		AI1_KIN_HORIZON_CAP	= 10;	// round 205: kinematic DJS horizon cap (rounds-to-stop, lap mode)
	private final static int		AI1_DEEP_HORIZON	= 8;	// round 65: rollout horizon for pack-gated deep escalations -- the hairpin-s10 doom commits 7 rounds out (oracle: three candidates FINISH @r6 while the chosen dies @r7)
	private final static int		AI1_DEEP_PACK	= 3;	// round 65: escalate only with >= this many rivals within AI1_DEEP_PACK_R of the landing (the doom class lives in packs; solo tunnels excluded)
	private final static int		AI1_DEEP_PACK_R	= 10;	// round 65: Chebyshev pack radius for the deep escalation gate
	private final static int		AI1_SLOW_PACK		= 7;	// round 67: rare dense slow-pack scorer trigger
	private final static int		AI1_SLOW_PACK_R	= 10;
	private final static int		AI1_SLOW_PACK_SPD2	= 16;
	private final static int		AI1_SLOW_PACK_MIN	= 3;	// round 71 (promoted): small-field generalization of the dense-pack gate -- the monaco-4car s9 funnel doom (m27, spd^2=13, 3 rivals all within Cheb 10) is smom-blind and non-fragile but scorer-rival-visible @r2
	private final static int		AI1_SLOW_PACK_SPD2_SMALL	= 12;	// round 71 (promoted): speed floor for the small-field gate (start-grid moves stay below it)
	private final static int		AI1_FUNNEL_WIDTH	= 4;	// round 83: static funnel escalation threshold -- the zandvoort corner and coil spiral pinch to ring width 4 while every measured open corridor is >= 7 (silverstone s1 distribution)
	private final static int		AI1_FUNNEL_MIN_SPD	= 3;	// round 83: Chebyshev landing-speed floor for the funnel signal (crawls cannot overcommit)
	private final static int		AI1_FUNNEL_RUN	= 6;	// round 83: minimum CONSECUTIVE narrow rings (short gates are threadable)
	private final static int		AI1_FUNNEL_DEEP_FIELD	= 4;	// round 83: max live rivals for trusting the deep fast-funnel verdict	// round 83: minimum CONSECUTIVE narrow rings -- a short gate (lemans chicane, 1-3 rings) is passable at speed; sustained corridors kill	// round 83: Chebyshev landing-speed floor for the funnel signal (crawls cannot overcommit)
	private final static int		AI1_DEEP_CERT_RIVALS	= 6;	// round 73: scorer-rival cap for the ahead-pack corridor certification -- the interlagos-s10 m103 killers are ranks 4-6 by landing distance, beyond the round-59 nearest-3 set
	private final static long	ROLLOUT_FAILURE_COST	= 1_000_000L;	// field comparison: one simulated rival failure dominates all finite TTF sums
	private final static int		AI1_FINISH_CERT_TTF	= 15;	// round 75 (promoted): legacy mixed-field cap for the dual-model finish sprint
	private final static int		AI1_FINISH_TRUE_CONFIRM_ROUNDS	= 5;	// round 176: faithful-rival veto for one-successor sprint lines
	private final static int		AI1_FINISH_DENIAL_ROUNDS	= 8;	// bounded faithful horizon for a contested finish pocket
	private final static int		AI1_FINISH_DENIAL_RIVALS	= 2;	// nearest full-fidelity rivals suffice for the measured denial class
	private final static int		AI1_FINISH_DENIAL_MAX_TTF	= 5;	// only the final one-turn map-gain commitment
	private final static int		AI1_FINISH_DENIAL_MIN_SPEED2	= 64;	// high-energy approach that can overrun a closing pocket
	private final static int		AI1_FINISH_DENIAL_MIN_BRAKE2	= 16;	// require a materially lower-energy escape
	private final static int		AI1_FINISH_DENIAL_NEAR_RIVALS	= 4;	// compact finish pack, not open-line racing
	private final static int		AI1_FINISH_DENIAL_ALIGNED_RIVALS	= 2;	// similarly moving bodies ahead can close the lane
	private final static int		AI1_FINISH_HOMOGENEOUS_TTF	= 20;	// round 94: extend only in mover-kind homogeneous fields; the new band forbids coasting
	private final static int		AI1_FINISH_EXTENDED_TTF	= 30;	// round 96: one-turn, non-coasting homogeneous extension of the full finish proof
	private final static int		AI1_PRIVATE_BASE_HORIZON	= 3;	// round 77: cheap rectangular private-lane certificate
	private final static int		AI1_PRIVATE_EXACT_HORIZON	= 4;	// round 77: geometry-clipped fallback horizon
	private final static int		AI1_PRIVATE_BASE_ESCAPES	= 3;	// broad rectangles need the original wide frontier
	private final static int		AI1_PRIVATE_EXACT_ESCAPES	= 2;	// clipped slow or homogeneous moderate-risk lines may use two exits
	private final static double	AI1_PRIVATE_EXACT_UNC_MAX	= 15.0;	// round 77: homogeneous fast lines above this retain three exits
	private final static int		AI1_PRIVATE_EXACT_NODES	= 512;	// per-turn exact-search budget; exhaustion fails closed
	private final static double	AI1_PRIVATE_FRONTIER_REST_SLACK	= 0.25;	// round 169: bounded exact-private/scorer-field frontier
	private final static int		AI1_PRIVATE_FRONTIER_MIN_TTF	= 46;	// incumbent phase; the candidate is exactly one turn faster
	private final static int		AI1_PRIVATE_FRONTIER_MAX_TTF	= 90;	// keep the eight-round field proof in medium range
	private final static int		AI1_PRIVATE_FIELD_MIN_RIVALS	= 5;	// round 78: compare field effects only in compressed large fields
	private final static int		AI1_PRIVATE_CONVOY_RADIUS_V	= 2;	// round 79: look two mover-velocity spans along a nearly collinear train
	private final static int		AI1_PRIVATE_CONVOY_HALF_WIDTH	= 4;	// maximum perpendicular distance from the mover's velocity ray
	private final static int		AI1_PRIVATE_CONVOY_MAX_AHEAD	= 1;	// the externality case is a compact rear train, not a two-sided pack
	private final static double	AI1_STAGED_REST_SLACK	= 1.00;	// round 81: one scorer point still needs strict rollout and field proof
	private final static double	AI1_STAGED_UNC_MAX	= 2.5;	// keep the staged rollout below the high-uncertainty class
	private final static int		AI1_STAGED_HORIZON	= 8;	// strict gain + non-worsening field
	private final static int		AI1_STAGED_MIN_TURNS	= 35;	// leave the existing finish sprint in charge near the line
	private final static int		AI1_STAGED_MAX_SPEED2_GAIN	= 9;	// at most one |v|=4->5 axis of extra energy vs the scorer
	private final static int		AI1_FIELD_ACCEL_MIN_SPEED2_GAIN	= 16;	// round 106: decisive one-turn energy gain
	private final static int		AI1_FIELD_UNCERTAIN_MIN_TTF	= 46;	// round 177: exact medium-range band
	private final static int		AI1_FIELD_UNCERTAIN_MAX_TTF	= 60;
	private final static int		AI1_FIELD_UNCERTAIN_LAST_MOVERS	= 3;	// avoid early partial-round trajectory drift
	private final static double	AI1_FIELD_UNCERTAIN_MAX	= 1.0;	// mild positive uncertainty only
	private final static int		AI1_FIELD_ACCEL_MIN_AHEAD	= 2;	// require a real forward pack
	private final static int		AI1_FIELD_ACCEL_MAX_AHEAD	= 5;	// bounded proof excludes full-tail six-ahead cases
	private final static int		AI1_FIELD_ACCEL_MAX_TTF	= 90;	// keep the 8-round proof in the medium-range race phase
	private final static int		AI1_FIELD_ACCEL_FRONTIER_MIN_SPEED2_GAIN	= 9;	// round 115 frontier: moderate acceleration floor
	private final static int		AI1_FIELD_ACCEL_FRONTIER_LOW_GAIN_MAX_TTF	= 45;	// round 115: short-range boundary for speed2 gains 9..15
	private final static int		AI1_FIELD_ACCEL_SIX_AHEAD_ROUNDS	= 8;	// round 117: synchronized six-ahead formations retain the established proof depth
	private final static int		AI1_FIELD_ACCEL_SIX_AHEAD_MODERATE_MIN_SPEED2	= 49;	// round 175: cross the high-speed threshold with a bounded gain
	private final static int		AI1_MOBILITY_DEPTH	= 4;	// frontier; projection/cache shared per turn
	/** Forensic gates: -Dai.debug.player=N per-turn pick dump for that player;
	 *  -Dai.debug.djs DJS-death events for all players; -Dai.debug.fieldVector
	 *  only the bounded field proof. All are off by default. */
	private final static int		AI_DEBUG_PLAYER	= Integer.getInteger("ai.debug.player", -1);
	private final static boolean	AI_DEBUG_DJS	= Boolean.getBoolean("ai.debug.djs");
	private final static boolean	AI_DEBUG_FINISH_DENIAL	=
			Boolean.getBoolean("ai.debug.finishDenial");
	private final static int		AI_DEBUG_FINISH_DENIAL_RIVAL_CAP	=
			Integer.getInteger("ai.debug.finishDenialRivalCap", AI1_FINISH_DENIAL_RIVALS);
	private final static boolean	AI_DEBUG_COMP	= Boolean.getBoolean("ai.debug.comp");
	private final static boolean	AI_DEBUG_FIELD_VECTOR	=
			Boolean.getBoolean("ai.debug.fieldVector");
	/** True while this game instance computes a rollout move with the real
	 *  scorer. Instance scope prevents concurrent games from suppressing each
	 *  other's recursive machinery; the flag is restored in a finally. */
	private boolean				inScorerSim;
	/** Instance-scoped recursion guard for the rare finish-denial proof. */
	private boolean				inFinishDenialConfirm;
	/** Round 99 latch, round 103 DEPTH: a binary latch stripped the confirm
	 *  from every in-confirm rival -- and since round 99 the confirm IS part
	 *  of champion behavior, so latched rivals diverged from real ones by
	 *  exactly one arm (zigzag s76: oracle-i0 claims the kill cell its
	 *  latched twin vacates -- the recursion boundary regenerating one level
	 *  up). One nested level is allowed; depth 2 blocks (cost recursion). */
	private int					trueConfirmDepth;
	private final static int		AI1_TRUE_CONFIRM_MAXDEPTH	= 2;
	private final static long	ROLLOUT_NOT_LIVE_COST	= -1L;
	private final static int		AI1_TRUE_CONFIRM_DEEP_ROUNDS	= 6;	// round 104: horizon for the deep-tier leg -- the zandvoort-s88 box seals at true round index 5
	private final static int		AI1_FASTSLOW_TTF	= 10;	// round 128: sim-final ttf ceiling for the fast finish-funnel leg -- the mixed-lemans class commitments sim to 6-7; every non-class fire measured 14+ (monaco/zandvoort mid-race crowds)
	private final static int		AI1_FASTV_MAX	= 11;	// round 133: max-axis speed from which the vmax overspeed deep check arms -- the serpentine2 dooms commit exactly at the 10->11 acceleration (VMAX-1); braking from 11 overruns what a hairpin absorbs once traffic fills the escape rows
	private final static int		AI1_FASTV_PACK_R	= 6;	// round 133: the vmax doom needs a train -- a rival within this Chebyshev radius of the mover; the three commitments carry theirs at 1, 2 and 5, and the gate excludes the lone-runner false kill (golden lemans-s1-4p)
	private final static int		AI1_RIDGE_MIN_SPD	= 8;	// round 178: max-axis floor for the thin-ridge check (lobe2-s111 holds 10 onto a one-lane ridge); round 180: floor 8 -- rand5-s40 accelerates into 8 on the same morphology, and the widened admission costs canon +10 audits per four races
	private final static int		AI1_RIDGE_MAX_SUCC	= 2;	// round 178: alive-successor ceiling at the chosen landing (referee-mask mirror); canon census 2/9/2/0 admissions per race, lobe2 116
	private final static int		AI1_RIDGE_PLATEAU_SPD	= 10;	// round 185: exact max-axis hold speed for the selective width-three plateau extension (rand13-s4); a broad <=3 admission is prohibitively noisy
	private final static int		AI1_RIDGE_PLATEAU_SUCC	= 3;	// round 185: chosen landing has width 3 and its alive child fan is exactly widths 1/2/3 before paying for the scorer audit
	private final static int		AI1_RIDGE_THREAD	= 4;	// round 178: s8-audit thread level that escalates to the true-6 verdict -- canon 0 escalations, lobe2 13 with DEAD only on the real doom line
	private final static int		AI1_RIDGE_TRUE_ROUNDS	= 6;	// round 178: the ridge doom lands 6 rounds out -- true-4 reads the m363 commitment alive (V=7), true-6 kills it
	private final static int		AI1_RIDGE_VMAX_TRUE_ROUNDS	= 7;	// codex round 187: exact axial speed-11 width-one holds can fail one round beyond the shared ridge horizon
	// multi-lap shedability now lives in Reachability.shedableLanding (minShed2 <= 36)
	private final static int		AI1_HOLDV_MAX	= 10;	// round 175: max-axis speed from which the hold-overspeed cheap-world check arms (hold or accel, with a train rival) -- the harvest-30 cross-track commitments hold 10 down a straight and die 4-7 oracle rounds out
	private final static int		AI1_EG_ETA		= 12;		// endgame solver: both cars within this many turns of the finish
	private final static int		AI1_EG_DEPTH	= 10;		// endgame solver: rounds of exact search (2x plies)
	private final static int		AI1_EG_NODES	= 50_000;	// endgame solver: node budget; blown -> claim nothing (200k added ~2x 1v1 bench time on unprovable positions; real proofs are shallow forcing lines found far below 50k)
	// Gate thresholds (round 39 tuning surface): each was hand-picked in a
	// past forensic and never jointly optimized. Values = champion's.
	private final static double	AI1_PO_ROOM_HI	= 0.88;	// paceOverride: fully-roomy clause
	private final static double	AI1_PO_ROOM_MID	= 0.78;	// paceOverride: mid-roominess clause (slow landings)
	private final static int		AI1_PO_SPD_MAX	= 4;		// paceOverride: max |v| component for the mid clause
	private final static double	AI1_BRAKE_SPEED	= 4.0;	// arming gate + slope base of the speed brakes
	private final static double	AI1_FOLLOW_W	= 1.0;	// round 206: surcharge per cell of stopping-distance excess behind a leader
	private final static double	AI1_FOLLOW_LAT	= 1.5;	// round 206: lateral half-width of the following cone (2.5 cured monaco 10 -> 0 but braked for adjacent-lane leaders on open track: four clean guards dirtied; 1.5 = same lane only)
	private final static double	AI1_FOLLOW_RANGE	= 40.0;	// round 206: look-ahead along my heading
	private final static int		AI1_PACK_R2		= 36;	// cornerEntry pack radius^2
	private final static int		AI1_VACATE_SPEED2	= 9;	// |v| >= 3: predicted cell nulled (transiting)
	private final static int		STALLED_RIVAL_SPEED2	= 6;	// integer |v| <= 2.5
	private final static double	AI1_TRAP_L1		= 2.0;	// trap ladder: 1 safe successor
	private final static double	AI1_TRAP_L2		= 0.5;	// trap ladder: 2 safe successors
	private final static int		AI1_ALONE_R	= 40;	// round 214: no live rival within this Chebyshev radius means the track is mine and the exact potential applies; 20 was too tight -- cars left the optimal line already inside a pack (weave3 lost 8 races of 10)
	private final static int		AI1_NEEDLE_RIVAL_R	= 8;	// round 197: traffic radius for the needle-headway law
	private final static double	AI1_NEEDLE_TRAP	= 30.0;	// round 197: surcharge for an unstoppable no-headway landing
	private final static double	AI1_LANE_STYLE	= 0.12;	// round 201: per-player tie-break style spread in lap traffic (multi-seed: 0.12 -> 89 crashes, 0.20 -> 105 -- past the sweet spot the style sacrifice costs more than spreading buys)

	/**
	 * The promoted policy, for every AI kind. Round 129 established one scorer
	 * body by delegation after promoting the measured Round 115/117/124
	 * field-acceleration frontier and Round 126's homogeneous false-target
	 * veto. Later promoted gates live in this body too: Round 169's
	 * exact-private slack, Round 174's squeeze check, Round 175's bounded
	 * high-speed six-ahead acceleration, Rounds 178-180's thin-ridge check,
	 * Round 216's exact-potential pace number, and -- promoted on the user's
	 * word on 2026-09-04 after a fleet grid -- the immediate-finish precedence,
	 * the finish-denial override and the exact axial-vmax ridge extension. No
	 * kind-gated arm remains; a candidate experiment must add an explicit kind
	 * gate until its own independently measured promotion.
	 */
	private Direction optimalMoveAI1(final int[] pos, final int[] vel, final int playerNum) {
		// Endgame seal (frontier, per "force the last rival to crash = win"): with
		// few rivals left, if a SAFE move of mine leaves the decisive rival with no
		// legal move (a forced crash), take it. Only a rival that moves after me this
		// round (ri > subgamestate) can be forced; gated on my own safety so I never
		// trap myself to trap them.
		prepareDecisionFrame(pos, vel, playerNum);
		// Round 214: with nobody near, the race is a shortest-path problem and
		// the exact potential solves it. Every caution term below is priced
		// against a rival that is not there, and the measured cost of that was
		// 3.45% of the fleet's solo moves. The descent cannot crash: a state
		// with a finite value always has a successor one move closer.
		if (game.lapGates != null && !rivalWithinCheb(pos[0], pos[1], playerNum, AI1_ALONE_R)) {
			final Direction alone = optimalAloneMove(pos, vel, playerNum);
			if (alone != null)
				return alone;
		}
		final int sealRivals = liveRivalsRemaining(playerNum);
		// Candidate: crossing now permanently secures this place, so it dominates
		// every seal that forgoes the finish to crash a later mover. Lap mode:
		// only once the gates are complete is a crossing actually the finish --
		// with a checkpoint still owed the referee treats it as an ordinary move,
		// so the legality-waived immediate crossing would drive into the wall.
		if (sealRivals >= 1 && sealRivals <= AI1_SEAL_MAXRIVALS && game.onFinalLap(playerNum)
				&& lapGate == 0) {
			final Direction finish = immediateFinishMove(pos, vel);
			if (finish != null)
				return finish;
		}
		if (sealRivals >= 1 && sealRivals <= AI1_SEAL_MAXRIVALS) {
			final int ri = decisiveRival(playerNum);
			if (ri > game.subgamestate && rivalEscapes(ri, -1, -1, playerNum) >= 1) {
				final Direction sd = findForcedCrashMove(pos, vel, ri, playerNum);
				if (sd != null)
					return sd;
			}
		}
		// Endgame solver (round 43, lever 5, shared champion): 1v1 exact paranoid
		// minimax near the finish. Acts ONLY on proven wins (I finish first or
		// the rival is forced to crash under its best defense) -- the deep
		// generalization of the 1-ply seal above; unproven values fall through
		// to the normal scorer (insurance-premium law: no paranoid defense).
		if (sealRivals == 1 && !inScorerSim) {
			final Direction eg = endgameSolve(pos, vel, playerNum);
			if (eg != null) {
				if (AI_DEBUG_PLAYER == playerNum || AI_DEBUG_DJS)
					System.err.println("AIDBG EG p=" + playerNum + " pos=(" + pos[0] + "," + pos[1]
							+ ") vel=(" + vel[0] + "," + vel[1] + ") WIN via " + eg);
				return eg;
			}
		}
		// paceOverride (round 34, PROMOTED): AI2.9 was NOT pace-optimal -- pure
		// greedy min-turnsToFinish measurably beat it crash-free (sprint 14.1 vs
		// 14.9, hairpin, curve, bigoval) because the robustness/momentum tie-breaks
		// pay for traffic uncertainty even on lines that are provably safe. So take
		// a strictly-faster move than the cautious scorer's pick ONLY when its 2-ply
		// escape route is FULLY roomy (robust to opponent-prediction error -- lower
		// thresholds crashed 1 h2h game). Pinches keep full caution.
		int poBestT = Integer.MAX_VALUE, poScorerT = Integer.MAX_VALUE;
		Direction poDir = null;
		final int[][][] predictedSteps = predictedOpponentSteps(playerNum, 1);
		// Vacated-cell awareness: a fast-moving opponent (|v| >= 3) will have
		// moved through/off its predicted cell by the time I could occupy it --
		// blocking those cells causes phantom detours. Null out transiting
		// opponents' predictions; only slow/parked rivals stay blocked.
		for (final Player p : game.players) {
			if (p.getNumber() == playerNum || p.isFinished())
				continue;
			final int[] pv = p.getVelocity();
			if (speedSquared(pv[0], pv[1]) >= AI1_VACATE_SPEED2)
				predictedSteps[0][p.getNumber() - 1] = null;
		}
		for (int step = 0; step < predictedSteps.length; step++)
			predictionWorkspace.occupancy[step].rebuild(predictedSteps[step]);
		final CellOccupancy predictedOccupancy = predictionWorkspace.occupancy[0];
		// Exact nested-scorer fast path. With the mover absent, record the
		// reference first-round landings once. If a candidate landing is not one
		// of those cells, adding it as a blocker cannot change the first mover;
		// inductively no later mover changes either, and round two (where the
		// blocker is removed) is therefore identical. Any hit falls back to the
		// original candidate-conditioned simulation.
		final TwoRoundWorkspace twoRoundReference = trueConfirmDepth > 0 || inScorerSim
				? prepareTwoRoundReference(playerNum) : null;
		// In-traffic ply-2 foresight RESTORED (fore2): the v4/v5 pack gate that
		// disabled the ply-2 price whenever any rival sat within squared
		// distance 36 is GONE -- the round-2 world (worlds[1]) is now priced on
		// every move. Ahead-rivals only: only bodies of rivals currently AHEAD
		// of me on track are priced (see occupiedByAheadRival +
		// searchMinTurnsCountedSoft3 below); a chaser's body is not priced,
		// since ceding a line two rounds out to a car behind me trades race
		// position for nothing. The queue brakes (queueBox, cornerEntry) now
		// guard the corridors the old gate was protecting.

		final CandidateWorkspace candidateWorkspace = candidateWorkspace();
		final double[] trapByDir = candidateWorkspace.trapByDirection;
		// round 49 arm C: non-spread score and raw map ttf per candidate, for the
		// certified pace tie-break after the loop.
		final double[] scoreNSByDir = candidateWorkspace.scoreWithoutSpread;
		final int[] poTByDir = candidateWorkspace.turnsByDirection;
		// round 62: full score and unc per candidate, for the certified UNC
		// override after the loop.
		final double[] scoreByDir = candidateWorkspace.scoreByDirection;
		final double[] uncByDir = candidateWorkspace.uncertaintyByDirection;
		MobilitySearch paceMobility = null;
		Direction best = null;
		double bestScore = Double.MAX_VALUE;
		int fallbackLegalMask = 0;
		int fallbackIllegalMask = 0;
		final int sm = succMask(pos[0], pos[1], vel[0], vel[1]);

		for (final Direction d : DIRECTIONS) {
			final int bit = 1 << d.ordinal();
			final int newVx = vel[0] + d.dx;
			final int newVy = vel[1] + d.dy;
			if ((sm & bit << 16) == 0)
				continue;
			final int newX = pos[0] + newVx;
			final int newY = pos[1] + newVy;
			if (game.crossesFinishLegally(pos[0], pos[1], newX, newY)) {
				// Multi-lap: survivable-and-shedable crossing precedence (see pure scan).
				if (!lapAware && game.onFinalLap(playerNum) || lapGate == 0 && ((sm & bit) != 0
						&& !game.isCrashingPlayer(newX, newY, playerNum)
						&& reach.shedableLanding(newX, newY, newVx, newVy)
						&& reach.turnsToGate(1, newX, newY, newVx, newVy) != Integer.MAX_VALUE
						&& needleHeadway(newX, newY, newVx, newVy, playerNum, 1)
						// Round 211: in traffic the landing must keep an out (see the
						// checkpoint precedence below).
						&& (!robustMode || reach.isRobust(1, newX, newY, newVx, newVy)))) {
					if (AI_DEBUG_PLAYER == playerNum && !inScorerSim)
						System.err.println("AIDBG SCAN-CROSS p=" + playerNum + " chosen=" + d);
					return d;
				}
				// Stray or unshedable crossing: an ordinary legal move (cars
				// spawn BEHIND the line -- excluding these walls them in).
			}
			// Checkpoint touch precedence: the post-touch landing prices a
			// full lap on the CURRENT gate map, so slow approaches would bob
			// one cell before the line forever (the gate-0 stall, at the CPs).
			// A touch with a continuing landing is progress -- take it (in
			// traffic only with needle headway; see pure scan).
			if (lapAware && lapGate != 0 && (sm & bit) != 0
					&& game.touchesGate(lapGate, pos[0], pos[1], newX, newY)
					&& !game.isCrashingPlayer(newX, newY, playerNum)
					&& reach.isAlive(newX, newY, newVx, newVy)
					&& reach.turnsToGate(lapGate == 1 ? 2 : 0, newX, newY, newVx, newVy)
							!= Integer.MAX_VALUE
					&& needleHeadway(newX, newY, newVx, newVy, playerNum, lapGate == 1 ? 2 : 0)
					// Round 211: needle headway is a snapshot -- both continuing
					// cells free NOW, one of them a rival's next landing (hybrid12
					// west side: the touch at (17,67) v(-5,8) scored 105 against 41
					// for the safe move and the precedence took it). In traffic the
					// landing must be in the robust set of the next gate; else the
					// scorer prices the touch and takes it a move later.
					&& (!robustMode
							|| reach.isRobust(lapGate == 1 ? 2 : 0, newX, newY, newVx, newVy))) {
				if (AI_DEBUG_PLAYER == playerNum && !inScorerSim)
					System.err.println("AIDBG SCAN-CP p=" + playerNum + " gate=" + lapGate + " chosen=" + d);
				return d;
			}
			if ((sm & bit) == 0) {
				fallbackIllegalMask |= bit;
				continue;
			}
			if (game.isCrashingPlayer(newX, newY, playerNum))
				continue;
			fallbackLegalMask |= bit;
			final int ownTurns = ttf(newX, newY, newVx, newVy);
			if (ownTurns == Integer.MAX_VALUE)
				continue;

			// TWO-ROUND SOFT WORLD-STEP (the experiment): simulate TWO whole
			// rounds in actual turn order, conditioned on THIS candidate
			// landing. worlds[0] answers the round-r+1 questions (safe
			// successors, ply-1 pricing) exactly as before; worlds[1] gives the
			// bodies' cells when I make my round-r+2 move, pricing the second
			// explicit search ply -- ALWAYS on now (fore2, no pack gate), but
			// ahead-rivals only: searchMinTurnsCountedSoft3 prices the ply-2
			// landing only when the round-2 body belongs to a rival currently
			// AHEAD of me on track (myDist = distAt of my CURRENT cell); a
			// chaser's body is left unpriced (ceding a line two rounds out to
			// a car behind me trades race position for nothing).
			final TwoRoundWorkspace worlds = simulateTwoRounds(playerNum, newX, newY,
					twoRoundReference);
			final byte[] aheadOccupancy = buildAheadOccupancy(worlds.current,
					reach.distAt(pos[0], pos[1]));
			final double[] deepCounted = searchMinTurnsCountedSoft3(newX, newY, newVx, newVy, AI1_DEEP_LOOKAHEAD, 0,
					predictionWorkspace.occupancy, playerNum, worlds.world1Occupancy, aheadOccupancy);
			final double deep = deepCounted[0];
			// Soft trap: if every depth-2 continuation is blocked but the state
			// itself can still reach the finish, keep the move alive with a
			// large finite surcharge instead of hard-skipping (which would drop
			// the AI to the foresight-free bestLegal/fallback pick).
			final double costToFinish = deep == Double.MAX_VALUE ? ownTurns + 20.0 : deep;

			// Optimism-floored safe-successor count: the sim removing phantom
			// stale bodies ADDS safe successors (pace), while its model-dependent
			// pessimism (a mispredicted fast leader) can only LOWER the timed
			// count -- so max() with the frozen count keeps the optimism and
			// discards the pessimism, never more cautious than the crash-free
			// frozen standard.
			final int d2SafeCount = Math.max(countFutureSafeSuccessors(newX, newY, newVx, newVy,
					playerNum, predictedOccupancy),
					countFutureSafeSuccessorsTimed(newX, newY, newVx, newVy, worlds.world1Occupancy));
			double trapPenalty = d2SafeCount == 0 ? 50.0
					: d2SafeCount == 1 ? AI1_TRAP_L1
							: d2SafeCount == 2 ? AI1_TRAP_L2
									: 0.0;
			// round 61 (AI1): rival-conditional trap relief. The ladder prices a
			// 1-2-wide certified thread as if a rival could claim the escape,
			// but with NO live rival within AI1_TRAP_SOLO_R of the landing the
			// thread is provably uncontestable for its consumption window and
			// the map's reach-certification suffices (monaco (116,46): every
			// car conceded 1 ttf to trap=2.0 on a SOLO thread the deep search
			// itself preferred). 0-safe stays 50 -- entering a dead fan is bad
			// even alone.
			if (trapPenalty > 0.0 && d2SafeCount > 0 && !rivalWithinCheb(newX, newY, playerNum, AI1_TRAP_SOLO_R))
				trapPenalty = 0.0;
			// Needle headway surcharge (round 197): an UNSTOPPABLE landing
			// without two body-free alive continuations under CURRENT
			// occupancy is one leader-stall from death -- the d2SafeCount
			// world-step credits rivals with vacating, which a stall wave
			// falsifies. Queues form at gates AND at narrow turns (rand2's
			// westward pocket), so the law is traffic-gated, not gate-gated.
			// Price it above every free approach so a stoppable entry wins.
			if (game.lapGates != null && lapAware && trapPenalty < 50.0
					&& !needleHeadway(newX, newY, newVx, newVy, playerNum, lapGate))
				trapPenalty = Math.max(trapPenalty, AI1_NEEDLE_TRAP);
			trapByDir[d.ordinal()] = trapPenalty;
			final double speed = Math.hypot(newVx, newVy);
			// Per-state certified budget with a legacy floor: the map-certified
			// minimal target T (>= 2 independent blind braking descents reach
			// |v| <= T from this candidate state) governs above the floor; the
			// floor preserves the zero-penalty regime at low speed.
			final int widthBudget = Math.max(5, reach.certBudget(newX, newY, newVx, newVy)) + d2SafeCount;
			final double overSpeed = Math.max(0.0, speed - widthBudget);
			double speedCap = overSpeed * overSpeed * 0.4;
			double uncertified = 0.0;
			if (speed > AI1_BRAKE_SPEED) {
				// Pace waiver: >= 2 alive braking descents prove the over-budget speed
				// is sheddable on the empty track -- waive the penalty entirely.
				if (overSpeed > 0 && countBrakeProofs(newX, newY, newVx, newVy, widthBudget, predictedOccupancy, null, false) >= 2)
					speedCap = 0.0;
				// Trap surcharge, graded by certified escape count: zero roomy
				// escapes is a genuine trap; a single knife-edge escape is
				// survivable and only worth a mild detour.
				if (hasConvergingOpponentAhead(newX, newY, playerNum, speed)) {
					final int proofs = countBrakeProofs(newX, newY, newVx, newVy, widthBudget, predictedOccupancy, null, true);
					if (proofs < 2)
						uncertified = (speed - AI1_BRAKE_SPEED) * (proofs == 0 ? 2.5 : 1.0);
				}
			}
			// Car-following law (round 206, Gipps): in lap traffic a landing's
			// stopping distance must fit inside the gap to the leader ahead on my
			// heading plus the leader's own stopping distance. Continuous (no
			// trap cliff), directional (forward cone on my route, not radial),
			// speed-relative (a fast leader's stopping distance lets me follow
			// fast; a parked one does not) -- exactly the headway the 1-cell
			// trains violated in the pocket dooms, and exactly what the radial
			// stalled-rival probe lacked when it braked for flowing traffic.
			if (game.lapGates != null) {
				final double excess = followingExcess(newX, newY, newVx, newVy, playerNum);
				if (excess > 0.0)
					uncertified += AI1_FOLLOW_W * excess;
			}
			// Pack-gated knife-edge corner-entry brake: price roomy-successor
			// scarcity when a pack is packed at a corner entry (>= 2 rivals
			// within squared distance 36 and <= 1 roomy escape) -- fires where
			// the converging-opponent surcharge reads false. The pack gate
			// spares the lone fast knife-edge that is the racing line on tight
			// circuits, so only genuine corner-entry traffic jams brake.
			double cornerEntry = 0.0;
			if (speed > AI1_BRAKE_SPEED) {
				final int roomySucc = countRoomySuccessors(newX, newY, newVx, newVy);
				if (roomySucc <= 1 && countNearbyOpponents(newX, newY, playerNum, AI1_PACK_R2) >= 2)
					cornerEntry = (speed - AI1_BRAKE_SPEED) * (roomySucc == 0 ? 3.0 : 1.5);
			}
			// v5.1 queue-compression corner guard (zandvoort forensic, AI1
			// only): the corner-entry brake above is opponent-BLIND in its
			// escape count, the brake proofs ignore transiting (|v| >= 3)
			// rivals, and the round-sims behind d2SafeCount and the ply-2
			// price assume a hairpin queue keeps flowing -- so a fast coast
			// whose timed margin is already thin (d2SafeCount <= 2) while
			// >= 2 STALLED rivals sit within squared distance 36 at-or-ahead
			// of the landing (compression, not a chase) is one round from
			// being boxed: on zandvoort both alive continuations of
			// (43,66)v(-4,3) were bodily occupied by the compressed queue
			// when the victim arrived, after the coast had beaten the
			// covered brake by 0.278. Price the coast like the survivable
			// knife-edge corner entry ((speed-4) * 1.5) so the brake wins.
			double queueBox = 0.0;
			if (speed > AI1_BRAKE_SPEED && cornerEntry == 0.0) {
				if (d2SafeCount <= 2 && countStalledRivalsAhead(newX, newY, playerNum) >= 2)
					queueBox = (speed - AI1_BRAKE_SPEED) * 1.5;
				else {
					// v3 long-range trigger: the near trigger needs d2SafeCount
					// to collapse, but at speed 5+ the zandvoort pinch killed
					// from 10-20 cells out -- by the time the local box shows,
					// stopping is impossible (the victims were in forced-move
					// territory two moves before death; 3rd kill in 3 rounds).
					// Fire when >= 2 STALLED rivals sit ahead INSIDE my
					// stopping distance ~ (s^2 - 2.5^2) / 2 cells (shedding
					// ~1/round from s down to the stalled threshold 2.5).
					final double stopCells = (speed * speed - 6.25) / 2.0;
					if (stopCells > 0 && countStalledRivalsWithin(newX, newY, stopCells, playerNum) >= 2)
						queueBox = (speed - AI1_BRAKE_SPEED) * 1.5;
				}
			}
			// AI2.9 intentionally has no soft conflict term; the hard live-body check remains.
			final double spread = opponentSpreadPenalty(newX, newY, playerNum);
			// Racing-line momentum tie-break: among moves of otherwise-equal cost,
			// prefer the one carrying more usable speed.
			final double momentum = AI2_MOMENTUM_TIEBREAK * speed;
			// Plateau-width robustness tie-break: prefer candidates whose best
			// follow-up is achievable many ways over knife-edge lines.
			final double robustness = AI2_PLATEAU_TIEBREAK * Math.min((int) deepCounted[1], 5);
			// Lane spreading (round 201): every magnet death in the multi-seed
			// census begins as displacement off a SINGLE shared geodesic --
			// eight cars stacked on one line. In lap traffic each driver weighs
			// the two tie-breaks slightly differently (deterministic by player
			// index; player 0 keeps the exact champion weights, laps=1
			// untouched), so the field fans across parallel near-optimal lines
			// instead of queueing nose-to-tail through the poison states.
			// The unstyled path keeps the LEGACY floating-point shape
			// (- momentum - robustness, two subtractions): folding them into
			// one subtraction is a one-ULP change that flips near-exact ties
			// (monza s30 trajectory pin caught it).
			final double score;
			if (game.lapGates != null && playerNum > 0) {
				final double f = 1.0 + AI1_LANE_STYLE * ((playerNum % 3) - 1);
				score = costToFinish + trapPenalty + speedCap + uncertified + cornerEntry
						+ queueBox + spread - (momentum * f + robustness * (2.0 - f));
			} else {
				score = costToFinish + trapPenalty + speedCap + uncertified + cornerEntry
						+ queueBox + spread - momentum - robustness;
			}
			final int poT = ownTurns;
			if (AI_DEBUG_COMP)
				System.err.println("R49C p=" + playerNum + " pos=(" + pos[0] + "," + pos[1] + ") vel=("
						+ vel[0] + "," + vel[1] + ") d=" + d + " land=(" + newX + "," + newY + ") ttf=" + poT
						+ " score=" + score + " cost=" + costToFinish + " trap=" + trapPenalty
						+ " cap=" + speedCap + " unc=" + uncertified + " ce=" + cornerEntry
						+ " qb=" + queueBox + " spread=" + spread + " mom=" + momentum
						+ " rob=" + robustness);
			scoreNSByDir[d.ordinal()] = score - spread;
			poTByDir[d.ordinal()] = poT;
			scoreByDir[d.ordinal()] = score;
			uncByDir[d.ordinal()] = uncertified;
			if (poT < poBestT) {
				if (paceMobility == null)
					paceMobility = mobilitySearch(playerNum, true, AI1_MOBILITY_DEPTH);
				final double poRoom = futureMobility(newX, newY, newVx, newVy, paceMobility);
				final int poSpd = Math.max(Math.abs(newVx), Math.abs(newVy));
				if (poRoom >= AI1_PO_ROOM_HI || (poRoom >= AI1_PO_ROOM_MID && poSpd <= AI1_PO_SPD_MAX)
						|| (sealRivals <= AI1_SPARSE_RIVALS && poRoom >= AI1_PACE_FLOOR
							&& !sealable(newX, newY, newVx, newVy, playerNum))) {
					poBestT = poT;
					poDir = d;
				}
			}
			if (score < bestScore) {
				bestScore = score;
				best = d;
				poScorerT = poT;
			}
		}
		// Round 49 arm C (AI1): certified pace tie-break. The lateral-spacing
		// term `spread` outranks raw pace -- in every decision it flips, the
		// traffic-priced deep search rates the alternative EXACTLY equal on
		// costToFinish and the alternative is strictly faster on the map
		// (comp_counterfactual, 5 traffic sinks: 46 ttf recoverable, ZERO cases
		// where the search preferred the slower cell). Deleting spread outright
		// (arm A) buys ~0.45% pace but costs crashes where spacing is really
		// load-bearing (hungaroring 1->6, lemans 1->5 over 10 seeds). So take
		// the faster line only when it is CERTIFIED: weakly better on every
		// non-spread term (spread is the sole reason it lost), zero trap
		// penalty, not sealable, and it survives the same 3-round joint
		// roll-forward DJS trusts. Survival-only asymmetry -- an uncertified
		// faster line is never taken.
		if (best != null && !inScorerSim) {
			final double bestNS = scoreNSByDir[best.ordinal()];
			int fastT = poTByDir[best.ordinal()];
			Direction fast = null;
			for (final Direction d : DIRECTIONS) {
				if (d == best || poTByDir[d.ordinal()] >= fastT)
					continue;
				if (scoreNSByDir[d.ordinal()] > bestNS + 1e-9)
					continue;
				if (trapByDir[d.ordinal()] != 0.0)
					continue;
				final int nvx = vel[0] + d.dx, nvy = vel[1] + d.dy;
				final int nx = pos[0] + nvx, ny = pos[1] + nvy;
				if (sealable(nx, ny, nvx, nvy, playerNum))
					continue;
				if (simOutcome(nx, ny, nvx, nvy, playerNum, AI1_DJS_ROUNDS, true, true, false, false) < 0)
					continue;
				fast = d;
				fastT = poTByDir[d.ordinal()];
			}
			if (fast != null)
				best = fast;
		}
		// round 62 (AI1): certified UNC override. The counterfactual on the
		// r61 equilibrium still attributes the largest recoverable pool to
		// `uncertified` (monaco s1: 50 ttf, deep search agreeing 48/48), and
		// rounds 49-53 proved the surcharge is load-bearing insurance that
		// must NOT be cut by predicate alone. Pay it everywhere EXCEPT where
		// a strictly faster line wins the unc-free comparison AND passes the
		// strongest proof owned: zero trap, not sealable, and survival in the
		// round-59 scorer-rival world (the proof round 52 lacked). Solo flips
		// have empty scorer sets, so their proofs cost nothing.
		if (best != null && !inScorerSim) {
			final double bestNU = scoreByDir[best.ordinal()] - uncByDir[best.ordinal()];
			int fastT = poTByDir[best.ordinal()];
			Direction fast = null;
			for (final Direction d : DIRECTIONS) {
				if (d == best || poTByDir[d.ordinal()] >= fastT)
					continue;
				if (uncByDir[d.ordinal()] <= 0.0 || scoreByDir[d.ordinal()] == Double.MAX_VALUE)
					continue;
				if (scoreByDir[d.ordinal()] - uncByDir[d.ordinal()] > bestNU + 1e-9)
					continue;
				if (trapByDir[d.ordinal()] != 0.0)
					continue;
				final int nvx = vel[0] + d.dx, nvy = vel[1] + d.dy;
				final int nx = pos[0] + nvx, ny = pos[1] + nvy;
				if (sealable(nx, ny, nvx, nvy, playerNum))
					continue;
				if (simOutcome(nx, ny, nvx, nvy, playerNum, AI1_DJS_SLOW_ROUNDS, true, true, true, true) < 0)
					continue;
				fast = d;
				fastT = poTByDir[d.ordinal()];
			}
			if (fast != null)
				best = fast;
		}
		Direction chosen = (poDir != null && poBestT < poScorerT) ? poDir : best;
		// Round 75-77 (AI1): recover a strictly-faster line only when a
		// conservative rival-occupancy proof leaves an empty-track-optimal escape
		// private, then require the independent real-scorer rollout to agree. The
		// existing seal and danger guards below keep final veto authority.
		if (chosen != null && !inScorerSim) {
			chosen = privatePaceOverride(pos, vel, playerNum, chosen, scoreByDir, scoreNSByDir,
					trapByDir, uncByDir, poTByDir);
			chosen = stagedPaceOverride(pos, vel, playerNum, chosen, scoreByDir, scoreNSByDir,
					trapByDir, uncByDir, poTByDir);
			chosen = guardedFieldPaceOverride(pos, vel, playerNum, chosen,
					trapByDir, uncByDir, poTByDir);
		}
		if (chosen != null) {
			// r50 sealGuard v2: exact worst-case box check (distinct-opponent
			// matching, legality-checked covers). If the chosen landing is
			// sealable, take the FASTEST unsealable alternative instead.
			final int cvx = vel[0] + chosen.dx, cvy = vel[1] + chosen.dy;
			final int cx = pos[0] + cvx, cy = pos[1] + cvy;
			if (!game.crossesFinishLegally(pos[0], pos[1], cx, cy) && sealable(cx, cy, cvx, cvy, playerNum)) {
				// Round 72 (AI1): a worst-case seal warning must not force the
				// scorer into a strictly narrower local trap. Nurburgring 8-car
				// seed 19 exposed the incoherence: the scorer's tier-L2 N was
				// oracle-alive, while the old fastest-unsealable guard replaced it
				// with tier-L1 E, which died. Keep the guard's anti-seal purpose,
				// but require a trap-monotone escape.
				final double chosenTrap = trapByDir[chosen.ordinal()];
				int bestT = Integer.MAX_VALUE;
				Direction safest = null;
				for (final Direction d : DIRECTIONS) {
					final int nvx = vel[0] + d.dx, nvy = vel[1] + d.dy;
					if (RaceGame.aiVelocityOutOfRange(nvx, nvy))
						continue;
					final int nx = pos[0] + nvx, ny = pos[1] + nvy;
					if (game.crossesFinishLegally(pos[0], pos[1], nx, ny)
							&& (!lapAware && game.onFinalLap(playerNum)
									|| lapGate == 0 && game.isMoveLegalGeometryCached(pos[0], pos[1], nx, ny)
									&& !game.isCrashingPlayer(nx, ny, playerNum)
									&& reach.shedableLanding(nx, ny, nvx, nvy))) {
						safest = d;
						bestT = -1;
						break;
					}
					if (!game.isMoveLegalGeometryCached(pos[0], pos[1], nx, ny))
						continue;
					if (game.isCrashingPlayer(nx, ny, playerNum))
						continue;
					if (!reach.isAlive(nx, ny, nvx, nvy))
						continue;
					if (trapByDir[d.ordinal()] > chosenTrap)
						continue;
					if (sealable(nx, ny, nvx, nvy, playerNum))
						continue;
					final int tt = ttf(nx, ny, nvx, nvy);
					if (tt < bestT) {
						bestT = tt;
						safest = d;
					}
				}
				if (safest != null)
					chosen = safest;
			}
			// Round 75 (PROMOTED): a bounded, proof-gated finish sprint. Local trap and
			// uncertainty terms can spend a whole turn protecting a line even when
			// a faster candidate is already close enough to certify all the way to
			// the flag. Monaco s16 m789 is the minimal example: S has map ttf=15
			// and finishes in 15 rounds, while narrow SW has ttf=14 and finishes in
			// exactly 14; every other move dies. Accept a strictly-faster candidate
			// only if BOTH the score-shaped-rival and scorer-rival joint worlds reach
			// the finish at the empty-map lower bound (ttf+1 simulation rounds; the
			// first partial round contains only players after me). The normal DJS
			// still runs afterwards, retaining its independent survival veto.
			if (!inScorerSim) {
				final int chosenT = poTByDir[chosen.ordinal()];
				final boolean homogeneousLive = chosenT > AI1_FINISH_CERT_TTF
						&& kindHomogeneousField(playerNum);
				final boolean extendedContext = chosenT >= AI1_FINISH_HOMOGENEOUS_TTF + 2
						&& chosenT <= AI1_FINISH_EXTENDED_TTF + 1
						&& kindHomogeneousRoster(playerNum)
						&& liveRivalsRemaining(playerNum) >= AI1_PRIVATE_FIELD_MIN_RIVALS
						&& hasAdjacentPriorVelocityPeer(pos, vel, playerNum);
				// Multi-lap: the sprint exists to cross ASAP -- final lap only.
				int sprintT = game.onFinalLap(playerNum) ? chosenT : Integer.MIN_VALUE;
				Direction sprint = null;
				for (final Direction d : DIRECTIONS) {
					final int t = poTByDir[d.ordinal()];
					final boolean extendedFrontier = t > AI1_FINISH_HOMOGENEOUS_TTF
							&& t <= AI1_FINISH_EXTENDED_TTF && t + 1 == chosenT
							&& d != Direction.NONE && extendedContext
							&& trapByDir[d.ordinal()] == AI1_TRAP_L2
							&& uncByDir[d.ordinal()] == 0.0;
					if (d == chosen || t >= sprintT
							|| (t > AI1_FINISH_HOMOGENEOUS_TTF && !extendedFrontier)
							|| (t > AI1_FINISH_CERT_TTF && (d == Direction.NONE
									|| !homogeneousLive))
							|| trapByDir[d.ordinal()] > AI1_TRAP_L1)
						continue;
					final int nvx = vel[0] + d.dx, nvy = vel[1] + d.dy;
					final int nx = pos[0] + nvx, ny = pos[1] + nvy;
					if (extendedFrontier && sealable(nx, ny, nvx, nvy, playerNum))
						continue;
					final int rounds = t + 1;
					if (simOutcome(nx, ny, nvx, nvy, playerNum, rounds, true, true, true, false) != 0)
						continue;
					if (simOutcome(nx, ny, nvx, nvy, playerNum, rounds, true, true, true, true,
							AI1_DEEP_CERT_RIVALS, null) != 0)
						continue;
					// Round 176: a one-successor sprint can pass both proxy worlds
					// while faithful rivals occupy its only continuation one round
					// later. Confirm only that narrow, traffic-dependent class;
					// wider sprint lines retain the established cheaper certificate.
					if (t >= AI1_FINISH_TRUE_CONFIRM_ROUNDS
							&& trapByDir[d.ordinal()] >= AI1_TRAP_L1
							&& liveRivalsRemaining(playerNum) > 0) {
						if (trueConfirmDepth >= AI1_TRUE_CONFIRM_MAXDEPTH)
							continue;
						trueConfirmDepth++;
						try {
							if (simOutcome(nx, ny, nvx, nvy, playerNum,
									AI1_FINISH_TRUE_CONFIRM_ROUNDS, true, true, true, true,
									false, true, AI1_DEEP_CERT_RIVALS, null, null, null) < 0)
								continue;
						} finally {
							trueConfirmDepth--;
						}
					}
					if (extendedFrontier) {
						final int frontierCvx = vel[0] + chosen.dx, frontierCvy = vel[1] + chosen.dy;
						final int chosenFinal = scorerFieldOutcome(pos[0] + frontierCvx,
								pos[1] + frontierCvy, frontierCvx, frontierCvy, playerNum,
								AI1_DEEP_HORIZON, AI1_DEEP_CERT_RIVALS, rolloutFieldCost);
						final long chosenField = rolloutFieldCost[0];
						final int candidateFinal = scorerFieldOutcome(nx, ny, nvx, nvy, playerNum,
								AI1_DEEP_HORIZON, AI1_DEEP_CERT_RIVALS, rolloutFieldCost);
						final long candidateField = rolloutFieldCost[0];
						if (chosenFinal < 0 || candidateFinal < 0 || candidateFinal >= chosenFinal
								|| candidateField >= chosenField)
							continue;
					}
					sprint = d;
					sprintT = t;
				}
				if (sprint != null) {
					if (AI_DEBUG_DJS)
						System.err.println("AIDBG SPRINT p=" + playerNum + " pos=(" + pos[0] + ","
								+ pos[1] + ") " + chosen + " -> " + sprint + " ttf=" + sprintT);
					chosen = sprint;
				}
			}
			// A high-energy one-turn finish approach can be denied by a leader
			// braking into the pocket after every cheap world has declared the
			// line safe. Pay for a faithful confirm only on the measured compact,
			// aligned, last-slot class. Normal DJS retains final veto authority.
			if (!inScorerSim)
				chosen = finishDenialOverride(pos, vel, playerNum, chosen,
						candidateWorkspace);

			// Danger joint search (round 40): in flagged states (the landing's
			// trap ladder >= 0.5, i.e. <= 2 safe successors) roll the joint game
			// 3 rounds forward on a detached greedy board. STRICTLY asymmetric:
			// only override when the pick provably dies in-sim and an alternative
			// survives -- a surviving pick is always kept (fs1's false-alarm
			// evasion crashes came from warning-based re-picks; survival-only
			// switching cannot fire on a line that was actually fine).
			if (AI_DEBUG_PLAYER == playerNum)
				System.err.println("AIDBG turn" + (inScorerSim ? "-sim" : "-REAL") + " p=" + playerNum + " pos=(" + pos[0] + "," + pos[1] + ") vel=("
						+ vel[0] + "," + vel[1] + ") chosen=" + chosen + " trap=" + trapByDir[chosen.ordinal()]
						+ " gate=" + lapGate + " ttf=" + ttf(pos[0] + vel[0] + chosen.dx,
								pos[1] + vel[1] + chosen.dy, vel[0] + chosen.dx, vel[1] + chosen.dy));
			// round 45 (AI1): sim fidelity only -- finished cars vanish from the
			// sim board (the real game removes them; ghosts caused phantom
			// blockage verdicts). The always-on trigger arm was REJECTED by the
			// ancestral screen: 6 DJS switches/race (vs 0-1) -> false-death
			// model errors perturbed the field into new doom pockets
			// (hungaroring guard 1->5). The trap gate is not just a cost gate;
			// it bounds exposure to sim model error.
			// round 55 (AI1): retry a wider trigger UNDER exact-self fidelity
			// (round 51 fixed the false-death class that sank the round-45 arm):
			// also fire at high landing speed, where the ancestral crash shapes
			// live but the trap ladder still reads 0. Survival-only asymmetry
			// unchanged -- extra fires can only override provably dying picks.
			// Landing velocity recomputed: the sealGuard may have swapped chosen.
			final int djvx = vel[0] + chosen.dx, djvy = vel[1] + chosen.dy;
			// round 59 (AI1): slow-class fires (landing below the wide-trigger
			// speed) use the real-scorer near-rival world and a 5-round
			// horizon -- the six residual champion crashes are ALL slow queue
			// dooms committing 3-5 rounds out, where every cheap proxy drifts
			// (oracle-proven at hungaroring-(64,115) and the lemans-s4
			// funnel). Fast fires keep the proven smom world at 3 rounds.
			final boolean djSlow = speedSquared(djvx, djvy) < AI1_DJS_SPD2;
			if (!inScorerSim) {
				if (trapByDir[chosen.ordinal()] >= 0.5 || !djSlow) {
					final int dangerRounds0 = djSlow && trapByDir[chosen.ordinal()] >= AI1_TRAP_L1
							? AI1_DJS_SLOW_L1_ROUNDS
							: djSlow ? AI1_DJS_SLOW_ROUNDS : AI1_DJS_ROUNDS;
					// Kinematic horizon (round 205): a certification must see the
					// stopping distance. Shedding one unit per round, a landing at
					// max-component speed s needs s rounds to stop -- yet fast fires
					// got the SHORTEST world (3 rounds): at speed 10 that world ends
					// 28 cells short of the wall it is certifying against (monaco's
					// (12,123) magnet committed vy=-10 forty-five cells out; the
					// flank twins and rand2's band are the same shape). Lap mode
					// only; laps=1 keeps its pinned horizons.
					final int dangerRounds = game.lapGates != null
							? Math.max(dangerRounds0, Math.min(AI1_KIN_HORIZON_CAP,
									Math.max(Math.abs(djvx), Math.abs(djvy))))
							: dangerRounds0;
					// round 65 (AI1): pack-gated DEEP escalation for fast fires.
					// The 5-7-round doom class (hairpin s10: three candidates
					// FINISH @r6 while the chosen dies @r7) is invisible to the
					// 3-round world. With >= AI1_DEEP_PACK rivals within
					// Chebyshev AI1_DEEP_PACK_R of the landing, run the cheap
					// smom pre-screen at the deep horizon and escalate to the
					// scorer-rival world on a dead-or-FRAGILE (final tier <= 1)
					// verdict; the scorer-rival re-verdict gates any switch.
					boolean deepHandled = false;
					// round 83 (AI1): the static funnel guard for FAST commitments,
					// run-length gated -- lemans-4car-s1 m131 holds spd^2=85 into
					// the bottom-turn complex and dies @r8 (survivors shed
					// laterally); short gates (run < 6) never fire, which is what
					// broke the first fast arm. Switch-only claiming.
					if (!deepHandled) {
						final int fCx = pos[0] + djvx, fCy = pos[1] + djvy;
						final int fSpdInf = Math.max(Math.abs(djvx), Math.abs(djvy));
						final int fSpan = fSpdInf * (fSpdInf + 1) / 2;
						final int fMinRing = fSpdInf >= AI1_FUNNEL_MIN_SPD
								? reach.minRingWidthAhead(fCx, fCy, fSpan)
								: Integer.MAX_VALUE;
						int liveRivals = 0;
						for (final Player pp : game.players)
							if (pp.getNumber() != playerNum && !pp.isFinished())
								liveRivals++;
						// Deep (8-round) sim verdicts are trustworthy in SPARSE
						// fields: the 4car lemans-s1 geometric doom is model-robust
						// at 3 rivals, while at 7 rivals accumulated rival drift
						// false-kills the certified private lane (lemans-8car-s3,
						// where 5-round worlds and reality agree it lives).
						if (liveRivals <= AI1_FUNNEL_DEEP_FIELD
								&& fMinRing <= AI1_FUNNEL_WIDTH && fSpdInf > fMinRing
								&& reach.narrowRunAhead(fCx, fCy, fSpan, AI1_FUNNEL_WIDTH) >= AI1_FUNNEL_RUN
								&& !game.crossesFinishLegally(pos[0], pos[1], fCx, fCy)) {
							if (AI_DEBUG_DJS)
								System.err.println("AIDBG ESC p=" + playerNum + " pos=(" + pos[0] + ","
										+ pos[1] + ") chosen=" + chosen + " fast-funnel-risk -> scorer rollout");
							final Direction funnelChoice = dangerJointSearch(pos, vel, playerNum, chosen,
									true, true, true, true, AI1_DEEP_HORIZON, AI1_DEEP_CERT_RIVALS, true);
							if (funnelChoice != chosen) {
								chosen = funnelChoice;
								deepHandled = true;
							}
						}
						// Round 178: the thin-ridge hold check. Holding 9-10 onto
						// a one-lane alive ridge (<= 2 alive successors at the
						// landing) -- lobe2-s111's single thread is closed by a
						// body 40 cells downstream; no train rival for the
						// round-175 bar, ring-wide waist for the round-83 funnel,
						// dense field for the guard above. s8-cap6 audits (never
						// a verdict: every admitted census fire reads s8-alive);
						// DEAD-or-loud escalates to the true-6 verdict (true-4
						// reads the doom alive -- it lands 6 rounds out). Switch
						// only to a certified quiet-alive alternative; none =>
						// keep chosen (round-161 semantics). Canon census: 2/9/2/0
						// admissions, zero escalations, zero kills.
						// Round 180: accels admitted too (rand5-s40 commits by
						// accelerating onto the ridge; 11+ stays with round 133).
						// User-ordered promotion: rounds 178-180 are the baseline;
						// both kinds run those established ridge bands, and since the
						// 2026-09-04 promotion the exact axial-vmax extension too.
						final boolean axialVmaxHold = isExactAxialVmaxHold(vel[0], vel[1], djvx, djvy);
						final int ridgeSucc = !deepHandled && fSpdInf >= AI1_RIDGE_MIN_SPD
								&& (fSpdInf < AI1_FASTV_MAX || axialVmaxHold)
								&& !game.crossesFinishLegally(pos[0], pos[1], fCx, fCy)
								? ridgeSuccAlive(fCx, fCy, djvx, djvy) : Integer.MAX_VALUE;
						final boolean axialVmaxRidge = axialVmaxHold && ridgeSucc == 1;
						if (!deepHandled && fSpdInf >= AI1_RIDGE_MIN_SPD
								&& (fSpdInf < AI1_FASTV_MAX || axialVmaxRidge)
								&& !game.crossesFinishLegally(pos[0], pos[1], fCx, fCy)
								&& (ridgeSucc <= AI1_RIDGE_MAX_SUCC
										|| fSpdInf == AI1_RIDGE_PLATEAU_SPD
										&& trapByDir[chosen.ordinal()] == 0.0
										&& isExactRidgePlateauHold(vel[0], vel[1], djvx, djvy)
										&& ridgeWidthThreePlateau(fCx, fCy, djvx, djvy))) {
							final int[] rgTr = { 0, 0 };
							final int rg8 = simOutcome(fCx, fCy, djvx, djvy, playerNum,
									AI1_DEEP_HORIZON, true, true, true, true, false, false,
									AI1_DEEP_CERT_RIVALS, null, null, rgTr);
							boolean ridgeTrueDead = false;
							if ((rg8 < 0 || rgTr[0] >= AI1_RIDGE_THREAD)
									&& trueConfirmDepth < AI1_TRUE_CONFIRM_MAXDEPTH) {
								// Round 223: the true-rival verdict counts against the
								// confirm depth like every other faithful leg, so a
								// train on one thin ridge cannot chain nested verdicts
								// without end.
								trueConfirmDepth++;
								try {
									ridgeTrueDead = simOutcome(fCx, fCy, djvx, djvy, playerNum,
											axialVmaxRidge ? AI1_RIDGE_VMAX_TRUE_ROUNDS
													: AI1_RIDGE_TRUE_ROUNDS,
											true, true, true, true, false,
											true, AI1_DEEP_CERT_RIVALS, null, null, null) < 0;
								} finally {
									trueConfirmDepth--;
								}
							}
							if (ridgeTrueDead) {
								final boolean ridgePlateau = ridgeSucc > AI1_RIDGE_MAX_SUCC;
								Direction ridgeBest = null;
								int ridgeTurns = Integer.MAX_VALUE;
								int ridgeRank = Integer.MAX_VALUE;
								int ridgeThread = Integer.MAX_VALUE;
								int ridgeSpeed2 = -1;
								// Round 179: loud-alive fallback tier -- rand2-s94's
								// only alive alternative reads thread=4 (one notch
								// over the quiet bar) while the chosen is DOUBLE-dead;
								// any s8-alive target dominates a certain death.
								Direction ridgeLoud = null;
								int ridgeLoudTurns = Integer.MAX_VALUE;
								for (final Direction rd : DIRECTIONS) {
									if (rd == chosen)
										continue;
									final int rvx = vel[0] + rd.dx, rvy = vel[1] + rd.dy;
									if (RaceGame.aiVelocityOutOfRange(rvx, rvy))
										continue;
									final int rx = pos[0] + rvx, ry = pos[1] + rvy;
									if (game.crossesFinishLegally(pos[0], pos[1], rx, ry)) {
										ridgeBest = rd;
										break;
									}
									if (!game.isMoveLegalGeometryCached(pos[0], pos[1], rx, ry)
											|| game.isCrashingPlayer(rx, ry, playerNum)
											|| !reach.isAlive(rx, ry, rvx, rvy))
										continue;
									final int[] cTr = { 0, 0 };
									if (simOutcome(rx, ry, rvx, rvy, playerNum, AI1_DEEP_HORIZON,
											true, true, true, true, false, false,
											AI1_DEEP_CERT_RIVALS, null, null, cTr) < 0)
										continue;
									final int rTurns = ttf(rx, ry, rvx, rvy);
									if (cTr[0] >= AI1_RIDGE_THREAD) {
										if (rTurns < ridgeLoudTurns) {
											ridgeLoudTurns = rTurns;
											ridgeLoud = rd;
										}
										continue;
									}
									final int rRank = rTurns + cTr[0];
									final int rSpeed2 = speedSquared(rvx, rvy);
									// Round 185: on the width-three extension, price each
									// threaded rollout round as one map turn; equal ranks prefer
									// the less-threaded line, then the established momentum tie.
									if (!ridgePlateau && rTurns < ridgeTurns
											|| ridgePlateau && (rRank < ridgeRank
													|| rRank == ridgeRank && (cTr[0] < ridgeThread
															|| cTr[0] == ridgeThread && rSpeed2 > ridgeSpeed2))) {
										ridgeTurns = rTurns;
										ridgeRank = rRank;
										ridgeThread = cTr[0];
										ridgeSpeed2 = rSpeed2;
										ridgeBest = rd;
									}
								}
								if (ridgeBest == null)
									ridgeBest = ridgeLoud;
								if (ridgeBest != null) {
									chosen = ridgeBest;
									deepHandled = true;
								}
							}
						}
					}
					if (!djSlow) {
						final int dcx = pos[0] + djvx, dcy = pos[1] + djvy;
						int packNear = 0;
						for (final Player pp : game.players) {
							if (pp.getNumber() == playerNum || pp.isFinished())
								continue;
							final int[] ppos = pp.getPosition();
							if (Math.abs(ppos[0] - dcx) <= AI1_DEEP_PACK_R
									&& Math.abs(ppos[1] - dcy) <= AI1_DEEP_PACK_R)
								packNear++;
						}
						if (packNear >= AI1_DEEP_PACK && !game.crossesFinishLegally(pos[0], pos[1], dcx, dcy)) {
							final int[] ft = rolloutWorkspace().finalTier;
							ft[0] = 3;
							final int dv = simOutcome(dcx, dcy, djvx, djvy, playerNum, AI1_DEEP_HORIZON,
									true, true, true, false, AI1_SCORER_MAXRIVALS, ft);
							if (dv < 0 || ft[0] <= 1) {
								if (AI_DEBUG_DJS)
									System.err.println("AIDBG DEEP p=" + playerNum + " pos=(" + pos[0] + ","
											+ pos[1] + ") chosen=" + chosen + " smom8 "
											+ (dv < 0 ? "dies" : "fragile") + " -> scorer rollout");
								Direction deepChoice = chosen;
								if (dv < 0 && trapByDir[chosen.ordinal()] >= AI1_TRAP_L2) {
									// Cross-model certificate: the topology-shaped smom world proves
									// a locally narrow pick dies and proposes a survivor; accept that
									// survivor only if the scorer-rival world independently keeps it
									// alive. The local trap gate excludes open-line false deaths.
									final Direction smomAlt = dangerJointSearch(pos, vel, playerNum, chosen,
											true, true, true, false, AI1_DEEP_HORIZON);
									if (smomAlt != chosen) {
										final int avx = vel[0] + smomAlt.dx, avy = vel[1] + smomAlt.dy;
										final int ax = pos[0] + avx, ay = pos[1] + avy;
										boolean falseAliveTarget = false;
										// Round 126 AI1 frontier: an equal-speed topology switch can
										// leave a faithful-rival-alive line for a faithful-rival-dead
										// one. Reuse the bounded true-confirm model only for that
										// transition; all ordinary ladder decisions remain unchanged.
										// Round 129 promotion: the Round-126 false-target veto is now
										// champion policy for both smart driver kinds.
										if (poTByDir[chosen.ordinal()] == poTByDir[smomAlt.ordinal()]
												&& Math.max(Math.abs(djvx), Math.abs(djvy))
														== Math.max(Math.abs(avx), Math.abs(avy))
												&& trapByDir[chosen.ordinal()] >= AI1_TRAP_L1
												&& liveRivalsRemaining(playerNum) >= AI1_PRIVATE_FIELD_MIN_RIVALS
												&& kindHomogeneousRoster(playerNum)
												&& trueConfirmDepth < AI1_TRUE_CONFIRM_MAXDEPTH) {
											trueConfirmDepth++;
											try {
												final int confirmCap = Math.max(AI1_SCORER_MAXRIVALS,
														AI1_DEEP_CERT_RIVALS);
												final boolean chosenTrueAlive = simOutcome(dcx, dcy, djvx, djvy,
														playerNum, AI1_DEEP_HORIZON, true, true, true, true,
														false, true, confirmCap, null, null, null) >= 0;
												final boolean altTrueAlive = simOutcome(ax, ay, avx, avy, playerNum,
														AI1_DEEP_HORIZON, true, true, true, true, false, true,
														confirmCap, null, null, null) >= 0;
												falseAliveTarget = chosenTrueAlive && !altTrueAlive;
												if (AI_DEBUG_DJS && falseAliveTarget)
													System.err.println("AIDBG EQUAL-VETO p=" + playerNum
															+ " keep " + chosen + " over false target " + smomAlt);
											} finally {
												trueConfirmDepth--;
											}
										}
										if (!falseAliveTarget && (game.crossesFinishLegally(pos[0], pos[1], ax, ay)
												|| simOutcome(ax, ay, avx, avy, playerNum, AI1_DEEP_HORIZON,
												true, true, true, true) >= 0)) {
											// Round 95 frontier: the topology-shaped model can false-kill a
											// genuinely faster line. In a large homogeneous field, retain an
											// exact-L2, zero-uncertainty, one-turn-faster chosen move only when
											// the same eight-round scorer-rival world proves strict improvement
											// for both the mover and aggregate field. Ambiguity keeps the old
											// survival switch.
											boolean retainChosen = false;
											if (trapByDir[chosen.ordinal()] == AI1_TRAP_L2
													&& uncByDir[chosen.ordinal()] == 0.0
													&& poTByDir[chosen.ordinal()] + 1 == poTByDir[smomAlt.ordinal()]
													&& liveRivalsRemaining(playerNum) >= AI1_PRIVATE_FIELD_MIN_RIVALS
													&& kindHomogeneousField(playerNum)) {
												final int chosenFinal = scorerFieldOutcome(dcx, dcy, djvx, djvy,
														playerNum, AI1_DEEP_HORIZON, AI1_DEEP_CERT_RIVALS,
														rolloutFieldCost);
												final long chosenField = rolloutFieldCost[0];
												final int altFinal = scorerFieldOutcome(ax, ay, avx, avy, playerNum,
														AI1_DEEP_HORIZON, AI1_DEEP_CERT_RIVALS, rolloutFieldCost);
												final long altField = rolloutFieldCost[0];
												retainChosen = chosenFinal >= 0 && altFinal >= 0
														&& chosenFinal < altFinal && chosenField < altField;
												if (AI_DEBUG_DJS && retainChosen)
													System.err.println("AIDBG DEEP p=" + playerNum
															+ " retain faster cross-model line " + chosen + " over "
															+ smomAlt + " self " + chosenFinal + " < " + altFinal
															+ " field " + chosenField + " < " + altField);
											}
											if (!retainChosen) {
												deepChoice = smomAlt;
												if (AI_DEBUG_DJS)
													System.err.println("AIDBG DEEP p=" + playerNum
															+ " cross-model SWITCH " + chosen + " -> " + smomAlt);
											}
										}
									}
								}
								if (deepChoice == chosen)
									deepChoice = dangerJointSearch(pos, vel, playerNum, chosen, true, true,
											true, true, AI1_DEEP_HORIZON, AI1_SCORER_MAXRIVALS,
											false, false, true);
								chosen = deepChoice;
								deepHandled = true;
							} else {
								// round 73 (AI1): the smom-8 pre-screen is blind to
								// CONVERGENCE dooms -- interlagos s10 m103 reads alive
								// tier-3 while faithful rivals kill @r2: the killers
								// (ranks 4-6 by landing distance) brake INTO my
								// shedding corridor, so drifting AND static rival
								// models both vacate the kill. With >= AI1_DEEP_PACK
								// rivals AHEAD of the landing (positive dot with the
								// landing velocity), certify the chosen in the
								// scorer-rival world at the widened cap (the nearest-3
								// set here is exactly the harmless rear queue).
								// Survival-only switch as everywhere.
								int aheadNear = 0;
								for (final Player pp : game.players) {
									if (pp.getNumber() == playerNum || pp.isFinished())
										continue;
									final int[] ppos = pp.getPosition();
									if (Math.abs(ppos[0] - dcx) <= AI1_DEEP_PACK_R
											&& Math.abs(ppos[1] - dcy) <= AI1_DEEP_PACK_R
											&& (ppos[0] - dcx) * djvx + (ppos[1] - dcy) * djvy > 0)
										aheadNear++;
								}
								// Round 74 (AI1): a fast whole-field queue can converge
								// from the SIDE/REAR, so the ahead-only Round 73 gate misses
								// it. Zigzag s22 m72 has all seven rivals within Cheb 10,
								// only one ahead, and three rival bodies already occupying
								// the mover's neutral 3x3 landing grid: smom-8 reads the chosen
								// alive/tier-3 while scorer rivals prove it dead @r2 and keep
								// two equal-ttf escapes alive. Certify only that rare shape,
								// and only when a near-equal low-trap escape is on the table.
								boolean closeEscape = false;
								final int chosenT = poTByDir[chosen.ordinal()];
								for (final Direction d : DIRECTIONS) {
									if (d != chosen && poTByDir[d.ordinal()] <= chosenT + 1
											&& trapByDir[d.ordinal()] <= AI1_TRAP_L2) {
										closeEscape = true;
										break;
									}
								}
								final int landingBodies = countRivalsWithinCheb(pos[0] + vel[0],
										pos[1] + vel[1], playerNum, 1);
								final boolean compressedRearQueue = packNear == sealRivals
										&& sealRivals >= AI1_SLOW_PACK && aheadNear <= 1
										&& landingBodies >= 2 && closeEscape;
								// Round 102 (AI1): ALONGSIDE packs -- monza s80 m183
								// lands amid four rivals braking into the turn
								// (Chebyshev <= 3 of the landing) yet none are
								// "ahead" by the dot test, so the corridor gate
								// stayed shut while the real field boxed the landing
								// in one round. Bodies at the landing itself are the
								// signature; the certified scorer check plus the
								// round-99 true-rival confirm do the rest.
								final int landingAdjacent = countRivalsWithinCheb(dcx, dcy,
										playerNum, 3);
								if (AI_DEBUG_DJS && (aheadNear >= AI1_DEEP_PACK || compressedRearQueue
										|| landingAdjacent >= AI1_DEEP_PACK)) {
									final int[] cft = { 3 };
									final int[] ctr = { 0, 0 };
									final int cv = simOutcome(dcx, dcy, djvx, djvy, playerNum,
											AI1_DJS_ROUNDS, true, true, true, true, false,
											AI1_DEEP_CERT_RIVALS, cft, null, ctr);
									System.err.println("AIDBG CORR-AUDIT p=" + playerNum + " v=" + cv
											+ " tier=" + cft[0] + " thread=" + ctr[0] + " snug=" + ctr[1]);
								}
								if (aheadNear >= AI1_DEEP_PACK || compressedRearQueue
										|| landingAdjacent >= AI1_DEEP_PACK) {
									if (AI_DEBUG_DJS)
										System.err.println("AIDBG " + (compressedRearQueue ? "QUEUE" : "CORR")
												+ " p=" + playerNum + " pos=(" + pos[0] + "," + pos[1]
												+ ") chosen=" + chosen + " ahead=" + aheadNear
												+ " bodies=" + landingBodies
												+ " -> certified scorer check");
									chosen = dangerJointSearch(pos, vel, playerNum, chosen, true, true, true,
											true, AI1_DJS_ROUNDS, AI1_DEEP_CERT_RIVALS, false, false,
											true);
									deepHandled = true;
								}
							}
						}
					}
					if (!deepHandled) {
						boolean fastFragileHandled = false;
						final int ffx = pos[0] + djvx, ffy = pos[1] + djvy;
						// Round 93: Le Mans mixed seed 7 exposes a one-round/fidelity
						// boundary. At a fast L2 landing with a nearby rival, the normal
						// smom world keeps the chosen line alive but fragile after three
						// rounds; real scorer rivals kill it in round four and preserve a
						// different escape. Reuse the normal chosen-move screen while also
						// collecting its final tier, and pay for the faithful extra round
						// only on that exact fragile class. A dead smom verdict falls back
						// to the established selector unchanged.
						final boolean fastL2 = !djSlow && trapByDir[chosen.ordinal()] == AI1_TRAP_L2
								&& !game.crossesFinishLegally(pos[0], pos[1], ffx, ffy);
						final int fastFragileRivals = fastL2
								? countRivalsWithinCheb(ffx, ffy, playerNum, AI1_SCORER_NEAR) : 0;
						// Three-or-more nearby rivals already have the deep-pack machinery.
						// Round 133 fix: an acceleration into the top speed band must
						// reach the vmax deep check in the fallback -- the round-93
						// healthy-tier path used to swallow it without any joint
						// search (spielberg s252 m159: fastFragile tier>=2 kept a
						// scorer-8-dead 11->12 commitment).
						final boolean fastVAccel = Math.max(Math.abs(djvx), Math.abs(djvy)) >= AI1_FASTV_MAX
								&& Math.max(Math.abs(djvx), Math.abs(djvy)) > Math.max(
										Math.abs(vel[0]), Math.abs(vel[1]))
								&& countRivalsWithinCheb(pos[0], pos[1], playerNum,
										AI1_FASTV_PACK_R) >= 1;
						if (!fastVAccel && fastFragileRivals > 0 && fastFragileRivals < AI1_DEEP_PACK) {
							final int[] ft = rolloutWorkspace().finalTier;
							ft[0] = 3;
							final int fastVerdict = simOutcome(ffx, ffy, djvx, djvy, playerNum,
									AI1_DJS_ROUNDS, true, true, true, false, AI1_SCORER_MAXRIVALS, ft);
							if (fastVerdict >= 0) {
								if (ft[0] <= 1) {
									if (AI_DEBUG_DJS)
										System.err.println("AIDBG FAST-FRAGILE p=" + playerNum + " pos=("
												+ pos[0] + "," + pos[1] + ") chosen=" + chosen
												+ " tier=" + ft[0] + " -> scorer-rival r4");
									chosen = dangerJointSearch(pos, vel, playerNum, chosen, true, true, true,
											true, AI1_DJS_FAST_FRAGILE_ROUNDS);
								}
								fastFragileHandled = true;
							}
						}
						if (!fastFragileHandled) {
							// Round 114 (AI1): the fast PAIR-SQUEEZE class -- silverstone
							// s167 m157 commits a fast L2 landing with ONE rival racing a
							// cell away (Chebyshev 1); every pack gate needs three-ish
							// bodies and the fast fallback historically runs the smom
							// world, which reads the squeeze alive (thread=0!) while the
							// plain 3-round scorer world at the DEFAULT cap already kills
							// it and keeps the true survivor (probe-verified both ways).
							// Gate measured at 0-5 fires/race: fast + L2 trap + a rival
							// within Chebyshev 2 of the landing arms a PAIR CONFIRM
							// leg: smom stays the verdict (a raw world flip broke
							// the hungaroring-s10 staged pin), and a smom-alive
							// chosen is killed only when the 3-round scorer world
							// AND the true-rival confirm both agree, with switch
							// targets ladder-verified as everywhere.
							final boolean fastPairRisk = !djSlow
									&& trapByDir[chosen.ordinal()] == AI1_TRAP_L2
									&& countRivalsWithinCheb(pos[0] + djvx, pos[1] + djvy, playerNum, 2) >= 1;
							// Round 98 (AI1): thread-fragility audit for slow pack
							// commitments -- see outThreadRounds. Gated to landings
							// with a real pack around them; solo single-file racing
							// through chicane gates stays untouched.
							final boolean threadPack = djSlow && countRivalsWithinCheb(
									pos[0] + djvx, pos[1] + djvy, playerNum,
									AI1_DEEP_PACK_R) >= AI1_DEEP_PACK;
							// Round 102 (AI1): monaco s88 m54 -- in this same gated context
							// the selfMove proxy BRAKES where the real champion holds speed
							// into the closing box (viable 2,2 -- no thread, no tier tell,
							// no bodies: predicate-invisible). Model me with the recursion-
							// guarded real scorer (round 78); a scorerSelf-dead verdict
							// escalates the whole search into that world so any switch
							// target is proven there too.
							boolean scorerSelfDead = false;
							if (threadPack && AI_DEBUG_DJS) {
								final int[] snug = { 0, 0 };
								final int pfx = pos[0] + djvx, pfy = pos[1] + djvy;
								final int pv = game.crossesFinishLegally(pos[0], pos[1], pfx, pfy) ? 99
										: simOutcome(pfx, pfy, djvx, djvy, playerNum, dangerRounds,
												true, true, true, djSlow, false,
												AI1_SCORER_MAXRIVALS, null, null, snug);
								System.err.println("AIDBG THREADPACK p=" + playerNum + " v=" + pv
										+ " thread=" + snug[0] + " snug=" + snug[1] + "/"
										+ (dangerRounds - 1));
							}
							if (threadPack) {
								final int sfx = pos[0] + djvx, sfy = pos[1] + djvy;
								scorerSelfDead = !game.crossesFinishLegally(pos[0], pos[1], sfx, sfy)
										&& simOutcome(sfx, sfy, djvx, djvy, playerNum, dangerRounds,
												true, true, true, djSlow, true,
												AI1_SCORER_MAXRIVALS, null) < 0;
								if (scorerSelfDead && AI_DEBUG_DJS)
									System.err.println("AIDBG SELFDEAD p=" + playerNum + " pos=("
											+ pos[0] + "," + pos[1] + ") chosen=" + chosen
											+ " -> scorerSelf world");
							}
							// User-ordered promotion: the round-128 fast finish-funnel
							// confirm is champion policy for both smart driver kinds
							// (the harvest-24/25 block orderings proved the identical
							// races crash iff the doomed slot lacks the leg).
							chosen = dangerJointSearch(pos, vel, playerNum, chosen, true, true, true,
									djSlow, dangerRounds, AI1_SCORER_MAXRIVALS, scorerSelfDead,
									threadPack, threadPack || fastPairRisk, true, fastPairRisk,
									!djSlow);
						}
					}
				} else {
					// round 60 (AI1): trap-0 slow moves get a CHEAP smom smoke
					// test -- the vacate-optimistic ladder reads roomy at the
					// zigzag-s4 doom entry (m102: count 0 in reality, death 4
					// rounds out, smom sees it) so nothing fired there. A smom
					// death ESCALATES to the faithful scorer-rival rollout,
					// which re-verdicts the chosen and gates any switch -- smom
					// false alarms are filtered before they can perturb.
					final int scvx = vel[0] + chosen.dx, scvy = vel[1] + chosen.dy;
					final int scx = pos[0] + scvx, scy = pos[1] + scvy;
					final int slowSpd2 = speedSquared(scvx, scvy);
					boolean closeEscape = false;
					final int chosenT = poTByDir[chosen.ordinal()];
					for (final Direction d : DIRECTIONS) {
						if (d != chosen && poTByDir[d.ordinal()] <= chosenT + 1
								&& trapByDir[d.ordinal()] <= AI1_TRAP_L2) {
							closeEscape = true;
							break;
						}
					}
					final int slowPack = countRivalsWithinCheb(scx, scy, playerNum, AI1_SLOW_PACK_R);
					// round 71 (AI1): the dense-pack gate generalized to SMALL
					// fields -- the monaco-4car s9 funnel doom (entry m27,
					// spd^2=13, all 3 rivals within Chebyshev 10, survivors N/SE)
					// is smom-blind AND non-fragile (tier 3) yet scorer-rival
					// visible @r2; only the trigger was missing. Whole live
					// field packed + close escape, with a lower speed floor for
					// fields below the 8-car pack size (start grids stay below
					// spd^2=12).
					final boolean packAll = slowPack == sealRivals && closeEscape;
					final boolean denseSlowPack = packAll && (sealRivals >= AI1_SLOW_PACK
							? slowSpd2 >= AI1_SLOW_PACK_SPD2
							: sealRivals >= AI1_SLOW_PACK_MIN && slowSpd2 >= AI1_SLOW_PACK_SPD2_SMALL);
					// round 78 (AI1): the smoke test runs the SCORER-RIVAL world --
					// smom read the zandvoort-s45 m920 chosen alive tier-3 while
					// faithful rivals (the chaser p7 in the round-59 nearest set)
					// kill it @r2; the third member of the m260/m103 class.
					// round 83 (AI1): STATIC funnel signal -- the deep-horizon
					// commitment class (zandvoort corner, coil spiral) holds
					// speed into a narrowing ring sequence; the narrowing is on
					// the distance map, no rollout needed. On risk, certify at
					// the deep horizon with the widened scorer-me world (the
					// class deaths land @r6-9, past the 5-round smoke).
					final int slowSpdInf = Math.max(Math.abs(scvx), Math.abs(scvy));
					final int funnelSpan = slowSpdInf * (slowSpdInf + 1) / 2;
					final int funnelMinRing = reach.minRingWidthAhead(scx, scy, funnelSpan);
					final boolean funnelRisk = slowSpdInf >= AI1_FUNNEL_MIN_SPD
							&& funnelMinRing <= AI1_FUNNEL_WIDTH && slowSpdInf > funnelMinRing
							&& reach.narrowRunAhead(scx, scy, funnelSpan, AI1_FUNNEL_WIDTH) >= AI1_FUNNEL_RUN;
					if (AI_DEBUG_DJS && slowSpdInf >= AI1_FUNNEL_MIN_SPD)
						System.err.println("AIDBG RING p=" + playerNum + " land=(" + scx + "," + scy
								+ ") spdInf=" + slowSpdInf + " span=" + funnelSpan + " minRing="
								+ reach.minRingWidthAhead(scx, scy, funnelSpan));
					// Round 92: dense-pack and funnel risks already force the
					// following scorer rollout. Avoid paying for a redundant five-
					// round smoke simulation unless diagnostics explicitly need it.
					// Speed (round 108): the slow-queue dooms the smoke exists for
					// need bodies close enough to box a slow landing within the
					// 5-round horizon. Profiled: 5162 smoke runs across sixteen
					// races spanning 8/4/2-car fields, seven real kills -- every
					// 8-car kill has >= 4 rivals within Chebyshev 3 of the landing
					// (gate at 2 = twice the margin), and the one sparse-field kill
					// (monaco 4-car s9 m19, the round-71 pin site) sits in a
					// seal<=3 field, so small fields are exempted wholesale. The
					// ungated smoke was 70-79% of all simulation time and died
					// 0.1% of the time; this keeps 54% of runs and 7/7 kills.
					// Debug modes still run it everywhere.
					final boolean smokeNear = sealRivals <= 3
							|| countRivalsWithinCheb(scx, scy, playerNum, 3) >= 2;
					final boolean smokeRequired = AI_DEBUG_DJS || AI_DEBUG_COMP
							|| AI_DEBUG_PLAYER >= 0 || !denseSlowPack && !funnelRisk && smokeNear;
					final int[] smokeThread = { 0, 0 };
					final boolean smokeDies = smokeRequired
							&& !game.crossesFinishLegally(pos[0], pos[1], scx, scy)
							&& simOutcome(scx, scy, scvx, scvy, playerNum, AI1_DJS_SLOW_ROUNDS,
									true, true, true, true, false, AI1_SCORER_MAXRIVALS,
									null, null, smokeThread) < 0;
					// Round 174: a slow landing with a rival at Chebyshev 2 whose
					// cheap worlds read alive is the two-car squeeze tell; the
					// cap-3 world is blind (the constraining bodies rank beyond
					// nearest-3), so one extra check runs the certification cap.
					// Armed from EITHER route: a run smoke carrying the threaded-
					// and-snug audit, or the dense-pack path (lemans-s216 m81/m89
					// route there in the bunched early field, where the cap-3 ESC
					// keeps the doomed line). Single-world kill: true-4 reads the
					// m81 sibling alive, so a conjunction would under-kill.
					boolean squeezeRisk = false;
					if (!smokeDies && !game.crossesFinishLegally(pos[0], pos[1], scx, scy)
							&& countRivalsWithinCheb(scx, scy, playerNum, 2) >= 1
							&& (denseSlowPack || smokeRequired && smokeThread[0] >= 1
									&& smokeThread[1] >= 2))
						squeezeRisk = simOutcome(scx, scy, scvx, scvy, playerNum, AI1_DJS_SLOW_ROUNDS,
								true, true, true, true, false, AI1_DEEP_CERT_RIVALS,
								null, null, null) < 0;
					if (AI_DEBUG_DJS && smokeRequired && (smokeThread[0] > 0 || smokeThread[1] > 1))
						System.err.println("AIDBG SMOKETHREAD p=" + playerNum + " pos=(" + pos[0]
								+ "," + pos[1] + ") chosen=" + chosen + " dies=" + smokeDies
								+ " thread=" + smokeThread[0] + " snug=" + smokeThread[1] + "/"
								+ (AI1_DJS_SLOW_ROUNDS - 1));
					if (denseSlowPack || smokeDies || funnelRisk || squeezeRisk) {
						if (AI_DEBUG_DJS) {
							final boolean deepCert = funnelRisk || squeezeRisk;
							System.err.println("AIDBG ESC p=" + playerNum + " pos=(" + pos[0] + ","
									+ pos[1] + ") chosen=" + chosen + (denseSlowPack ? " dense-pack"
											: smokeDies ? " scorer-dies"
													: funnelRisk ? " funnel-risk" : " squeeze-risk")
									+ " -> scorer rollout");
							final int[] eft = { 3 };
							final int[] etr = { 0, 0 };
							final int ev = simOutcome(scx, scy, scvx, scvy, playerNum,
									funnelRisk ? AI1_DEEP_HORIZON : AI1_DJS_SLOW_ROUNDS, true, true,
									true, true, false, deepCert ? AI1_DEEP_CERT_RIVALS
											: AI1_SCORER_MAXRIVALS, eft, null, etr);
							System.err.println("AIDBG ESC-AUDIT p=" + playerNum + " v=" + ev
									+ " tier=" + eft[0] + " thread=" + etr[0] + " snug=" + etr[1]);
						}
						chosen = dangerJointSearch(pos, vel, playerNum, chosen, true, true, true,
								true, funnelRisk ? AI1_DEEP_HORIZON : AI1_DJS_SLOW_ROUNDS,
								funnelRisk || squeezeRisk ? AI1_DEEP_CERT_RIVALS
									: AI1_SCORER_MAXRIVALS, true,
								false, true, false, false);
					}
				}
			}
			return chosen;
		}
		// Multi-lap survival fallback: when the lap map prices every candidate
		// MAX (the single-file shedable approach is blocked by bodies), stay
		// ALIVE by the finish map at minimum speed instead of dead-coasting --
		// circle, then cross when the line unblocks.
		if (lapAware) {
			if (AI_DEBUG_PLAYER == playerNum && !inScorerSim) {
				final StringBuilder sb = new StringBuilder("AIDBG SURVIVAL p=" + playerNum
						+ " pos=(" + pos[0] + "," + pos[1] + ") vel=(" + vel[0] + ","
						+ vel[1] + ") gate=" + lapGate
						+ " selfAlive=" + reach.isAlive(pos[0], pos[1], vel[0], vel[1])
						+ " selfG0=" + reach.turnsToGate(0, pos[0], pos[1], vel[0], vel[1])
						+ " selfG1=" + reach.turnsToGate(1, pos[0], pos[1], vel[0], vel[1])
						+ " vals=");
				for (final Direction d : DIRECTIONS) {
					final int nvx = vel[0] + d.dx, nvy = vel[1] + d.dy;
					final int t = reach.turnsToGate(lapGate, pos[0] + nvx, pos[1] + nvy, nvx, nvy);
					final int da = reach.distAt(pos[0] + nvx, pos[1] + nvy);
					sb.append(d.ordinal()).append(':').append(t == Integer.MAX_VALUE ? "INF" : t)
							.append('/').append(da == Integer.MAX_VALUE ? "X" : da).append(' ');
				}
				System.err.println(sb);
			}
			Direction alive = null;
			int aliveT = Integer.MAX_VALUE;
			int aliveSpd = Integer.MAX_VALUE;
			for (final Direction d : DIRECTIONS) {
				if ((fallbackLegalMask & 1 << d.ordinal()) == 0)
					continue;
				final int nvx = vel[0] + d.dx, nvy = vel[1] + d.dy;
				final int nx = pos[0] + nvx, ny = pos[1] + nvy;
				if (game.isCrashingPlayer(nx, ny, playerNum)
						|| !reach.isAlive(nx, ny, nvx, nvy))
					continue;
				final int t = reach.turnsToFinish(nx, ny, nvx, nvy);
				final int spd = speedSquared(nvx, nvy);
				if (spd < aliveSpd || spd == aliveSpd && t < aliveT) {
					alive = d;
					aliveSpd = spd;
					aliveT = t;
				}
			}
			if (alive != null)
				return alive;
		}
		return scoreMinTurnsFallback(pos[0], pos[1], vel[0], vel[1],
				fallbackLegalMask, fallbackIllegalMask, Direction.NONE);
	}

	/** Certificate for a high-energy line that a rival can close at the flag.
	 * The incumbent must die under faithful policies; an escape must survive
	 * both the deep scorer world and the same faithful world. */
	private Direction finishDenialOverride(final int[] pos, final int[] vel,
			final int playerNum, final Direction chosen,
			final CandidateWorkspace candidates) {
		if (inFinishDenialConfirm
				|| trueConfirmDepth >= trueConfirmCandidateSnapshots.length
				|| game.subgamestate != game.players.length - 1
				|| !game.onFinalLap(playerNum) || lapGate != 0)
			return chosen;
		final double[] trapByDir = candidates.trapByDirection;
		final double[] uncByDir = candidates.uncertaintyByDirection;
		final int[] turnsByDir = candidates.turnsByDirection;
		final int chosenT = turnsByDir[chosen.ordinal()];
		if (chosenT < 0 || chosenT > AI1_FINISH_DENIAL_MAX_TTF
				|| ttf(pos[0], pos[1], vel[0], vel[1]) != chosenT + 1)
			return chosen;
		final int cvx = vel[0] + chosen.dx, cvy = vel[1] + chosen.dy;
		final int cx = pos[0] + cvx, cy = pos[1] + cvy;
		if (game.crossesFinishLegally(pos[0], pos[1], cx, cy))
			return chosen;
		final int chosenSpeed2 = speedSquared(cvx, cvy);
		if (chosenSpeed2 < AI1_FINISH_DENIAL_MIN_SPEED2
				|| countRivalsWithinCheb(pos[0] + vel[0], pos[1] + vel[1], playerNum, 1) == 0
				|| countRivalsWithinCheb(cx, cy, playerNum, AI1_SCORER_NEAR)
						< AI1_FINISH_DENIAL_NEAR_RIVALS)
			return chosen;
		int alignedAhead = 0;
		for (final Player p : game.players) {
			if (p.getNumber() == playerNum || p.isFinished())
				continue;
			final int[] pp = p.getPosition();
			if (Math.abs(pp[0] - cx) > AI1_SCORER_NEAR
					|| Math.abs(pp[1] - cy) > AI1_SCORER_NEAR
					|| (long) (pp[0] - cx) * cvx + (long) (pp[1] - cy) * cvy <= 0L)
				continue;
			final int[] pv = p.getVelocity();
			if (Math.abs(pv[0] - cvx) <= 2 && Math.abs(pv[1] - cvy) <= 2)
				alignedAhead++;
		}
		if (alignedAhead < AI1_FINISH_DENIAL_ALIGNED_RIVALS)
			return chosen;

		int brakeMask = 0;
		for (final Direction d : DIRECTIONS) {
			if (d == chosen || turnsByDir[d.ordinal()] > chosenT + 1
					|| trapByDir[d.ordinal()] > AI1_TRAP_L1
					|| uncByDir[d.ordinal()] > uncByDir[chosen.ordinal()])
				continue;
			final int nvx = vel[0] + d.dx, nvy = vel[1] + d.dy;
			if (chosenSpeed2 - speedSquared(nvx, nvy) >= AI1_FINISH_DENIAL_MIN_BRAKE2)
				brakeMask |= 1 << d.ordinal();
		}
		if (brakeMask == 0)
			return chosen;

		final int faithfulCap = AI_DEBUG_FINISH_DENIAL
				? Math.max(1, Math.min(game.players.length,
						AI_DEBUG_FINISH_DENIAL_RIVAL_CAP))
				: AI1_FINISH_DENIAL_RIVALS;
		final CandidateWorkspace snapshot =
				trueConfirmCandidateSnapshots[trueConfirmDepth];
		snapshot.copyFrom(candidates);
		inFinishDenialConfirm = true;
		trueConfirmDepth++;
		try {
			final int chosenFinal = faithfulFinishDenialOutcome(cx, cy, cvx, cvy,
					playerNum, faithfulCap);
			if (chosenFinal >= 0) {
				if (AI_DEBUG_FINISH_DENIAL)
					System.err.println("AIDBG FINISH-DENIAL cap=" + faithfulCap
							+ " p=" + playerNum + " pos=(" + pos[0] + "," + pos[1]
							+ ") chosen=" + chosen + " keep sim=" + chosenFinal);
				return chosen;
			}
			Direction best = null;
			int bestFinal = Integer.MAX_VALUE;
			int bestSpeed2 = Integer.MAX_VALUE;
			int bestT = Integer.MAX_VALUE;
			for (final Direction d : DIRECTIONS) {
				if ((brakeMask & 1 << d.ordinal()) == 0)
					continue;
				final int nvx = vel[0] + d.dx, nvy = vel[1] + d.dy;
				if (RaceGame.aiVelocityOutOfRange(nvx, nvy))
					continue;
				final int speed2 = speedSquared(nvx, nvy);
				if (chosenSpeed2 - speed2 < AI1_FINISH_DENIAL_MIN_BRAKE2)
					continue;
				final int nx = pos[0] + nvx, ny = pos[1] + nvy;
				final int t = ttf(nx, ny, nvx, nvy);
				if (game.crossesFinishLegally(pos[0], pos[1], nx, ny))
					return d;
				if (!game.isMoveLegalGeometryCached(pos[0], pos[1], nx, ny)
						|| game.isCrashingPlayer(nx, ny, playerNum)
						|| !reach.isAlive(nx, ny, nvx, nvy))
					continue;
				final int scorerFinal = simOutcome(nx, ny, nvx, nvy, playerNum,
						AI1_FINISH_DENIAL_ROUNDS, true, true, true, true, true,
						AI1_DEEP_CERT_RIVALS, null);
				final int candidateFinal = scorerFinal < 0 ? -1
						: faithfulFinishDenialOutcome(nx, ny, nvx, nvy,
								playerNum, faithfulCap);
				if (AI_DEBUG_FINISH_DENIAL || AI_DEBUG_DJS || AI_DEBUG_PLAYER == playerNum)
					System.err.println("AIDBG FINISH-DENIAL cap=" + faithfulCap
							+ " alt=" + d + " t=" + t + " speed2=" + speed2
							+ " scorer=" + scorerFinal + " faithful=" + candidateFinal);
				if (candidateFinal < 0)
					continue;
				if (candidateFinal < bestFinal
						|| candidateFinal == bestFinal && speed2 < bestSpeed2
						|| candidateFinal == bestFinal && speed2 == bestSpeed2 && t < bestT) {
					best = d;
					bestFinal = candidateFinal;
					bestSpeed2 = speed2;
					bestT = t;
				}
			}
			if (AI_DEBUG_FINISH_DENIAL || AI_DEBUG_DJS || AI_DEBUG_PLAYER == playerNum)
				System.err.println("AIDBG FINISH-DENIAL cap=" + faithfulCap
						+ " p=" + playerNum + " pos=(" + pos[0] + "," + pos[1]
						+ ") chosen=" + chosen + " dies -> "
						+ (best == null ? "keep (no survivor)" : "switch " + best
								+ " sim=" + bestFinal + " speed2=" + bestSpeed2));
			return best != null ? best : chosen;
		} finally {
			trueConfirmDepth--;
			inFinishDenialConfirm = false;
			candidates.copyFrom(snapshot);
		}
	}

	private int faithfulFinishDenialOutcome(final int x, final int y, final int vx,
			final int vy, final int playerNum, final int faithfulCap) {
		return simOutcome(x, y, vx, vy, playerNum, AI1_FINISH_DENIAL_ROUNDS,
				true, true, true, true, true, true, faithfulCap, null, null, null);
	}

	/** Identical frame preparation for normal decisions and standalone sim queries. */
	private void prepareDecisionFrame(final int[] pos, final int[] vel, final int playerNum) {
		lapGate = game.nextGateOf(playerNum);
		lapAware = !game.onFinalLap(playerNum) || lapGate != 0;
		final int robustSp = Math.max(Math.abs(vel[0]), Math.abs(vel[1]));
		robustMode = lapAware && rivalAheadWithinCheb(pos[0], pos[1], vel[0], vel[1], playerNum,
				Math.max(AI1_ROBUST_RANGE, Math.min(robustSp * (robustSp + 1) / 2, AI1_ROBUST_KIN_CAP)));
		exactPot = game.optimalPotential();
		if (exactPot != null) {
			int lapsDone = 0;
			for (final Player q : game.players)
				if (q.getNumber() == playerNum)
					lapsDone = q.getLap();
			exactRemaining = OptimalPotential.remainingEvents(lapGate, lapsDone, game.totalLaps);
		}
		recordPlayerFrames();
	}

	/** Multi-lap: true while choosing for a mover NOT on its final lap --
	 *  every turns-to-finish read then uses the shedable-crossing lap map.
	 *  Set at optimalMoveAI1 entry; the dispatcher is only entered from
	 *  RaceGame (no recursion), so a plain field is safe per instance. */
	private boolean lapAware;
	/** Multi-lap: the mover's next gate (0=S/F, 1=CP1, 2=CP2). */
	private int lapGate;
	/** Round 210: a live rival within AI1_ROBUST_RANGE -- the lap potential
	 *  surcharges needle states (single-thread continuations); alone, the
	 *  plain map keeps the solo line. Set beside lapAware at entry. */
	private boolean robustMode;
	/** Round 216: the exact distance-to-finish map, and the gate events this
	 *  mover still owes. Null on a board too large for the potential's budget
	 *  and on a course without lap gates; the gate maps then serve as before.
	 *  Round 222: like lapGate/lapAware/robustMode these are the MOVER's and
	 *  a nested rival compute reassigns them -- scorerMoveOverState restores
	 *  all four. */
	private OptimalPotential	exactPot;
	private int					exactRemaining;
	/** Round 222: every player's own lap frame, by player index, recorded at
	 *  each decision entry so a rival's state is priced on the rival's gate
	 *  schedule and not the mover's. */
	private int[]				frameGate		= new int[0];
	private int[]				frameRemaining	= new int[0];
	private boolean[]			frameLapAware	= new boolean[0];

	/** Round 222: each player's gate, lap-awareness and remaining events, by
	 *  player index. Per-player facts, so a nested rival compute records the
	 *  projected values. Rollouts and nested scorers own separate frame arrays. */
	private void recordPlayerFrames() {
		final int n = game.players.length;
		if (frameGate.length < n) {
			frameGate = new int[n];
			frameRemaining = new int[n];
			frameLapAware = new boolean[n];
		}
		for (int i = 0; i < n; i++) {
			final Player q = game.players[i];
			final int number = q.getNumber();
			frameGate[i] = game.nextGateOf(number);
			frameLapAware[i] = !game.onFinalLap(number) || frameGate[i] != 0;
			frameRemaining[i] = OptimalPotential.remainingEvents(frameGate[i], q.getLap(),
					game.totalLaps);
		}
	}

	/** Round 222: ttf() in player {@code idx}'s own frame -- its gate, its
	 *  remaining events, its lap-awareness. Robust mode stays the mover's:
	 *  it describes the traffic, not the car. */
	private int ttfFor(final int idx, final int x, final int y, final int vx, final int vy) {
		if (exactPot != null) {
			final int v = exactPot.movesToFinish(frameRemaining[idx], x, y, vx, vy);
			if (v == Integer.MAX_VALUE)
				return Integer.MAX_VALUE;
			return robustMode && !reach.isRobust(frameGate[idx], x, y, vx, vy)
					? v + AI1_ROBUST_SURCHARGE : v;
		}
		if (!frameLapAware[idx])
			return reach.turnsToFinish(x, y, vx, vy);
		return robustMode
				? reach.turnsToGateNeedleAware(frameGate[idx], x, y, vx, vy, AI1_ROBUST_SURCHARGE)
				: reach.turnsToGate(frameGate[idx], x, y, vx, vy);
	}

	/** Round 222: the crossing rule of the rollout's move models, in player
	 *  {@code idx}'s frame: a crossing is a finish or a lap only when that
	 *  player owes nothing else. */
	private boolean crossingCountsFor(final int idx, final int nx, final int ny, final int nvx,
			final int nvy) {
		return !frameLapAware[idx]
				|| frameGate[idx] == 0 && reach.shedableLanding(nx, ny, nvx, nvy);
	}

	private int ttf(final int x, final int y, final int vx, final int vy) {
		// Round 216: the exact remaining distance whenever the potential exists.
		// The gate maps answer "how far to the NEXT gate", which is not what a
		// race minimises -- arriving at a gate in a poor state is paid for after
		// it, and measurement put half the pace given up on landings the policy
		// would happily take beyond what the gate map can see. The round-210
		// needle surcharge still rides on top, so robust mode prices
		// single-thread states exactly as it did.
		if (exactPot != null) {
			final int v = exactPot.movesToFinish(exactRemaining, x, y, vx, vy);
			if (v == Integer.MAX_VALUE)
				return Integer.MAX_VALUE;
			return robustMode && !reach.isRobust(lapGate, x, y, vx, vy)
					? v + AI1_ROBUST_SURCHARGE : v;
		}
		if (!lapAware)
			return reach.turnsToFinish(x, y, vx, vy);
		return robustMode ? reach.turnsToGateNeedleAware(lapGate, x, y, vx, vy, AI1_ROBUST_SURCHARGE)
				: reach.turnsToGate(lapGate, x, y, vx, vy);
	}

	/** Whether every live rival runs the mover's policy. Since the 2026-09-04
	 *  promotion every AI kind is the one policy, so the question is whether a
	 *  human is among the live rivals; before it the gates compared kind labels,
	 *  which kept them off in the mixed-label fleet field for no reason. */
	private boolean kindHomogeneousField(final int playerNum) {
		for (final Player p : game.players)
			if (p.getNumber() != playerNum && !p.isFinished() && !p.isAi())
				return false;
		return true;
	}

	/** Whether every racer in the starting roster runs the mover's policy.
	 *  Unlike the live-field gate, this cannot become true late in a mixed race
	 *  after the human has finished or crashed. */
	private boolean kindHomogeneousRoster(final int playerNum) {
		for (final Player p : game.players)
			if (p.getNumber() != playerNum && !p.isAi())
				return false;
		return true;
	}

	/** Whether a previously moved live rival is adjacent, shares the mover's
	 *  current velocity, and has a lateral (or nearly lateral) offset. */
	private boolean hasAdjacentPriorVelocityPeer(final int[] pos, final int[] vel,
			final int playerNum) {
		for (int i = 0; i < game.subgamestate; i++) {
			final Player p = game.players[i];
			if (p.getNumber() == playerNum || p.isFinished())
				continue;
			final int[] pp = p.getPosition();
			final int dx = pp[0] - pos[0], dy = pp[1] - pos[1];
			if (Math.max(Math.abs(dx), Math.abs(dy)) != 1)
				continue;
			final int[] pv = p.getVelocity();
			if (pv[0] == vel[0] && pv[1] == vel[1]
					&& Math.abs((long) dx * vel[0] + (long) dy * vel[1]) <= 1L)
				return true;
		}
		return false;
	}


	/** Round 117 candidate-formation proof: a previously moved rival is
	 * adjacent to the proposed landing and already carries its exact velocity.
	 * The lateral dot bound keeps the peer alongside rather than directly in
	 * the mover's path. */
	private boolean hasAdjacentPriorCandidateVelocityPeer(final int x, final int y,
			final int vx, final int vy, final int playerNum) {
		for (int i = 0; i < game.subgamestate; i++) {
			final Player p = game.players[i];
			if (p.getNumber() == playerNum || p.isFinished())
				continue;
			final int[] pp = p.getPosition();
			final int dx = pp[0] - x, dy = pp[1] - y;
			if (Math.max(Math.abs(dx), Math.abs(dy)) != 1)
				continue;
			final int[] pv = p.getVelocity();
			if (pv[0] == vx && pv[1] == vy
					&& Math.abs((long) dx * vx + (long) dy * vy) <= 1L)
				return true;
		}
		return false;
	}

	/** Round 106: recover a one-turn acceleration only in a bounded forward
	 * pack when the same eight-round scorer world proves strict mover and
	 * aggregate-field gains. Round 117 admits an exact-six-ahead high-energy
	 * formation only with an adjacent prior candidate-velocity peer. Round 124
	 * additionally admits a positive L1/L2 candidate only for the first two
	 * movers inside TTF 45; the partial-round counterexamples remain excluded.
	 * Round 175 admits a bounded moderate-gain six-ahead move only when it
	 * crosses into the high-speed band. Round 177 admits one five-ahead,
	 * low-energy, mildly uncertain winner from one of the round's last three
	 * movers only after a full-field componentwise faithful confirmation. */
	private Direction guardedFieldPaceOverride(final int[] pos, final int[] vel,
			final int playerNum, final Direction chosen, final double[] trapByDir,
			final double[] uncByDir, final int[] turnsByDir) {
		final int chosenT = turnsByDir[chosen.ordinal()];
		if (chosenT == Integer.MAX_VALUE || chosenT < AI1_FINISH_HOMOGENEOUS_TTF + 2
				|| chosenT > AI1_FIELD_ACCEL_MAX_TTF || !kindHomogeneousRoster(playerNum))
			return chosen;
		int liveRivals = 0, rivalsAhead = 0;
		long aheadProgress = 0L;
		final boolean stagedLaunch = useTrackDistanceForStagedLaunch(vel[0], vel[1],
				game.startZoneA.contains(pos[0], pos[1]));
		final int moverProgress = reach.distAt(pos[0], pos[1]);
		for (final Player rival : game.players) {
			if (rival.getNumber() == playerNum || rival.isFinished())
				continue;
			liveRivals++;
			final int[] rivalPos = rival.getPosition();
			final int rivalProgress = reach.distAt(rivalPos[0], rivalPos[1]);
			final boolean ahead = stagedLaunch
					? isStrictlyAheadByTrackDistance(moverProgress, rivalProgress)
					: ((long) rivalPos[0] - pos[0]) * vel[0]
							+ ((long) rivalPos[1] - pos[1]) * vel[1] > 0L;
			if (ahead) {
				rivalsAhead++;
				if (moverProgress != Integer.MAX_VALUE && rivalProgress != Integer.MAX_VALUE)
					aheadProgress += (long) moverProgress - rivalProgress;
			}
		}
		// Round 129 promotion: Rounds 115, 117 and 124 cleared the
		// frontier census; both smart driver kinds use the certified pace arms.
		final boolean frontierMover = true;
		final boolean sixAheadFrontier = frontierMover
				&& rivalsAhead == AI1_FIELD_ACCEL_MAX_AHEAD + 1;
		final boolean sixAheadHighSpeedModerateFrontier = sixAheadFrontier;
		final boolean earlyRoundTrapFrontier = frontierMover
				&& game.subgamestate <= 1
				&& chosenT <= AI1_FIELD_ACCEL_FRONTIER_LOW_GAIN_MAX_TTF
				&& rivalsAhead <= AI1_FIELD_ACCEL_MAX_AHEAD;
		if (liveRivals < AI1_PRIVATE_FIELD_MIN_RIVALS
				|| rivalsAhead < AI1_FIELD_ACCEL_MIN_AHEAD
				|| rivalsAhead > AI1_FIELD_ACCEL_MAX_AHEAD && !sixAheadFrontier
				|| aheadProgress <= 0L)
			return chosen;

		final int chosenVx = vel[0] + chosen.dx, chosenVy = vel[1] + chosen.dy;
		final int chosenX = pos[0] + chosenVx, chosenY = pos[1] + chosenVy;
		final int chosenSpeed2 = speedSquared(chosenVx, chosenVy);
		final int fieldProofRounds = sixAheadFrontier
				? AI1_FIELD_ACCEL_SIX_AHEAD_ROUNDS : AI1_STAGED_HORIZON;
		int chosenFinal = Integer.MIN_VALUE;
		long chosenField = Long.MAX_VALUE;
		Direction best = null;
		int bestFinal = Integer.MAX_VALUE;
		long bestField = Long.MAX_VALUE;
		Direction uncertainBest = null;
		int uncertainBestFinal = Integer.MAX_VALUE;
		long uncertainBestField = Long.MAX_VALUE;
		int uncertainBestX = 0, uncertainBestY = 0;
		int uncertainBestVx = 0, uncertainBestVy = 0;
		for (final Direction d : DIRECTIONS) {
			final int turns = turnsByDir[d.ordinal()];
			final double candidateTrap = trapByDir[d.ordinal()];
			final double candidateUnc = uncByDir[d.ordinal()];
			final boolean frontierTrapCandidate = earlyRoundTrapFrontier
					&& candidateTrap > 0.0 && candidateTrap <= AI1_TRAP_L2;
			if (d == chosen || d == Direction.NONE || turns == Integer.MAX_VALUE
					|| turns + 1 != chosenT
					|| candidateTrap != 0.0 && !frontierTrapCandidate)
				continue;
			final int nvx = vel[0] + d.dx, nvy = vel[1] + d.dy;
			final int speed2 = speedSquared(nvx, nvy);
			final int speed2Gain = speed2 - chosenSpeed2;
			final boolean frontierModerateGain = frontierMover
					&& chosen != Direction.NONE
					&& chosenSpeed2 < AI1_DJS_SPD2
					&& chosenT <= AI1_FIELD_ACCEL_FRONTIER_LOW_GAIN_MAX_TTF
					&& speed2Gain >= AI1_FIELD_ACCEL_FRONTIER_MIN_SPEED2_GAIN;
			final boolean sixAheadHighSpeedModerateGain = sixAheadHighSpeedModerateFrontier
					&& chosen != Direction.NONE
					&& chosenSpeed2 < AI1_FIELD_ACCEL_SIX_AHEAD_MODERATE_MIN_SPEED2
					&& speed2 >= AI1_FIELD_ACCEL_SIX_AHEAD_MODERATE_MIN_SPEED2
					&& speed2Gain >= AI1_FIELD_ACCEL_FRONTIER_MIN_SPEED2_GAIN
					&& speed2Gain < AI1_FIELD_ACCEL_MIN_SPEED2_GAIN;
			final boolean boundedUncertainModerateGain = rivalsAhead == AI1_FIELD_ACCEL_MAX_AHEAD
					&& chosen != Direction.NONE && candidateTrap == 0.0
					&& game.subgamestate >= game.players.length - AI1_FIELD_UNCERTAIN_LAST_MOVERS
					&& chosenT >= AI1_FIELD_UNCERTAIN_MIN_TTF
					&& chosenT <= AI1_FIELD_UNCERTAIN_MAX_TTF
					&& chosenSpeed2 < AI1_FIELD_ACCEL_SIX_AHEAD_MODERATE_MIN_SPEED2
					&& speed2 < AI1_FIELD_ACCEL_SIX_AHEAD_MODERATE_MIN_SPEED2
					&& speed2 >= speedSquared(vel[0], vel[1])
					&& speed2Gain >= AI1_FIELD_ACCEL_FRONTIER_MIN_SPEED2_GAIN
					&& speed2Gain < AI1_FIELD_ACCEL_MIN_SPEED2_GAIN
					&& candidateUnc > 0.0 && candidateUnc <= AI1_FIELD_UNCERTAIN_MAX;
			if (candidateUnc != 0.0 && !boundedUncertainModerateGain)
				continue;
			if (speed2Gain < AI1_FIELD_ACCEL_MIN_SPEED2_GAIN
					&& !frontierModerateGain && !sixAheadHighSpeedModerateGain
					&& !boundedUncertainModerateGain)
				continue;
			// Six-ahead moderate acceleration is limited to Round 175's bounded
			// transition into the high-speed band; the broad class stays excluded.
			if (sixAheadFrontier && speed2Gain < AI1_FIELD_ACCEL_MIN_SPEED2_GAIN
					&& !sixAheadHighSpeedModerateGain)
				continue;
			if (turns <= AI1_FINISH_EXTENDED_TTF && speed2 < AI1_DJS_SPD2)
				continue;
			final int nx = pos[0] + nvx, ny = pos[1] + nvy;
			if (sixAheadFrontier && !sixAheadHighSpeedModerateGain
					&& !hasAdjacentPriorCandidateVelocityPeer(
					nx, ny, nvx, nvy, playerNum))
				continue;
			final int candidateInf = Math.max(Math.abs(nvx), Math.abs(nvy));
			final int candidateSpan = candidateInf * (candidateInf + 1) / 2;
			final int candidateRing = reach.minRingWidthAhead(nx, ny, candidateSpan);
			if (candidateRing < AI1_FUNNEL_WIDTH) {
				final int chosenInf = Math.max(Math.abs(chosenVx), Math.abs(chosenVy));
				final int chosenSpan = chosenInf * (chosenInf + 1) / 2;
				if (rivalsAhead < AI1_FIELD_ACCEL_MAX_AHEAD
						|| aheadProgress < (long) chosenSpan + candidateSpan)
					continue;
			}
			if (sealable(nx, ny, nvx, nvy, playerNum))
				continue;
			if (chosenFinal == Integer.MIN_VALUE) {
				chosenFinal = scorerFieldOutcome(chosenX, chosenY, chosenVx, chosenVy, playerNum,
						fieldProofRounds, AI1_DEEP_CERT_RIVALS, rolloutFieldCost);
				chosenField = rolloutFieldCost[0];
				if (chosenFinal < 0 || chosenField >= ROLLOUT_FAILURE_COST)
					return chosen;
			}
			final int candidateFinal = scorerFieldOutcome(nx, ny, nvx, nvy, playerNum,
					fieldProofRounds, AI1_DEEP_CERT_RIVALS, rolloutFieldCost);
			final long candidateField = rolloutFieldCost[0];
			if (candidateFinal < 0 || candidateFinal >= chosenFinal
					|| candidateField >= chosenField)
				continue;
			if (boundedUncertainModerateGain) {
				if (uncertainBest == null || candidateFinal < uncertainBestFinal
						|| candidateFinal == uncertainBestFinal
								&& candidateField < uncertainBestField) {
					uncertainBest = d;
					uncertainBestFinal = candidateFinal;
					uncertainBestField = candidateField;
					uncertainBestX = nx;
					uncertainBestY = ny;
					uncertainBestVx = nvx;
					uncertainBestVy = nvy;
				}
			} else if (best == null || candidateFinal < bestFinal
					|| candidateFinal == bestFinal && candidateField < bestField) {
				best = d;
				bestFinal = candidateFinal;
				bestField = candidateField;
			}
		}
		if (uncertainBest != null && (best == null || uncertainBestFinal < bestFinal
				|| uncertainBestFinal == bestFinal && uncertainBestField < bestField)) {
			final boolean faithfulImproves = faithfulFieldPaceImproves(chosenX, chosenY,
					chosenVx, chosenVy, uncertainBestX, uncertainBestY,
					uncertainBestVx, uncertainBestVy, playerNum, fieldProofRounds);
			if (faithfulImproves) {
				best = uncertainBest;
				bestFinal = uncertainBestFinal;
				bestField = uncertainBestField;
			}
		}
		if (best != null && AI_DEBUG_DJS)
			System.err.println("AIDBG FIELD-ACCEL p=" + playerNum + " pos=(" + pos[0]
					+ "," + pos[1] + ") " + chosen + " -> " + best + " ttf " + chosenT
					+ " -> " + turnsByDir[best.ordinal()] + " ahead=" + rivalsAhead
					+ " progress=" + aheadProgress + " self " + chosenFinal + " -> "
					+ bestFinal + " field " + chosenField + " -> " + bestField);
		return best != null ? best : chosen;
	}

	/** Round 177 vector proof for the bounded positive-uncertainty arm. The
	 * suppressed scorer proof ranks candidates first, so this expensive pair is
	 * run at most once per move. Every rival that is live in the real position
	 * runs its unsuppressed scorer, with no radius or cap filter. Besides strict
	 * self and aggregate-field improvements, no rival may have a worse projected
	 * personal cost (simulated move slots plus terminal TTF). */
	private boolean faithfulFieldPaceImproves(final int chosenX, final int chosenY,
			final int chosenVx, final int chosenVy, final int candidateX,
			final int candidateY, final int candidateVx, final int candidateVy,
			final int playerNum, final int rounds) {
		if (trueConfirmDepth >= trueConfirmCandidateSnapshots.length)
			return false;
		final int players = game.players.length;
		final RolloutWorkspace proofWorkspace = rolloutWorkspace();
		final boolean[] originallyLiveRival = proofWorkspace.faithfulOriginallyLiveRival;
		final long[] chosenRivalCost = proofWorkspace.faithfulChosenRivalCost;
		final long[] candidateRivalCost = proofWorkspace.faithfulCandidateRivalCost;
		for (int i = 0; i < players; i++) {
			final Player player = game.players[i];
			originallyLiveRival[i] = player.getNumber() != playerNum && !player.isFinished();
		}
		final CandidateWorkspace snapshot = trueConfirmCandidateSnapshots[trueConfirmDepth];
		snapshot.copyFrom(candidatesByDepth[simDepth]);
		trueConfirmDepth++;
		try {
			final int chosenFinal = simOutcome(chosenX, chosenY, chosenVx, chosenVy,
					playerNum, rounds, true, true, true, true, true, true, players,
					null, rolloutFieldCost, null, true, chosenRivalCost);
			final long chosenField = rolloutFieldCost[0];
			final int candidateFinal = simOutcome(candidateX, candidateY,
					candidateVx, candidateVy, playerNum, rounds,
					true, true, true, true, true, true, players,
					null, rolloutFieldCost, null, true, candidateRivalCost);
			final long candidateField = rolloutFieldCost[0];
			long chosenProjectedField = 0L, candidateProjectedField = 0L;
			boolean componentwiseNonWorse = true;
			for (int i = 0; i < players; i++) {
				if (!originallyLiveRival[i])
					continue;
				if (chosenRivalCost[i] < 0L || candidateRivalCost[i] < 0L
						|| candidateRivalCost[i] > chosenRivalCost[i])
					componentwiseNonWorse = false;
				chosenProjectedField += chosenRivalCost[i];
				candidateProjectedField += candidateRivalCost[i];
			}
			final boolean accepted = chosenFinal >= 0 && candidateFinal >= 0
					&& candidateFinal < chosenFinal
					&& chosenField < ROLLOUT_FAILURE_COST && candidateField < chosenField
					&& componentwiseNonWorse
					&& candidateProjectedField < chosenProjectedField;
			if (AI_DEBUG_DJS || AI_DEBUG_FIELD_VECTOR) {
				System.err.println("AIDBG FIELD-VECTOR p=" + playerNum + " chosen=("
						+ chosenX + "," + chosenY + ")v(" + chosenVx + "," + chosenVy
						+ ") candidate=(" + candidateX + "," + candidateY + ")v("
						+ candidateVx + "," + candidateVy + ") rounds=" + rounds
						+ " self=" + chosenFinal + "->" + candidateFinal
						+ " field=" + chosenField + "->" + candidateField
						+ " projected=" + chosenProjectedField + "->"
						+ candidateProjectedField + " componentwise="
						+ componentwiseNonWorse + " accepted=" + accepted
						+ " chosenRivals=" + projectedRivalVector(chosenRivalCost,
								originallyLiveRival)
						+ " candidateRivals=" + projectedRivalVector(candidateRivalCost,
								originallyLiveRival));
			}
			return accepted;
		} finally {
			trueConfirmDepth--;
			candidatesByDepth[simDepth].copyFrom(snapshot);
		}
	}

	private String projectedRivalVector(final long[] costs, final boolean[] included) {
		final StringBuilder result = new StringBuilder("{");
		boolean first = true;
		for (int i = 0; i < costs.length; i++) {
			if (!included[i])
				continue;
			if (!first)
				result.append(',');
			first = false;
			result.append('p').append(game.players[i].getNumber()).append('=').append(costs[i]);
		}
		return result.append('}').toString();
	}

	private Direction privatePaceOverride(final int[] pos, final int[] vel, final int playerNum,
			final Direction chosen, final double[] scoreByDir, final double[] scoreNSByDir,
			final double[] trapByDir, final double[] uncByDir, final int[] turnsByDir) {
		final int chosenT = turnsByDir[chosen.ordinal()];
		if (chosenT == Integer.MAX_VALUE)
			return chosen;
		final double chosenRest = scoreNSByDir[chosen.ordinal()] - trapByDir[chosen.ordinal()]
				- uncByDir[chosen.ordinal()];
		RaceAiPrivateLane.ProofSession privateProof = null;
		RaceAiPrivateLane.ProofSession slackProof = null;
		// Promotion semantics (round 83 mirror, round 223): "self-play" means
		// every rival runs the mover's policy -- since the 2026-09-04 promotion
		// that is every AI kind, so only a human breaks it.
		final int slackChosenVx = vel[0] + chosen.dx;
		final int slackChosenVy = vel[1] + chosen.dy;
		final int slackChosenSpeed2 = speedSquared(slackChosenVx, slackChosenVy);
		final int slackCurrentSpeed2 = speedSquared(vel[0], vel[1]);
		final boolean slackFrontier = chosenT >= AI1_PRIVATE_FRONTIER_MIN_TTF
				&& chosenT <= AI1_PRIVATE_FRONTIER_MAX_TTF
				&& chosen != Direction.NONE
				&& kindHomogeneousRoster(playerNum);
		boolean homogeneousFrontier = true;
		for (final Player p : game.players) {
			if (p.getNumber() != playerNum && !p.isFinished() && !p.isAi()) {
				homogeneousFrontier = false;
				break;
			}
		}
		Direction best = null;
		Direction slackBest = null;
		int bestT = chosenT;
		int slackChosenFinal = Integer.MIN_VALUE;
		long slackChosenField = Long.MAX_VALUE;
		int slackBestFinal = Integer.MAX_VALUE;
		long slackBestField = Long.MAX_VALUE;
		double slackBestScore = Double.MAX_VALUE;
		double slackBestRestDelta = Double.MAX_VALUE;
		double bestTrap = Double.MAX_VALUE;
		double bestUnc = Double.MAX_VALUE;
		double bestScore = Double.MAX_VALUE;
		for (final Direction d : DIRECTIONS) {
			final int turns = turnsByDir[d.ordinal()];
			if (turns >= chosenT || turns > bestT)
				continue;
			final double trap = trapByDir[d.ordinal()];
			final double unc = uncByDir[d.ordinal()];
			// Spread-only lanes already have their own certified override. This
			// stronger proof targets the residual trap/uncertainty pool; skipping
			// pure lateral ties also bounds scorer-rollout exposure on open tracks.
			if (trap == 0.0 && unc == 0.0)
				continue;
			final double rest = scoreNSByDir[d.ordinal()] - trap - unc;
			if (rest > chosenRest + 1e-9) {
				final double restDelta = rest - chosenRest;
				// Frontier experiment: a tiny non-trap score concession may recover
				// exactly one map turn only for a kind-homogeneous starting roster. Keep this
				// candidate separate so it cannot displace an existing private-lane
				// winner. Keep the eight-round field proof in its established
				// non-overlapping medium-range phase; both moves must be non-coasting,
				// and the low-energy candidate must preserve current energy while
				// improving on and remaining aligned with the chosen acceleration. It
				// must otherwise be exact-L2 with zero uncertainty and unsealable,
				// exact-private with two exits, and strictly better for the mover while
				// non-worsening for the field in the longer eight-round scorer world.
				if (slackFrontier && restDelta <= AI1_PRIVATE_FRONTIER_REST_SLACK + 1e-9
						&& turns + 1 == chosenT && d != Direction.NONE
						&& chosen.dx * d.dx + chosen.dy * d.dy > 0
						&& trap == AI1_TRAP_L2 && unc == 0.0) {
					final int nvx = vel[0] + d.dx, nvy = vel[1] + d.dy;
					final int nx = pos[0] + nvx, ny = pos[1] + nvy;
					final int speed2 = speedSquared(nvx, nvy);
					if (speed2 < AI1_DJS_SPD2 && speed2 >= slackCurrentSpeed2
							&& speed2 > slackChosenSpeed2
							&& !sealable(nx, ny, nvx, nvy, playerNum)) {
						if (slackProof == null)
							slackProof = privateLane.begin(playerNum,
									AI1_PRIVATE_EXACT_HORIZON + 1, AI1_PRIVATE_EXACT_NODES);
						if (slackProof.certifiesExact(nx, ny, nvx, nvy, turns,
								AI1_PRIVATE_EXACT_HORIZON, AI1_PRIVATE_EXACT_ESCAPES)) {
							if (slackChosenFinal == Integer.MIN_VALUE) {
								slackChosenFinal = scorerFieldOutcome(pos[0] + slackChosenVx,
										pos[1] + slackChosenVy, slackChosenVx, slackChosenVy, playerNum,
										AI1_STAGED_HORIZON, AI1_DEEP_CERT_RIVALS,
										rolloutFieldCost);
								slackChosenField = rolloutFieldCost[0];
							}
							if (slackChosenFinal >= 0
									&& slackChosenFinal != Integer.MAX_VALUE
									&& slackChosenField < ROLLOUT_FAILURE_COST) {
								final int candidateFinal = scorerFieldOutcome(nx, ny, nvx, nvy,
										playerNum, AI1_STAGED_HORIZON,
										AI1_DEEP_CERT_RIVALS, rolloutFieldCost);
								final long candidateField = rolloutFieldCost[0];
								final double score = scoreByDir[d.ordinal()];
								if (candidateFinal >= 0 && candidateFinal != Integer.MAX_VALUE
										&& candidateFinal < slackChosenFinal
										&& candidateField <= slackChosenField
										&& candidateField < ROLLOUT_FAILURE_COST
										&& (slackBest == null || candidateFinal < slackBestFinal
												|| candidateFinal == slackBestFinal
														&& (candidateField < slackBestField
																|| candidateField == slackBestField
																		&& score < slackBestScore))) {
									slackBest = d;
									slackBestFinal = candidateFinal;
									slackBestField = candidateField;
									slackBestScore = score;
									slackBestRestDelta = restDelta;
								}
							}
						}
					}
				}
				continue;
			}
			final int nvx = vel[0] + d.dx, nvy = vel[1] + d.dy;
			final int nx = pos[0] + nvx, ny = pos[1] + nvy;
			if (sealable(nx, ny, nvx, nvy, playerNum))
				continue;
			if (privateProof == null)
				privateProof = privateLane.begin(playerNum, AI1_PRIVATE_EXACT_HORIZON + 1,
						AI1_PRIVATE_EXACT_NODES);
			boolean certified = privateProof.certifiesApproximate(nx, ny, nvx, nvy, turns,
					AI1_PRIVATE_BASE_HORIZON, AI1_PRIVATE_BASE_ESCAPES);
			if (!certified) {
				// The narrower two-exit proof is safe only when every live rival uses
				// the same frontier policy. In mixed fields, one car's acceleration
				// can perturb a frozen-policy rival and create a delayed crash for a
				// third car, so fast moves retain the broader three-exit certificate.
				final boolean moderateHomogeneousFast = homogeneousFrontier
						&& unc <= AI1_PRIVATE_EXACT_UNC_MAX;
				final int requiredEscapes = speedSquared(nvx, nvy) < AI1_DJS_SPD2
						|| moderateHomogeneousFast
						? AI1_PRIVATE_EXACT_ESCAPES : AI1_PRIVATE_BASE_ESCAPES;
				certified = privateProof.certifiesExact(nx, ny, nvx, nvy, turns,
						AI1_PRIVATE_EXACT_HORIZON, requiredEscapes);
			}
			if (!certified)
				continue;
			final double score = scoreByDir[d.ordinal()];
			if (turns < bestT || turns == bestT && (trap < bestTrap
					|| trap == bestTrap && (unc < bestUnc
							|| unc == bestUnc && score < bestScore))) {
				best = d;
				bestT = turns;
				bestTrap = trap;
				bestUnc = unc;
				bestScore = score;
			}
		}
		if (best == null) {
			if (slackBest != null && AI_DEBUG_DJS)
				System.err.println("AIDBG PRIVATE-SLACK p=" + playerNum + " pos=(" + pos[0]
						+ "," + pos[1] + ") " + chosen + " -> " + slackBest + " ttf "
						+ chosenT + " -> " + turnsByDir[slackBest.ordinal()] + " self "
						+ slackChosenFinal + " -> " + slackBestFinal + " field "
						+ slackChosenField + " -> " + slackBestField + " trap "
						+ AI1_TRAP_L2 + " unc 0.0 restDelta "
						+ slackBestRestDelta);
			return slackBest != null ? slackBest : chosen;
		}
		final int bestVx = vel[0] + best.dx, bestVy = vel[1] + best.dy;
		final int bestX = pos[0] + bestVx, bestY = pos[1] + bestVy;
		// Cross-model check once, after the adversarial certificate has ranked all
		// candidates. Calling the full scorer rollout per candidate made open
		// circuits needlessly expensive without strengthening proof.
		final boolean compareField = privateFieldComparisonRequired(bestX, bestY, bestVx, bestVy,
				playerNum);
		final int scorerCap = compareField ? AI1_DEEP_CERT_RIVALS : AI1_SCORER_MAXRIVALS;
		final int bestFinal = scorerFieldOutcome(bestX, bestY, bestVx, bestVy, playerNum,
				AI1_DJS_SLOW_ROUNDS, scorerCap, compareField ? rolloutFieldCost : null);
		if (bestFinal < 0)
			return chosen;
		if (compareField) {
			final long bestField = rolloutFieldCost[0];
			final int chosenVx = vel[0] + chosen.dx, chosenVy = vel[1] + chosen.dy;
			final int chosenX = pos[0] + chosenVx, chosenY = pos[1] + chosenVy;
			final int chosenFinal = scorerFieldOutcome(chosenX, chosenY, chosenVx, chosenVy,
					playerNum, AI1_DJS_SLOW_ROUNDS, AI1_DEEP_CERT_RIVALS, rolloutFieldCost);
			final long chosenField = rolloutFieldCost[0];
			// A private lane can be safe for its mover while perturbing the rest of
			// the field into slower or failed lines. In a compressed fast pack, take
			// it only when the same scorer-rival world proves strict self progress and
			// a non-worsening aggregate rival state.
			if (chosenFinal < 0 || bestFinal >= chosenFinal || bestField > chosenField) {
				if (AI_DEBUG_DJS)
					System.err.println("AIDBG PRIVATE-FIELD p=" + playerNum + " pos=(" + pos[0]
							+ "," + pos[1] + ") keep " + chosen + " over " + best + " self "
							+ chosenFinal + " -> " + bestFinal + " field "
							+ chosenField + " -> " + bestField);
				return chosen;
			}
		}
		if (AI_DEBUG_DJS)
			System.err.println("AIDBG PRIVATE p=" + playerNum + " pos=(" + pos[0] + "," + pos[1]
					+ ") " + chosen + " -> " + best + " ttf " + chosenT + " -> " + bestT);
		return best;
	}


	/**
	 * Round 82 frontier experiment: recover a one-turn map gain in the slow
	 * class when the candidate is almost tied on every non-trap/non-uncertainty
	 * score term. The broad class still requires four rivals ahead. Exactly
	 * three may qualify only at slow-pack speed with a finite incumbent field
	 * rollout. An eight-round six-rival scorer rollout must prove strict self
	 * progress without increasing aggregate rival cost. High-speed candidates,
	 * deaths, field regressions, ties, and model ambiguity fail closed. Existing
	 * seal and danger guards still run afterwards.
	 */
	private Direction stagedPaceOverride(final int[] pos, final int[] vel, final int playerNum,
			final Direction chosen, final double[] scoreByDir, final double[] scoreNSByDir,
			final double[] trapByDir, final double[] uncByDir, final int[] turnsByDir) {
		final int chosenT = turnsByDir[chosen.ordinal()];
		if (chosenT == Integer.MAX_VALUE || chosenT < AI1_STAGED_MIN_TURNS)
			return chosen;
		// Round 79's convoy counterexample established that a mover-safe pace
		// change can destabilise a different policy hundreds of moves later.
		// This new long-horizon certificate is therefore self-play-only until a
		// mixed-policy externality proof exists.
		int rivalsAhead = 0;
		final boolean stagedLaunch = useTrackDistanceForStagedLaunch(vel[0], vel[1],
				game.startZoneA.contains(pos[0], pos[1]));
		final int moverProgress = reach.distAt(pos[0], pos[1]);
		for (final Player p : game.players) {
			if (p.getNumber() == playerNum || p.isFinished())
				continue;
			if (!p.isAi())
				return chosen;
			final int[] rivalPos = p.getPosition();
			// Round 91: a stationary starting-grid car has no velocity
			// half-plane, so use the track-distance heuristic for that launch
			// only. Moving cars retain the promoted geometric rule. Equal or
			// unavailable map distances fail closed.
			final boolean ahead = stagedLaunch
					? isStrictlyAheadByTrackDistance(moverProgress,
							reach.distAt(rivalPos[0], rivalPos[1]))
					: ((long) rivalPos[0] - pos[0]) * vel[0]
							+ ((long) rivalPos[1] - pos[1]) * vel[1] > 0L;
			if (ahead)
				rivalsAhead++;
		}
		// Round 82 opens the adjacent three-ahead class, but only after the
		// incumbent reaches the established slow-pack speed floor and its own
		// scorer-world field outcome is finite. The four-ahead class is unchanged.
		if (rivalsAhead < 3)
			return chosen;
		final double chosenRest = scoreNSByDir[chosen.ordinal()] - trapByDir[chosen.ordinal()]
				- uncByDir[chosen.ordinal()];
		final int chosenVx = vel[0] + chosen.dx, chosenVy = vel[1] + chosen.dy;
		final int chosenSpeed2 = speedSquared(chosenVx, chosenVy);
		if (rivalsAhead == 3 && chosenSpeed2 < AI1_SLOW_PACK_SPD2)
			return chosen;
		final int chosenX = pos[0] + chosenVx, chosenY = pos[1] + chosenVy;
		int chosenFinal = Integer.MIN_VALUE;
		long chosenField = Long.MAX_VALUE;
		Direction best = null;
		double bestRestDelta = Double.MAX_VALUE;
		RaceAiPrivateLane.ProofSession energyProof = null;
		for (final Direction d : DIRECTIONS) {
			final int turns = turnsByDir[d.ordinal()];
			if (turns == Integer.MAX_VALUE || chosenT - turns != 1
					|| scoreByDir[d.ordinal()] == Double.MAX_VALUE)
				continue;
			final double trap = trapByDir[d.ordinal()];
			final double unc = uncByDir[d.ordinal()];
			if (trap > 0.0 || unc > AI1_STAGED_UNC_MAX)
				continue;
			final double rest = scoreNSByDir[d.ordinal()] - trap - unc;
			final double restDelta = rest - chosenRest;
			if (restDelta > AI1_STAGED_REST_SLACK)
				continue;
			final int nvx = vel[0] + d.dx, nvy = vel[1] + d.dy;
			final int speed2 = speedSquared(nvx, nvy);
			if (speed2 >= AI1_DJS_SPD2)
				continue;
			final int nx = pos[0] + nvx, ny = pos[1] + nvy;
			final boolean highEnergy = speed2 - chosenSpeed2 > AI1_STAGED_MAX_SPEED2_GAIN;
			if (highEnergy) {
				if (rivalsAhead < 4)
					continue;
				if (energyProof == null)
					energyProof = privateLane.begin(playerNum, AI1_PRIVATE_EXACT_HORIZON + 1,
							AI1_PRIVATE_EXACT_NODES);
				final int requiredEscapes = unc <= AI1_PRIVATE_EXACT_UNC_MAX
						? AI1_PRIVATE_EXACT_ESCAPES : AI1_PRIVATE_BASE_ESCAPES;
				if (!energyProof.certifiesExact(nx, ny, nvx, nvy, turns,
						AI1_PRIVATE_EXACT_HORIZON, requiredEscapes))
					continue;
			}
			if (sealable(nx, ny, nvx, nvy, playerNum))
				continue;
			if (chosenFinal == Integer.MIN_VALUE) {
				chosenFinal = scorerFieldOutcome(chosenX, chosenY, chosenVx, chosenVy, playerNum,
						AI1_STAGED_HORIZON, AI1_DEEP_CERT_RIVALS, rolloutFieldCost);
				chosenField = rolloutFieldCost[0];
				if (rivalsAhead == 3 && chosenField >= ROLLOUT_FAILURE_COST)
					return chosen;
			}
			if (chosenFinal < 0)
				return chosen;
			final int candidateFinal = scorerFieldOutcome(nx, ny, nvx, nvy, playerNum,
					AI1_STAGED_HORIZON, AI1_DEEP_CERT_RIVALS, rolloutFieldCost);
			final long candidateField = rolloutFieldCost[0];
			if (candidateFinal < 0 || candidateFinal >= chosenFinal
					|| candidateField > chosenField)
				continue;
			if (highEnergy && (unc <= 0.0
					|| rivalsAhead >= 5 && candidateField >= chosenField))
				continue;
			if (best == null || restDelta < bestRestDelta) {
				best = d;
				bestRestDelta = restDelta;
			}
		}
		if (best != null && AI_DEBUG_DJS)
			System.err.println("AIDBG STAGED p=" + playerNum + " pos=(" + pos[0] + ","
					+ pos[1] + ") " + chosen + " -> " + best + " ttf " + chosenT
					+ " -> " + turnsByDir[best.ordinal()] + " trap="
					+ trapByDir[best.ordinal()] + " unc=" + uncByDir[best.ordinal()]);
		return best != null ? best : chosen;
	}

	private boolean privateFieldComparisonRequired(final int x, final int y, final int vx,
			final int vy, final int playerNum) {
		final int speed2 = speedSquared(vx, vy);
		if (speed2 < AI1_DJS_SPD2)
			return false;
		int rivals = 0, rivalsAhead = 0;
		boolean compactPack = true, alignedConvoy = true;
		final int convoyRadius = Math.max(AI1_DEEP_PACK_R,
				AI1_PRIVATE_CONVOY_RADIUS_V * Math.max(Math.abs(vx), Math.abs(vy)));
		for (final Player p : game.players) {
			if (p.getNumber() == playerNum || p.isFinished())
				continue;
			rivals++;
			final int[] position = p.getPosition();
			final long dx = (long) position[0] - x, dy = (long) position[1] - y;
			if (Math.abs(dx) > AI1_DEEP_PACK_R || Math.abs(dy) > AI1_DEEP_PACK_R)
				compactPack = false;
			final long cross = dx * vy - dy * vx;
			final long corridorLimit = (long) AI1_PRIVATE_CONVOY_HALF_WIDTH
					* AI1_PRIVATE_CONVOY_HALF_WIDTH * speed2;
			if (Math.max(Math.abs(dx), Math.abs(dy)) > convoyRadius
					|| squareExceeds(cross, corridorLimit))
				alignedConvoy = false;
			if (dx * vx + dy * vy > 0L)
				rivalsAhead++;
			if (!compactPack && !alignedConvoy)
				return false;
		}
		return rivals >= AI1_PRIVATE_FIELD_MIN_RIVALS
				&& (compactPack || alignedConvoy
						&& rivalsAhead <= AI1_PRIVATE_CONVOY_MAX_AHEAD);
	}

	/** Queue-compression support: count live STALLED rivals within squared
	 *  distance 36 of the candidate landing that are at-or-ahead in track
	 *  progress. Ahead-ness keeps the same-progress +3 slack and the 15-cell
	 *  wall exclusion used by the original Zandvoort forensic. */
	private int countStalledRivalsAhead(final int x, final int y, final int playerNum) {
		final int myDist = reach.distAt(x, y);
		if (myDist == Integer.MAX_VALUE)
			return 0;
		int count = 0;
		for (final Player p : game.players) {
			if (p.getNumber() == playerNum || p.isFinished())
				continue;
			final int[] pp = p.getPosition();
			final int dx = x - pp[0];
			final int dy = y - pp[1];
			if (distanceSquared(dx, dy) > 36L)
				continue;
			final int oDist = reach.distAt(pp[0], pp[1]);
			if (oDist == Integer.MAX_VALUE || Math.abs(oDist - myDist) > 15 || oDist > myDist + 3)
				continue; // behind me, or across a wall: no compression
			final int[] pv = p.getVelocity();
			// v2: only genuinely STALLED rivals count as a boxing queue (the
			// zandvoort doom queue crawled at |v| 1-2). A merely-slower but
			// FLOWING train clears the corridor before I arrive -- braking for
			// it is pure place-ceding in mixed fields (h2h: zandvoort 4.75,
			// interlagos 4.62 under the old relative test). With the outer
			// speed > 4 gate, <= 2.5 also implies the old mySpeed-1 margin.
			if (speedSquared(pv[0], pv[1]) <= STALLED_RIVAL_SPEED2)
				count++;
		}
		return count;
	}

	/** Shared champion frontier (queueBox v3 long-range trigger): count STALLED
	 *  rivals (|v| <= 2.5, the {@link #countStalledRivalsAhead} threshold)
	 *  at-or-ahead of (x,y) in track progress within {@code reachCells}
	 *  euclidean cells -- my stopping distance, so unlike the near trigger
	 *  this must see the queue BEFORE the local successor count collapses.
	 *  Ahead-ness keeps the +3 same-progress slack; the wall exclusion
	 *  scales with reach (a rival physically near but further along the
	 *  corridor than I can even travel while stopping is across a wall). */
	private int countStalledRivalsWithin(final int x, final int y, final double reachCells, final int playerNum) {
		final int myDist = reach.distAt(x, y);
		if (myDist == Integer.MAX_VALUE)
			return 0;
		final double reachSq = reachCells * reachCells;
		int count = 0;
		for (final Player p : game.players) {
			if (p.getNumber() == playerNum || p.isFinished())
				continue;
			final int[] pp = p.getPosition();
			final int dx = x - pp[0];
			final int dy = y - pp[1];
			if (distanceSquared(dx, dy) > reachSq)
				continue;
			final int oDist = reach.distAt(pp[0], pp[1]);
			if (oDist == Integer.MAX_VALUE || myDist - oDist > reachCells + 3 || oDist > myDist + 3)
				continue; // behind me, or across a wall: no compression
			final int[] pv = p.getVelocity();
			if (speedSquared(pv[0], pv[1]) <= STALLED_RIVAL_SPEED2)
				count++;
		}
		return count;
	}

	/** {@link #pureMinTurnsMove} against an exact counted simulated occupancy
	 *  instead of the live player positions; used by
	 *  {@link #simulateRoundPass}. */
	private Direction pureMinTurnsMoveSim(final int idx, final int[] pos, final int[] vel,
			final CellOccupancy occupied) {
		Direction best = null;
		int bestTurns = Integer.MAX_VALUE;
		int fallbackLegalMask = 0;
		final int sm = succMask(pos[0], pos[1], vel[0], vel[1]);
		for (final Direction d : DIRECTIONS) {
			final int bit = 1 << d.ordinal();
			final int newVx = vel[0] + d.dx;
			final int newVy = vel[1] + d.dy;
			if ((sm & bit << 16) == 0)
				continue;
			final int newX = pos[0] + newVx;
			final int newY = pos[1] + newVy;
			if (game.crossesFinishLegally(pos[0], pos[1], newX, newY))
				return d;
			if ((sm & bit) == 0)
				continue;
			if (occupied.contains(newX, newY))
				continue;
			fallbackLegalMask |= bit;
			final int turns = ttfFor(idx, newX, newY, newVx, newVy);
			if (turns < bestTurns) {
				bestTurns = turns;
				best = d;
			}
		}
		if (best != null)
			return best;
		return scoreMinTurnsFallback(pos[0], pos[1], vel[0], vel[1],
				fallbackLegalMask, 0, null);
	}

	/** Reusable two-round opponent projection. The reference arrays and every
	 *  generated coordinate/velocity pair are retained across candidate moves;
	 *  each pass only rewrites primitive values and swaps row references. */
	private TwoRoundWorkspace twoRoundWorkspace() {
		final int players = game.players.length;
		if (twoRoundWorkspace == null || twoRoundWorkspace.current.length != players)
			twoRoundWorkspace = new TwoRoundWorkspace(players,
					game.gameCols + 1, game.gameRows + 1);
		return twoRoundWorkspace;
	}

	private TwoRoundWorkspace nestedScorerTwoRoundReferenceWorkspace() {
		final int players = game.players.length;
		if (nestedScorerTwoRoundReferenceWorkspace == null
				|| nestedScorerTwoRoundReferenceWorkspace.current.length != players)
			nestedScorerTwoRoundReferenceWorkspace = new TwoRoundWorkspace(players,
					game.gameCols + 1, game.gameRows + 1);
		return nestedScorerTwoRoundReferenceWorkspace;
	}

	/** Build the no-mover reference used only inside a nested scorer. */
	private TwoRoundWorkspace prepareTwoRoundReference(final int playerNum) {
		return simulateTwoRounds(nestedScorerTwoRoundReferenceWorkspace(), playerNum,
				0, 0, false);
	}

	/** Reuse is exact unless the candidate blocks a landing selected in the
	 *  no-mover first round. A hit takes the unchanged conditioned path. */
	private TwoRoundWorkspace simulateTwoRounds(final int playerNum, final int candX,
			final int candY, final TwoRoundWorkspace reference) {
		if (reference != null && !reference.world1Occupancy.contains(candX, candY))
			return reference;
		return simulateTwoRounds(playerNum, candX, candY);
	}

	/** Simulate two complete opponent rounds in actual turn order, conditioned
	 *  on my candidate landing. {@code world1} contains the cells for my next
	 *  move and {@code current} the cells for the move after that. */
	private TwoRoundWorkspace simulateTwoRounds(final int playerNum, final int candX, final int candY) {
		return simulateTwoRounds(twoRoundWorkspace(), playerNum, candX, candY, true);
	}

	private TwoRoundWorkspace simulateTwoRounds(final TwoRoundWorkspace workspace,
			final int playerNum, final int candX, final int candY,
			final boolean blockCandidate) {
		final int[][] current = workspace.current;
		final int[][] simulatedVelocity = workspace.simulatedVelocity;
		java.util.Arrays.fill(current, null);
		for (final Player p : game.players) {
			if (p.getNumber() == playerNum || p.isFinished())
				continue;
			final int idx = p.getNumber() - 1;
			current[idx] = p.getPosition();
			simulatedVelocity[idx] = p.getVelocity();
		}
		workspace.blockedOccupancy.rebuild(current);
		if (blockCandidate)
			workspace.blockedOccupancy.add(candX, candY);
		simulateRoundPass(playerNum, current, simulatedVelocity,
				workspace.blockedOccupancy, workspace.round1Position, workspace.round1Velocity);
		System.arraycopy(current, 0, workspace.world1, 0, current.length);
		workspace.world1Occupancy.rebuild(workspace.world1);
		if (blockCandidate)
			workspace.blockedOccupancy.remove(candX, candY);
		simulateRoundPass(playerNum, current, simulatedVelocity,
				workspace.blockedOccupancy, workspace.round2Position, workspace.round2Velocity);
		return workspace;
	}

	/** One two-pass opponent round. A mover always receives a fresh logical
	 *  position row, but that row is caller-owned and reused on the next root;
	 *  a velocity row is replaced only when the move is legal, matching the
	 *  original stay-put semantics exactly. */
	private void simulateRoundPass(final int playerNum, final int[][] occupancy,
			final int[][] simulatedVelocity, final CellOccupancy blockedOccupancy,
			final int[][] nextPosition, final int[][] nextVelocity) {
		for (int pass = 0; pass < 2; pass++) {
			for (final Player p : game.players) {
				final boolean later = p.getNumber() > playerNum;
				if (p.getNumber() == playerNum || p.isFinished() || (pass == 0 ? !later : later))
					continue;
				final int idx = p.getNumber() - 1;
				final int[] current = occupancy[idx];
				blockedOccupancy.remove(current[0], current[1]);
				final int[] velocity = simulatedVelocity[idx];
				final Direction direction = pureMinTurnsMoveSim(idx, current, velocity, blockedOccupancy);
				int nx = current[0];
				int ny = current[1];
				if (direction != null) {
					final int nvx = velocity[0] + direction.dx;
					final int nvy = velocity[1] + direction.dy;
					if (!RaceGame.aiVelocityOutOfRange(nvx, nvy)
							&& game.isMoveLegalGeometryCached(current[0], current[1], current[0] + nvx, current[1] + nvy)
							&& !blockedOccupancy.contains(current[0] + nvx, current[1] + nvy)) {
						nx = current[0] + nvx;
						ny = current[1] + nvy;
						final int[] velocityOut = nextVelocity[idx];
						velocityOut[0] = nvx;
						velocityOut[1] = nvy;
						simulatedVelocity[idx] = velocityOut;
					}
				}
				final int[] positionOut = nextPosition[idx];
				positionOut[0] = nx;
				positionOut[1] = ny;
				occupancy[idx] = positionOut;
				blockedOccupancy.add(nx, ny);
			}
		}
	}

	/** Build the exact first-occupant ahead verdict once for this candidate.
	 * Byte 1 means the first simulated occupant is not ahead; byte 2 means it
	 * is ahead. Duplicate simulated cells therefore retain the original loop's
	 * first-match semantics. */
	private byte[] buildAheadOccupancy(final int[][] occupancy, final int myDist) {
		final TwoRoundWorkspace workspace = twoRoundWorkspace();
		final byte[] direct = workspace.aheadOccupancy;
		for (int i = 0; i < workspace.aheadTouchedCount; i++)
			direct[workspace.aheadTouched[i]] = 0;
		workspace.aheadTouchedCount = 0;
		final int h = game.gameRows + 1;
		for (int i = 0; i < occupancy.length; i++) {
			final int[] cell = occupancy[i];
			if (cell == null || cell[0] < 0 || cell[1] < 0
					|| cell[0] > game.gameCols || cell[1] > game.gameRows)
				continue;
			final int index = cell[0] * h + cell[1];
			if (direct[index] != 0)
				continue;
			final int[] rivalPos = game.players[i].getPosition();
			direct[index] = reach.distAt(rivalPos[0], rivalPos[1]) < myDist
					? (byte) 2 : (byte) 1;
			workspace.aheadTouched[workspace.aheadTouchedCount++] = index;
		}
		return direct;
	}

	private boolean occupiedByAheadRival(final int x, final int y,
			final byte[] occupancy) {
		if (x < 0 || y < 0 || x > game.gameCols || y > game.gameRows)
			return false;
		return occupancy[x * (game.gameRows + 1) + y] == 2;
	}

	/** The champion's soft-priced depth-2 search (both AI bodies). Each of my
	 *  next TWO moves is searched explicitly: a {@code stepIdx == 0} landing on a
	 *  round-1 sim body is priced (+3.0, the conflict weight) rather than
	 *  hard-skipped, and a {@code stepIdx == 1} landing is priced only when the
	 *  round-2 body (the round-two occupancy map) belongs to a rival currently AHEAD of me
	 *  on track (the mover's current progress), via
	 *  {@link #occupiedByAheadRival} instead of {@link CellOccupancy#contains}.
	 *  A chaser's body is left unpriced; the precomputed verdict map threads unchanged through
	 *  the recursion. Geometry stays hard; a finish crossing escapes pricing. */
	private double searchMinTurnsSoft3(final int x, final int y, final int vx, final int vy, final int levels, final int stepIdx,
			final CellOccupancy[] predictedSteps, final int playerNum,
			final CellOccupancy occupancy, final byte[] aheadOccupancy) {
		if (levels == 0) {
			final int t = ttf(x, y, vx, vy);
			return t == Integer.MAX_VALUE ? Double.MAX_VALUE : t;
		}
		double best = Double.MAX_VALUE;
		final int sm = succMask(x, y, vx, vy);
		for (final Direction d : DIRECTIONS) {
			final int nvx = vx + d.dx, nvy = vy + d.dy;
			if ((sm & 1 << 16 + d.ordinal()) == 0)
				continue;
			final int nx = x + nvx, ny = y + nvy;
			if (game.crossesFinishLegally(x, y, nx, ny) && (!lapAware || lapGate == 0 && reach.shedableLanding(nx, ny, nvx, nvy)))
				return 1;
			if ((sm & 1 << d.ordinal()) == 0)
				continue;
			double price = 0.0;
			if (stepIdx == 0) {
				if (occupancy.contains(nx, ny))
					price = 3.0;
			} else {
				// Round 217: the predicted-occupancy veto that used to sit here
				// could not fire. predictedSteps is built one step deep
				// (predictedOpponentSteps(playerNum, 1)), so its length-1 bound
				// admits only stepIdx == 0 -- the other arm of this if/else.
				// Pricing it 0.0 through 6.0 gave byte-identical logs over
				// thirty races. Ply-1 bodies are priced through aheadOccupancy
				// below, which is live.
				if (stepIdx == 1 && aheadOccupancy != null && occupiedByAheadRival(nx, ny, aheadOccupancy))
					price = AI1_PLY2_PRICE;
			}
			final double sub = searchMinTurnsSoft3(nx, ny, nvx, nvy, levels - 1, stepIdx + 1, predictedSteps, playerNum,
					occupancy, aheadOccupancy);
			if (sub == Double.MAX_VALUE)
				continue;
			if (1.0 + price + sub < best)
				best = 1.0 + price + sub;
		}
		return best;
	}

	/** Plateau-counting twin of {@link #searchMinTurnsSoft3} (both AI bodies):
	 *  same ahead-only ply-2 pricing (at {@code stepIdx == 1} only bodies of
	 *  rivals AHEAD of me are priced), recursing into
	 *  {@link #searchMinTurnsSoft3}, and additionally reporting the plateau
	 *  width (how many follow-ups achieve the minimum) for the robustness
	 *  tie-break. The ahead-occupancy verdict map is built once by the caller. Prices stay exact small constants, so the plateau compare
	 *  remains an exact {@code ==}. */
	private double[] searchMinTurnsCountedSoft3(final int x, final int y, final int vx, final int vy, final int levels,
			final int stepIdx, final CellOccupancy[] predictedSteps, final int playerNum,
			final CellOccupancy occupancy, final byte[] aheadOccupancy) {
		double best = Double.MAX_VALUE;
		int countAtMin = 0;
		final int sm = succMask(x, y, vx, vy);
		for (final Direction d : DIRECTIONS) {
			final int nvx = vx + d.dx, nvy = vy + d.dy;
			if ((sm & 1 << 16 + d.ordinal()) == 0)
				continue;
			final int nx = x + nvx, ny = y + nvy;
			if (game.crossesFinishLegally(x, y, nx, ny) && (!lapAware || lapGate == 0 && reach.shedableLanding(nx, ny, nvx, nvy)))
				return new double[]{1, 9 };
			if ((sm & 1 << d.ordinal()) == 0)
				continue;
			double price = 0.0;
			if (stepIdx == 0) {
				if (occupancy.contains(nx, ny))
					price = 3.0;
			} else {
				// Round 217: the predicted-occupancy veto that used to sit here
				// could not fire. predictedSteps is built one step deep
				// (predictedOpponentSteps(playerNum, 1)), so its length-1 bound
				// admits only stepIdx == 0 -- the other arm of this if/else.
				// Pricing it 0.0 through 6.0 gave byte-identical logs over
				// thirty races. Ply-1 bodies are priced through aheadOccupancy
				// below, which is live.
				if (stepIdx == 1 && aheadOccupancy != null && occupiedByAheadRival(nx, ny, aheadOccupancy))
					price = AI1_PLY2_PRICE;
			}
			final double sub = searchMinTurnsSoft3(nx, ny, nvx, nvy, levels - 1, stepIdx + 1, predictedSteps, playerNum,
					occupancy, aheadOccupancy);
			if (sub == Double.MAX_VALUE)
				continue;
			final double total = 1.0 + price + sub;
			if (total < best) {
				best = total;
				countAtMin = 1;
			} else if (total == best)
				countAtMin++;
		}
		return new double[]{best, countAtMin };
	}

	/**
	 * Timing-exact variant of {@link #countFutureSafeSuccessors} (AI1
	 * frontier), used to floor the safe-successor count with the sim's
	 * optimism. The successors counted here are ply-2 questions -- moves I
	 * would make in round r+1, by which time every live opponent has moved
	 * exactly once (see {@link #simulateRoundPass} for the move-order
	 * derivation) -- so the stale-body check ({@link #isCrashingPlayer}) and
	 * the nulled prediction check are replaced by a single test against
	 * {@code occupancy}, the simulated round-step positions of all live
	 * opponents (current cells as conservative fallback where unmoved).
	 */
	private int countFutureSafeSuccessorsTimed(final int x, final int y, final int vx, final int vy,
			final CellOccupancy occupancy) {
		int count = 0;
		final int sm = succMask(x, y, vx, vy);
		for (final Direction d : DIRECTIONS) {
			final int nvx = vx + d.dx;
			final int nvy = vy + d.dy;
			if ((sm & 1 << 16 + d.ordinal()) == 0)
				continue;
			final int nx = x + nvx;
			final int ny = y + nvy;
			if (game.crossesFinishLegally(x, y, nx, ny) && (!lapAware || lapGate == 0 && reach.shedableLanding(nx, ny, nvx, nvy)))
				return 9;
			if ((sm & 1 << d.ordinal()) == 0)
				continue;
			if (occupancy.contains(nx, ny))
				continue;
			if (reach.isAlive(nx, ny, nvx, nvy))
				count++;
		}
		return count;
	}

	/**
	 * Project each live opponent forward {@code steps} of their own moves using
	 * the pure min-turns policy. {@code result[k][opponentIdx]} is that
	 * opponent's position after {@code k+1} moves (null if it can't be
	 * projected that far).
	 */
	private int[][][] predictedOpponentSteps(final int myPlayerNum, final int steps) {
		final int projectionSteps = Math.max(1, steps);
		if (predictionWorkspace == null || predictionWorkspace.result.length != projectionSteps
				|| predictionWorkspace.result[0].length != game.players.length)
			predictionWorkspace = new PredictionWorkspace(projectionSteps, game.players.length,
					game.gameCols + 1, game.gameRows + 1);
		for (final int[][] step : predictionWorkspace.result)
			java.util.Arrays.fill(step, null);
		for (final Player player : game.players) {
			if (player.getNumber() == myPlayerNum || player.isFinished())
				continue;
			int px = player.getPosition()[0], py = player.getPosition()[1];
			int pvx = player.getVelocity()[0], pvy = player.getVelocity()[1];
			final int playerIndex = player.getNumber() - 1;
			for (int step = 0; step < steps; step++) {
				final Direction direction = pureMinTurnsMove(px, py, pvx, pvy, player.getNumber());
				if (direction == null)
					break;
				final int nvx = pvx + direction.dx;
				final int nvy = pvy + direction.dy;
				if (RaceGame.aiVelocityOutOfRange(nvx, nvy))
					break;
				px += nvx;
				py += nvy;
				pvx = nvx;
				pvy = nvy;
				final int[] cell = predictionWorkspace.cells[step][playerIndex];
				cell[0] = px;
				cell[1] = py;
				predictionWorkspace.result[step][playerIndex] = cell;
			}
		}
		return predictionWorkspace.result;
	}


	private static int speedSquared(final int vx, final int vy) {
		return vx * vx + vy * vy;
	}

	static boolean isStrictlyAheadByTrackDistance(final int moverDistance,
			final int rivalDistance) {
		return moverDistance != Integer.MAX_VALUE && rivalDistance != Integer.MAX_VALUE
				&& rivalDistance < moverDistance;
	}

	static boolean useTrackDistanceForStagedLaunch(final int vx, final int vy,
			final boolean inStartZone) {
		return inStartZone && vx == 0 && vy == 0;
	}

	private static boolean squareExceeds(final long value, final long limit) {
		if (limit < 0L || value == Long.MIN_VALUE)
			return true;
		final long magnitude = Math.abs(value);
		return magnitude != 0L && magnitude > limit / magnitude;
	}

	private static long distanceSquared(final int dx, final int dy) {
		return (long) dx * dx + (long) dy * dy;
	}

	private static boolean occupiedByOther(final int x, final int y, final int self,
			final int[] px, final int[] py, final boolean[] alive) {
		for (int i = 0; i < px.length; i++)
			if (i != self && alive[i] && px[i] == x && py[i] == y)
				return true;
		return false;
	}

	private static boolean writeMove(final int[] out, final int x, final int y,
			final int vx, final int vy) {
		out[0] = x;
		out[1] = y;
		out[2] = vx;
		out[3] = vy;
		return true;
	}

	/** Greedy min-turnsToFinish move for a car at (x,y) vel (cvx,cvy) over a
	 *  DETACHED array board (alive cars at px/py). Writes {nx,ny,nvx,nvy} to
	 *  {@code out} and returns true, or returns false if boxed. */
	private boolean greedyMoveOverState(final int x, final int y, final int cvx, final int cvy, final int self,
			final int[] px, final int[] py, final boolean[] alive, final int[] out) {
		int bestT = Integer.MAX_VALUE;
		int bestX = 0, bestY = 0, bestVx = 0, bestVy = 0;
		boolean found = false;
		for (final Direction d : DIRECTIONS) {
			final int nvx = cvx + d.dx, nvy = cvy + d.dy;
			if (RaceGame.aiVelocityOutOfRange(nvx, nvy))
				continue;
			final int nx = x + nvx, ny = y + nvy;
			if (game.crossesFinishLegally(x, y, nx, ny) && crossingCountsFor(self, nx, ny, nvx, nvy)
					&& (!frameLapAware[self] || game.isMoveLegalGeometryCached(x, y, nx, ny)
							&& !occupiedByOther(nx, ny, self, px, py, alive)))
				return writeMove(out, nx, ny, nvx, nvy);
			if (!game.isMoveLegalGeometryCached(x, y, nx, ny))
				continue;
			if (occupiedByOther(nx, ny, self, px, py, alive) || !reach.isAlive(nx, ny, nvx, nvy))
				continue;
			final int turns = ttfFor(self, nx, ny, nvx, nvy);
			if (turns < bestT) {
				bestT = turns;
				bestX = nx;
				bestY = ny;
				bestVx = nvx;
				bestVy = nvy;
				found = true;
			}
		}
		return found && writeMove(out, bestX, bestY, bestVx, bestVy);
	}

	/** Count the legal, alive, unoccupied 1-step successors of (x,y,vx,vy) over
	 *  a DETACHED sim board. Stops at 3: only the trap ladder's zero-penalty
	 *  boundary (>= 3 safe successors) matters to the caller. */
	private int safeSuccessorsOverState(final int x, final int y, final int cvx, final int cvy, final int self,
			final int[] px, final int[] py, final boolean[] alive) {
		int count = 0;
		final int sm = succMask(x, y, cvx, cvy);
		for (final Direction d : DIRECTIONS) {
			final int nvx = cvx + d.dx, nvy = cvy + d.dy;
			if ((sm & 1 << 16 + d.ordinal()) == 0)
				continue;
			final int nx = x + nvx, ny = y + nvy;
			if (game.crossesFinishLegally(x, y, nx, ny) && crossingCountsFor(self, nx, ny, nvx, nvy)
					&& (!frameLapAware[self] || game.isMoveLegalGeometryCached(x, y, nx, ny)
							&& !occupiedByOther(nx, ny, self, px, py, alive)))
				return 3;
			if ((sm & 1 << d.ordinal()) == 0)
				continue;
			if (occupiedByOther(nx, ny, self, px, py, alive) || !reach.isAlive(nx, ny, nvx, nvy))
				continue;
			if (++count >= 3)
				return 3;
		}
		return count;
	}

	/** Round 51 (shared champion): MY move inside the joint rollout. The real me is the
	 *  full scorer, whose trap ladder refuses landings with <= 2 safe
	 *  successors -- so a greedy sim-self drives into boxes the real me would
	 *  never enter and simOutcome reports a FALSE death ("zandvoort s7 is
	 *  greedy-me model error, not horizon"). Maximise safe successors (capped at
	 *  3, the ladder's zero-penalty boundary), then minimise turnsToFinish -- so
	 *  among genuinely roomy landings this is exactly the greedy pace policy,
	 *  and it only diverges where the real me would have refused. Round 56:
	 *  also the RIVAL policy inside the DJS rollout (exactRivals) -- the r55
	 *  forensic proved greedy rivals dissolve every real box in-sim. */
	private boolean selfMoveOverState(final int x, final int y, final int cvx, final int cvy, final int self,
			final int[] px, final int[] py, final boolean[] alive, final int[] out) {
		int bestTier = -1, bestT = Integer.MAX_VALUE;
		int bestX = 0, bestY = 0, bestVx = 0, bestVy = 0;
		boolean found = false;
		final int sm = succMask(x, y, cvx, cvy);
		for (final Direction d : DIRECTIONS) {
			final int nvx = cvx + d.dx, nvy = cvy + d.dy;
			if ((sm & 1 << 16 + d.ordinal()) == 0)
				continue;
			final int nx = x + nvx, ny = y + nvy;
			if (game.crossesFinishLegally(x, y, nx, ny) && crossingCountsFor(self, nx, ny, nvx, nvy)
					&& (!frameLapAware[self] || game.isMoveLegalGeometryCached(x, y, nx, ny)
							&& !occupiedByOther(nx, ny, self, px, py, alive)))
				return writeMove(out, nx, ny, nvx, nvy);
			if ((sm & 1 << d.ordinal()) == 0)
				continue;
			if (occupiedByOther(nx, ny, self, px, py, alive) || !reach.isAlive(nx, ny, nvx, nvy))
				continue;
			final int tier = safeSuccessorsOverState(nx, ny, nvx, nvy, self, px, py, alive);
			final int turns = ttfFor(self, nx, ny, nvx, nvy);
			if (tier > bestTier || tier == bestTier && turns < bestT) {
				bestTier = tier;
				bestT = turns;
				bestX = nx;
				bestY = ny;
				bestVx = nvx;
				bestVy = nvy;
				found = true;
			}
		}
		return found && writeMove(out, bestX, bestY, bestVx, bestVy);
	}

	/** Round 57 (AI1): RIVAL move inside the joint rollout -- the two loudest
	 *  terms of the real scorer, correctly WEIGHTED: minimise turnsToFinish
	 *  PLUS the trap ladder of the landing (50 / 2.0 / 0.5 / 0 for 0/1/2/>=3
	 *  safe successors). The oracle forensic proved why both prior proxies
	 *  miss real kills: greedy is trap-blind, and the lexicographic selfMove
	 *  policy (tier first) REFUSES the one-lane corridor cells the real
	 *  pace-seeking scorer claims (ttf gain > trap 2.0), so neither
	 *  reconstructs the queue boxes that actually kill (silverstone s6 m145,
	 *  hungaroring s6 m181: chosen dies in 2 rounds under real-scorer rivals,
	 *  survivors exist -- both invisible under greedy AND selfMove rivals). */
	private boolean rivalMoveOverState(final int x, final int y, final int cvx, final int cvy, final int self,
			final int[] px, final int[] py, final boolean[] alive, final int[] out) {
		double bestScore = Double.MAX_VALUE;
		int bestSpd2 = -1;
		int bestX = 0, bestY = 0, bestVx = 0, bestVy = 0;
		boolean found = false;
		final int sm = succMask(x, y, cvx, cvy);
		for (final Direction d : DIRECTIONS) {
			final int nvx = cvx + d.dx, nvy = cvy + d.dy;
			if ((sm & 1 << 16 + d.ordinal()) == 0)
				continue;
			final int nx = x + nvx, ny = y + nvy;
			if (game.crossesFinishLegally(x, y, nx, ny) && crossingCountsFor(self, nx, ny, nvx, nvy)
					&& (!frameLapAware[self] || game.isMoveLegalGeometryCached(x, y, nx, ny)
							&& !occupiedByOther(nx, ny, self, px, py, alive)))
				return writeMove(out, nx, ny, nvx, nvy);
			if ((sm & 1 << d.ordinal()) == 0)
				continue;
			if (occupiedByOther(nx, ny, self, px, py, alive) || !reach.isAlive(nx, ny, nvx, nvy))
				continue;
			final int tier = safeSuccessorsOverState(nx, ny, nvx, nvy, self, px, py, alive);
			final double trap = tier == 0 ? 50.0 : tier == 1 ? AI1_TRAP_L1 : tier == 2 ? AI1_TRAP_L2 : 0.0;
			final double score = ttfFor(self, nx, ny, nvx, nvy) + trap;
			// Momentum tie-break (policy matrix "smom"): among score-equal
			// candidates the real scorer HOLDS SPEED down the racing line
			// (deep cost + momentum), so prefer the faster landing. This is
			// what reproduces the silverstone box; the trap term reproduces
			// the hungaroring corridor claim -- smom matches the real-scorer
			// reference on all four site/candidate cells of the matrix.
			final int spd2 = speedSquared(nvx, nvy);
			if (score < bestScore || score == bestScore && spd2 > bestSpd2) {
				bestScore = score;
				bestSpd2 = spd2;
				bestX = nx;
				bestY = ny;
				bestVx = nvx;
				bestVy = nvy;
				found = true;
			}
		}
		return found && writeMove(out, bestX, bestY, bestVx, bestVy);
	}

	/** Round 59: a rival's rollout move computed by its REAL scorer -- the
	 *  only world model faithful enough for the slow queue dooms (the smom
	 *  proxy drifts within ~2 rounds in dense slow traffic; oracle-validated
	 *  at the hungaroring-(64,115) pocket and the lemans-s4 start funnel,
	 *  where real-scorer rivals flag both deaths with survivors intact).
	 *  Installs the sim board into the live Player objects (the
	 *  processQueries pattern), runs the mover's own scorer with the
	 *  recursive machinery suppressed ({@code inScorerSim}), restores everything
	 *  in a finally. Writes the landing to {@code out} and returns true, or
	 *  returns false when the scorer is boxed or would enter a body/dead state. */
	private boolean scorerMoveOverState(final int i, final int[] px, final int[] py,
			final int[] vx, final int[] vy, final boolean[] alive, final int[] out,
			final RolloutWorkspace rollout) {
		return scorerMoveOverState(i, px, py, vx, vy, alive, out, rollout, true);
	}

	/** suppress=false (round 99): the rival's computeAiMove runs its FULL pace
	 *  stack -- the zandvoort-s32 killer move is a private-lane pace-arm
	 *  product, invisible to every suppressed world. The rival's own nested
	 *  sims still self-suppress (each nested scorer move re-sets the flag).
	 *  Per-depth workspaces and separately saved frames prevent the rival's
	 *  rollouts from clobbering their parent's projected state. */
	private boolean scorerMoveOverState(final int i, final int[] px, final int[] py,
			final int[] vx, final int[] vy, final boolean[] alive, final int[] out,
			final RolloutWorkspace rollout, final boolean suppress) {
		final ScorerWorkspace workspace = rollout.scorer;
		final int n = game.players.length;
		final int ss = game.subgamestate;
		final boolean previousScorerSim = inScorerSim;
		// Round 222: the rival's compute assigns ITS lap frame at entry --
		// gate, lap-awareness, robust flag, remaining events. Put the mover's
		// back afterwards, or the rest of this decision is priced on the
		// rival's map.
		final int outerLapGate = lapGate, outerExactRemaining = exactRemaining;
		final boolean outerLapAware = lapAware, outerRobustMode = robustMode;
		final int[] outerFrameGate = frameGate, outerFrameRemaining = frameRemaining;
		final boolean[] outerFrameLapAware = frameLapAware;
		final int outerTurns = game.turnCount();
		for (int j = 0; j < n; j++) {
			final Player player = game.players[j];
			workspace.originalPosition[j] = player.getPosition();
			workspace.originalVelocity[j] = player.getVelocity();
			workspace.finishedPlace[j] = player.getFinishedPlace();
			workspace.originalLapState[j] = player.lapState();
		}
		final Direction direction;
		try {
			frameGate = workspace.frameGate;
			frameRemaining = workspace.frameRemaining;
			frameLapAware = workspace.frameLapAware;
			game.setQueryTurnCounter(rollout.turns);
			for (int j = 0; j < n; j++) {
				final Player player = game.players[j];
				final int[] position = workspace.simulatedPosition[j];
				position[0] = px[j];
				position[1] = py[j];
				final int[] velocity = workspace.simulatedVelocity[j];
				velocity[0] = vx[j];
				velocity[1] = vy[j];
				player.setPosition(position);
				player.setVelocity(velocity);
				player.setFinishedPlace(alive[j] ? 0 : 77);
				player.restoreLapState(new int[]{rollout.laps[j], rollout.gates[j], 0, 0, 0, 0});
			}
			game.subgamestate = i;
			inScorerSim = suppress;
			direction = computeAiMove();
		} finally {
			inScorerSim = previousScorerSim;
			lapGate = outerLapGate;
			lapAware = outerLapAware;
			robustMode = outerRobustMode;
			exactRemaining = outerExactRemaining;
			frameGate = outerFrameGate;
			frameRemaining = outerFrameRemaining;
			frameLapAware = outerFrameLapAware;
			game.setQueryTurnCounter(outerTurns);
			for (int j = 0; j < n; j++) {
				final Player player = game.players[j];
				player.setPosition(workspace.originalPosition[j]);
				player.setVelocity(workspace.originalVelocity[j]);
				player.setFinishedPlace(workspace.finishedPlace[j]);
				player.restoreLapState(workspace.originalLapState[j]);
			}
			game.subgamestate = ss;
		}
		if (direction == null)
			return false;
		final int nvx = vx[i] + direction.dx, nvy = vy[i] + direction.dy;
		if (RaceGame.aiVelocityOutOfRange(nvx, nvy))
			return false;
		final int nx = px[i] + nvx, ny = py[i] + nvy;
		final RaceGame.MoveResult result = game.evaluateMove(rollout.laps[i], rollout.gates[i],
				px[i], py[i], nx, ny, occupiedByOther(nx, ny, i, px, py, alive));
		if (result.finishes())
			return writeMove(out, nx, ny, nvx, nvy);
		if (!result.legal() || !reach.isAlive(nx, ny, nvx, nvy))
			return false;
		return writeMove(out, nx, ny, nvx, nvy);
	}

	/** Disjoint storage for every active rollout, including suppressed nested
	 * scorers. Parent proof vectors and progress ledgers remain live. */
	private RolloutWorkspace rolloutWorkspace() {
		if (simDepth >= rolloutsByDepth.length)
			rolloutsByDepth = java.util.Arrays.copyOf(rolloutsByDepth, simDepth + 4);
		final int players = game.players.length;
		if (rolloutsByDepth[simDepth] == null || rolloutsByDepth[simDepth].px.length != players)
			rolloutsByDepth[simDepth] = new RolloutWorkspace(players);
		return rolloutsByDepth[simDepth];
	}

	/** Roll the joint game forward from MY candidate landing over a DETACHED
	 *  board copy: every car plays greedy min-turnsToFinish; move-order aware
	 *  (the first simulated round covers only the players who still move after
	 *  me this round). Returns my turnsToFinish after {@code rounds} full
	 *  rounds, or -1 if I end up boxed (no legal alive move at one of my
	 *  slots). No mutation of live players[] -- deterministic, cannot
	 *  livelock. Shared champion logic (round 40 danger joint search). */
	private int simOutcome(final int myX, final int myY, final int myVx, final int myVy,
			final int playerNum, final int rounds, final boolean simFinishVanish, final boolean exactSelf,
			final boolean exactRivals, final boolean scorerRivals) {
		return simOutcome(myX, myY, myVx, myVy, playerNum, rounds, simFinishVanish, exactSelf,
				exactRivals, scorerRivals, AI1_SCORER_MAXRIVALS, null);
	}

	private int simOutcome(final int myX, final int myY, final int myVx, final int myVy,
			final int playerNum, final int rounds, final boolean simFinishVanish, final boolean exactSelf,
			final boolean exactRivals, final boolean scorerRivals, final int scorerCap,
			final int[] outFinalTier) {
		return simOutcome(myX, myY, myVx, myVy, playerNum, rounds, simFinishVanish, exactSelf,
				exactRivals, scorerRivals, false, scorerCap, outFinalTier, null);
	}

	/** Field-neutral scorer rollout used by the private and staged pace proofs.
	 *  Naming this fixed flag bundle keeps the safety-critical call sites out of
	 *  the boolean-argument soup used by the general simulator. */
	private int scorerFieldOutcome(final int myX, final int myY, final int myVx, final int myVy,
			final int playerNum, final int rounds, final int scorerCap, final long[] outFieldCost) {
		return simOutcome(myX, myY, myVx, myVy, playerNum, rounds, true, true, true, true,
				false, scorerCap, null, outFieldCost);
	}

	/** scorerSelf (round 78): model ME with the recursion-guarded real scorer
	 *  (scorerMoveOverState) instead of the selfMove proxy -- the zandvoort
	 *  m920 survivor exists only under the champion's own continued play, so
	 *  selfMove-me kills it and survival-only switching finds nothing. */
	private int simOutcome(final int myX, final int myY, final int myVx, final int myVy,
			final int playerNum, final int rounds, final boolean simFinishVanish, final boolean exactSelf,
			final boolean exactRivals, final boolean scorerRivals, final boolean scorerSelf,
			final int scorerCap, final int[] outFinalTier) {
		return simOutcome(myX, myY, myVx, myVy, playerNum, rounds, simFinishVanish, exactSelf,
				exactRivals, scorerRivals, scorerSelf, scorerCap, outFinalTier, null);
	}

	private int simOutcome(final int myX, final int myY, final int myVx, final int myVy,
			final int playerNum, final int rounds, final boolean simFinishVanish, final boolean exactSelf,
			final boolean exactRivals, final boolean scorerRivals, final boolean scorerSelf,
			final int scorerCap, final int[] outFinalTier, final long[] outFieldCost) {
		return simOutcome(myX, myY, myVx, myVy, playerNum, rounds, simFinishVanish, exactSelf,
				exactRivals, scorerRivals, scorerSelf, false, scorerCap, outFinalTier, outFieldCost, null);
	}

	/** outThreadRounds (round 98): counts my move slots entered with at most ONE
	 *  viable candidate (legal, unoccupied, reachability-alive). An alive verdict
	 *  that threads a one-lane needle on EVERY slot is no certificate at all in
	 *  pack traffic -- chicane s51 m121 rolls alive through viable=1,1,1,1 in
	 *  every affordable rival world while the real pack's champion braking (their
	 *  own suppressed arms) seals the lane @r2; the two true survivors roll
	 *  viable>=2 on all slots in the same cheap world. The count is model-free:
	 *  no rival fidelity needed, no extra simulations, just the candidate
	 *  enumeration my own sim move already performs. */
	private int simOutcome(final int myX, final int myY, final int myVx, final int myVy,
			final int playerNum, final int rounds, final boolean simFinishVanish, final boolean exactSelf,
			final boolean exactRivals, final boolean scorerRivals, final boolean scorerSelf,
			final int scorerCap, final int[] outFinalTier, final long[] outFieldCost,
			final int[] outThreadRounds) {
		return simOutcome(myX, myY, myVx, myVy, playerNum, rounds, simFinishVanish, exactSelf,
				exactRivals, scorerRivals, scorerSelf, false, scorerCap, outFinalTier, outFieldCost,
				outThreadRounds);
	}

	/** Round 103 probe: when armed (query-sim protocol), the TOP-LEVEL
	 *  rollout prints one SIMTRACE line per mover step to stderr -- the
	 *  in-game twin of the Python roll, diffable line by line. Nested
	 *  rollouts (inside scorer/true rival computes) stay silent. */
	volatile boolean				simTrace;
	private int						simDepth;

	/** Query-sim entry (round 103): verdict of the core rollout from the
	 *  installed board, me already AT the queried landing. */
	int querySimOutcome(final int mover, final int rounds, final boolean scorerRivals,
			final boolean trueRivals, final boolean scorerSelf, final int scorerCap,
			final int[] outAudit) {
		reach.ensureReachabilityReady();
		fmMemoEpoch++;
		final Player me = game.players[mover];
		final int[] mp = me.getPosition(), mv = me.getVelocity();
		prepareDecisionFrame(mp, mv, me.getNumber());
		final int[] ft = { 3 };
		final int[] tr = { 0, 0 };
		final int v = simulate(mp[0], mp[1], mv[0], mv[1], me.getNumber(), rounds, true, true,
				true, scorerRivals, scorerSelf, trueRivals, scorerCap, ft, null, tr, false, null, false);
		if (outAudit != null) {
			outAudit[0] = ft[0];
			outAudit[1] = tr[0];
			outAudit[2] = tr[1];
		}
		return v;
	}

	/** trueRivals (round 99): scorer-set rivals run their UNSUPPRESSED real
	 *  champion -- pace arms included. Reserved for the rare bounded confirm;
	 *  cost is rivals x rounds full computeAiMove calls. */
	private int simOutcome(final int myX, final int myY, final int myVx, final int myVy,
			final int playerNum, final int rounds, final boolean simFinishVanish, final boolean exactSelf,
			final boolean exactRivals, final boolean scorerRivals, final boolean scorerSelf,
			final boolean trueRivals, final int scorerCap, final int[] outFinalTier,
			final long[] outFieldCost, final int[] outThreadRounds) {
		return simOutcome(myX, myY, myVx, myVy, playerNum, rounds, simFinishVanish,
				exactSelf, exactRivals, scorerRivals, scorerSelf, trueRivals, scorerCap,
				outFinalTier, outFieldCost, outThreadRounds, false, null);
	}

	/** allScorerRivals bypasses both the normal cap and distance filter. The
	 * optional rival-cost vector is indexed by game.players and contains -1 for
	 * the mover/already-finished drivers, 0+ personal projected moves for a live
	 * rival, or ROLLOUT_FAILURE_COST for a failed/unreachable rival. Callers that
	 * request the vector also request field cost so a mover finish does not end
	 * the rollout before rival costs are complete. */
	private int simOutcome(final int myX, final int myY, final int myVx, final int myVy,
			final int playerNum, final int rounds, final boolean simFinishVanish, final boolean exactSelf,
			final boolean exactRivals, final boolean scorerRivals, final boolean scorerSelf,
			final boolean trueRivals, final int scorerCap, final int[] outFinalTier,
			final long[] outFieldCost, final int[] outThreadRounds,
			final boolean allScorerRivals, final long[] outRivalCost) {
		return simulate(myX, myY, myVx, myVy, playerNum, rounds, simFinishVanish, exactSelf,
				exactRivals, scorerRivals, scorerSelf, trueRivals, scorerCap, outFinalTier,
				outFieldCost, outThreadRounds, allScorerRivals, outRivalCost, true);
	}

	private int simulate(final int myX, final int myY, final int myVx, final int myVy,
			final int playerNum, final int rounds, final boolean simFinishVanish, final boolean exactSelf,
			final boolean exactRivals, final boolean scorerRivals, final boolean scorerSelf,
			final boolean trueRivals, final int scorerCap, final int[] outFinalTier,
			final long[] outFieldCost, final int[] outThreadRounds,
			final boolean allScorerRivals, final long[] outRivalCost, final boolean candidatePending) {
		final int outerGate = lapGate, outerRemaining = exactRemaining;
		final boolean outerAware = lapAware, outerRobust = robustMode;
		final int[] outerGates = frameGate, outerRemainingByPlayer = frameRemaining;
		final boolean[] outerAwareByPlayer = frameLapAware;
		simDepth++;
		try {
			final RolloutWorkspace workspace = rolloutWorkspace();
			frameGate = workspace.gates;
			frameRemaining = workspace.remaining;
			frameLapAware = workspace.lapAware;
			return simOutcomeCore(myX, myY, myVx, myVy, playerNum, rounds, simFinishVanish,
					exactSelf, exactRivals, scorerRivals, scorerSelf, trueRivals, scorerCap,
					outFinalTier, outFieldCost, outThreadRounds, allScorerRivals,
					outRivalCost, candidatePending);
		} finally {
			frameGate = outerGates;
			frameRemaining = outerRemainingByPlayer;
			frameLapAware = outerAwareByPlayer;
			lapGate = outerGate;
			exactRemaining = outerRemaining;
			lapAware = outerAware;
			robustMode = outerRobust;
			simDepth--;
		}
	}

	private void updateRolloutFrame(final RolloutWorkspace workspace, final int i) {
		frameLapAware[i] = workspace.laps[i] + 1 < game.totalLaps || frameGate[i] != 0;
		frameRemaining[i] = OptimalPotential.remainingEvents(frameGate[i], workspace.laps[i], game.totalLaps);
	}

	private void usePlayerFrame(final int i) {
		lapGate = frameGate[i];
		lapAware = frameLapAware[i];
		exactRemaining = frameRemaining[i];
	}

	private int simOutcomeCore(final int myX, final int myY, final int myVx, final int myVy,
			final int playerNum, final int rounds, final boolean simFinishVanish, final boolean exactSelf,
			final boolean exactRivals, final boolean scorerRivals, final boolean scorerSelf,
			final boolean trueRivals, final int scorerCap, final int[] outFinalTier,
			final long[] outFieldCost, final int[] outThreadRounds,
			final boolean allScorerRivals, final long[] outRivalCost, final boolean candidatePending) {
		final RolloutWorkspace workspace = rolloutWorkspace();
		final int[] px = workspace.px;
		final int[] py = workspace.py;
		final int[] vx = workspace.vx;
		final int[] vy = workspace.vy;
		final boolean[] alive = workspace.alive;
		final boolean[] scorerSet = workspace.scorerSet;
		final int[] projectedMoves = workspace.projectedMoves;
		final int[] move = workspace.move;
		workspace.turns = game.turnCount();
		java.util.Arrays.fill(scorerSet, false);
		if (outRivalCost != null) {
			if (outRivalCost.length < game.players.length)
				throw new IllegalArgumentException("rival-cost vector shorter than roster");
			java.util.Arrays.fill(outRivalCost, ROLLOUT_NOT_LIVE_COST);
			java.util.Arrays.fill(projectedMoves, 0);
		}
		if (outFieldCost != null)
			outFieldCost[0] = 0L;
		long failedRivalCost = 0L;
		boolean myFinished = false;
		int myIdx = 0;
		for (int i = 0; i < game.players.length; i++) {
			final Player player = game.players[i];
			final int[] position = player.getPosition();
			final int[] velocity = player.getVelocity();
			px[i] = position[0];
			py[i] = position[1];
			vx[i] = velocity[0];
			vy[i] = velocity[1];
			alive[i] = !player.isFinished();
			workspace.laps[i] = player.getLap();
			workspace.gates[i] = game.lapGates == null ? 0 : player.getNextGate();
			updateRolloutFrame(workspace, i);
			if (player.getNumber() == playerNum)
				myIdx = i;
		}
		if (candidatePending) {
			final RaceGame.MoveResult candidate = game.evaluateMove(workspace.laps[myIdx], workspace.gates[myIdx],
					px[myIdx], py[myIdx], myX, myY, occupiedByOther(myX, myY, myIdx, px, py, alive));
			if (!candidate.legal())
				return -1;
			workspace.laps[myIdx] = candidate.lapAfter();
			workspace.gates[myIdx] = game.lapGates == null ? 0 : candidate.gateAfter();
			updateRolloutFrame(workspace, myIdx);
			workspace.turns++;
			if (candidate.finishes() && simFinishVanish) {
				alive[myIdx] = false;
				myFinished = true;
				if (outFinalTier != null)
					outFinalTier[0] = 3;
				if (outFieldCost == null && outRivalCost == null)
					return 0;
			}
		}
		px[myIdx] = myX;
		py[myIdx] = myY;
		vx[myIdx] = myVx;
		vy[myIdx] = myVy;
		if (outRivalCost != null)
			for (int i = 0; i < game.players.length; i++)
				if (i != myIdx && alive[i])
					outRivalCost[i] = ROLLOUT_FAILURE_COST;
		// Round 59: slow-class fires roll the nearest rivals with their REAL
		// scorer (recursion-guarded); the rest keep the smom proxy.
		// Membership is fixed at rollout start: the nearest
		// AI1_SCORER_MAXRIVALS within Chebyshev AI1_SCORER_NEAR.
		if (scorerRivals && allScorerRivals) {
			for (int i = 0; i < game.players.length; i++)
				if (i != myIdx && alive[i])
					scorerSet[i] = true;
		} else if (scorerRivals) {
			// Round 102: for TRUE-RIVAL confirms only, the membership radius
			// scales with MY speed -- monza s80 commits at spd-inf 10 toward a
			// braking car 11 cells downstream; a fixed Chebyshev-10 net can
			// never contain the rivals a fast landing reaches within the
			// horizon. Suppressed worlds keep the pinned radius (a global
			// change slowed the round-96 coil finish frontier by four moves).
			final int spdInf = Math.max(Math.abs(myVx), Math.abs(myVy));
			final int scorerNear = trueRivals ? Math.max(AI1_SCORER_NEAR, 2 * spdInf)
					: AI1_SCORER_NEAR;
			for (int k = 0; k < scorerCap; k++) {
				int nearest = -1, nearestD = scorerNear + 1;
				for (int j = 0; j < game.players.length; j++) {
					if (j == myIdx || !alive[j] || scorerSet[j])
						continue;
					final int distance = Math.max(Math.abs(px[j] - myX), Math.abs(py[j] - myY));
					if (distance < nearestD) {
						nearestD = distance;
						nearest = j;
					}
				}
				if (nearest < 0)
					break;
				scorerSet[nearest] = true;
			}
		}
		final boolean trace = simTrace && simDepth == 1;
		if (trace) {
			final StringBuilder sb = new StringBuilder("SIMTRACE start me=i").append(myIdx)
					.append(" (").append(myX).append(',').append(myY).append(")v(")
					.append(myVx).append(',').append(myVy).append(") scorerSet=");
			for (int i = 0; i < game.players.length; i++)
				if (scorerSet[i])
					sb.append('i').append(i).append(' ');
			System.err.println(sb);
		}
		for (int round = 0; round < rounds; round++) {
			// First simulated round: only players after me in this real round's
			// move order still move before my next slot.
			final int from = round == 0 ? game.subgamestate + 1 : 0;
			for (int i = from; i < game.players.length; i++) {
				if (!alive[i] || i == myIdx && round == 0)
					continue;
				usePlayerFrame(i);
				if (outRivalCost != null && i != myIdx)
					projectedMoves[i]++;
				if (i == myIdx && outThreadRounds != null) {
					int viable = 0;
					for (final Direction d : DIRECTIONS) {
						final int tvx = vx[i] + d.dx, tvy = vy[i] + d.dy;
						if (RaceGame.aiVelocityOutOfRange(tvx, tvy))
							continue;
						final int tx = px[i] + tvx, ty = py[i] + tvy;
						if (game.evaluateMove(workspace.laps[i], workspace.gates[i], px[i], py[i], tx, ty,
								occupiedByOther(tx, ty, i, px, py, alive)).finishes()) {
							viable = DIRECTIONS.length;
							break;
						}
						if (!game.isMoveLegalGeometryCached(px[i], py[i], tx, ty))
							continue;
						if (occupiedByOther(tx, ty, i, px, py, alive)
								|| !reach.isAlive(tx, ty, tvx, tvy))
							continue;
						viable++;
					}
					if (viable <= 1)
						outThreadRounds[0]++;
					if (viable <= 2 && outThreadRounds.length > 1)
						outThreadRounds[1]++;
				}
				// Round 51: my car follows the trap-aware policy. Round 57:
				// rivals use the score-shaped ttf + trap proxy; selected close
				// rivals instead use their recursion-guarded real scorer.
				final boolean moved;
				if (i == myIdx)
					moved = scorerSelf
							? scorerMoveOverState(i, px, py, vx, vy, alive, move, workspace)
							: exactSelf
									? selfMoveOverState(px[i], py[i], vx[i], vy[i], i, px, py, alive, move)
									: greedyMoveOverState(px[i], py[i], vx[i], vy[i], i, px, py, alive, move);
				else if (scorerSet[i])
					moved = scorerMoveOverState(i, px, py, vx, vy, alive, move, workspace,
							!trueRivals);
				else if (exactRivals)
					moved = rivalMoveOverState(px[i], py[i], vx[i], vy[i], i, px, py, alive, move);
				else
					moved = greedyMoveOverState(px[i], py[i], vx[i], vy[i], i, px, py, alive, move);
				final RaceGame.MoveResult transition = moved
						? game.evaluateMove(workspace.laps[i], workspace.gates[i], px[i], py[i], move[0], move[1],
								occupiedByOther(move[0], move[1], i, px, py, alive)) : null;
				final boolean timedOut = game.lapGates != null
						&& workspace.turns > (long) game.totalLaps * 750 * game.players.length;
				workspace.turns++;
				if (trace)
					System.err.println("SIMTRACE r=" + round + " i=" + i + " "
							+ (i == myIdx ? (scorerSelf ? "scorerME" : exactSelf ? "selfME" : "greedyME")
									: scorerSet[i] ? (trueRivals ? "TRUE" : "scorer")
											: exactRivals ? "smom" : "greedy")
							+ " (" + px[i] + "," + py[i] + ")v(" + vx[i] + "," + vy[i] + ") -> "
							+ (!moved ? "STUCK"
									: "(" + move[0] + "," + move[1] + ")v(" + move[2] + "," + move[3]
											+ ")" + (timedOut ? " TIMEOUT" : !transition.legal() ? " CRASH"
													: transition.finishes() ? " FINISH" : transition.lapCross() ? " LAP" : "")
											+ " progress=" + transition.lapAfter() + "," + transition.gateAfter()));
				// Round 223: only a FINISHING crossing takes the car off the board
				// -- final lap, nothing owed, in the crosser's own frame; a lap
				// scored or a stray crossing keeps it in the race.
				if (simFinishVanish && !timedOut && moved && transition.finishes()) {
					alive[i] = false;
					if (i == myIdx) {
						if (outFinalTier != null)
							outFinalTier[0] = 3;
						if (outFieldCost == null)
							return 0;
						myFinished = true;
					} else if (outRivalCost != null)
						outRivalCost[i] = projectedMoves[i];
					continue;
				}
				if (!moved || timedOut || !transition.legal()) {
					if (i == myIdx)
						return -1;
					alive[i] = false;
					if (outFieldCost != null)
						failedRivalCost += ROLLOUT_FAILURE_COST;
					continue;
				}
				workspace.laps[i] = transition.lapAfter();
				workspace.gates[i] = game.lapGates == null ? 0 : transition.gateAfter();
				updateRolloutFrame(workspace, i);
				px[i] = move[0];
				py[i] = move[1];
				vx[i] = move[2];
				vy[i] = move[3];
			}
		}
		if (outFieldCost != null || outRivalCost != null) {
			long fieldCost = failedRivalCost;
			for (int i = 0; i < game.players.length; i++) {
				if (i == myIdx || !alive[i])
					continue;
				final int turns = ttfFor(i, px[i], py[i], vx[i], vy[i]);
				final long terminalCost = turns == Integer.MAX_VALUE
						? ROLLOUT_FAILURE_COST : turns;
				fieldCost += terminalCost;
				if (outRivalCost != null)
					outRivalCost[i] = terminalCost == ROLLOUT_FAILURE_COST
							? ROLLOUT_FAILURE_COST : projectedMoves[i] + terminalCost;
			}
			if (outFieldCost != null)
				outFieldCost[0] = fieldCost;
		}
		usePlayerFrame(myIdx);
		// Round 65: a surviving-but-fragile final (tier <= 1) is the
		// escalation signal for the 5-7-round doom class.
		if (outFinalTier != null && !myFinished)
			outFinalTier[0] = safeSuccessorsOverState(px[myIdx], py[myIdx], vx[myIdx], vy[myIdx],
					myIdx, px, py, alive);
		return myFinished ? 0 : ttf(px[myIdx], py[myIdx], vx[myIdx], vy[myIdx]);
	}

	/** Danger joint search (round 40, shared champion): if the chosen landing DIES in
	 *  the joint rollout, switch to the surviving candidate with the best
	 *  sim-final turnsToFinish; keep the chosen move in every other case. */
	private Direction dangerJointSearch(final int[] pos, final int[] vel, final int playerNum,
			final Direction chosen, final boolean simFinishVanish, final boolean exactSelf,
			final boolean exactRivals, final boolean scorerRivals, final int rounds) {
		return dangerJointSearch(pos, vel, playerNum, chosen, simFinishVanish, exactSelf,
				exactRivals, scorerRivals, rounds, AI1_SCORER_MAXRIVALS);
	}

	private Direction dangerJointSearch(final int[] pos, final int[] vel, final int playerNum,
			final Direction chosen, final boolean simFinishVanish, final boolean exactSelf,
			final boolean exactRivals, final boolean scorerRivals, final int rounds, final int scorerCap) {
		return dangerJointSearch(pos, vel, playerNum, chosen, simFinishVanish, exactSelf,
				exactRivals, scorerRivals, rounds, scorerCap, false);
	}

	private Direction dangerJointSearch(final int[] pos, final int[] vel, final int playerNum,
			final Direction chosen, final boolean simFinishVanish, final boolean exactSelf,
			final boolean exactRivals, final boolean scorerRivals, final int rounds, final int scorerCap,
			final boolean scorerSelf) {
		return dangerJointSearch(pos, vel, playerNum, chosen, simFinishVanish, exactSelf,
				exactRivals, scorerRivals, rounds, scorerCap, scorerSelf, false);
	}

	private Direction dangerJointSearch(final int[] pos, final int[] vel, final int playerNum,
			final Direction chosen, final boolean simFinishVanish, final boolean exactSelf,
			final boolean exactRivals, final boolean scorerRivals, final int rounds, final int scorerCap,
			final boolean scorerSelf, final boolean threadCheck) {
		return dangerJointSearch(pos, vel, playerNum, chosen, simFinishVanish, exactSelf,
				exactRivals, scorerRivals, rounds, scorerCap, scorerSelf, threadCheck, false);
	}

	private Direction dangerJointSearch(final int[] pos, final int[] vel, final int playerNum,
			final Direction chosen, final boolean simFinishVanish, final boolean exactSelf,
			final boolean exactRivals, final boolean scorerRivals, final int rounds, final int scorerCap,
			final boolean scorerSelf, final boolean threadCheck, final boolean trueConfirm) {
		return dangerJointSearch(pos, vel, playerNum, chosen, simFinishVanish, exactSelf,
				exactRivals, scorerRivals, rounds, scorerCap, scorerSelf, threadCheck, trueConfirm,
				true, false);
	}

	/** corrLeg=false (round 105): suppress the corridor fragility leg --
	 *  thread-plus-bodies is ubiquitous at dense-pack ESC fires and switch
	 *  churn there broke the mixed-safety pin; the slow and deep legs stay. */
	private Direction dangerJointSearch(final int[] pos, final int[] vel, final int playerNum,
			final Direction chosen, final boolean simFinishVanish, final boolean exactSelf,
			final boolean exactRivals, final boolean scorerRivals, final int rounds, final int scorerCap,
			final boolean scorerSelf, final boolean threadCheck, final boolean trueConfirm,
			final boolean corrLeg, final boolean pairRisk) {
		return dangerJointSearch(pos, vel, playerNum, chosen, simFinishVanish, exactSelf, exactRivals,
				scorerRivals, rounds, scorerCap, scorerSelf, threadCheck, trueConfirm, corrLeg,
				pairRisk, false);
	}

	private Direction dangerJointSearch(final int[] pos, final int[] vel, final int playerNum,
			final Direction chosen, final boolean simFinishVanish, final boolean exactSelf,
			final boolean exactRivals, final boolean scorerRivals, final int rounds, final int scorerCap,
			final boolean scorerSelf, final boolean threadCheck, final boolean trueConfirm,
			final boolean corrLeg, final boolean pairRisk, final boolean fastSlow) {
		final int cvx = vel[0] + chosen.dx, cvy = vel[1] + chosen.dy;
		final int cx = pos[0] + cvx, cy = pos[1] + cvy;
		if (game.crossesFinishLegally(pos[0], pos[1], cx, cy))
			return chosen;
		final boolean audit = threadCheck || trueConfirm || fastSlow;
		final int[] threadRounds = audit ? new int[2] : null;
		final int[] finalTier = audit ? rolloutWorkspace().finalTier : null;
		if (finalTier != null)
			finalTier[0] = 3;
		boolean trueDead = false;
		final int chosenT = simOutcome(cx, cy, cvx, cvy, playerNum, rounds, simFinishVanish, exactSelf,
				exactRivals, scorerRivals, scorerSelf, scorerCap, finalTier, null, threadRounds);
		if (chosenT >= 0) {
			// Round 99: fragile alive verdict in pack traffic -> confirm the
			// chosen with two rounds of FULL-FIDELITY rivals. The suppressed
			// world's blind spot is the rivals' own pace arms (zandvoort s32:
			// the killer move is a private-lane override); tier<=1 plus at
			// least one threaded slot plus a body on the neutral grid is the
			// measured signature of the two doom decisions, at ~0.25 fires
			// per race elsewhere.
			// Round 100: the tier<=1 leg dropped -- zandvoort s74 (the second
			// specimen of the corridor class) carries thread=1 with a HEALTHY
			// final tier at its last avoidable move; the widened predicate
			// (any threaded slot + a body on the neutral grid) measured 0
			// fires outside zandvoort across the healthy sample.
			// Round 104: THREE fragility legs, each measured surgical:
			// corridor (r99/r100, thread + neutral-grid body -> the proven
			// true-4 check, unchanged); slow-pack (thread>=2 AND snug>=3,
			// ~1/race at the threadPack fallback -- monaco s88 m54 is
			// invisible to every other tell); deep-tier (final tier<=1 with
			// NO thread at ~0.13/race -- zandvoort s88 m96, box @true-r5).
			// The new legs pay a cost ladder: the suppressed 8-round
			// certification-cap world first (~100ms), true rivals only on a
			// kill; the deep leg verifies at 6 true rounds.
			final boolean legCorr = trueConfirm && corrLeg && threadRounds != null
					&& threadRounds[0] >= 1
					&& countRivalsWithinCheb(pos[0] + vel[0], pos[1] + vel[1], playerNum, 1) >= 1;
			final boolean legSlow = trueConfirm && threadRounds != null
					&& threadRounds[0] >= 2 && threadRounds[1] >= 2;
			final boolean legDeep = trueConfirm && threadRounds != null && finalTier != null
					&& finalTier[0] <= 1 && threadRounds[0] == 0;
			// Round 114: the pair-squeeze leg -- armed by the call site when a
			// fast L2 landing has a rival within Chebyshev 2; detection is the
			// 3-round scorer world at the default cap (probe-verified to kill
			// silverstone-s167 m157 and keep its survivor), verification the
			// standard true-rival confirm.
			final boolean legPair = trueConfirm && pairRisk;
			// Round 128: the fast FINISH-FUNNEL leg -- mixed-lemans kills at
			// one commitment per crash seed: a fast landing into the terminal
			// funnel where the field compresses onto the finish. Signature =
			// the slow-pack thread tell (thread>=2, snug>=2) PLUS a sim
			// horizon already inside the finish approach (chosen final ttf <=
			// AI1_FASTSLOW_TTF; monaco mid-race crowds sit at ttf 14+, so the
			// horizon bounds arming to ~5/race there and ~0 elsewhere). The
			// scorer screen is blind here (scorer-3 alive on the doomed line),
			// so the confirm is the direct true-rival check at the
			// certification cap -- audited at ZERO false kills across every
			// signature fire on monaco/mxmonaco/hungaroring, killing exactly
			// the class commitments (both the tier=1 and tier=3 siblings).
			final boolean legFastSlow = fastSlow && threadRounds != null
					&& threadRounds[0] >= 2 && threadRounds[1] >= 2
					&& chosenT <= AI1_FASTSLOW_TTF;
			// Round 133: the vmax overspeed deep check -- every harvest-25
			// slow-track crash is one serpentine2 commitment: accelerating to
			// max-axis 11 on the bottom straight is a 5-9-round joint doom
			// (the reach map holds a solo escape; traffic occupies it). The
			// smom fire carries no tell and even the true confirm worlds read
			// the doomed line alive; the deep suppressed world at the
			// certification cap is the one shipped world that kills it, so
			// the confirm rides it alone (r107 single-world precedent). Armed
			// on ACCELERATION into the band at this depth for every entry
			// path (the commitments route via the deep-pack escalation, not
			// the fallback); measured zero false kills and wall-free.
			// The doom needs a TRAIN: without a rival close behind or alongside
			// there is nobody to seal the escape rows, and the deep world's
			// pessimism false-killed a lone-runner line on 4-player lemans
			// (golden lemans-s1-4p, outcome-identical but trajectory-diverged).
			// The three commitments carry rivals at Chebyshev 1, 2 and 5.
			final boolean legFastV = Math.max(Math.abs(cvx), Math.abs(cvy)) >= AI1_FASTV_MAX
					&& Math.max(Math.abs(cvx), Math.abs(cvy)) > Math.max(Math.abs(vel[0]),
							Math.abs(vel[1]))
					&& countRivalsWithinCheb(pos[0], pos[1], playerNum, AI1_FASTV_PACK_R) >= 1;
			// Round 175: the hold-overspeed check -- harvest-30's cross-track
			// family HOLDS max-axis 10 down a straight (no acceleration, so
			// the round-133 arm never sees it) and dies 4-7 oracle rounds
			// out; one-unit deviations survive. The CHEAP slow world (smoke
			// shape: 5 rounds, cap 3) kills both reachable commitments and
			// measured ZERO false deads across 1459 probed fires on eight
			// tracks -- cheaper AND cleaner than the certification cap,
			// whose serpentine2 hold false-positives vanish at cap 3.
			// In OR LEAVING the top band: the rand16-s43 sibling commits by
			// DECELERATING 10->9 at the same straight-end (dies @r8, holding
			// 10 survives) -- the cheap world kills it too; only the arm
			// missed it.
			// EXACTLY the 10-band: at max-axis 11-12 the cheap world
			// false-killed a surviving braking line in mixed-front lemans s7
			// (m246, the round-93 pin race) -- that regime belongs to the
			// round-133 cert-cap leg; the harvest-30 commitments all live at
			// 10 (hold) or 9-leaving-10 (decel).
			// Train bar at Chebyshev 3: the commitments carry their pressing
			// rival at 1 (rand16 s31, two adjacent), 3 (s43) -- and the tight
			// bar cuts the speed-10-native cruise flood roughly in half.
			final boolean legHoldV = (Math.max(Math.abs(cvx), Math.abs(cvy)) == AI1_HOLDV_MAX
					|| Math.max(Math.abs(cvx), Math.abs(cvy)) == AI1_HOLDV_MAX - 1
							&& Math.max(Math.abs(vel[0]), Math.abs(vel[1])) >= AI1_HOLDV_MAX)
					&& countRivalsWithinCheb(pos[0], pos[1], playerNum, 3) >= 1;
			// Round 176: the 11-12 HOLD band (accel stays with the round-133
			// leg). lobe5-s35 holds 11 and dies @r4 with every scorer world
			// alive -- but the scorer-8 audit is loud (thread 4/7) and the
			// true world kills. Audit-only s8: its one band DEAD verdict
			// sits in the round-93 pin race, which survives it, so only
			// alive-with-thread>=4 escalates to the true-4 verdict; probe:
			// zero escalations in 282 canon band fires. No train bar -- the
			// lobe5 rival is 11 away; the thread tell is the selectivity.
			final boolean legHold11 = Math.max(Math.abs(cvx), Math.abs(cvy)) >= AI1_FASTV_MAX
					&& Math.max(Math.abs(cvx), Math.abs(cvy)) <= Math.max(Math.abs(vel[0]),
							Math.abs(vel[1]));
			if ((legCorr || legSlow || legDeep || legPair || legFastSlow || legFastV || legHoldV
					|| legHold11)
					&& trueConfirmDepth < AI1_TRUE_CONFIRM_MAXDEPTH) {
				trueConfirmDepth++;
				try {
					// Round 103: confirms ALWAYS run the certification cap --
					// zigzag s76 m234 is true-alive at cap 3 (the smom flow of
					// the uncapped cars hands the key rival a context where it
					// vacates the kill cell) and true-DEAD at cap 6, matching
					// the offline all-champion roll and the real race.
					final int confirmCap = Math.max(scorerCap, AI1_DEEP_CERT_RIVALS);
					if (legFastSlow) {
						trueDead = simOutcome(cx, cy, cvx, cvy, playerNum, AI1_TRUE_CONFIRM_ROUNDS,
								simFinishVanish, exactSelf, exactRivals, true, scorerSelf, true,
								confirmCap, null, null, null) < 0;
					} else if (legFastV) {
						trueDead = simOutcome(cx, cy, cvx, cvy, playerNum, AI1_DEEP_HORIZON,
								simFinishVanish, exactSelf, exactRivals, true, scorerSelf, false,
								confirmCap, null, null, null) < 0;
					} else if (legHoldV || legHold11) {
						final long hvKey = ((long) playerNum << 40) | reach.aliveIdx(cx, cy, cvx, cvy);
						final int hvSlot = (int) (hvKey * 0x9E3779B97F4A7C15L >>> 52);
						if (holdVMemoEpochs[hvSlot] == fmMemoEpoch && holdVMemoKeys[hvSlot] == hvKey) {
							trueDead = holdVMemoVals[hvSlot] != 0;
						} else {
							if (legHoldV) {
								trueDead = simOutcome(cx, cy, cvx, cvy, playerNum,
										AI1_DJS_SLOW_ROUNDS, simFinishVanish, exactSelf,
										exactRivals, true, scorerSelf, false,
										AI1_SCORER_MAXRIVALS, null, null, null) < 0;
							} else {
								final int[] h11Tr = { 0, 0 };
								simOutcome(cx, cy, cvx, cvy, playerNum,
										AI1_DEEP_HORIZON, simFinishVanish, exactSelf, exactRivals,
										true, scorerSelf, false, confirmCap, null, null, h11Tr);
								// Round 177: the s8 verdict is ignored entirely (both
								// worlds false-kill the round-93 pin fire, thread=1);
								// the THREAD level is the separator -- pin 1, the
								// lobe5 siblings 3 and 4, canon 279x0/3x1 -- so the
								// true-4 verdict runs at thread >= 2.
								trueDead = h11Tr[0] >= 2
										&& simOutcome(cx, cy, cvx, cvy, playerNum,
												AI1_TRUE_CONFIRM_ROUNDS, simFinishVanish,
												exactSelf, exactRivals, true, scorerSelf, true,
												confirmCap, null, null, null) < 0;
							}
							holdVMemoKeys[hvSlot] = hvKey;
							holdVMemoVals[hvSlot] = (byte) (trueDead ? 1 : 0);
							holdVMemoEpochs[hvSlot] = fmMemoEpoch;
						}
					} else if (legPair && !legCorr && !legSlow && !legDeep) {
						trueDead = simOutcome(cx, cy, cvx, cvy, playerNum, rounds,
								simFinishVanish, exactSelf, exactRivals, true, scorerSelf, false,
								AI1_SCORER_MAXRIVALS, null, null, null) < 0
								&& simOutcome(cx, cy, cvx, cvy, playerNum, AI1_TRUE_CONFIRM_ROUNDS,
										simFinishVanish, exactSelf, exactRivals, true, scorerSelf,
										true, confirmCap, null, null, null) < 0;
					} else if (legCorr) {
						trueDead = simOutcome(cx, cy, cvx, cvy, playerNum, AI1_TRUE_CONFIRM_ROUNDS,
								simFinishVanish, exactSelf, exactRivals, true, scorerSelf, true,
								confirmCap, null, null, null) < 0;
					} else if (legSlow && !corrLeg) {
						// Round 107: at the ESC route the suppressed deep world
						// is blind (hungaroring s144 m26: scorer-8 alive, true-5
						// dead) -- true rivals directly, 5 rounds. Gated to the
						// exact s144 signature (thread==2, snug==2, healthy tier;
						// 0-3 fires/race) -- the wider slice cost +70% wall time.
						trueDead = threadRounds[0] == 2 && threadRounds[1] == 2
								&& finalTier != null && finalTier[0] >= 3
								&& simOutcome(cx, cy, cvx, cvy, playerNum, 5,
										simFinishVanish, exactSelf, exactRivals, true, scorerSelf,
										true, confirmCap, null, null, null) < 0;
					} else {
						trueDead = simOutcome(cx, cy, cvx, cvy, playerNum, AI1_DEEP_HORIZON,
								simFinishVanish, exactSelf, exactRivals, true, scorerSelf, false,
								confirmCap, null, null, null) < 0
								&& simOutcome(cx, cy, cvx, cvy, playerNum,
										legDeep ? AI1_TRUE_CONFIRM_DEEP_ROUNDS
												: AI1_TRUE_CONFIRM_ROUNDS,
										simFinishVanish, exactSelf, exactRivals, true, scorerSelf,
										true, confirmCap, null, null, null) < 0;
					}
				} finally {
					trueConfirmDepth--;
				}
				if (AI_DEBUG_DJS || AI_DEBUG_PLAYER == playerNum)
					System.err.println("AIDBG TRUECONF p=" + playerNum + " pos=(" + pos[0] + ","
							+ pos[1] + ") chosen=" + chosen + " tier="
							+ (finalTier != null ? finalTier[0] : -1) + " thread="
							+ (threadRounds != null ? threadRounds[0] : -1) + " -> true rivals "
							+ (trueDead ? "KILL @" + AI1_TRUE_CONFIRM_ROUNDS + "r, switching"
									: "keep alive"));
			}
			if (!trueDead) {
			// Round 98 (AI1): an alive verdict that entered EVERY simulated move
			// slot with at most one viable candidate is a single-file needle
			// through traffic, not a survival proof -- the exact chicane-s51
			// signature. Switch only to an alternative that is BOTH alive and
			// non-threaded in the same world; if none exists, keep the chosen
			// (survival-only asymmetry preserved: no untreaded rescue, no churn).
			if (!threadCheck || threadRounds == null || threadRounds[0] < rounds - 1)
				return chosen;
			final boolean tdbg = AI_DEBUG_DJS || AI_DEBUG_PLAYER == playerNum;
			if (tdbg)
				System.err.println("AIDBG THREAD p=" + playerNum + " pos=(" + pos[0] + "," + pos[1]
						+ ") chosen=" + chosen + " alive but viable<=1 on " + threadRounds[0]
						+ "/" + (rounds - 1) + " slots -> robust alternative search");
			Direction robust = null;
			int robustT = Integer.MAX_VALUE;
			for (final Direction d : DIRECTIONS) {
				if (d == chosen)
					continue;
				final int nvx = vel[0] + d.dx, nvy = vel[1] + d.dy;
				if (RaceGame.aiVelocityOutOfRange(nvx, nvy))
					continue;
				final int nx = pos[0] + nvx, ny = pos[1] + nvy;
				if (game.crossesFinishLegally(pos[0], pos[1], nx, ny))
					return d;
				if (!game.isMoveLegalGeometryCached(pos[0], pos[1], nx, ny))
					continue;
				if (game.isCrashingPlayer(nx, ny, playerNum))
					continue;
				if (!reach.isAlive(nx, ny, nvx, nvy))
					continue;
				threadRounds[0] = 0;
				threadRounds[1] = 0;
				final int t = simOutcome(nx, ny, nvx, nvy, playerNum, rounds, simFinishVanish, exactSelf,
						exactRivals, scorerRivals, scorerSelf, scorerCap, null, null, threadRounds);
				if (tdbg)
					System.err.println("AIDBG THREAD  alt " + d + " land=(" + nx + "," + ny + ") simT="
							+ (t < 0 ? "DIES" : String.valueOf(t)) + " thread=" + threadRounds[0]);
				if (t >= 0 && threadRounds[0] < rounds - 1 && t < robustT) {
					robustT = t;
					robust = d;
				}
			}
			if (tdbg)
				System.err.println("AIDBG THREAD  -> " + (robust != null
						? "SWITCH " + robust + " simT=" + robustT : "KEEP " + chosen + " (no robust)"));
			return robust != null ? robust : chosen;
			}
		}
		final boolean dbg = AI_DEBUG_DJS || AI_DEBUG_PLAYER == playerNum;
		// Round 102 (AI1): a cheap-dead chosen in a confirm-capable context
		// must not hand the race to a cheap-alive-but-truly-dead switch
		// target -- zigzag s76 m234: the scorer world kills the TRUE
		// survivor E and its switch picks NE, which real rivals kill in two
		// rounds. Confirm targets exactly as the fragile-alive path does.
		if (trueConfirm && trueConfirmDepth < AI1_TRUE_CONFIRM_MAXDEPTH)
			trueDead = true;
		if (dbg)
			System.err.println("AIDBG DJS p=" + playerNum + " pos=(" + pos[0] + "," + pos[1] + ") vel=(" + vel[0]
					+ "," + vel[1] + ") chosen=" + chosen + " DIES in-sim");
		Direction best = null;
		int bestT = Integer.MAX_VALUE;
		final boolean[] rejected = new boolean[DIRECTIONS.length];
		for (final Direction d : DIRECTIONS) {
			if (d == chosen)
				continue;
			final int nvx = vel[0] + d.dx, nvy = vel[1] + d.dy;
			if (RaceGame.aiVelocityOutOfRange(nvx, nvy))
				continue;
			final int nx = pos[0] + nvx, ny = pos[1] + nvy;
			if (game.crossesFinishLegally(pos[0], pos[1], nx, ny))
				return d;
			if (!game.isMoveLegalGeometryCached(pos[0], pos[1], nx, ny))
				continue;
			if (game.isCrashingPlayer(nx, ny, playerNum))
				continue;
			if (!reach.isAlive(nx, ny, nvx, nvy))
				continue;
			final int t = simOutcome(nx, ny, nvx, nvy, playerNum, rounds, simFinishVanish, exactSelf, exactRivals,
					scorerRivals, scorerSelf, scorerCap, null);
			if (dbg)
				System.err.println("AIDBG DJS  alt " + d + " land=(" + nx + "," + ny + ") simT="
						+ (t < 0 ? "DIES" : String.valueOf(t)));
			if (t >= 0 && t < bestT) {
				bestT = t;
				best = d;
			}
		}
		if (trueDead && best != null) {
			// Round 99: the cheap world proposed the switch target; make the
			// target itself survive the true-rival world too (a cheap-alive
			// but truly-dead escape would trade one crash for another). Walk
			// candidates by cheap sim-final ttf, first true-survivor wins.
			Direction confirmed = null;
			for (int pass = 0; pass < DIRECTIONS.length && confirmed == null; pass++) {
				Direction cand = null;
				int candT = Integer.MAX_VALUE;
				int candSpd = Integer.MAX_VALUE;
				for (final Direction d : DIRECTIONS) {
					if (d == chosen || rejected[d.ordinal()])
						continue;
					final int nvx = vel[0] + d.dx, nvy = vel[1] + d.dy;
					if (RaceGame.aiVelocityOutOfRange(nvx, nvy))
						continue;
					final int nx = pos[0] + nvx, ny = pos[1] + nvy;
					if (!game.isMoveLegalGeometryCached(pos[0], pos[1], nx, ny)
							|| game.isCrashingPlayer(nx, ny, playerNum)
							|| !reach.isAlive(nx, ny, nvx, nvy)
							|| game.crossesFinishLegally(pos[0], pos[1], nx, ny))
						continue;
					final int t = simOutcome(nx, ny, nvx, nvy, playerNum, rounds, simFinishVanish,
							exactSelf, exactRivals, scorerRivals, scorerSelf, scorerCap, null);
					// Round 105: slower-first -- the shelf invariant governs
					// switch targets too: a fast sibling passing both ladder
					// worlds can still be a depth-7 doom (zandvoort s128).
					final int spd = Math.max(Math.abs(nvx), Math.abs(nvy));
					if (t >= 0 && (spd < candSpd || spd == candSpd && t < candT)) {
						candT = t;
						candSpd = spd;
						cand = d;
					}
				}
				if (cand == null)
					break;
				final int ncvx = vel[0] + cand.dx, ncvy = vel[1] + cand.dy;
				trueConfirmDepth++;
				final boolean survives;
				try {
					survives = simOutcome(pos[0] + ncvx, pos[1] + ncvy, ncvx, ncvy, playerNum,
							AI1_DEEP_HORIZON, simFinishVanish, exactSelf, exactRivals, true,
							scorerSelf, false, Math.max(scorerCap, AI1_DEEP_CERT_RIVALS),
							null, null, null) >= 0
							&& simOutcome(pos[0] + ncvx, pos[1] + ncvy, ncvx, ncvy, playerNum,
									AI1_TRUE_CONFIRM_ROUNDS, simFinishVanish, exactSelf,
									exactRivals, true, scorerSelf, true,
									Math.max(scorerCap, AI1_DEEP_CERT_RIVALS),
									null, null, null) >= 0;
				} finally {
					trueConfirmDepth--;
				}
				if (dbg)
					System.err.println("AIDBG TRUECONF  alt " + cand + " simT=" + candT
							+ (survives ? " true-ALIVE" : " true-DIES"));
				if (survives)
					confirmed = cand;
				else
					rejected[cand.ordinal()] = true;
			}
			// A confirm-capable search must never hand the race to an
			// UNCERTIFIED escape: when every candidate fails the true-rival
			// certification, keep the chosen (spielberg s252 m159: the cheap
			// world false-killed the true survivor E, certification correctly
			// rejected the doomed NE as true-DIES, and the old fallthrough
			// switched into NE anyway -- trading no crash for a crash).
			best = confirmed;
		}
		if (dbg)
			System.err.println("AIDBG DJS  -> " + (best != null ? "SWITCH " + best + " simT=" + bestT
					: "KEEP " + chosen + " (no survivor)"));
		return best != null ? best : chosen;
	}

	private final static double	AI2_MOMENTUM_TIEBREAK	= 0.02;
	private final static double	AI2_PLATEAU_TIEBREAK	= 0.05;

	/** Round 178: alive successors of a landing state, mirroring the referee
	 *  mask -- finish-crossing or (edge-legal AND map-alive). Map-only. */
	private int ridgeSuccAlive(final int x, final int y, final int vx, final int vy) {
		int succ = 0;
		for (final Direction sd : DIRECTIONS) {
			final int svx = vx + sd.dx, svy = vy + sd.dy;
			if (RaceGame.aiVelocityOutOfRange(svx, svy))
				continue;
			final int sx = x + svx, sy = y + svy;
			if (game.crossesFinishLegally(x, y, sx, sy)
					|| game.isMoveLegalGeometryCached(x, y, sx, sy) && reach.isAlive(sx, sy, svx, svy))
				succ++;
		}
		return succ;
	}

	/** Round 185: selective extension of the thin-ridge trigger. Exactly three
	 *  map-alive exits must remain, none may finish immediately, and their child
	 *  widths must be exactly 1/2/3. This admits the rand13-s4 speed-10 narrowing
	 *  fan while rejecting 100/113 broader width-three matches in its 50-seed
	 *  census and every match in the canonical golden corpus. */
	private boolean ridgeWidthThreePlateau(final int x, final int y, final int vx, final int vy) {
		int succ = 0;
		int childWidths = 0;
		final int mask = succMask(x, y, vx, vy);
		for (final Direction d : DIRECTIONS) {
			final int bit = 1 << d.ordinal();
			if ((mask & (bit << 16)) == 0)
				continue;
			final int nvx = vx + d.dx, nvy = vy + d.dy;
			final int nx = x + nvx, ny = y + nvy;
			if (game.crossesFinishLegally(x, y, nx, ny) && (!lapAware || lapGate == 0 && reach.shedableLanding(nx, ny, nvx, nvy)))
				return false;
			if ((mask & bit) == 0 || !reach.isAlive(nx, ny, nvx, nvy))
				continue;
			final int childSucc = ridgeSuccAlive(nx, ny, nvx, nvy);
			if (childSucc > AI1_RIDGE_PLATEAU_SUCC)
				return false;
			childWidths |= 1 << childSucc;
			succ++;
		}
		return succ == AI1_RIDGE_PLATEAU_SUCC && childWidths == 0b1110;
	}

	/** True only when a move enters the calibrated width-three class by holding
	 *  an already-maximal signed speed-10 component exactly unchanged. */
	static boolean isExactRidgePlateauHold(final int vx, final int vy,
			final int nvx, final int nvy) {
		final int nextMax = Math.max(Math.abs(nvx), Math.abs(nvy));
		return nextMax == AI1_RIDGE_PLATEAU_SPD
				&& Math.max(Math.abs(vx), Math.abs(vy)) == nextMax
				&& (Math.abs(vx) == nextMax && nvx == vx
						|| Math.abs(vy) == nextMax && nvy == vy);
	}

	/** True only when the chosen landing is exactly axial speed 11 and holds
	 *  the already-maximal signed component unchanged. */
	static boolean isExactAxialVmaxHold(final int vx, final int vy,
			final int nvx, final int nvy) {
		return Math.max(Math.abs(vx), Math.abs(vy)) == AI1_FASTV_MAX
				&& (Math.abs(nvx) == AI1_FASTV_MAX && nvy == 0 && nvx == vx
						|| Math.abs(nvy) == AI1_FASTV_MAX && nvx == 0 && nvy == vy);
	}

	/** Round 183: per-state successor mask -- bits 16-24 velocity-in-range,
	 *  bits 0-8 in-range AND geometry-legal, per Direction ordinal. Geometry
	 *  is immutable per track, so cached entries never invalidate; the
	 *  direct-mapped table (full-key verify) resets on reach change. One
	 *  probe replaces the nine range checks and nine edge-legality calls of
	 *  every candidate enumeration (49.5%% of all samples pre-round). */
	private int succMask(final int x, final int y, final int vx, final int vy) {
		final int max = RaceGame.AI_MAX_SPEED;
		if (x < 0 || y < 0 || x > game.gameCols || y > game.gameRows
				|| vx < -max || vx > max || vy < -max || vy > max)
			return succMaskCompute(x, y, vx, vy);
		if (smReach != reach) {
			if (smTab == null)
				smTab = new long[1 << 18];
			java.util.Arrays.fill(smTab, -1L);
			smReach = reach;
		}
		final int span = 2 * max + 1;
		final int vkey = (vx + max) * span + vy + max;
		final int key = (x * (game.gameRows + 1) + y) * (span * span) + vkey;
		final int slot = key * 0x9E3779B1 >>> 14;
		final long entry = smTab[slot];
		// round 184: one interleaved slot (key<<32 | 9-bit legal plane); the
		// velocity-range plane is position-independent and read from the
		// static table instead of being stored per state
		if ((int) (entry >>> 32) == key)
			return RANGE9[vkey] | (int) entry;
		final int legal = succMaskLegal(x, y, vx, vy);
		smTab[slot] = (long) key << 32 | legal;
		return RANGE9[vkey] | legal;
	}

	private int succMaskCompute(final int x, final int y, final int vx, final int vy) {
		int mask = 0;
		for (final Direction d : DIRECTIONS) {
			final int nvx = vx + d.dx, nvy = vy + d.dy;
			if (RaceGame.aiVelocityOutOfRange(nvx, nvy))
				continue;
			mask |= 1 << 16 + d.ordinal();
			if (game.isMoveLegalGeometryCached(x, y, x + nvx, y + nvy))
				mask |= 1 << d.ordinal();
		}
		return mask;
	}

	/** The 9-bit legal plane only (range-plane bits come from RANGE9). */
	private int succMaskLegal(final int x, final int y, final int vx, final int vy) {
		int mask = 0;
		for (final Direction d : DIRECTIONS) {
			final int nvx = vx + d.dx, nvy = vy + d.dy;
			if (RaceGame.aiVelocityOutOfRange(nvx, nvy))
				continue;
			if (game.isMoveLegalGeometryCached(x, y, x + nvx, y + nvy))
				mask |= 1 << d.ordinal();
		}
		return mask;
	}

	/** Round 184: the velocity-range plane (bits 16-24) per packed (vx,vy). */
	private static final int[] RANGE9 = buildRange9();

	private static int[] buildRange9() {
		final int max = RaceGame.AI_MAX_SPEED;
		final int span = 2 * max + 1;
		final int[] table = new int[span * span];
		for (int vx = -max; vx <= max; vx++)
			for (int vy = -max; vy <= max; vy++) {
				int mask = 0;
				for (final Direction d : DIRECTIONS)
					if (!RaceGame.aiVelocityOutOfRange(vx + d.dx, vy + d.dy))
						mask |= 1 << 16 + d.ordinal();
				table[(vx + max) * span + vy + max] = mask;
			}
		return table;
	}

	private Reachability smReach;
	private long[] smTab;

	private int countRivalsWithinCheb(final int x, final int y, final int playerNum, final int cheb) {
		int count = 0;
		for (final Player p : game.players) {
			if (p.getNumber() == playerNum || p.isFinished())
				continue;
			final int[] pp = p.getPosition();
			if (Math.abs(pp[0] - x) <= cheb && Math.abs(pp[1] - y) <= cheb)
				count++;
		}
		return count;
	}

	/** Round 210: a live rival within the radius that is AHEAD of or beside
	 *  me along my heading (dot with my velocity >= -2 speed) -- only such a
	 *  rival can occupy my continuation cell; a car behind me cannot turn my
	 *  needle into a wall. At rest every rival counts. Gating on all rivals
	 *  cost twice the pace for the same crash cut. */
	private boolean rivalAheadWithinCheb(final int x, final int y, final int vx, final int vy,
			final int playerNum, final int cheb) {
		final int sp = Math.max(Math.abs(vx), Math.abs(vy));
		for (final Player p : game.players) {
			if (p.getNumber() == playerNum || p.isFinished())
				continue;
			final int[] pp = p.getPosition();
			final int dx = pp[0] - x, dy = pp[1] - y;
			if (Math.abs(dx) > cheb || Math.abs(dy) > cheb)
				continue;
			if (sp == 0 || dx * vx + dy * vy >= -2 * sp)
				return true;
		}
		return false;
	}

	/** Round 214: the exact optimal move for a car with the track to itself, or
	 *  null when the potential was not built (an over-budget board) or the
	 *  state has no finite continuation. */
	private Direction optimalAloneMove(final int[] pos, final int[] vel, final int playerNum) {
		final OptimalPotential potential = game.optimalPotential();
		if (potential == null)
			return null;
		int lapsDone = 0;
		for (final Player p : game.players)
			if (p.getNumber() == playerNum)
				lapsDone = p.getLap();
		return potential.bestMove(game, pos[0], pos[1], vel[0], vel[1],
				OptimalPotential.remainingEvents(lapGate, lapsDone, game.totalLaps));
	}

	/** Round 61: any live opponent within Chebyshev distance {@code cheb} of
	 *  (x,y)? Chebyshev (not d^2) because the safety argument is per-axis:
	 *  max per-axis displacement in one move is |v|+1 <= 13. */
	private boolean rivalWithinCheb(final int x, final int y, final int playerNum, final int cheb) {
		for (final Player p : game.players) {
			if (p.getNumber() == playerNum || p.isFinished())
				continue;
			final int[] pp = p.getPosition();
			if (Math.abs(pp[0] - x) <= cheb && Math.abs(pp[1] - y) <= cheb)
				return true;
		}
		return false;
	}

	/** Count live opponents within squared distance r2 of (x,y). */
	private int countNearbyOpponents(final int x, final int y, final int playerNum, final int r2) {
		int count = 0;
		for (final Player p : game.players) {
			if (p.getNumber() == playerNum || p.isFinished())
				continue;
			final int[] pp = p.getPosition();
			final int dx = x - pp[0];
			final int dy = y - pp[1];
			if (distanceSquared(dx, dy) <= r2)
				count++;
		}
		return count;
	}

	/** True iff a live opponent genuinely threatens my escape thread at cell
	 *  (x,y): spatially near (squared distance <= 144), at similar track
	 *  progress (|distAt difference| <= 15 -- not merely across a wall on
	 *  another part of the circuit), and at-or-ahead
	 *  in track progress (smaller-or-similar distAt): a chaser behind cannot
	 *  occupy my escape thread ahead of me, so it shouldn't trigger the trap
	 *  surcharge. The +3 slack keeps side-by-side cars counted. Blockers moving
	 *  at similar-or-higher speed than {@code mySpeed} on open road (roomy
	 *  state, {@link #isRoomy}) are receding -- the gap stays stable and they
	 *  vacate the thread before I arrive -- so they don't count either; a
	 *  same-speed blocker threading a knife-edge stretch still does, because
	 *  it is about to brake (corner-entry compression). */
	private boolean hasConvergingOpponentAhead(final int x, final int y, final int playerNum, final double mySpeed) {
		final int myDist = reach.distAt(x, y);
		if (myDist == Integer.MAX_VALUE)
			return true; // off-map: be conservative
		for (final Player p : game.players) {
			if (p.getNumber() == playerNum || p.isFinished())
				continue;
			final int[] pp = p.getPosition();
			final int dx = x - pp[0];
			final int dy = y - pp[1];
			if (distanceSquared(dx, dy) > 144L)
				continue;
			final int oDist = reach.distAt(pp[0], pp[1]);
			if (oDist == Integer.MAX_VALUE || Math.abs(oDist - myDist) > 15 || oDist > myDist + 3)
				continue;
			final int[] pv = p.getVelocity();
			final double oSpeed = Math.hypot(pv[0], pv[1]);
			// Receding blockers don't block: at similar-or-higher speed on
			// OPEN ROAD (roomy state) the gap stays stable and they vacate
			// the thread before I arrive. A blocker threading a knife-edge
			// stretch is about to brake -- compression -- and still counts,
			// whatever its current speed (round-6 lesson: lemans corner-entry
			// packs crash when equal-speed blockers are treated as receding).
			if (oSpeed >= 3.0 && oSpeed >= mySpeed - 1.0 && isRoomy(pp[0], pp[1], pv[0], pv[1], 1))
				continue;
			return true;
		}
		return false;
	}

	/** Tiny penalty for ending up close to other live game.players, breaks lateral ties. */
	private double opponentSpreadPenalty(final int x, final int y, final int playerNum) {
		double penalty = 0;
		for (final Player p : game.players) {
			if (p.getNumber() == playerNum || p.isFinished())
				continue;
			final int[] pp = p.getPosition();
			final int dx = x - pp[0];
			final int dy = y - pp[1];
			final long d2 = distanceSquared(dx, dy);
			if (d2 <= 4)
				penalty += 0.3;
			else if (d2 <= 9)
				penalty += 0.1;
		}
		return penalty;
	}

	/**
	 * Count alive 1-step successors of (x,y,vx,vy) that are NOT also predicted
	 * to be occupied by an opponent's next move. Approximates the number of
	 * still-viable continuations after one opponent reaction.
	 */
	private int countFutureSafeSuccessors(final int x, final int y, final int vx, final int vy,
			final int playerNum, final CellOccupancy predicted) {
		int count = 0;
		final int sm = succMask(x, y, vx, vy);
		for (final Direction d : DIRECTIONS) {
			final int nvx = vx + d.dx;
			final int nvy = vy + d.dy;
			if ((sm & 1 << 16 + d.ordinal()) == 0)
				continue;
			final int nx = x + nvx;
			final int ny = y + nvy;
			if (game.crossesFinishLegally(x, y, nx, ny) && (!lapAware || lapGate == 0 && reach.shedableLanding(nx, ny, nvx, nvy)))
				return 9;
			if ((sm & 1 << d.ordinal()) == 0)
				continue;
			if (game.isCrashingPlayer(nx, ny, playerNum))
				continue;
			if (predicted.contains(nx, ny))
				continue;
			if (reach.isAlive(nx, ny, nvx, nvy))
				count++;
		}
		return count;
	}

	/**
	 * Shared scorer twin of {@link #countFutureSafeSuccessors} keyed on ROOMINESS
	 * rather than mere aliveness, and opponent-blind (geometry + reachability
	 * only). Counts the geometry-legal one-step successors of (x,y,vx,vy) that
	 * are alive AND {@link #isRoomy roomy} at depth 0 -- i.e. escape moves onto
	 * genuinely open road, not alive-but-single-file knife-edge threads. A
	 * finish crossing short-circuits to a large count (a candidate that can end
	 * the race is never a corner-entry trap). Used solely by the AI2 knife-edge
	 * corner-entry brake as the geometric half of that gate; the traffic half
	 * (a pack around the target) is applied separately at the call site, because
	 * the funnel geometry is a fixed property of the state while the danger only
	 * materialises when rivals are packed at the corner entry.
	 */
	private int countRoomySuccessors(final int x, final int y, final int vx, final int vy) {
		int count = 0;
		for (final Direction d : DIRECTIONS) {
			final int nvx = vx + d.dx;
			final int nvy = vy + d.dy;
			if (RaceGame.aiVelocityOutOfRange(nvx, nvy))
				continue;
			final int nx = x + nvx;
			final int ny = y + nvy;
			if (game.crossesFinishLegally(x, y, nx, ny) && (!lapAware || lapGate == 0 && reach.shedableLanding(nx, ny, nvx, nvy)))
				return 9;
			if (!game.isMoveLegalGeometryCached(x, y, nx, ny))
				continue;
			if (reach.isAlive(nx, ny, nvx, nvy) && isRoomy(nx, ny, nvx, nvy, 0))
				count++;
		}
		return count;
	}

	/** Rebuild the exact live-cell set once per mobility projection. Only cells
	 * touched by the preceding projection are cleared. */
	private void refreshLiveOccupancy() {
		final int cells = (game.gameCols + 1) * (game.gameRows + 1);
		if (liveOccupancy == null || liveOccupancy.length != cells) {
			liveOccupancy = new byte[cells];
			liveOccupancyTouched = new int[game.players.length];
			liveOccupancyTouchedCount = 0;
		} else {
			for (int i = 0; i < liveOccupancyTouchedCount; i++)
				liveOccupancy[liveOccupancyTouched[i]] = 0;
			liveOccupancyTouchedCount = 0;
		}
		final int h = game.gameRows + 1;
		for (final Player p : game.players) {
			if (p.isFinished())
				continue;
			final int[] pp = p.getPosition();
			if (pp[0] < 0 || pp[1] < 0 || pp[0] > game.gameCols
					|| pp[1] > game.gameRows)
				continue;
			final int index = pp[0] * h + pp[1];
			if (liveOccupancy[index] != 0)
				continue;
			liveOccupancy[index] = 1;
			liveOccupancyTouched[liveOccupancyTouchedCount++] = index;
		}
	}

	/** True iff a live player other than the one at (sx,sy) occupies (nx,ny). */
	private boolean cellOccupiedByLive(final int nx, final int ny, final int sx, final int sy) {
		if (nx == sx && ny == sy)
			return false;
		if (nx < 0 || ny < 0 || nx > game.gameCols || ny > game.gameRows)
			return false;
		return liveOccupancy[nx * (game.gameRows + 1) + ny] != 0;
	}

	/** Number of rivals still racing (not finished, not crashed). */
	private int liveRivalsRemaining(final int playerNum) {
		int n = 0;
		for (final Player p : game.players)
			if (p.getNumber() != playerNum && !p.isFinished())
				n++;
		return n;
	}

	/** The decisive rival to pressure: the live rival nearest the finish (the
	 *  one to beat; in 1v1 the sole rival). Array index, or -1 if none. */
	private int decisiveRival(final int playerNum) {
		int best = -1, bestDist = Integer.MAX_VALUE;
		for (int i = 0; i < game.players.length; i++) {
			final Player p = game.players[i];
			if (p.getNumber() == playerNum || p.isFinished())
				continue;
			final int[] pp = p.getPosition();
			final int dd = reach.distAt(pp[0], pp[1]);
			if (dd < bestDist) {
				bestDist = dd;
				best = i;
			}
		}
		return best;
	}

	/** Count rival {@code ri}'s viable immediate moves: geometry-legal next
	 *  cells, not my landing (blockX,blockY), not occupied by another live car.
	 *  0 => the rival has no legal move and must crash; 99 => it can finish
	 *  (unsealable). Uses the rival's CURRENT velocity, so it is exact only for
	 *  a rival that has not moved yet this round. */
	private int rivalEscapes(final int ri, final int blockX, final int blockY, final int playerNum) {
		final int[] rp = game.players[ri].getPosition();
		final int[] rv = game.players[ri].getVelocity();
		final int riNum = game.players[ri].getNumber();
		int n = 0;
		for (final Direction d : DIRECTIONS) {
			final int nvx = rv[0] + d.dx, nvy = rv[1] + d.dy;
			if (RaceGame.aiVelocityOutOfRange(nvx, nvy))
				continue;
			final int nx = rp[0] + nvx, ny = rp[1] + nvy;
			if (game.crossesFinishLegally(rp[0], rp[1], nx, ny))
				return 99;
			if (!game.isMoveLegalGeometryCached(rp[0], rp[1], nx, ny))
				continue;
			if (nx == blockX && ny == blockY)
				continue;
			boolean blocked = false;
			for (final Player q : game.players) {
				if (q.isFinished() || q.getNumber() == playerNum || q.getNumber() == riNum)
					continue;
				final int[] qp = q.getPosition();
				if (qp[0] == nx && qp[1] == ny) {
					blocked = true;
					break;
				}
			}
			if (!blocked)
				n++;
		}
		return n;
	}

	/** Round 197 needle headway: TRUE when a landing may take a lap-gate
	 *  precedence in traffic. Stoppable (both velocity components <= 1: the
	 *  car can park next turn and absorb a queue stall the way a leader
	 *  does), no rival near the landing, or two body-free alive
	 *  continuations proven under CURRENT occupancy. The world-step trap
	 *  ladder predicts rivals vacating -- exactly wrong in a stall wave:
	 *  the first follower above stoppable speed one cell behind a parked
	 *  leader is dead (hybrid20 CP2 pocket: p5/p7 parked and lived, p8
	 *  entered at vy=2 and died). */
	private boolean needleHeadway(final int nx, final int ny, final int nvx, final int nvy,
			final int playerNum, final int gate) {
		if (Math.abs(nvx) <= 1 && Math.abs(nvy) <= 1)
			return true;
		if (!rivalWithinCheb(nx, ny, playerNum, AI1_NEEDLE_RIVAL_R))
			return true;
		// A queue-DEPTH extension (>= 2 stalled rivals within stopping
		// distance, direction-agnostic) was probed here in round 198 and
		// REGRESSED the fleet (hybrid12 1 -> 3, lobe2 0 -> 1, monaco
		// 1 -> 2, rand2 unmoved): heading-blind stall counting brakes for
		// flowing trains -- the place-ceding trap the queue-box v2 note
		// warns about. Deeper queue awareness needs heading, not radius.
		return currentFreeContinuingSuccessors(nx, ny, nvx, nvy, playerNum, gate, 2) >= 2;
	}

	/** Successor landings that are velocity-valid, geometry-legal, body-free
	 *  RIGHT NOW, alive, and -- in lap mode -- able to CONTINUE the lap on
	 *  the given gate map. Surviving is not continuing: a successor that
	 *  cannot reach the next gate is a parking lot, not headway (round 199,
	 *  rand2: a speed-7 crossing's landing counted 2+ alive successors, all
	 *  of them lap-INF threads into a dead upper band, while the single
	 *  certified continuation cell was occupied by the car ahead). A
	 *  successor that itself crosses the S/F while heading for gate 0
	 *  continues on the gate-1 map. A negative {@code gate} skips the
	 *  continuation requirement (alive-only counting: the scorer surcharge
	 *  uses it -- requiring continuation there over-brakes flowing traffic,
	 *  gear 0 -> 1 and hybrid12 1 -> 3 in the round-199 ablation).
	 *  Early-exits at {@code cap}. */
	private int currentFreeContinuingSuccessors(final int x, final int y, final int vx, final int vy,
			final int playerNum, final int gate, final int cap) {
		int n = 0;
		for (final Direction d : DIRECTIONS) {
			final int nvx = vx + d.dx, nvy = vy + d.dy;
			if (RaceGame.aiVelocityOutOfRange(nvx, nvy))
				continue;
			final int nx = x + nvx, ny = y + nvy;
			if (!game.isMoveLegalGeometryCached(x, y, nx, ny)
					|| game.isCrashingPlayer(nx, ny, playerNum)
					|| !reach.isAlive(nx, ny, nvx, nvy))
				continue;
			if (gate >= 0 && lapAware
					&& reach.turnsToGate(gate, nx, ny, nvx, nvy) == Integer.MAX_VALUE
					&& !(gate == 0 && game.crossesFinishLegally(x, y, nx, ny)
							&& reach.turnsToGate(1, nx, ny, nvx, nvy) != Integer.MAX_VALUE))
				continue;
			if (++n >= cap)
				return n;
		}
		return n;
	}

	/** Round 206 (Gipps): the largest stopping-distance excess against any
	 *  live rival ahead in my heading cone from the candidate landing.
	 *  Along-heading integer-shed physics: stopping from speed s covers
	 *  s(s+1)/2 cells. The leader is credited its own along-heading stopping
	 *  distance plus this round's advance; one cell of occupancy is taken
	 *  off the gap. Oncoming rivals (adjacent hairpin leg) are ignored. */
	private double followingExcess(final int nx, final int ny, final int nvx, final int nvy,
			final int playerNum) {
		final double sp = Math.hypot(nvx, nvy);
		if (sp < 1.0)
			return 0.0;
		final double ux = nvx / sp, uy = nvy / sp;
		final double myStop = sp * (sp + 1.0) / 2.0;
		double worst = 0.0;
		for (final Player r : game.players) {
			if (r.getNumber() == playerNum || r.isFinished())
				continue;
			final int[] rp = r.getPosition();
			final double dx = rp[0] - nx, dy = rp[1] - ny;
			final double along = dx * ux + dy * uy;
			if (along <= 0.0 || along > AI1_FOLLOW_RANGE)
				continue;
			final double lat = Math.abs(dx * uy - dy * ux);
			if (lat > AI1_FOLLOW_LAT)
				continue;
			final int[] rv = r.getVelocity();
			final double rAlong = rv[0] * ux + rv[1] * uy;
			if (rAlong < -0.5)
				continue; // oncoming: another leg of the corridor, not my leader
			final double lead = Math.max(0.0, rAlong);
			final double leadStop = lead * (lead + 1.0) / 2.0;
			final double gap = along + lead - 1.0;
			final double excess = myStop - gap - leadStop;
			if (excess > worst)
				worst = excess;
		}
		return worst;
	}

	/** Finish precedence mirrors the main candidate scan: a velocity-range-valid
	 * crossing wins before ordinary geometry or body legality is considered. */
	private Direction immediateFinishMove(final int[] pos, final int[] vel) {
		for (final Direction d : DIRECTIONS) {
			final int nvx = vel[0] + d.dx, nvy = vel[1] + d.dy;
			if (RaceGame.aiVelocityOutOfRange(nvx, nvy))
				continue;
			final int nx = pos[0] + nvx, ny = pos[1] + nvy;
			if (game.crossesFinishLegally(pos[0], pos[1], nx, ny))
				return d;
		}
		return null;
	}

	/** A safe move of mine (alive, non-crashing, not self-sealable) that leaves
	 *  rival {@code ri} with zero legal moves -- forcing its crash this turn --
	 *  or null if none exists. */
	private Direction findForcedCrashMove(final int[] pos, final int[] vel, final int ri, final int playerNum) {
		for (final Direction d : DIRECTIONS) {
			final int nvx = vel[0] + d.dx, nvy = vel[1] + d.dy;
			if (RaceGame.aiVelocityOutOfRange(nvx, nvy))
				continue;
			final int nx = pos[0] + nvx, ny = pos[1] + nvy;
			if (game.crossesFinishLegally(pos[0], pos[1], nx, ny))
				continue;
			if (!game.isMoveLegalGeometryCached(pos[0], pos[1], nx, ny))
				continue;
			if (game.isCrashingPlayer(nx, ny, playerNum))
				continue;
			if (!reach.isAlive(nx, ny, nvx, nvy))
				continue;
			if (sealable(nx, ny, nvx, nvy, playerNum))
				continue;
			if (rivalEscapes(ri, nx, ny, playerNum) == 0)
				return d;
		}
		return null;
	}

	private java.util.HashMap<Long, Boolean>	egMemo;
	private int									egNodes;

	/** Lever 5 (round 43, shared champion): 1v1 exact endgame solver. When the sole
	 *  live rival and I are both within {@link #AI1_EG_ETA} turns of the
	 *  finish, run a boolean paranoid minimax over the joint state (strict
	 *  me/rival alternation -- exact for two live movers regardless of index
	 *  order; landing-cell blocking, the campaign's board convention) to
	 *  {@link #AI1_EG_DEPTH} rounds. Returns the FASTEST move with a
	 *  guaranteed win (I cross first, or the rival is forced to crash while
	 *  my state stays alive) or null. A blown node budget claims nothing. */
	private Direction endgameSolve(final int[] pos, final int[] vel, final int playerNum) {
		final int ri = decisiveRival(playerNum);
		// The minimax key has no progress ledger. It is sound only when
		// BOTH racers owe just their final S/F crossing; being near the next
		// gate is not being near victory when the exact potential is absent.
		if (ri < 0 || lapAware || frameLapAware[ri])
			return null;
		final int myT = ttf(pos[0], pos[1], vel[0], vel[1]);
		final int[] rp = game.players[ri].getPosition(), rv = game.players[ri].getVelocity();
		final int rT = ttfFor(ri, rp[0], rp[1], rv[0], rv[1]);
		if (myT > AI1_EG_ETA || rT > AI1_EG_ETA)
			return null;
		egMemo = new java.util.HashMap<>();
		egNodes = 0;
		Direction best = null;
		int bestT = Integer.MAX_VALUE;
		for (final Direction d : DIRECTIONS) {
			final int nvx = vel[0] + d.dx, nvy = vel[1] + d.dy;
			if (RaceGame.aiVelocityOutOfRange(nvx, nvy))
				continue;
			final int nx = pos[0] + nvx, ny = pos[1] + nvy;
			if (game.crossesFinishLegally(pos[0], pos[1], nx, ny))
				return d;		// immediate finish: the fastest win there is
			if (!game.isMoveLegalGeometryCached(pos[0], pos[1], nx, ny))
				continue;
			if (nx == rp[0] && ny == rp[1])
				continue;
			if (!reach.isAlive(nx, ny, nvx, nvy))
				continue;
			final int t = ttf(nx, ny, nvx, nvy);
			if (best != null && t >= bestT)
				continue;		// only a strictly faster win can improve
			if (egRival(nx, ny, nvx, nvy, rp[0], rp[1], rv[0], rv[1], AI1_EG_DEPTH * 2 - 1)) {
				best = d;
				bestT = t;
			}
			if (egNodes > AI1_EG_NODES)
				return null;	// budget blown mid-search: results untrusted
		}
		return best;
	}

	/** Rival ply: TRUE iff my win survives EVERY legal rival reply (worst
	 *  case; suicidal blocking lines included -- only geometry and my body
	 *  restrict it). A boxed rival crashes: my win iff my state is alive. */
	private boolean egRival(final int mx, final int my, final int mvx, final int mvy,
			final int rx, final int ry, final int rvx, final int rvy, final int depth) {
		egNodes++;
		if (depth <= 0)
			return false;		// horizon: no guarantee
		final long key = endgameMemoKey(mx, my, mvx, mvy, rx, ry, rvx, rvy, depth, true);
		final Boolean memo = egMemo.get(key);
		if (memo != null)
			return memo;
		boolean anyMove = false;
		boolean win = true;
		for (final Direction d : DIRECTIONS) {
			if (egNodes > AI1_EG_NODES) {
				win = false;	// budget: conservative, claim nothing
				break;
			}
			final int nvx = rvx + d.dx, nvy = rvy + d.dy;
			if (RaceGame.aiVelocityOutOfRange(nvx, nvy))
				continue;
			final int nx = rx + nvx, ny = ry + nvy;
			if (game.crossesFinishLegally(rx, ry, nx, ny)) {
				win = false;	// rival crosses first
				anyMove = true;
				break;
			}
			if (!game.isMoveLegalGeometryCached(rx, ry, nx, ny))
				continue;
			if (nx == mx && ny == my)
				continue;
			anyMove = true;
			if (!egMy(mx, my, mvx, mvy, nx, ny, nvx, nvy, depth - 1)) {
				win = false;
				break;
			}
		}
		if (!anyMove)
			win = reach.isAlive(mx, my, mvx, mvy);
		egMemo.put(key, win);
		return win;
	}

	/** My ply: TRUE iff some alive (or finishing) move of mine keeps the
	 *  guaranteed win alive. */
	private boolean egMy(final int mx, final int my, final int mvx, final int mvy,
			final int rx, final int ry, final int rvx, final int rvy, final int depth) {
		egNodes++;
		if (depth <= 0)
			return false;
		final long key = endgameMemoKey(mx, my, mvx, mvy, rx, ry, rvx, rvy, depth, false);
		final Boolean memo = egMemo.get(key);
		if (memo != null)
			return memo;
		boolean win = false;
		for (final Direction d : DIRECTIONS) {
			if (egNodes > AI1_EG_NODES)
				break;
			final int nvx = mvx + d.dx, nvy = mvy + d.dy;
			if (RaceGame.aiVelocityOutOfRange(nvx, nvy))
				continue;
			final int nx = mx + nvx, ny = my + nvy;
			if (game.crossesFinishLegally(mx, my, nx, ny)) {
				win = true;
				break;
			}
			if (!game.isMoveLegalGeometryCached(mx, my, nx, ny))
				continue;
			if (nx == rx && ny == ry)
				continue;
			if (!reach.isAlive(nx, ny, nvx, nvy))
				continue;
			if (egRival(nx, ny, nvx, nvy, rx, ry, rvx, rvy, depth - 1)) {
				win = true;
				break;
			}
		}
		egMemo.put(key, win);
		return win;
	}

	/** Pack a joint endgame state into a collision-free memo key for every
	 *  supported grid coordinate: 9b coordinates, 5b velocity offsets (+12),
	 *  5b depth and 1b turn = 62 bits. */
	static long endgameMemoKey(final int mx, final int my, final int mvx, final int mvy,
			final int rx, final int ry, final int rvx, final int rvy, final int depth, final boolean rivalTurn) {
		long k = mx & 0x1FFL;
		k = k << 9 | my & 0x1FFL;
		k = k << 5 | mvx + 12 & 0x1FL;
		k = k << 5 | mvy + 12 & 0x1FL;
		k = k << 9 | rx & 0x1FFL;
		k = k << 9 | ry & 0x1FFL;
		k = k << 5 | rvx + 12 & 0x1FL;
		k = k << 5 | rvy + 12 & 0x1FL;
		k = k << 5 | depth & 0x1FL;
		k = k << 1 | (rivalTurn ? 1 : 0);
		return k;
	}

	/** TRUE iff state (x,y,vx,vy) is SEALABLE: opponents can jointly occupy
	 *  every escape (geometry-legal alive successor) with DISTINCT cars whose
	 *  landings are geometry-legal for them (worst-case physics, matching via
	 *  Kuhn). A finishing escape is never sealable. */
	private boolean sealable(final int x, final int y, final int vx, final int vy, final int playerNum) {
		int escapeCount = 0;
		for (final Direction direction : DIRECTIONS) {
			final int nvx = vx + direction.dx, nvy = vy + direction.dy;
			if (RaceGame.aiVelocityOutOfRange(nvx, nvy))
				continue;
			final int nx = x + nvx, ny = y + nvy;
			if (game.crossesFinishLegally(x, y, nx, ny) && (!lapAware || lapGate == 0 && reach.shedableLanding(nx, ny, nvx, nvy)))
				return false;
			if (!game.isMoveLegalGeometryCached(x, y, nx, ny))
				continue;
			if (!reach.isAlive(nx, ny, nvx, nvy))
				continue;
			sealEscapes[escapeCount * 2] = nx;
			sealEscapes[escapeCount * 2 + 1] = ny;
			escapeCount++;
		}
		if (escapeCount == 0)
			return true;
		java.util.Arrays.fill(sealCover, 0, escapeCount, 0);
		int opponentCount = 0;
		for (final Player opponent : game.players) {
			if (opponent.getNumber() == playerNum || opponent.isFinished())
				continue;
			final int bit = 1 << opponentCount;
			opponentCount++;
			final int[] position = opponent.getPosition();
			final int[] velocity = opponent.getVelocity();
			final int cx = position[0] + velocity[0], cy = position[1] + velocity[1];
			for (int escape = 0; escape < escapeCount; escape++) {
				final int ex = sealEscapes[escape * 2];
				final int ey = sealEscapes[escape * 2 + 1];
				if (Math.abs(ex - cx) <= 1 && Math.abs(ey - cy) <= 1
						&& game.isMoveLegalGeometryCached(position[0], position[1], ex, ey))
					sealCover[escape] |= bit;
			}
		}
		return hasDistinctCover(sealCover, escapeCount, opponentCount, sealMatch);
	}

	/** Whether every requested cell can be assigned a different opponent from
	 *  its bitmask. Package-private for regression tests of the 9-player case. */
	static boolean hasDistinctCover(final int[] cover, final int opponentCount) {
		if (opponentCount < 0 || opponentCount > Integer.SIZE)
			throw new IllegalArgumentException("opponentCount out of range: " + opponentCount);
		return hasDistinctCover(cover, cover.length, opponentCount, new int[opponentCount]);
	}

	private static boolean hasDistinctCover(final int[] cover, final int escapeCount,
			final int opponentCount, final int[] matchOpponent) {
		if (escapeCount > opponentCount)
			return false;
		java.util.Arrays.fill(matchOpponent, 0, opponentCount, -1);
		for (int escape = 0; escape < escapeCount; escape++) {
			if (!sealAugment(escape, cover, matchOpponent, opponentCount, 0))
				return false;
		}
		return true;
	}

	private static boolean sealAugment(final int escape, final int[] cover, final int[] matchOpponent,
			final int opponentCount, final int usedMask) {
		for (int opponent = 0; opponent < opponentCount; opponent++) {
			final int bit = 1 << opponent;
			if ((cover[escape] & bit) == 0 || (usedMask & bit) != 0)
				continue;
			if (matchOpponent[opponent] < 0
					|| sealAugment(matchOpponent[opponent], cover, matchOpponent, opponentCount, usedMask | bit)) {
				matchOpponent[opponent] = escape;
				return true;
			}
		}
		return false;
	}

	/** Generic N-ply escape headroom: max over alive moves (dodging predicted
	 *  traffic per ply) with the leaf ply scored as the alive-fraction. */
	private double fmRec(final int x, final int y, final int vx, final int vy,
			final MobilitySearch search, final int ply) {
		final long memoKey = mobilityMemoKey(x, y, vx, vy, ply);
		final double cached = fmMemoGet(memoKey, search.epoch);
		if (cached == cached)
			return cached;
		final long[] b = search.blocked[ply - 1];
		final int bc = search.blockedCount[ply - 1];
		final long[] direct = search.blockedBits[ply - 1];
		if (ply == search.depth) {
			int cnt = 0;
			for (final Direction d : DIRECTIONS) {
				final int nvx = vx + d.dx, nvy = vy + d.dy;
				if (RaceGame.aiVelocityOutOfRange(nvx, nvy))
					continue;
				final int nx = x + nvx, ny = y + nvy;
				if (game.crossesFinishLegally(x, y, nx, ny) && (!lapAware || lapGate == 0 && reach.shedableLanding(nx, ny, nvx, nvy))) {
					cnt++;
					continue;
				}
				if (blockedContains(b, bc, direct, search.gridW, search.gridH, nx, ny))
					continue;
				if (reach.isAlive(nx, ny, nvx, nvy))
					cnt++;
			}
			final double result = cnt / 9.0;
			fmMemoPut(memoKey, search.epoch, result);
			return result;
		}
		double best = 0.0;
		for (final Direction d : DIRECTIONS) {
			final int nvx = vx + d.dx, nvy = vy + d.dy;
			if (RaceGame.aiVelocityOutOfRange(nvx, nvy))
				continue;
			final int nx = x + nvx, ny = y + nvy;
			if (game.crossesFinishLegally(x, y, nx, ny) && (!lapAware || lapGate == 0 && reach.shedableLanding(nx, ny, nvx, nvy))) {
				fmMemoPut(memoKey, search.epoch, 1.0);
				return 1.0;
			}
			if (blockedContains(b, bc, direct, search.gridW, search.gridH, nx, ny))
				continue;
			if (!reach.isAlive(nx, ny, nvx, nvy))
				continue;
			final double v = fmRec(nx, ny, nvx, nvy, search, ply + 1);
			if (v > best) {
				best = v;
				if (best >= 1.0) {
					fmMemoPut(memoKey, search.epoch, 1.0);
					return 1.0;
				}
			}
		}
		fmMemoPut(memoKey, search.epoch, best);
		return best;
	}

	/** One immutable opponent projection plus a transposition epoch shared by
	 *  every candidate root in one real turn. Candidate roots overlap heavily;
	 *  rebuilding the projection for each root repeated the same search. The
	 *  memo itself is the pooled primitive table on RaceAi (round 130): a hit
	 *  needs this search's epoch AND the key, so concurrent nested searches
	 *  never cross-hit and evictions only recompute. Blocked cells are tiny
	 *  per-ply arrays (<= 3 per opponent) -- linear scan, no boxing. */
	private static final class MobilitySearch {
		int depth;
		final long[][] blocked;
		final int[] blockedCount;
		final long[][] blockedBits;
		final int[][] touchedWords;
		final int[] touchedCount;
		final int gridW;
		final int gridH;
		int epoch;

		MobilitySearch(final int depth, final int players, final int gridW,
				final int gridH) {
			this.gridW = gridW;
			this.gridH = gridH;
			blocked = new long[depth][3 * players];
			blockedCount = new int[depth];
			final int words = (gridW * gridH + Long.SIZE - 1) >>> 6;
			blockedBits = new long[depth][words];
			touchedWords = new int[depth][3 * players];
			touchedCount = new int[depth];
		}

		void reset(final int newDepth, final int newEpoch) {
			for (int ply = 0; ply < blockedBits.length; ply++) {
				for (int i = 0; i < touchedCount[ply]; i++)
					blockedBits[ply][touchedWords[ply][i]] = 0L;
				touchedCount[ply] = 0;
				blockedCount[ply] = 0;
			}
			depth = newDepth;
			epoch = newEpoch;
		}

		void indexBlockedCells() {
			for (int ply = 0; ply < depth; ply++) {
				final long[] bits = blockedBits[ply];
				for (int i = 0; i < blockedCount[ply]; i++) {
					final long cell = blocked[ply][i];
					final int x = (int) (cell >> 32), y = (int) cell;
					if (x < 0 || y < 0 || x >= gridW || y >= gridH)
						continue;
					final int index = x * gridH + y;
					final int word = index >>> 6;
					if (bits[word] == 0L)
						touchedWords[ply][touchedCount[ply]++] = word;
					bits[word] |= 1L << (index & 63);
				}
			}
		}
	}

	/** Round 130: pooled open-addressing transposition table for {@link #fmRec}
	 *  (long keys, double values, epoch validity). Replaces the per-turn boxed
	 *  HashMap that dominated the mobility recursion's self time (JFR: getNode
	 *  plus per-turn resize churn). Probe chains are capped; past the cap a
	 *  store is skipped -- correctness never depends on a store landing. */
	private static final int FM_MEMO_BITS = 15;
	private static final int FM_MEMO_PROBE_CAP = 32;
	private final long[] fmMemoKeys = new long[1 << FM_MEMO_BITS];
	private final double[] fmMemoVals = new double[1 << FM_MEMO_BITS];
	private final int[] fmMemoEpochs = new int[1 << FM_MEMO_BITS];
	private int fmMemoEpoch;

	/** Round 175: pooled verdict memo for the hold-overspeed cheap-world
	 *  check. The same (landing, velocity) state re-fires across nested
	 *  rival computes many times per turn on speed-10-native tracks; the
	 *  verdict is deterministic per epoch, so a hit skips the whole sim.
	 *  Epochs ride the mobility epoch (bumped per search build) -- staler
	 *  entries only recompute, never mislead. */
	private final long[] holdVMemoKeys = new long[1 << 12];
	private final byte[] holdVMemoVals = new byte[1 << 12];
	private final int[] holdVMemoEpochs = new int[1 << 12];

	private static int fmMemoSlot(final long key) {
		return (int) (key * 0x9E3779B97F4A7C15L >>> 64 - FM_MEMO_BITS);
	}

	/** NaN = miss (stored values live in [0, 1]). */
	private double fmMemoGet(final long key, final int epoch) {
		int slot = fmMemoSlot(key);
		for (int probe = 0; probe < FM_MEMO_PROBE_CAP && fmMemoEpochs[slot] == epoch; probe++) {
			if (fmMemoKeys[slot] == key)
				return fmMemoVals[slot];
			slot = slot + 1 & (1 << FM_MEMO_BITS) - 1;
		}
		return Double.NaN;
	}

	private void fmMemoPut(final long key, final int epoch, final double value) {
		int slot = fmMemoSlot(key);
		for (int probe = 0; probe < FM_MEMO_PROBE_CAP; probe++) {
			if (fmMemoEpochs[slot] != epoch || fmMemoKeys[slot] == key) {
				fmMemoKeys[slot] = key;
				fmMemoVals[slot] = value;
				fmMemoEpochs[slot] = epoch;
				return;
			}
			slot = slot + 1 & (1 << FM_MEMO_BITS) - 1;
		}
	}

	static boolean blockedContains(final long[] cells, final int count,
			final long[] direct, final int gridW, final int gridH,
			final int x, final int y) {
		if (x >= 0 && y >= 0 && x < gridW && y < gridH) {
			final int index = x * gridH + y;
			return (direct[index >>> 6] & 1L << (index & 63)) != 0;
		}
		final long cell = ((long) x << 32) | (y & 0xffffffffL);
		for (int i = 0; i < count; i++)
			if (cells[i] == cell)
				return true;
		return false;
	}

	/** Build an N-ply opponent world once per AI turn. Opponents advance N
	 *  greedy steps, blocking their top-3 min-turns cells at each ply. */
	private MobilitySearch mobilitySearch(final int subjectNum, final boolean avoidOcc, final int depth) {
		refreshLiveOccupancy();
		final boolean nested = inScorerSim || trueConfirmDepth != 0 || simDepth != 0;
		MobilitySearch search = nested ? nestedMobilityWorkspace : outerMobilityWorkspace;
		final int gridW = game.gameCols + 1, gridH = game.gameRows + 1;
		if (search == null || search.blocked.length != depth
				|| search.blocked[0].length != 3 * game.players.length
				|| search.gridW != gridW || search.gridH != gridH) {
			search = new MobilitySearch(depth, game.players.length, gridW, gridH);
			if (nested)
				nestedMobilityWorkspace = search;
			else
				outerMobilityWorkspace = search;
		}
		search.reset(depth, ++fmMemoEpoch);
		final long[][] blocked = search.blocked;
		final int[] blockedCount = search.blockedCount;
		for (final Player opponent : game.players) {
			if (opponent.getNumber() == subjectNum || opponent.isFinished())
				continue;
			final int[] position = opponent.getPosition();
			final int[] velocity = opponent.getVelocity();
			int x = position[0], y = position[1], vx = velocity[0], vy = velocity[1];
			for (int k = 0; k < depth; k++) {
				final int nc = greedyStepBlockTop3(x, y, vx, vy, avoidOcc, blocked[k],
						blockedCount[k], mobilityMove);
				if (nc < 0)
					break;
				blockedCount[k] = nc;
				x = mobilityMove[0];
				y = mobilityMove[1];
				vx = mobilityMove[2];
				vy = mobilityMove[3];
			}
		}
		search.indexBlockedCells();
		return search;
	}

	/** N-ply escape headroom in a per-turn opponent world (see {@link #fmRec}). */
	private double futureMobility(final int x, final int y, final int vx, final int vy,
			final MobilitySearch search) {
		if (reach.turnsArr == null)
			return 1.0;
		return fmRec(x, y, vx, vy, search, 1);
	}

	/** Collision-free key for one mobility-search state. Reachability already
	 *  assigns every in-domain (position, velocity) a unique non-negative int;
	 *  the high word adds the ply. The blocked world is implicit in the memo's
	 *  per-turn lifetime. */
	private long mobilityMemoKey(final int x, final int y, final int vx, final int vy, final int ply) {
		return ((long) ply << 32) | (reach.aliveIdx(x, y, vx, vy) & 0xffffffffL);
	}

	/** Best greedy step; blocks the rival's up-to-3 lowest-turns cells by
	 *  appending to the ply's cell array (duplicates fine -- the reader is a
	 *  linear scan). Returns the new count, or -1 when no step exists. */
	private int greedyStepBlockTop3(final int x, final int y, final int vx, final int vy,
			final boolean avoidOcc, final long[] block, final int blockCount, final int[] out) {
		int t1 = Integer.MAX_VALUE, t2 = Integer.MAX_VALUE, t3 = Integer.MAX_VALUE;
		int x1 = 0, y1 = 0, vx1 = 0, vy1 = 0;
		int x2 = 0, y2 = 0, x3 = 0, y3 = 0;
		for (final Direction direction : DIRECTIONS) {
			final int nvx = vx + direction.dx, nvy = vy + direction.dy;
			if (reach.velocityOutOfRange(nvx, nvy))
				continue;
			final int nx = x + nvx, ny = y + nvy;
			if (nx < 0 || ny < 0 || nx >= reach.aliveW || ny >= reach.aliveH)
				continue;
			if (avoidOcc && cellOccupiedByLive(nx, ny, x, y))
				continue;
			final int turns = reach.turnsArr[reach.aliveIdx(nx, ny, nvx, nvy)];
			if (turns == Integer.MAX_VALUE)
				continue;
			if (turns < t1) {
				t3 = t2;
				x3 = x2;
				y3 = y2;
				t2 = t1;
				x2 = x1;
				y2 = y1;
				t1 = turns;
				x1 = nx;
				y1 = ny;
				vx1 = nvx;
				vy1 = nvy;
			} else if (turns < t2) {
				t3 = t2;
				x3 = x2;
				y3 = y2;
				t2 = turns;
				x2 = nx;
				y2 = ny;
			} else if (turns < t3) {
				t3 = turns;
				x3 = nx;
				y3 = ny;
			}
		}
		if (t1 == Integer.MAX_VALUE)
			return -1;
		int count = blockCount;
		block[count++] = ((long) x1 << 32) | (y1 & 0xffffffffL);
		if (t2 != Integer.MAX_VALUE)
			block[count++] = ((long) x2 << 32) | (y2 & 0xffffffffL);
		if (t3 != Integer.MAX_VALUE)
			block[count++] = ((long) x3 << 32) | (y3 & 0xffffffffL);
		return writeMove(out, x1, y1, vx1, vy1) ? count : -1;
	}

	/** Count certified braking descents from (x,y,vx,vy) down to targetSpeed
	 *  (see canShedSpeed); proofs are first braking moves that are geometry-legal,
	 *  alive, not on a predicted opponent cell, recursively roomy when
	 *  {@code requireRoomy}, and complete the descent within 2 more moves. If
	 *  bestBrake is non-null, the accel of the proof move with the lowest
	 *  resulting speed (ties: Direction order) is written to it. Stops counting
	 *  at 2 (only "< 2" vs ">= 2" matters).
	 */
	private int countBrakeProofs(final int x, final int y, final int vx, final int vy,
			final double targetSpeed, final CellOccupancy predicted,
			final int[] bestBrake, final boolean requireRoomy) {
		int proofs = 0;
		double bestSpeed = Double.MAX_VALUE;
		final double speed = Math.hypot(vx, vy);
		for (final Direction bd : DIRECTIONS) {
			final int bvx = vx + bd.dx;
			final int bvy = vy + bd.dy;
			if (RaceGame.aiVelocityOutOfRange(bvx, bvy))
				continue;
			final double bSpeed = Math.hypot(bvx, bvy);
			if (bSpeed > speed)
				continue; // braking cone only
			final int bx = x + bvx;
			final int by = y + bvy;
			if (!game.isMoveLegalGeometryCached(x, y, bx, by))
				continue;
			if (!reach.isAlive(bx, by, bvx, bvy))
				continue;
			if (predicted.contains(bx, by))
				continue;
			if (requireRoomy && !isRoomy(bx, by, bvx, bvy, 1))
				continue;
			// O(1) fast path via the precomputed min-|v|^2 maps:
			// canShedSpeed(..., 2, ...) succeeds iff SOME state on a <=2-step
			// braking chain has hypot <= targetSpeed, i.e. iff the minimum
			// |v|^2 over those chains is <= targetSpeed^2. Exact for the
			// integral targetSpeed of all callers (the widthBudget <= 14):
			// while targetSpeed^2 < 255 the clamp can't flip the compare.
			// Anything else falls back to the recursive reference code. The
			// aliveIdx access is in range: isAlive above returned true.
			final byte[] shedMap = requireRoomy ? reach.minShed2Roomy : reach.minShed2;
			final boolean shed;
			if (shedMap != null && targetSpeed >= 0 && targetSpeed == Math.rint(targetSpeed) && targetSpeed * targetSpeed < 255.0)
				shed = (shedMap[reach.aliveIdx(bx, by, bvx, bvy)] & 0xFF) <= targetSpeed * targetSpeed;
			else
				shed = canShedSpeed(bx, by, bvx, bvy, targetSpeed, 2, requireRoomy);
			if (shed) {
				proofs++;
				if (bestBrake != null && bSpeed < bestSpeed) {
					bestSpeed = bSpeed;
					bestBrake[0] = bd.dx;
					bestBrake[1] = bd.dy;
				}
				if (proofs >= 2 && bestBrake == null)
					break;
			}
		}
		return proofs;
	}

	/** True iff speed can be reduced to <= targetSpeed within {@code depth} moves
	 *  using only non-speed-increasing, geometry-legal moves through alive
	 *  states -- additionally recursively roomy states when {@code requireRoomy}
	 *  ({@link #isRoomy} -- knife-edge single-file threads don't count).
	 *  Opponent-blind beyond the first move, like the reachability map. */
	private boolean canShedSpeed(final int x, final int y, final int vx, final int vy, final double targetSpeed, final int depth,
			final boolean requireRoomy) {
		if (Math.hypot(vx, vy) <= targetSpeed)
			return true;
		if (depth == 0)
			return false;
		final double speed = Math.hypot(vx, vy);
		for (final Direction d : DIRECTIONS) {
			final int nvx = vx + d.dx;
			final int nvy = vy + d.dy;
			if (RaceGame.aiVelocityOutOfRange(nvx, nvy))
				continue;
			if (Math.hypot(nvx, nvy) > speed)
				continue; // braking cone only
			final int nx = x + nvx;
			final int ny = y + nvy;
			if (!game.isMoveLegalGeometryCached(x, y, nx, ny))
				continue;
			if (!reach.isAlive(nx, ny, nvx, nvy))
				continue;
			if (requireRoomy && !isRoomy(nx, ny, nvx, nvy, 1))
				continue;
			if (canShedSpeed(nx, ny, nvx, nvy, targetSpeed, depth - 1, requireRoomy))
				return true;
		}
		return false;
	}

	/** True iff (x,y,vx,vy) has at least two one-step continuations that are
	 *  geometry-legal, alive and -- for depth > 0 -- themselves recursively
	 *  roomy. Finish-crossings count unconditionally. Distinguishes genuinely
	 *  open road from alive-but-knife-edge single-file threads. */
	private boolean isRoomy(final int x, final int y, final int vx, final int vy, final int depth) {
		// O(1) fast path via the maps precomputed in computeReachability()
		// (always ready in practice: reach.ensureReachabilityReady() runs before any
		// AI move). States outside the precomputed space fall through to the
		// recursive body, which states the same rule (its in-range sub-calls
		// hit the maps). Round 222: the body used to carry a lap-aware
		// crossing rule -- a crossing is an out only when it finishes, or
		// scores a lap onto a shedable landing -- that no reachable state
		// ever ran, because the map answered first. Built as frame-specific
		// maps and raced on the fleet it was inert (crashes 0 -> 0, +78 moves
		// in 1854172, 708 of 730 races identical, fractal18 slower on seven of
		// ten seeds), so the map's rule is the rule: a legal forward crossing
		// counts as an out in every lap frame.
		final BitSet roomyMap = depth == 0 ? reach.roomy0 : depth == 1 ? reach.roomy1 : null;
		if (roomyMap != null && !reach.velocityOutOfRange(vx, vy) && x >= 0 && y >= 0 && x < reach.aliveW
				&& y < reach.aliveH)
			return roomyMap.get(reach.aliveIdx(x, y, vx, vy));
		int count = 0;
		for (final Direction d : DIRECTIONS) {
			final int nvx = vx + d.dx;
			final int nvy = vy + d.dy;
			if (RaceGame.aiVelocityOutOfRange(nvx, nvy))
				continue;
			final int nx = x + nvx;
			final int ny = y + nvy;
			if (game.crossesFinishLegally(x, y, nx, ny)) {
				count++;
			} else {
				if (!game.isMoveLegalGeometryCached(x, y, nx, ny))
					continue;
				if (!reach.isAlive(nx, ny, nvx, nvy))
					continue;
				if (depth > 0 && !isRoomy(nx, ny, nvx, nvy, depth - 1))
					continue;
				count++;
			}
			if (count >= 2)
				return true;
		}
		return false;
	}

}
