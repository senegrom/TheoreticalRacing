# racing-memory.md — full working state for continuing the AI campaign

Written 2026-07-21 at the end of the round-40 session (session id
749c6115-9b8c-4154-9f26-d8f380240d27). A fresh agent should be able to
continue from this file alone. Long-form history: see
`C:\Users\carlg\.claude\projects\E--OneDrive-Coding-Java-theoreticRacing\memory\project_ai_architecture.md`
(auto-memory, ~2000 lines, every round's laws and rejections).

## Round 223: the second review, and self-play means every AI

The user asked for another bug-and-debloat pass over the codebase. Three
reviewers over the changed layers (the round-222 AI edits, the game and GUI
layer after the audit fixes, the Python tooling), every finding re-verified
here, and every finding that could change a decision given its own fleet
grid -- the box was free again, so a 730-race grid took fifteen minutes.

FIRST, A CORRECTION TO THE AUDIT ENTRY. Its item 4 said the event thread
swallows an exception thrown inside invokeLater, so a headless failure hung
forever; the fix wrapped headless tasks in a catch-and-exit. The reviewer
probed it: an exception escaping an invokeLater task IS routed to the
default uncaught-exception handler, which Main installs in headless mode
and which exits 1 ("HANDLER on AWT-EventQueue-0", exit 1). The wrapper was
redundant and is removed. The hang mode that does exist is exception-free:
in GUI mode the daemon marks itself ready even when it failed, the AI's
compute rethrew on the EDT with no handler, and the status said "Computing
track reachability..." forever -- the turn now ends the game with the
message.

DECISION-FREE, SHIPPED (corpus byte-identical: 8 goldens, 22 pins; and the
base build's own grid identical to the round-222 final on all 730 races):
  - Restart left the old game playing beside the new one: restartMe never
    left PLAY, so the dead game's AI turn chain kept running on the EDT,
    wrote the log over the new game's and popped its dialog on a disposed
    frame. It leaves PLAY first now, and carries --props / --log / --seed
    into the new game (before, one Restart lost them and a session on a
    bench profile wrote it over user.properties again).
  - --optimal-laps started the reachability daemon and ran the exact search
    beside it, sharing the unsynchronised fallback edge cache on boards past
    the dense limit, for a result it never read. It runs before the maps now
    and rejects a start cell off the course.
  - Undo restored the start-zone flag but not the drawing; lapClosable is
    cleared when a drawn track becomes the loaded track, not when "Draw new"
    is merely chosen; the TRUECONF debug print no longer dereferences null
    audit arrays; optimalMoveAI2 and the kind dispatch are gone (one entry,
    one body; the promotion history moved onto optimalMoveAI1's javadoc).
  - Tooling: 23 files. The log grammar gained TIMEOUT (a timed-out car had
    stayed a live body in every offline board reconstruction) and a detail
    field; needle_audit's private regex, which rejected negative landing
    coordinates, and crash_scan's are gone in favour of parse_move; the six
    log helpers copied across the pins (150 lines) and four copies of
    configure_console live in forensics_common; the builders and
    crash_scan/extract_baseline no longer do work at import time (the
    Nordschleife builder's loop JSON is committed beside it; the Le Mans
    builder's docstring records that the committed track is its output
    after width_normalize); four dead locals; README and AI_DEVELOPMENT
    wording. crash_scan's output is byte-identical before and after.

MEASURED, each against the decision-free base (730 races, 0 crashes,
1854134 moves):

  h. SELF-PLAY MEANS EVERY RIVAL RUNS THE ONE POLICY. The self-play gates
     (certified pace, the equal veto and its retain, the field-acceleration
     frontier, the private-slack frontier, the staged pace certificate)
     compared Kind labels, so after the promotion a mixed AI1/AI2 field --
     the fleet's field -- counted as heterogeneous and kept every one of
     them off, while an all-AI1 or all-AI2 field had them on. They ask
     isAi() now; moverKind is gone.
         seeds 1-10   crashes 0 -> 0   moves -323 (-0.02%)   495 of 730 identical
                      30 tracks faster, 28 slower, median 0.00%
         seeds 11-20  crashes 1 -> 1 (the same race)   moves -507 (-0.03%)
                      502 of 730 identical, 40 tracks faster, 16 slower
     SHIPPED. The first pace gain since round 216, and it came from making
     the code mean what it said.
  i. CANDIDATE ROWS PER ROLLOUT DEPTH. An unsuppressed (true-rival) nested
     scorer took the outer decision's candidate rows and reset them, so the
     decision read a rival's trap/pace rows afterwards (the DJS trigger
     among them); only two of seven sites snapshotted around it. Rows are
     keyed by simDepth now.
         crashes 0 -> 0   moves +20   727 of 730 identical (hybrid6 s10 +5,
         rand6 s3 +7, s9 +8)
     SHIPPED as a correctness fix at noise cost: no added mechanism, a real
     hazard removed.
  j. THE THIN-RIDGE TRUE-RIVAL VERDICT under the confirm depth cap, like
     every other faithful leg.   730 of 730 identical. SHIPPED: free.
  k. THE 1-PLY RIVAL PREDICTOR (pureMinTurnsMove, the trap ladder's and the
     brake proofs' view of a rival) in the rival's own lap frame -- the twin
     of round 222's B.   730 of 730 identical. SHIPPED: free.
  l. THE ROLLOUT VANISHES A CAR ONLY ON A FINISHING CROSSING (final lap,
     nothing owed, its own frame); before, a lap scored or a stray crossing
     took the car off the board.   moves +0, 725 of 730 identical, two
     tracks faster and two slower. SHIPPED: free.

THE FINAL BUILD (base + h + i + j + k + l):
    seeds 1-10 vs the base:   crashes 0 -> 0   moves 1854134 -> 1853792 (-342, -0.02%)
                              486 of 730 identical, 31 tracks faster, 29 slower
    seeds 11-20 vs round 222: crashes 1 -> 1 (the same race)   moves 1853701 -> 1853177 (-524, -0.03%)
                              492 of 730 identical, 41 tracks faster, 16 slower
    against h alone (1-10): -19 more moves, 714 of 730 identical -- i, j, k, l
    compose with it at noise cost.

Corpus on the final build: 8 goldens byte-identical and 22 of 22 pins pass
unchanged -- the self-play gates, now on in mixed fields, never changed a
pinned race, mixed-roster pins included.

## Round 222, second part: the audit's defects, one grid each

Same fleet, same discipline as the promotion above: 73 lap tracks x seeds
1-10, 8 cars, the mixed field, one change per build on top of the promoted
champion, one JVM at nice 19 on the shared box. Each row is that build
against the promotion grid (730 races, 0 crashes, 1854172 moves).

  A. LAP FRAME RESTORED after a nested rival compute. scorerMoveOverState
     saves lapGate / lapAware / robustMode / exactRemaining before it runs a
     rival's compute and puts them back in its finally, beside inScorerSim.
         crashes 0 -> 0   moves 1854172 -> 1854143   728 of 730 identical
     Two races changed, both faster (hybrid6 s9 -19, lobe6 s6 -10). SHIPPED.
     The clobber was real and rarely decisive: the rollouts that reach a
     rival's compute mostly finish before the outer decision reads ttf again.

  B. EVERY CAR PRICED ON ITS OWN GATE SCHEDULE. Each decision entry records
     per-player gate, lap-awareness and remaining events by player index;
     ttfFor(idx, ...) prices a state in that player's frame and is used by
     the rollout's rival models (smom and greedy), the two-round pure
     min-turns rival prediction, the rollout's terminal field cost and the
     decisive rival's distance in endgameSolve; the rival models' crossing
     rule follows the same frame. ttf() for the mover is unchanged.
         crashes 0 -> 0   moves 1854172 -> 1854163   724 of 730 identical
     Six races moved by one to eight moves, net faster. SHIPPED. Small for a
     reason: a rival close enough to shape the mover's decision is usually
     in the mover's own gate phase, so the wrong frame rarely reached a
     choice.

  C. THE ROBUST SET'S DOUBLE COUNT -- built strictly and MEASURED WORSE. The
     pop skipping gate-passing edges shrinks the robust sets by about one
     per cent (circle: 261523/262888/263320 -> 259120/259405/259405) and on
     the fleet:
         crashes 0 -> 1 (circle s6)   moves +0.14%   116 of 712 identical
         42 tracks slower, 28 faster
     (712 races: the kernel took the JVM on lemans and the Nordschleife at
     the memory low point, by design; the verdict does not depend on them.)
     NOT SHIPPED. The lenient count is kept and named THE PASSAGE RULE in
     computeRobustReach's javadoc: a passage whose landing is robust in the
     next gate's set carries that fault tolerance across the line -- the
     crossing move itself is the one edge no rival lane closes. Read as a
     definition it was a double count; read as racing it is right, and the
     rounds 210-221 measured exactly this set.

  D. ROOMY MAPS IN THE MOVER'S LAP FRAME -- built and MEASURED INERT. Three
     variants per depth (FINAL: a legal crossing finishes, the map as before;
     LAP: gate 0 owed on a non-final lap, a crossing counts only as a legal
     move to a shedable landing; OWED: a checkpoint owed, a crossing is an
     ordinary move), built by the post-gate re-derive and selected by the
     mover's frame -- the rule the recursive body had always stated and
     never got to run.
         crashes 0 -> 0   moves 1854172 -> 1854250   708 of 730 identical
     Twenty-two races moved; the only systematic effect is fractal18 slower
     on seven of ten seeds (+93), the other tracks net -15. NOT SHIPPED: an
     inert addition of three maps is not a fix. The body now states the
     map's rule -- a legal forward crossing is an out in every lap frame --
     with the measurement beside it, so the two no longer disagree.

  E. Re-examined and reclassified: BY DESIGN. finishRunUpLegal waives the
     part of a finishing move past the line for EVERY crossing; a car that
     stands on the line has an empty run-up, so its forward move finishes
     wherever it lands -- exactly what a car one cell behind the line gets.
     Reaching the line without crossing it costs a move, so there is nothing
     to exploit and nothing for a grid to see. Not changed.

  F. THE CACHE KEY VERSIONED ON BOTH BRANCHES (-lap14 / -p2p14, one constant).
     Behaviour-neutral on the lap fleet by construction; point-to-point
     courses rebuilt once under the new key and the four goldens on them
     came back byte-identical, so the pre-215 files had not drifted for
     those geometries. SHIPPED with the others.

THE FINAL BUILD (promotion + A + B + F, with C and D resolved in comments):

    seeds 1-10 vs the promotion grid:
        crashes 0 -> 0   moves 1854172 -> 1854134 (-38)   722 of 730 identical
        the eight changed races are exactly A's two and B's six, at the same
        deltas: the fixes compose additively and F changes nothing on the lap
        fleet, as it must.
    seeds 11-20 (never tuned on) vs the round-216 champion:
        crashes 1 -> 1 (the same race)   moves 1853712 -> 1853701 (-11)
        724 of 730 identical; six races moved by one to ten moves, net faster.

Corpus on the final build: 8 goldens byte-identical, 22 of 22 pins pass unchanged -- the fixes
change decisions too rarely to reach any pinned race.

What this round says about the frontier: the scorer's correctness debts
were real and almost free. Three of them, fixed, move fewer than one race
in a hundred; the one that moves many races (C) moves them the wrong way,
because the "bug" was carrying a racing truth the definition had missed.

## Round 222: the agents made equal

The user's word on the audit's findings: "fix them, make the agents equal /
fix the defects / review the other six findings with grids", then "promote
once ready and tested". This entry is the promotion; the defect fixes follow
as their grids land.

THE PROMOTION. The three arms still gated `moverKind == AI1` -- the
immediate-finish precedence before the endgame seal, the finish-denial
override, and the exact axial-vmax extension of the r178 ridge check -- are
lifted. `optimalMoveAI2` already delegated to `optimalMoveAI1`; with the gates
gone the two kinds are one policy and no kind-gated arm remains. `moverKind`
survives only for the homogeneity gates, which compare kinds among players
and are unaffected.

TESTED THREE WAYS.
  - The board that pinned the difference: hairpin s68 with an all-AI2 field,
    where p8 as AI2 died at move 104, now finishes p8 sixth with no crash.
  - The corpus: 8 goldens byte-identical (no golden race reaches the arms);
    20 of 22 pins unchanged; the two that froze the old AI2 control moved
    exactly as the promotion predicts -- finish-denial's AI2 race is now the
    rescued race (7 finishers, no crash, hash 802fef7f...) and AI2 takes the
    guaranteed crossing on all three immediate-finish boards -- and both pins
    are rewritten to assert that every roster of either kind drives the same
    race. Both pass on the promoted jar.
  - The fleet grid, 73 lap tracks x seeds 1-10, 8 cars, the mixed AI1/AI2
    field, against the round-216 champion:

        crashes    0 -> 0      timeouts  0 -> 0
        finishes   5110 -> 5110
        moves      1854172 -> 1854172     730 of 730 races identical

    The arms never changed an outcome in 730 lap races: they fire on
    final-lap endgames with one to three live rivals and on exact speed-11
    ridge holds, situations these races do not produce. Provably free.

Grid conditions worth recording: the box was shared with another session's
seven MILP jobs at 100% CPU, so the grid ran one JVM at nice 19 on the one
free core (80 minutes for 730 races instead of 15) and left those jobs alone.

## 2026-09-04 audit: the champion is current, AI1 is NOT AI2, and eleven defects

The user asked three things: is the champion promoted and current, is AI1 = AI2,
and scan once more for bugs and debloat.

CURRENT: yes. `build_main.sh` from HEAD reproduces the repo jar byte for byte
(sha256 a844c92d...), and the whole corpus is green on it -- 22 Python pins, 8
golden races (every hash unchanged), CoreTests/MainTests/TrackDataTests, the
tooling unittests and compileall. The shipped champion is round 216; 217-221
were all reverted or never shipped, so HEAD is the champion.

AI1 = AI2: NO, and the pins say so out loud. `optimalMoveAI2` delegates to
`optimalMoveAI1` -- one body -- but THREE arms are still gated `moverKind ==
AI1`, all merged from the local agent's branch under the post-promotion
protocol and never promoted since:

  - the immediate-finish precedence (optimalMoveAI1, before the endgame seal)
  - the finish-denial override (its own kind gate at the top)
  - the exact axial-vmax extension of the r178 ridge check

`ai1_finish_denial_regression` pins the difference by SHA256: on hairpin s68,
p8 as AI2 crashes at move 104 and as AI1 is rescued to seventh. The class
comment on `optimalMoveAI2` claimed "No kind-gated arms remain", which has been
false since those arms landed; it now names them. Promotion still awaits the
user's explicit word, per the frozen-baseline law.

### THE AUDIT. Four reviewers over the four layers, every finding re-verified
here before it was believed. Eleven hold up. They split cleanly into the ones
that cannot touch an AI decision (shipped in this commit, corpus byte-identical)
and the ones that can (NOT shipped -- they are the next rounds).

SHIPPED, provably decision-free. Undo snapshots exist only when `!autoMode`,
the confirm dialog is human-only, the CLI guards run before any race, and the
properties target is an IO path. Goldens byte-identical, 22 pins pass.

 1. `commitMove` granted the CP1/CP2 advance BEFORE legality and before the
    human "going there will crash you" confirm, whose No-return abandons the
    move -- so a human could bank a checkpoint by proposing a crashing move
    through the gate and declining it. The snapshot push sat after the
    mutation, so Undo could not recover it either. The transitions are now
    computed, used for `lapCross` exactly as before, and applied only once the
    move commits.
 2. `MoveSnapshot` never captured `lap`, `nextGate`, `traceStart`, `gateMark`
    or `startZoneGone`. Undo across an S/F crossing rewound position and
    velocity and left the lap banked: the car then finished the race a lap
    early. The snapshot now carries the gate ledger.
 3. `isAutoRace()` forgot `--optimal-laps`, which `Options.headless()` counts,
    so the exact solo search aborted with "--auto requires every configured
    player to be AI" on any config with a human -- which is the default. And
    `--seed A-B --optimal-laps` silently ran the races and dropped the search.
    Both reproduced from the CLI; both are now correct/explicit.
 4. Headless work runs inside `EventQueue.invokeLater`, and the EDT catches
    Throwable and keeps pumping: a headless failure printed a trace and then
    hung forever on a non-daemon thread. A hung fleet job costs hours, so
    headless tasks now exit 1.
 5. `--props FILE` was honoured on read and ignored on write, so a GUI session
    started on a bench profile wrote it over the user's own `user.properties`
    on Save, OK, Exit or Restart.
 6. The round-215 "Exit saves config" fix overshot: Cancel ran the full
    `commitSelections()`, so merely BROWSING the track combo and pressing Exit
    selected that circuit and overwrote the typed grid size with its
    dimensions. Cancel now keeps the fields and the kinds and leaves the track
    alone; only OK commits a track.
 7. "Draw new track" left `lapClosable` from the previously loaded circuit in
    the properties, so a hand-drawn open track could skip the loop-closure
    clamp.
 8. `bench_ai.DEFAULT_TRACKS` still named `the_long_loop`, `sprint` and
    `curve` -- deleted or renamed by 4a99798 on 2026-08-29. A missing track
    makes the row INVALID and the bench invalid, and EIGHT of the eleven
    promotion-battery stages call `bench_ai.py` with no positional tracks, so
    they run on this list. The promotion battery has been broken for a week.
    Same deleted `sprint` led `ai_probe.DEFAULT_TRACKS` and the README command
    that copy-pastes it.
 9. Debloat: a dead `h11` binding whose own comment says the verdict is
    ignored; `OptimalPotential.stages()`, no callers repo-wide; the last two
    record-only pin constants (the earlier sweep missed them -- their names
    differ from their siblings'); an unused import; README listed
    racing-memory.md twice, omitted the pins, and named a Silverstone golden
    case the 12-case corpus does not contain.

NOT SHIPPED -- these change decisions and are owed a measured round:

 A. **The nested compute clobbers the mover's lap context.** `optimalMoveAI1`
    assigns `lapGate`, `lapAware`, `robustMode` and `exactRemaining` at entry,
    unconditionally, before any `inScorerSim` gate. `scorerMoveOverState` sets
    `game.subgamestate = i` and calls `computeAiMove()` for a RIVAL; its
    `finally` restores positions, velocities, finished places, subgamestate and
    `inScorerSim` -- but not those four. So after the first scorer-rival move
    inside a rollout, the outer decision keeps pricing on a rival's gate, lap
    count and robust flag, and `simOutcomeCore`'s own terminal `ttf` reads
    return values from whichever rival happened to be computed last. The field
    javadoc asserts the invariant this falsifies ("the dispatcher is only
    entered from RaceGame (no recursion)"). Inert when `lapGates == null`;
    live on every lap race, which is the entire fleet.
 B. **`ttf()` prices rivals on the mover's frame even without (A).** Round
    216 made `ttf` read `exactPot.movesToFinish(exactRemaining, ...)`, and
    `exactRemaining` encodes the MOVER's gate phase and laps done. It is then
    called on rival states in `rivalMoveOverState`, in the rollout field cost,
    and in `endgameSolve`'s `rT` -- which is compared against `myT` to decide
    "I cross first". Two cars in the same lap but either side of CP1 differ by
    a whole gate, so the predicted rival line skips a checkpoint. The shape
    predates 216 (`lapGate` was always the mover's); 216 widened the error from
    one gate to whole laps.
 C. **The robust set double-counts one continuation.** In `computeRobustReach`
    the seed pass credits `arrivals[P]` for the edge P->S that crosses the
    gate; when S is later popped, the pop decodes P as S's predecessor for that
    SAME direction and credits it again. A state with exactly ONE continuation
    reaches arrivals == 2 and is certified 1-fault-tolerant. On a closed
    circuit S is in the robust set for essentially every gate-passing state, so
    this is not a corner case. `isRobust` is what the whole needle surcharge
    (rounds 210, 216-221) rides on: it over-certifies, so the surcharge is
    silently NOT firing on some genuinely thin states. This is the most
    consequential finding of the audit.
 D. **The roomy map and its reference body compute different predicates.**
    `isRoomy` returns the precomputed bit unconditionally for any in-range
    state, so the recursive body's lap-aware crossing rule
    (`!lapAware || lapGate == 0 && shedableLanding`) is dead code, while
    `sweepRoomy` counts `crossesFinish && finishRunUpLegal` with no
    lap-awareness at all. Since 215 this applies to single-lap races too.
 E. **`finishRunUpLegal` waives the whole move when it starts ON the line.**
    `along == 0` gives `u == 0`, so the sample loop re-tests the start cell and
    nothing else: a car standing on the gate can finish through a wall. The
    same referee backs `OptimalLap`, so the "exact optimum" inherits it.
 F. **The cache key versions only the lap branch.** Round 215 added
    `finishRunUpLegal` to the alive seed unconditionally but bumped the key to
    `-lap14` only when `lapGates != null`, so a point-to-point cache written
    before 215 is still accepted. `E:\tr-reach-cache` holds unsuffixed files
    from 2026-08-13/14 under a live key. `verify_reach_cache.sh` proves
    cold == warm within one build, which is exactly the axis that cannot catch
    this.
 G. Smaller: an unsuppressed rival compute calls `outerCandidates.reset()` on
    the arrays the enclosing decision is still reading (only two of seven sites
    take the `trueConfirmCandidateSnapshots` guard that exists for it, so the
    round-95 retain gate silently never fires after a true-rival confirm); the
    ridge true-rival leg omits `trueConfirmDepth++`, so the depth cap never
    engages on that leg; an NPE in the `TRUECONF` debug print when the speed
    bands arm on a non-audit call; a live `javax.swing.Timer` orphaned by
    Restart that races the dead game on the EDT.

### FRONTIER after this audit. The scorer is at a measured local optimum and
the remaining gap is not in its weights -- it is in three things the audit
found, in this order: (C) the robust set certifies needles it should refuse;
(A) the rollout prices the outer decision on a rival's lap frame; (B) rivals
are predicted on the mover's gate schedule. Each is a correctness fix with a
plausible racecraft payoff, and each needs its own fleet grid. Round 220's
list -- the start gradient, and a game where cars are not equal -- stands
behind them.

## Round 221 (not shipped): the 8% false alarms, predicted away, are worth 41 moves

Round 220 found that 8% of the lanes the needle surcharge refuses stay clear.
The user asked for that fixed. The fix is the lane planner in its smallest
form: at each decision every live rival is rolled four moves along its own
exact solo line and, as a second branch, coasted straight at its velocity;
every cell touched, dilated by one, goes into a per-decision set; a thin
state is charged only if the cells of its own solo line -- the state and its
next three moves -- meet that set. robustMode, isRobust, the surcharge's size
and the gate-map fallback are untouched. It is a strict subset of the old
gate: it can only remove charges.

PRE-FLIGHT. All seven killer boards finish every car, net faster on them.
The 30-race sample: +0.04%.

THE FIX MEASURED ON ITS OWN TERMS. The round-220 probe rebuilt on top of the
candidate and re-run on the same forty races, now also recording the gate's
verdict on each declined lane:

                                   champion        candidate
    decisions / moves lost         90528 / 6289    90469 / 6248
    thin optimal landing declined  11995 / 3612    11900 / 3596
    lane contested within 4 rounds 11030 / 3503    10906 / 3503
    false alarm (lane stayed clear)  965 /  109      994 /   93

    candidate false alarms by its own gate:
      gate let the lane through, car declined anyway   389 decisions   24 moves
      gate still charged it (predictor too pessimistic)  605 decisions   69 moves

So the false alarms were never one thing. Four in ten are not the surcharge's
decisions at all -- the lane was uncharged and some other term (the trap
ladder, needle headway, a charged leaf two plies down) still declined it. The
rest are lanes a solo-line-plus-coast predictor cannot tell from contested
ones, and they carry 69 lost moves in 90469 decisions. End to end the
candidate recovers 41 moves: 0.05% of race moves, inside the noise of a 30-race
sample, against a gate that now lets 436 genuinely-contested lanes through
(the car declined them for other reasons in these races; in others it would
not). Not shipped, and not sent to the fleet: a crash-risk experiment for a
gain the instrument cannot see.

WHAT THIS CLOSES. The needle surcharge is now measured from every side --
removed (218), aimed (219), audited against the race (220), and predicted
(221). Its cost is earned. Recall of the four-round solo-line predictor on
genuinely contested lanes is 96% (10470 of 10906), which says these cars are
predictable; the trouble is that nearly every thin lane in traffic IS
contested, so there is nothing left to predict away.
## Round 220 (feasibility probe, no candidate): the lane is almost never free

After 216-219 the scorer is at a local optimum on every weight and the
remaining gap looked structural: eight equal cars on one racing line. The one
structural idea left was a multi-car lane planner -- predict the rival's path
through the next corner and take a thin lane when it will stay clear instead
of paying the surcharge for it. Before building it, one probe to size its
pool.

THE PROBE. A scratch build prices every real decision against the exact
potential and, whenever the surcharge plausibly moved the car off its optimal
landing (robust mode on, that landing non-robust, another taken), prints the
lane it declined: the landing plus the next three cells of the exact solo line
from it. An offline pass then reads the ACTUAL race: did any rival stand on or
beside one of those cells during the next four rounds? Forty races, twenty
tracks from twisty to flowing, seeds 1-2.

THE NUMBERS. 90528 real decisions, 6289 moves lost (6.9% of moves). Two
thirds of the loss (4192 moves) falls while a rival is within ten road cells
and six cells -- in company. The surcharge-shaped decisions number 11995 and
carry 3612 lost moves, 57% of everything lost. Of those lanes:

    contested within four rounds   11030  (92%)   3503 moves
    false alarm, lane stayed clear   965  ( 8%)    109 moves  = 1.7% of all loss

Per track the false-alarm share tops out at 6% (fractal20) and is zero on
cog, hybrid3, lobe4 and rand12 -- the twisty boards where the pace is lost
are exactly where every declined lane gets taken.

WHAT IT MEANS. The surcharge is right nine times in ten by the race's own
testimony: the lanes it refuses are lanes a rival then occupies. A planner
that predicted rivals perfectly could recover 109 of 6289 moves -- a tenth of
a percent of race moves -- before paying anything for its own mistakes. That
is not a project. The field's loss in traffic is earned caution over
genuinely contested road, and the campaign's instruments now say so from four
directions: removing the caution kills cars (218), aiming it recovers nothing
(219), scaling it changes nothing (217), and the lanes it avoids are occupied
(220).

FRONTIER. Pace in traffic is closed for this architecture. What is left:
(a) the 8% false alarms, worth 0.1%; (b) the start -- p1 runs 0.5% off the
fastest car on its board, p7 3.2%, and that ordering is set before the first
corner; (c) a different game entirely, where cars are not equal. The probe
build and its analysis (E:\tmp-claude\probe220.py, needle_pool.py) are the
instrument for whoever reopens this.

## Round 219: the needle surcharge, aimed (reverted)

Round 218 said the surcharge was a veto worth 2.3% of the fleet's moves and
that removing it killed cars. This round asked what, exactly, it was
preventing, and aimed it at that.

THE AUDIT. A new tool (tracks/needle_audit.py) walks a crashed car back
through its last moves and asks the game's own oracle how many of its nine
landings were alive and how wide the lane it chose was, with the rivals where
they stood. Five surcharge-0 deaths were audited -- Monza s1 p2 (the double
crash that hit every seed), Monaco s4 p1, Le Mans s6 p8, fractal20 s1 p8,
lobe1 s2 p6 -- and they tell one story. The car enters a single-lane landing
two to four moves before the wall (Le Mans ran four consecutive thread-1
states) and a rival then occupies the one cell it needs; the crash move itself
has nothing open, the death was decided upstream. At the decisive move the
closing rival stood ONE TO THREE cells from the chosen landing in every case:
Monza p8 at 3/2/1, Monaco p5 at 2/1/1, Le Mans p7 at 1, fractal20 p4 at 2/1,
lobe1 p5 at 1. Wheel to wheel, never twelve cells ahead.

THE OLD GATE. robustMode fires on any rival ahead or beside the CAR within
max(12, min(s(s+1)/2, 24)) cells, and then every non-robust state the scorer
prices -- including the deep search's leaves two plies out -- costs twelve.
A first attempt gated each priced state on a rival's two-round kinematic
reach (2|v_r|+3 plus the state's envelope): that bound is about the size of
the old radius, so it fired in the same places, 7 of 10 tracks byte-identical,
-0.04%. A gate has to be tight to discriminate, and the audit says tight is
correct.

THE CANDIDATE. A non-robust state is charged only if a live rival stands
within the state's own next-move envelope plus two cells,
cheb(rival, state) <= |v|+1+2 -- "someone is on or beside the lane I am about
to use". Evaluated per priced state, so the search still sees it at its leaves.
isRobust, the trap ladder, needle headway, the seals and the joint
roll-forward are untouched. The one-round-each variant (|v|+1 + |v_r|+1) was
also tried: flat (+0.01%). On the five killer boards both variants finish
every car; near2 is a few moves faster on four of them. 30-race sample:
near2 -0.36%, 7 of 10 tracks faster, no crashes.

V1 ON THE FLEET -- reverted after one slice. Seeds 1-10: 2 crashes against
the champion's 0 (monza s3, spielberg s9). Both audited at once, and they are
the OTHER way a lane closes: the car enters a long single lane at speed with a
SLOW rival 11-18 cells ahead IN the lane (Monza p7 at 11, |v| 4 falling to 2;
Spielberg p5 at 18, |v| 6 falling to 3), the rival keeps slowing, and the exit
shuts five to seven moves later. That is round 212's rand6 lesson -- a parked
pack thirteen cells ahead -- and the old gate's 12-24 cell kinematic range was
exactly the stopping distance that covers it. A two-cell gate cannot see it.

V2. Two conditions, both measured from the priced state: a rival within the
next-move envelope plus two cells (beside), OR a rival ahead ON THE ROAD --
distAt smaller -- by no more than the state's stopping range
max(12, min(s(s+1)/2, 24)) and within that many cells geometrically (ahead).
What the old gate charged and v2 does not: a rival beside or behind beyond the
envelope, and one geometrically ahead but not ahead on the road (the opposite
leg of a hairpin, the outside of a wide turn). On the box: all seven killer
boards finish every car, net faster on them; the 30-race sample -0.02%.

THE FLEET (730 races per slice, champion = round 216):

            crashes        moves       tracks
    1-10      0 -> 0     -0.02%   37 faster / 30 slower
    11-20     1 -> 1     -0.04%   39 faster / 27 slower
    21-30     0 -> 0     -0.04%   40 faster / 22 slower

Seeds 1-10 in detail: 207 of 730 races byte-identical, median per-track
delta -0.01%, 37 tracks faster, 30 slower, 6 unchanged -- total moves are
FLAT. The other two instruments are not. Closing-lap pace gap (start-free):
best car 1.69% -> 1.41% above a
perfect lap, field median 4.71% -> 4.29%,
18 tracks closer and 13 further. Running order over the last two laps: 1056 ->
1195 inversions of 15330 pairs (6.9% -> 7.8%), races with no change 327 -> 290,
cars holding station 3514 -> 3350. On 730 races that is a four-sigma change,
not the 30-race mirage of round 218. What it means: the fleet is no faster in
sum, but the cars pass each other more and a thin state is taken where nobody
can contest it, so the running order is earned more often -- or so slice one said.

SLICES TWO AND THREE. Seeds 11-20: the one crash is fractal3 s17, the race
the champion loses too; moves -0.04%, 212 races byte-identical, 39 faster /
27 slower. Seeds 21-30: 0 -> 0, -0.04%, 226 identical, 40 faster / 22
slower. Safety is exactly the champion's over 2190 races. But the order effect
did NOT reproduce: on seeds 11-20 inversions went 7.3% -> 7.2% and the
closing-lap gap 4.55% -> 4.48% (23 tracks closer, 14 further). Slice one's
four-sigma signal was real for those seeds and specific to them. Flat pace,
no reliable order change, more code: reverted.

WHAT STANDS. Once the gate covers both ways a lane closes -- a rival beside it
within the envelope, or ahead in it within stopping distance on the road --
it fires where the old gate fires. The old gate was not blunt; the surcharge's
2.3% is the price of those two mechanisms, and the campaign has now measured
it from both sides (218: remove it and cars die; 219: aim it and nothing is
gained). The needle deaths are structural: a single lane is dangerous exactly
when someone can reach it, and someone usually can.

LANE STYLE, MEASURED WHILE WAITING. Round 201 gives two thirds of the field
perturbed tie-break weights (AI1_LANE_STYLE = 0.12) so eight cars do not
stack on one geodesic. The per-class pace numbers had looked like a cost
(class 1 at 1.2-1.4% off the fastest car on its board, class 2 at 2.1-2.2%).
A dial build racing the 30-race sample at 0.06 and at 0.0: -0.00% and
-0.01%, no crashes. The classes differ by grid position, not by their
weights; the spread costs nothing and is left alone.

ALSO. tracks/forensics_common.py now parses lap-completion lines; before,
every "LAP n/3" move was skipped, a reconstructed board could put two cars on
one cell, and the oracle died. board_at.py's docstring now says its offline
map is the finish map and is blind to gates in a lap race.

## Rounds 217-218 (reverted): where the time is NOT, and one veto that never fired

Two candidates, six sweeps, three new instruments, no shipped policy change.
The map they drew is the result, so it is written down in full.

WHAT 216 LEFT OPEN. Half the recoverable pace was "a caution term outbidding a
pace term that had already found the optimum". A term-attribution probe named
it: over 12199 decisions on seven tracks, 651 moves went to a term, and
uncertified took 279 of them (trap 167, cost 107, rob 57, spread 31; corner,
queue and mom negligible). Inside uncertified the round-206 car-following
excess was present in 242 of 272 cases against 152 for the brake proofs.

ROUND 217, ARM A -- reverted. The round-49 and round-62 pace recoveries ask
"strictly faster?" of poTByDir, which since 216 carries the round-210 needle
surcharge. Of 450 landings they refused as not faster, 407 WERE faster on the
raw exact distance; the surcharge alone said otherwise. Giving both recoveries
the surcharge-free number: 10 tracks x 3 seeds, +0.09%. The unblinded lines
reach the later gates (zero trap, not sealable, DJS survival) and die there.

ROUND 217, ARM B -- reverted. The following law projects rivals onto a
forty-cell heading ray, and on a twisty board the ray leaves the tarmac: of 373
optimal landings charged for following, 206 were braking for a car BEHIND me
on the road (152 within five cells; none the finish-line wrap). Requiring the
leader to be at-or-ahead in track progress, with the +3 slack and wall
exclusion every other traffic term uses: +0.01%. Both arms removed a caution
exactly where its premise was false, and neither converted into race time.
LESSON: per-decision loss against the solo potential is an upper bound on
recoverable pace, not a prediction of it. In company, a locally optimal move
is not a globally faster race.

THE SWEEPS. One dial at a time, 10 tracks x 3 seeds, K = 1 bit-identical to
the champion (folding the cautions into one product regroups the additions and
flips near-exact ties by a ULP; the scaled path only runs when the dial is
turned):

  whole soft caution stack x0.85/0.70/0.50/0.30 : +0.02 +0.05 +0.06 -0.01%, 0 crashes
  search depth 3 / 4                            : +0.32 / +0.83%  (deeper is WORSE:
                                                   body pricing covers plies 1-2 only,
                                                   so a deeper search is traffic-blind
                                                   at its far end)
  predicted-body price x0.5 / x2.0              : -0.01 / +0.02%  (8 of 10 tracks 0.00)
  ply>=1 predicted-body veto -> price 0/1.5/3/6 : byte-identical on all 30 races

The soft stack is nearly weightless: scaled to 30% it neither costs a crash nor
buys pace. The ranking is decided by costToFinish, whose leaves are the exact
potential since 216 -- the car is already driving very nearly the deep-search
optimum, and the caution terms mostly break ties.

THE VETO THAT NEVER FIRED. Both soft searches carried, at every ply past the
first, "if predictedSteps[stepIdx] contains the landing, continue". It reads as
refusing to plan through a predicted body. predictedSteps is built ONE step
deep (predictedOpponentSteps(playerNum, 1)), so its length-1 bound admits only
stepIdx == 0 -- the other arm of the same if/else. Unreachable by reading,
byte-identical by measurement. Removed; ply-1 bodies are priced through
aheadOccupancy, which is live. Behaviour-identical build, verified on four
races against the champion logs.

ROUND 218 -- reverted, and the most instructive number of the session. The
needle surcharge is the one weight that lives INSIDE the pace term, so no
caution sweep could touch it. Sweeping it:

  12 / 8 / 5 / 3 / 2 : byte-identical      -- not a weight but a VETO: anything
                                              >= 2 exceeds every candidate gap
  1                  : -0.61%, 0 crashes   -- a tie-break toward thick states
  0                  : -2.29%, 0 crashes   -- and on those 30 races 14.6% of
                                              pairs swapped order vs 8.1%

Then the fleet. Surcharge 0: 6 crashes in the first 283 races, two cars in
EVERY monza seed, stopped there. Surcharge 1, three full slices:

                     seeds 1-10   seeds 11-20   seeds 21-30   total
    champion (216)   0 crashes    1             0             1 in 2190
    surcharge 1      0            2             5             7 in 2190
    moves            -0.72%       -0.72%        -0.79%

69 of 73 tracks faster on every slice, field pace gap 4.71% -> 3.92%, and
seven cars lost against one. Crashes decide first. The surcharge is
load-bearing; it just does not look like a weight. And the "more racing" the
30-race sample showed did not survive the fleet: 6.9% -> 6.8% of pairs swap
order, 69% -> 71% hold station. METHOD LESSON, twice over: the 30-race sample
said "zero crashes at every setting" and the fleet found 7; the 30-race sample
said "twice the overtaking" and the fleet found none. Ten tracks by three seeds
ranks candidates; it does not clear them.

THE PROCESSION. New instrument: order at the end of lap 1 versus the flag.
Fleet-wide, 6.9% of car pairs swap over the last two laps; 69% of cars hold
station; 327 of 730 races see no change at all. A second instrument (following
a slower car within four cells) finds cars in that state 9.5% of the time at a
mean speed 2.4% below clear air -- so queueing is not where the field's 4.7%
goes. The gap is caution paid in the pack (p1 runs 0.5% off the fastest car on
its board, p7 3.2%), and the sweeps say that caution is, at the margin, neither
expensive nor removable. What remains is largely the geometry of eight cars
sharing one racing line.

ALSO. A local sweep with sixteen JVMs at 6 GB each paged a 31 GB box to a
crawl; the capped runner is xargs -P 4 at 4 GB. And the AWS `aws login`
session expired mid-run: only start/stop/describe and the Instance Connect key
push need it, so a running grid finishes regardless, but the box cannot be
stopped or its results pulled until the user logs in again.

## Round 216: the scorer was measuring the wrong distance

SHIPPED. Every caution in the scorer is weighed against a pace number, and that
number was reach.turnsToGate -- how far to the NEXT gate. A race does not
minimise that. The state a car reaches a gate in shapes the segment after it,
so the fastest way to a checkpoint is often not the fastest way to the flag.
OptimalPotential, built in round 214 for the solo policy, answers the right
question in one array read, and ttf() now returns it whenever it exists. The
round-210 needle surcharge still rides on top (reach.isRobust decides, exactly
as turnsToGateNeedleAware did), so robust mode prices single-thread states as
before. No safety term, ladder or weight changed: only the number they are all
weighed against.

HOW THE TARGET WAS FOUND. A scratch build priced every real decision against
the potential -- loss = 1 + value(after) - value(before), zero when the move is
on a shortest race -- and tagged each with what the car could see. 9093
decisions over five tracks, 952 moves lost:

    85 (  9%) forced   -- a live car sat on the best landing
   867 ( 91%) chosen   -- among landings no car occupied, of which
   847 ( 89%) were also on the alive map, and
   652 ( 68%) also had three or more continuations

So two thirds of the whole gap is landings that are free, alive and roomy --
safe by the policy's OWN standards -- and declined anyway. Splitting that again:
half is the pace term ranking a slower landing first (myopia), half is a
caution term outbidding a pace term that found the optimum. This round takes
the first half. Loss also climbed steeply with speed (0.04/move at |v|=3,
0.15 at |v|=7-10), which is the signature of braking that buys nothing.

THE EXTREME WAS MEASURED FIRST. Variant A drove the exact move in traffic
whenever the landing was empty -- no caution at any distance. Five races, ten
crashes against the champion's none. Caution is buying something real, so the
fix had to be the NUMBER, not its removal.

EVIDENCE (both grids 730 races, 8 cars, 73 lap tracks, on the AWS box):

                       seeds 1-10        seeds 11-20 (never tuned on)
    crashes            1 ->  0           4 ->  1
    timeouts           0 ->  0           0 ->  0
    moves             -0.63%            -0.63%
    tracks faster     50 / 22 slower    51 / 21 slower

The three crashes that vanished on the fresh slice are spa s20, rand6 s17 and
rand19 s20; fractal3 s17 still crashes on both builds. The start-free pace
instrument agrees: best car on a track 2.99% -> 1.69% above a perfect lap
(median), whole field 5.73% -> 4.71%, 49 tracks closer to perfect and 20
further. Biggest gains on the small twisty boards the last entry named
(rand12 -4.2%, fractal1 -3.9%, rand3 -3.9%); the losses are small and clustered
on the lobes (lobe4 +1.8%, lobe2 +1.7%).

CONTROLS. The Nordschleife is byte-identical across all twenty seeds -- its
potential is over budget, exactPot is null, and the gate maps serve exactly as
they did, which is the fallback path proving itself. Solo racing is still
exact (circle 111, cog 132, serpentine 103 against the same optima); the alone
branch returns before ttf is ever consulted. Courses without lap gates are
untouched by construction.

RE-BASELINE. 8 of 12 goldens and 8 of 22 pins moved, every one of them a pace
or placement number with finishers and crashes unchanged; re-frozen from
measurement. The bounded-uncertain-field pin is the clean control: seven of its
nine cases came back byte-identical, only Le Mans s29 and s14 moved.

WHAT IS LEFT, AND ONE THING TO CHECK. The other half of the recoverable gap is
caution outbidding a correct pace term -- 489 moves over the five probed tracks
even after this round. That is the next candidate, and it needs the same
treatment: find WHICH term, not remove them all. Separately, lapGate, lapAware,
robustMode and now exactPot/exactRemaining are plain fields set at
optimalMoveAI1 entry with no save/restore, so a scorerMoveOverState rollout
that re-enters the dispatcher for a rival leaves them describing that rival.
simulateTwoRounds does not do this (it uses pureMinTurnsMoveSim), so the main
candidate loop is unaffected, but the DJS path is. It is pre-existing and this
round inherits it rather than adding it; whether restoring them is an
improvement is a measurable question nobody has asked.

TOOLING. The fleet grid is now tracks/fleet_grid.sh in the repo instead of an
ad-hoc script: resumable, RACING_JAR/JAVA/PROPS/HEAP/TRACKS to point it
anywhere, NOLOOP and NOTRACK instead of silent MISSING rows. It is what ran
both grids above. tracks/modal_bench.py is gone (all compute is on AWS) and so
is the vmax-narrow-ridge pin, retired in round 215 and running nothing since.

## Post-215 verification (local agent): the rules cost nothing, and a second instrument

The round-215 rules changed what a lap is, so every reading taken before them
had to be retaken. Three of them were, and one correction follows.

TRAFFIC IS UNTOUCHED. The fleet grid on the round-215 build (all 73 lap tracks
x seeds 1-10, 730 races, on the AWS box in 19 minutes over eight cores): 1
crash, 0 timeouts -- the same rand19 s9 at the same 1456 moves as round 214.
691 of the 730 races run identically to the previous build and fleet moves
differ by -0.00%. Checkpoints everywhere and the finish-wall rule cost the
field nothing.

SOLO IS STILL EXACT. Three laps: 72 of 73 lap tracks match the optimum, the
Nordschleife the only exception at +10 moves because its potential is over
budget. Single lap: 84 of 84, the whole fleet -- which CORRECTS the round-215
entry above, written before the wall rule reached the solver. It said 83 of 84
with serpentine outstanding; serpentine reads 103 against 103 now. The eleven
courses that cannot be lapped were re-measured directly and every one is exact.

THE ATLAS WAS WRONG AND IS FIXED. Its optima were computed with the old
waiver, so it advertised routes that finished through a wall. Only three
figures actually moved: serpentine's perfect run 72 -> 103, and one move each
on fractal10 and rand18. Republished.

THE NEW INSTRUMENT -- WHAT TRAFFIC COSTS. With crashes at one per 730 races the
grid can no longer rank candidates, so pace against the exact optimum becomes
the second axis. Measuring it needs care: the eight cars start on different
cells, so comparing a winner with a solo optimum measured from one cell lets a
well-placed car appear to beat perfection. The start-free version compares the
moves a car spends between its FIRST LAP COMPLETION and the flag -- two laps,
both bounded by line crossings -- against twice the exact steady-state lap.
Reading on the round-215 build: the best car on a track is a median 3.0% above
a perfect lap and the field median 5.7%; the worst tracks are the small twisty
boards (rand19 10.3%, rand5 9.8%, rand12 9.5%, cog 9.3%) and the flowing ones
sit near 1%. Caveat kept in the open: the final lap enjoys the finish
allowance, so a lone car's last lap can be marginally cheaper than a middle
one, which is why a best-car figure can read slightly negative. The number is
comparative between tracks, not a strict bound.

OPS: the round-215 cache key retired 10.2 GB of maps across both cache
locations (E:\tr-reach-cache and a stray LOCALAPPDATA copy written by runs that
did not carry the override).

## Round 215 (local agent, SHIPPED): two rule fixes -- a lap is a lap, and a finish is not a wall pass

Per user direction ("add the checkpoints also to single lap/no lap races" and
"the last move should be allowed to cross walls only on or after crossing the
finish line"). Both were prompted by measurement, and both void old baselines.

RULE ONE -- CHECKPOINTS ON EVERY RACE. The gate machinery switched on only at
laps > 1, so a single-lap race was "cross the line going forwards" with nothing
in between. On circle, whose start zone sits just behind the line, that was a
THREE-MOVE race; on rand20 a car could reach the line without going round (26
moves against an honest lap of 68). The switch is now "does this track have
gates" rather than "is this multi-lap": one lap means CP1, CP2, then the line,
whatever the lap count. Courses whose boundary cannot close still have no gates
and still race end to end. Circle's single lap is now 39 moves.

RULE TWO -- THE FINISH IS NOT A DOOR THROUGH A WALL. The referee waived
legality for the whole race-ending move, so a car could finish by driving
THROUGH a wall into the line from a neighbouring fold. The rule now: the part
of the move before the crossing must be an ordinary legal move; only the part
at or beyond the line is free (RaceGame.finishRunUpLegal intersects the move
with the gate and samples containment along the run-up only). Everything that
reasons about crossings uses the same test -- the alive search, both gate-map
seeders, the robust reach sets, the exact potential, the offline solver -- so
the map and the referee cannot disagree. Cache key -lap13 -> -lap14.

WHY RULE TWO MATTERED, AND A CORRECTION TO THE PREVIOUS ROUND'S NUMBERS: the
"3.45% off optimal" finding was measured with a solver that inherited the
waiver. On serpentine it claimed 72 moves against the AI's 103, and on rand20
26 against 66. Forbid the wall pass and both optima become exactly what the AI
drives. The single-lap AI was never suboptimal: it declined an exploit. Under
the new rules it is exactly optimal on 83 of 84 tracks (the exception is
serpentine, whose remaining gap is the same artifact in the other direction --
see the pin note below).

WHAT DID NOT CHANGE: multi-lap racing. rand19 s9 still runs 1456 moves with one
crash, weave3 s2 3695/0, monaco s1 3451/0 -- byte-for-byte the shipped
behaviour, because gates were already on there.

THE COST, PAID IN BASELINES: the goldens moved on the eight gated circuits (the
four open courses did not) and are re-frozen. Of the 27 battery checks, 16
passed untouched; six re-froze from measurement; five needed judgment:
  - two compared against the PRE-PROMOTION model using constants recorded under
    the old rules. That build cannot be re-run, so the comparison is undefined;
    re-freezing both sides would compare the build with itself. Retired.
  - three pinned a MOMENT -- "at move 95 the car takes the SE rescue", a
    decision trace, a control race that crashes. Replaying the same races on
    the pre-change build shows the car never reaches those states now, and the
    vmax control race no longer crashes at all, so there is no rescue to
    detect. Retired, constants kept as a record.
  - two more pinned a finish by its move index as well as its place; the index
    is a clock the rules moved, so they now pin the placing only.
  - two h2h pins expected both grid orderings to give the same totals; they are
    mirror images now (one policy, two slots), so each ordering carries its own.

## Round 214 (local agent, SHIPPED): drive the exact optimum when nobody is near

Per user direction ("if no opponent is close they should drive optimally").
The measurement said a lone car spends 3.45% more moves than the track allows,
and none of it can be traffic caution because there is no traffic.

FIRST PROBE, and why it was not enough: with no rival inside 20 cells, take the
move the GATE MAP prefers (the greedy descent the rollouts already use to model
rivals) and skip the scorer. It recovered about a third -- circle 9.9% -> 4.5%,
cog 12.1% -> 9.1% -- but rand12 barely moved (15.7% -> 15.1%) and silverstone
got worse. The gate map answers "how far to the NEXT gate", and the state you
arrive at a gate in shapes the segment after it, so its descent is not the
shortest race. Composition, not caution, is the bigger half.

THE LAW (OptimalPotential): fold the gates still owed into the state and search
backward from the finish. Every move and every seed costs one turn, so it is a
plain breadth-first search, not a weighted one, and its greedy descent is
optimal by construction and cannot crash -- a state with a finite value always
has a successor one move closer. It obeys the referee, not the AI: a non-final
passage must be an ordinarily legal move, the race-ending crossing is
legality-waived, and nothing must be shedable or alive. RaceAi consults it when
no live rival is within Chebyshev AI1_ALONE_R = 20; otherwise every existing
law stands untouched. laps=1 never reaches it (8-car byte-identical).

COST: the potential is short-valued over (state, gates remaining), built once
per (geometry, laps) and shared across races in a JVM. Median board 245 MB,
built in under a second; the budget of 1.5 GB skips exactly one track, the
Nordschleife (2.2 GB), which was already within 1.2% of optimal.

SOLO, the point of the round: 72 of the 73 lap tracks now race the EXACT
optimum -- not close to it, equal to it -- and the fleet sits 0.05% above the
theoretical minimum where it was 3.45%. 741 moves saved. The single exception
is the Nordschleife, whose potential is over budget and which keeps the
ordinary policy (10 moves, 1.2%).

TRAFFIC, and the radius that decides it: at AI1_ALONE_R = 20 the fleet grid
went 1 -> 10 crashes, eight of them on weave3. The forensics killed the
obvious theory: at the crash the SCORER was in control, two cells behind a
rival, so this was not a hot handover out of the optimal line. Cars that drive
optimally while isolated simply arrive at the pack in configurations the
traffic laws have never seen. Widening the radius to 40 restores the baseline
exactly: 720 races, 1 crash -- the same rand19 s9, the same 1456 moves -- with
fleet moves -0.01% and 591 of 720 races running identically to the shipped
build. The optimum still applies wherever the track is genuinely clear.
The deeper slice agrees: the 21 bench tracks over fresh seeds 11-20 give
2 crashes, the same two races and the same count as the shipped build.

INSTRUMENT NOTE: the same 730-race grid was run on Modal and on the AWS box,
and every race matched on both move count and crashes. The bench is hardware-
independent. Wall time was about ten minutes either way -- the box keeps its
reachability caches on disk, so it needs no rebuilds, while each container
pays for its own.

VERIFICATION: laps=1 8-car byte-identical; gate battery 27/27 (compile under
-Werror, CoreTests with TrackDataTests 84, MainTests, smoke, tooling, goldens,
23 pins).

## Solo optimum (local agent, SHIPPED tooling): the exact shortest race, and the gap to it

The question was whether a car alone on the track is already optimal. It is
answerable exactly: every move costs one turn, so the fewest moves to complete
the laps is a breadth-first search over (position, velocity, gates completed).
tracks/../src/tr/logic/OptimalLap.java does that search and `--optimal-laps X,Y`
runs it from a given start cell; the flag exits before racing, so the race path
is untouched (laps=1 8-car byte-identical, a lap race unchanged at 1456 moves).

WHAT THE SEARCH OBEYS: the referee's rules only -- a non-final gate passage
must be an ordinarily legal move, the race-ending crossing is legality-waived,
and nothing must be shedable, certified or reachability-alive. Pruning to the
AI's own alive set would have measured the AI against its own conservatism.
The one shared limit is the velocity domain (|v| <= 12 per axis). Cost: about
a second per track on a 150x150 board, because the search only ever visits the
states actually reachable from the start (1-2M of the 10M-state product).

THE READING (all 73 lap tracks, one car, three laps, the AI's own start
cell): the AI spends 22510 moves where 21759 suffice -- 3.45% above optimal. Spread:
21 tracks within 2%, 27 between 2 and 5%, 20 between 5 and 10%, 4 worse, worst
rand12 at +15.7% (199 against 172). Exactly one track is driven perfectly:
fractal17, 354 moves against 354.

WHERE THE LOSS IS: the real circuits are nearly optimal -- interlagos +0.6%,
lemans +0.7%, monaco +1.0%, silverstone +1.1%, spielberg +1.5%, hungaroring
+1.8%, monza +2.0%, nurburgring +2.7%, spa +4.4%. The double-digit gaps are
all small twisty boards (rand12 +15.7%, rand14 +12.3%, cog +12.1%, rand19
+11.6%, circle +9.9%), where a lap is under 70 moves and every cautious corner
is a larger share of it. The Nordschleife, 20 km of it, is +1.2% (841 against
831) and took 133 s to solve -- 2.5M states of an 801M-state product.

WHAT IT MEANS: alone, the AI is safe but not fast. It never crashes (73 of 73
lap tracks complete), yet it spends measurably more moves than the track
allows. The loss cannot be traffic caution -- there is no traffic -- so it is
the scorer's own terms firing on an empty track, plus the fact that descending
each gate map in turn is not the same as minimising the whole race: the state
you arrive at a gate in shapes the next segment, and a per-gate greedy descent
never accounts for that.

THE LEVER, if it is ever worth pulling: the same search run BACKWARD from the
terminal gives an exact distance-to-go for every (state, gate) pair, and a car
that descends it is optimal by construction and cannot crash (every state on a
finite path has a successor one closer). Gating that on "no live rival" would
leave traffic behaviour untouched, which is where all the campaign's evidence
lives. The cost is memory: the staged potential is three times the three gate
maps already built, which is comfortable on a 150x150 board and heavy on the
Nordschleife.

OPS: measured on the AWS lab box (8 vCPU / 32 GiB), which suits this better
than Modal -- one JVM per track with a big heap and a persistent disk for the
caches, rather than many small containers. Temurin 25 had to be installed by
hand (Ubuntu 24.04 ships Java 21, too old for this bytecode).

## Round 213 (local agent, REVERTED): second-order headway cures the named magnets and mints new ones

THE CANDIDATE, straight from the fleet baseline's forensics: needleHeadway
(round 197) counts continuations that are body-free RIGHT NOW, and every rival
moves once between my landing and my next one. So it also required at least one
continuation outside every live rival's NEXT-MOVE BOX (its coasting landing
plus one cell of steering per axis) -- "keep an out that survives the pack's
next step". Lap-traffic only; laps=1 byte-identical.

TARGET EVIDENCE, all three magnets cured: rand6 s17, rand19 s20 and rand19 s9
each went from one crash to seven finishers.

FULL EVIDENCE, and the verdict: 940 races, 5 crashes against the round-212
build's 3.
  - fleet (73 tracks x seeds 1-10): 1 crash, but a DIFFERENT one -- rand19 s9
    cured, rand19 s1 broken.
  - bench tracks x fresh seeds 11-20: 4 crashes against 2 -- rand6 s17 and
    rand19 s20 cured, fractal1 s11, rand16 s17, rand16 s18 and rand19 s19
    broken.
  - pace unchanged (fleet moves 1866185 -> 1867046, +0.05%).

DIAGNOSIS: the new deaths are the SAME state family as the cured ones -- a car
crossing the S/F at speed 5 into the corner (rand19 (138,5) v(0,-5) is
literally the state round 212 died in on another seed; rand16 (140,8) v(0,-5)).
The veto does not remove the class, it re-phases which seed meets it: braking
one move earlier hands the corner to a different car. A law that only shifts
arrival phase cannot be told from noise except by the direction it happens to
land, and here it landed worse. The corner state itself has to become
survivable -- upstream commitment, not one more decision-time refusal. That is
the ninth measured negative of the decision-time class and the clearest: its
own targets were cured and the fleet still got worse.

INSTRUMENT NOTE: this is exactly what the widened bench is for. On the old
21x5 grid the candidate would have shown 0 crashes on its targets and nothing
else -- it would have shipped.

## Fleet baseline (local agent): the round-212 build over 940 races -- three magnets left

The 21-track x 5-seed grid read 0 after round 212, so the instrument grew in
both directions at once: WIDER on Modal (every lap-ready track, seeds 1-10 =
730 races, ~10 min wall) and DEEPER locally (the 21 bench tracks over FRESH
seeds 11-20 = 210 races, batch mode, ~25 min on four workers).

THE READING: 940 races, 3 crashes, 0 timeouts -- 6507 of 6510 cars finish.
  - fleet, seeds 1-10: 1 crash (rand19 s9); 72 of 73 tracks perfectly clean
  - bench tracks, seeds 11-20: 2 crashes (rand6 s17, rand19 s20)
  - the Nordschleife needed its own container size: at 4 GB / -Xmx3g its
    89M-state board died with OutOfMemoryError and its ten races came back
    MISSING, a hole the summary made obvious; re-run at 8 GB / -Xmx6g.

FORENSICS ON THE CLASS (query oracle, rand6 s17): the car was ALREADY DEAD two
moves before the wall -- at (139,20) v(-1,-5) every candidate was illegal,
body-blocked or reachability-dead. Walking back, at (140,25) v(-1,-6) exactly
ONE candidate was alive and free, and the AI took it; the cells beyond it were
then taken by the braking pack. So the veto that would save these cars has to
look one RIVAL MOVE ahead: keep an out that survives the pack's next step, not
just the current board. Needle headway (round 197) checks free-NOW; the
second-order version is the queued round 213.

CROSS-CHECK: on the 105 races the cloud grid shares with the local round-212
grid, every move count is identical -- the fan-out is the same instrument at
scale, not just on the five races that were compared byte-for-byte.

THE THREE MAGNETS, all first-lap pack traffic at speed, none a needle:
rand19 (16,42) v(-2,4) and rand6 (133,4) v(-3,-4) are cars in a braking train
whose alive landings fill with bodies; rand19 s9 is the third. This is the
class round 210's forensics named "a car at speed 8-9 in a first-lap pack
whose alive landings fill as the pack brakes" -- the follow law prices the
leader, not the second and third rows.

RESIDUE RATE: 3 in 940 races is 0.3%; the old instrument would have needed
~60 seeds of its 21 tracks to see them. Cost of the wide half: cents (a
container is 1 core / 8 GB and exits with its batch).

## Cloud bench (local agent, SHIPPED): the instrument fans out, and it is the same instrument

Per user direction ("Run on modal if possible"). tracks/modal_bench.py races
the fleet on Modal: one container per track, all its seeds in ONE JVM via the
existing batch mode (--seed A-B), so a container costs one reachability build
plus N races. The jar and tracks/ ride in the image (0.5 MB); the properties
file travels as a string argument, so one image serves every bench shape. The
image is eclipse-temurin:25-jre, pinned -- a different JVM would be a different
instrument. tracks/lap_bench.properties (the 8-car laps=3 grid config) moved
into the repo with it, so the bench no longer depends on a scratch file.

THE CHECK THAT MATTERS: rand2 seeds 1-5 raced in a Linux container on Temurin
25 produce logs BYTE-IDENTICAL to the local Windows JDK 26 logs of the same
build (round 212's grid). Integer physics and array-order decisions carry
across OS and JVM, so cloud results are directly comparable to every local
baseline in this ledger -- the summaries carry a per-race SHA-256 prefix so
identity is checkable without shipping logs around.

WHAT IT COSTS AND WHAT LIMITS IT: a container is CPU-only (1 core, 4 GB,
-Xmx3g) and exits with its batch; an 84-track x 10-seed fleet grid is roughly
2-3 core-hours, i.e. cents. The binding constraint is not money but the
WORKSPACE CONTAINER CAP: another project's app held 94 of ~100 containers
during the first fleet run, which starved this one to a single container and
turned a 5-minute grid into an hour-plus trickle. Check `modal container list`
before counting on fan-out; when the pool is free the same run is minutes.

WHY IT MATTERS FOR THE CAMPAIGN: the 21-track x 5-seed local grid reads 0 after
round 212 and can no longer separate candidates. The next instrument is more
seeds over the whole lap-ready fleet, which is exactly what fan-out buys.

## Round 212 (local agent, SHIPPED): the kinematic gate -- a rival within my stopping distance

THE FINDING (replay of the rand6 west-wall death that round 210 added):
from (24,10) v(-7,-1) the car had exactly ONE alive candidate at six
successive moves -- a long needle down the west channel, entered at
speed 7 with the parked pack 13 cells ahead. The round-210 gate is a
fixed 12-cell radius; the pack sat one cell outside it, so the needle
cost nothing and the plain map ran the solo line into a corner full
of parked cars.

THE LAW (RaceAi entry): the needle surcharge is on when a live rival is
ahead or beside within max(12, min(s(s+1)/2, AI1_ROBUST_KIN_CAP = 24))
cells, s the larger velocity component -- my stopping distance, the
distance over which a parked rival is a wall I am already committed
to. Uncapped, a car at speed 9-10 saw 45-55 cells of traffic and the
long tracks paid (guard set +1.7%: weave1 +6, silverstone +6, lemans
+8 rounds); capped at 24 (full stopping distance up to speed 6) the
cost vanished. Probes, 35 races on top of round 211: cap 24 and cap
18 both 0 crashes at round-211 pace; the five round-210 grid singles
(rand6 x3, gear, rand17) all clean.

MULTI-SEED BENCH #20 vs shipped #19: 3 -> 0, zero timeouts, all 735
cars finish. hybrid20 1 -> 0, rand17 1 -> 0, rand6 1 -> 0; no track
worse. Solo fleet 73/73 with byte-identical move counts (22510). Gate
battery 27/27.

INSTRUMENT ARC: 100 (birth) -> 89 (lane spreading) -> 86 (narrowed
board) -> 84 (kinematic horizon) -> 77 (following law) -> 34 (robust
seeds) -> 24 (coherent alive) -> 11 (needle surcharge) -> 3 (robust
precedence) -> 0 (kinematic gate). The 21-track x 5-seed instrument
is exhausted; the next residue needs a bigger one (more seeds, the
whole lap-ready fleet), which is a compute question -- see the
Modal/EC2 note in the session.

VERIFICATION: laps=1 fractal8 byte-identical; the scratch probe
reproduced byte-for-byte by the repo build; apply_c16_kin.py
reproduces the working tree from HEAD. Gate battery 27/27.

## Round 211 (local agent, SHIPPED): robust precedence -- a checkpoint touch must keep an out

THE INSTRUMENT: --query-moves now takes an optional 6th field per car
(the lap gate), so a multi-lap board replays faithfully, and
-Dai.debug.comp=true prints every candidate's score components. The
first replay explained the hybrid12 hairpin death that survived
round 210: at move 222 the mover (22,59) v(-5,7) had a safe move
scored 41 and the CP1-touching move (17,67) v(-5,8) scored 105 (unc
39.8, corner-entry 16.3) -- and the checkpoint-touch precedence took
the 105. Needle headway (round 197) is a SNAPSHOT: both continuing
cells of the landing were free at that instant; one was a rival's
next landing, and from there every state had one alive successor
until the wall at (7,113).

THE LAW (RaceAi, main policy only): with a live rival ahead or beside
(the round-210 robustMode), the checkpoint-touch precedence and the
non-final crossing precedence require a landing in the ROBUST reach
set of the next gate (Reachability.isRobust) -- an out with one
successor denied at every step. Without it the scorer prices the
touch like any candidate; the car takes the safe move and touches a
move later. Alone, unchanged. laps=1 untouched (both precedences are
lap-only).

PROBE (scratch build, 30 races): forensic 20 crashes 4 -> 1, guard
10 stays at 0, pace +0.3% on top of round 210 (mean finisher +1.2%
vs round 209, winners +0.6%). The same replay tool showed the rand6
west-wall crawl death to be a LONG needle: from (24,10) v(-7,-1) the
car had exactly one alive candidate at six successive moves, entered
at speed 7 with the parked pack 13 cells ahead -- one cell outside
the fixed 12-cell gate.
A KINEMATIC gate range (the needle surcharge also on with a rival
ahead within my stopping distance s(s+1)/2) cleared the remaining
crash and the five round-210 grid singles (0 in 35 races) but, uncapped,
taxed the long tracks (guard set +1.7%: weave1 +6, silverstone +6,
lemans +8 rounds of mean finisher -- a car at speed 9-10 sees 45-55
cells of traffic). Capped at 24 or 18 cells the cost vanishes (0 in
35, pace equal to this round). Queued as round 212 at cap 24, one
change per bench.

MULTI-SEED BENCH #19 vs shipped #18: 11 -> 3, zero timeouts,
finishers 724 -> 732. hybrid12 2 -> 0, rand6 4 -> 1, gear 1 -> 0,
hybrid20 2 -> 1, hybrid17 1 -> 0; rand17 1 unmoved; no track worse.
Solo fleet 73/73 with byte-identical move counts (22510). Gate battery
27/27.

INSTRUMENT ARC: 100 -> 89 -> 86 -> 84 -> 77 -> 34 -> 24 -> 11 -> 3.
Residue: hybrid20 1, rand17 1, rand6 1 (the long needle, round 212).

VERIFICATION: laps=1 fractal8 byte-identical; the scratch probe
reproduced byte-for-byte by the repo build; apply_c15_touch.py
reproduces the working tree from HEAD. Gate battery 27/27.

## Round 210 (local agent, SHIPPED): the needle surcharge -- 1-fault-tolerant reach, traffic-gated

THE FINDING (query-oracle forensics on the round-209 residue): the
remaining chains are NEEDLES. rand2 after the S/F: (121,23) v(-1,-6)
-> (119,18) -> (117,14) -> (114,11) -> (112,9) -> (111,8), every
state with exactly ONE alive successor; a rival parked on that one
cell ((112,8) v(0,0)) and the follower took the dead cell (107,8).
The same shape at rand19 (138,8), weave3 (89,79), hybrid20 (117,33).
Fleet census: 6-20% of coherent-alive states are needles (monaco
19.9%, hybrid12 13.4%, rand2 9.3%), nearly all at speed >= 4.

THE LAW (Reachability.computeRobustReach): per gate, the set of
states with a 1-FAULT-TOLERANT path -- a second-arrival BFS where a
state joins only once TWO distinct successors are in (each valid
gate passage counts as one arrival), the product cycle closed over
the robust sets (a robust seed's landing must be in the next gate's
robust set; robustLandingIn). Membership only, one BitSet per gate
(16 MB on the Nordschleife; the BFS distances live in one transient
scratch map). RaceAi: with a live rival AHEAD or beside within
Chebyshev 12 (rivalAheadWithinCheb: dot with my velocity >= -2 speed),
ttf() reads turnsToGateNeedleAware -- the PLAIN turns, plus
AI1_ROBUST_SURCHARGE = 12 on a needle state. Alone, or with only cars
behind, the plain map: solo pace untouched by construction.

WHAT THE SWEEP TAUGHT (20 forensic races that carried 15 round-209
crashes; scratch build, constants as JVM properties): the full
ROBUST-DISTANCE gradient (turns with one successor denied at every
step) is a different racer -- 0 crashes but +4.4% mean-finisher pace,
at surcharge 40, 12 or 6, at range 12 or 8: in a pack the mode is on
nearly always and the 2-wide margin costs everywhere. The plain
gradient with a needle surcharge keeps the fast line: 3 crashes at
+1.9% (surcharge 12; 6 gives byte-identical races, 3 gives 2 crashes
-- the surcharge is an ordering, not a weight). Gating on ANY rival
within 12 taxed the leader for cars behind it (guard set +3.2%);
gating on rivals ahead or beside halves the cost: forensic 4 crashes
at +0.9% (winners +0.5%), guard set 2 -> 0 crashes at +0.7%. Range 8
loses half the benefit (9 crashes). Shipped: ahead-gate, 12, 12.

MULTI-SEED BENCH #18 vs shipped #17: 24 -> 11, zero timeouts,
finishers 711 -> 724. rand2 7 -> 0 (the band that eleven candidates
never touched is clean on all five seeds), weave3 3 -> 0, hybrid20
4 -> 2, hybrid12 3 -> 2, fractal1/rand12/rand16/lobe2/rand13 -1 each;
pushes rand6 2 -> 4 (the west-wall long needle, see round 211),
gear +1, rand17 +1, hybrid17 +1. Solo fleet 73/73 with byte-identical
move counts (22510 = 22510: the gate needs a rival). Traffic pace on
the 30 forensic+guard races: winners +0.5%, mean finisher +0.9%.

INSTRUMENT ARC: 100 -> 89 -> 86 -> 84 -> 77 -> 34 -> 24 -> 11.
Residue: rand6 4, hybrid12 2, hybrid20 2, gear 1, rand17 1,
hybrid17 1.

PROBED AND LEFT ALONE: the Gipps weight (AI1_FOLLOW_W 1.0 -> 2.0 / 3.0)
on top of the needle gate, 30 races: 4 -> 3 -> 3 crashes at the same
pace, the hybrid12 hairpin death untouched -- the follow surcharge is
not what the boxed-in hot arrival lacks. What remains on the forensic
set is four scattered singletons, no magnet clusters: a car at speed
8-9 in a first-lap pack whose alive landings fill with bodies as the
pack brakes for a hairpin (hybrid12 west side (7,113)). The next
instrument is a per-candidate score breakdown in --query-moves.

VERIFICATION: laps=1 fractal8 byte-identical; repo build reproduces
the scratch config T logs byte-for-byte (rand2, hybrid12, rand19,
monaco); apply_c14_needle.py reproduces the working tree from HEAD;
Nordschleife 3-lap solo 48 s (robust sets 389k of 649k alive). Gate
battery 27/27.

TRAP RECORDED: a scratch jar resolves tracks/ next to ITSELF -- the
scratchpad copy had a stale 130x170 monaco, which made one sweep row
look 14% faster. Sync the scratch tracks before any scratch-jar
comparison; check the log header grid size.

## Round 209 (local agent, SHIPPED): coherent alive -- the phantom states before the line, residual 34 -> 24

THE FINDING (query-oracle forensics on the round-208 residue): the
hot-arrival crashes at S/F corners (hybrid12 (143,35) braking
9,8,7,6,5 into the wall behind the line; rand19 (143,9); rand16,
rand17, rand6) were sealed 3-5 moves out in states the engine called
ALIVE although every continuation crossed the line into the wall.
The finish BFS seeds from every forward crossing as a TERMINAL --
laps=1 semantics, where the final crossing finishes even into a
wall. A non-final crossing must land legally and continue, so states
whose only continuation is such a crossing are phantom-alive: the
run-up to an S/F placed at a corner looks survivable at any speed,
the danger rollouts certify the hot approach, and the car dies two
moves past the line. Phantoms per track: hybrid12 20847 (5.2% of
alive), rand19 24992, hybrid20 19753, nordschleife 7825.

THE LAW (Reachability.computeGateMaps): after the product fixpoint,
alive := finite on any product-coherent gate map (a state that can
reach one coherent gate reaches them all); the successor mask and
the roomy/shed/certified sweeps are re-derived over it. The gate
maps and this coherent set are now computed on EVERY reachability
path -- the memo path (multi-seed batches in one JVM) used to race
lap mode with no gate maps at all, silently falling back to the
finish map. Per-race products of the memoized finish closure, so
single and batch JVMs agree. Start-up cost: Nordschleife load 1.75 s,
a 3-lap solo in 42 s. laps=1 untouched (no gate maps there):
fractal8 8-car byte-identical.

MULTI-SEED BENCH #17 vs shipped #16: 34 -> 24, zero timeouts,
finishers 701 -> 711. hybrid12 8 -> 3, rand19 6 -> 0, rand2 9 -> 7,
rand17 1 -> 0; single-crash pushes on fractal1, rand12, lobe2, rand13
(+1 each). Solo fleet 73/73 clean, pace +0.15% (23 tracks +1/+2
moves: the truthful S/F approach brakes one move earlier). Gate
battery 27/27 (run_tests incl. TrackDataTests 84, smoke, tooling
14, goldens, 23 pins).

INSTRUMENT ARC: 100 -> 89 -> 86 -> 84 -> 77 -> 34 -> 24. Residue:
rand2 7, hybrid20 4, hybrid12 3, weave3 3, rand6 2, fractal1 1,
rand12 1, rand16 1, lobe2 1, rand13 1 -- the needle class (single-
thread corridors blocked by a rival: rand2 (107,8), rand19 (138,8),
weave3 (89,79), hybrid20 (117,33)) is what remains. Queued as round
210: the 1-fault-tolerant potential (second-arrival gate maps,
traffic-gated), clean on 20/20 forensic seeds in a scratch build.

OPS: schtasks-launched workers died twice with STATUS_CONTROL_C_EXIT
(a console closed on this busy PC); workers now run hidden and
battery-proof via Register-ScheduledTask, with PID-checked locks.

## Round 208 (local agent, SHIPPED): robust gate-0 seeds -- residual 77 -> 34, the largest cut of the campaign

THE FINDING (census of the residue): every residual crash is a
deterministic magnet state, and rand2's were identical chains from
vy=-6 crossings whose CERTIFIED continuation was a single thread --
the whole train arrives hot onto one lane, the leader's cell is the
follower's only finite successor, and the alive-aware fallback
substitutes a dead cell. The needle-headway law (r197) refuses such
moves at decision time; the map still CERTIFIED them, so commitment
kept targeting needles.

THE LAW (Reachability.computeGateMap): a gate-0 crossing seeds the
lap map only if its landing is ROBUST -- at least two legal-edge,
alive successors that continue the lap on the next gate map (alive
alone before the product fixpoint has a next map). Two-pass seeding:
pass 0 robust; a gate with no robust seed at all falls back to the
plain law in pass 1 and says so ([laps] ... seeds=plain-fallback).
All 73 lap-ready tracks seed robust; nothing fell back. Gate maps are
computed live (not in the -lap13 cache), so no key bump. The first
shipped change to WHAT is certified rather than how it is scored:
the ">= 2 continuing successors" idea moved from the decision layer
into the map itself.

MULTI-SEED BENCH #16 vs shipped #14: 77 -> 34, zero timeouts,
finishers 658 -> 701 of 840, NO TRACK WORSE. rand12 9 -> 0, rand16
9 -> 1, rand2 18 -> 9 (the band, halved), gear 2 -> 0, rand6 2 -> 0,
rand17 3 -> 1, fractal1 1 -> 0, hybrid20 5 -> 4; guards lobe2 2 -> 0,
rand13 2 -> 0, circle 2 -> 0, cog 1 -> 0, rand19 8 -> 6. Unmoved:
hybrid12 8, weave3 3, monaco 0. Twelve of twenty-one tracks moved,
all downward -- no amplification class anywhere.

INSTRUMENT NOTE: the gate-0 FINITE SET is unchanged on all 72
comparable tracks (a robust crossing is reachable from wherever any
crossing is); the VALUES changed -- turns-to-crossing now route
through robust landings. Solo laps=3 is therefore not byte-frozen by
design: on the non-normalized lap-ready tracks total moves 19646 ->
19616 (-0.15%), 15 tracks moved by <= 10 moves, no result changed,
73/73 complete. laps=1 byte-identical (gate maps are null there).

VERIFICATION: run_tests.sh (-Werror compile, CoreTests incl.
TrackDataTests 84 OK, MainTests), headless smoke, tooling 14/14,
goldens, 23/23 AI1 pins.

INSTRUMENT ARC: 100 (birth) -> 89 (lane spreading) -> 86 (narrowed
board) -> 84 (kinematic horizon) -> 77 (following law) -> 34
(robust seeds). Residue: rand2 9, hybrid12 8, rand19 6, hybrid20 4,
weave3 3, rand6 2, rand16 1, rand17 1.

OPS: a worker killed abnormally (the capacity pause, ~10:45) left
its lock file and the resumable bench stalled 106 min honoring it.
Next worker template: record the PID in the lock and treat a dead
PID as no lock.

## Round 207 (local agent, REVERTED): traffic-triggered certification -- more rollout is not the lever at speeds 4-6

The two commitment laws' shared blind spot: the kinematic horizon acts
only when a danger rollout runs (trap >= 0.5 or landing speed >= 7),
and the surviving hot-arrival magnets (rand12 (14x,74)v(2,-3), rand16
(14x,17)v(1,-5), hybrid12 (142,40)v(2,-5)) sit at speeds 4-6 with the
trap ladder at 0. C11 fired DJS for any lap-traffic commitment at
speed >= 4 with a rival within the needle radius. Bench #15: 77 vs 77
-- flat -- hybrid12 -2 but rand12 +1, hybrid20 +2, fractal1 +2, rand2
unmoved, at +30% compute per race. Reverted.

WHAT IT PINS DOWN: at these speeds the rollout either does not
reproduce the specific traffic displacement that kills (its rival
model diverges from the real field within the horizon), or it sees
the death and finds no surviving alternative -- in both cases the
certification machinery is not the bottleneck. The residue after the
two laws: rand2 18 (16 of them the alcove band pair, untouched by
horizon or headway), rand12 9, rand16 9, hybrid12 8, rand19 8 (its
(136,8)->(133,8) westward alcove is rand2's twin), hybrid20 5.

STANDING STATE: shipped = r201 lane spreading + r205 kinematic
horizon + r206 Gipps following (same-lane cone 1.5). Instrument arc
100 -> 89 -> 86 -> 84 -> 77. The rand2/rand19 alcove class is now the
dominant residue and has resisted seven distinct mechanisms; it is
the named target for a dedicated forensic of the ENTRY into the band
(post-crossing displacement), with the following law's cone and the
band's INF-map status as the two open levers.

## Round 206 (local agent, SHIPPED): the Gipps following law -- monaco 10 -> 0, residual 84 -> 77

The second commitment law. Real racecraft has a GAP law: my stopping
distance must fit inside the gap to the leader plus the leader's own
stopping distance (Gipps). In integer-shed physics stopping from speed
s covers s(s+1)/2 cells. Implemented as followingExcess(landing): for
every live rival in my forward cone (along-heading > 0, within 40,
lateral <= AI1_FOLLOW_LAT, not oncoming), excess = myStop - (gap +
leadAdvance - 1) - leadStop; the largest excess is surcharged at
AI1_FOLLOW_W = 1.0 per cell, folded into `uncertified` inside a
lap-mode branch (laps=1 byte-frozen). Continuous (no trap cliff),
directional (a cone, not a radius -- the radial stalled-rival probe
of round 198 braked for flowing traffic), speed-relative (a fast
leader's stopping distance lets me follow fast; a parked one does
not).

TWO BENCHES: wide cone (LAT 2.5): 81 vs 84 with MONACO 10 -> 0 (the
merge corner, cured outright -- followers hold gap behind the pack
instead of ramming the turn hot), rand16 -5, hybrid12 -2 -- but four
robustly clean guards each lost a car (weave1, silverstone, circle,
cog): the cone caught adjacent-lane leaders on open straights and
followers braked for cars they would simply pass. Same-lane cone
(LAT 1.5): 77 vs 84 -- monaco 0 retained, fractal1 5 -> 1, rand16
14 -> 9, rand13 -3, both round-205 gains intact (hybrid20 5, rand2
18); weave1/silverstone clean again; residual pushes on rand19 (+4,
the noisiest guard in every bench) and lobe2 (+2). Shipped at LAT 1.5.

INSTRUMENT ARC: 100 (birth) -> 89 (lane spreading) -> 86 (narrowed
board) -> 84 (kinematic horizon) -> 77 (following law). Two physical
laws of commitment did what twelve decision-time heuristics could
not. Residue: rand2 18 (the band; horizon reached it, headway did
not), rand12 9, rand16 9, hybrid12 8, rand19 8, hybrid20 5.

## Round 205 (local agent, SHIPPED): the kinematic horizon -- the first fix to reach a flank magnet

New-approach premise: the residual dooms are COMMITMENT errors, sealed
3-7 moves before death by momentum, so decision-time penalties cannot
touch them (eleven measured negatives agree). Commitments need laws
about distance and time.

THE FINDING: the danger rollouts that certify hot moves ran 3 rounds
for FAST fires (landing speed^2 >= 49) and 5-6 for slow ones --
kinematically backwards. A car at max-component speed s needs s
rounds to stop (shedding one unit per round), so a 3-round world at
speed 10 ends 28 cells short of the wall it is certifying against.
Monaco's magnet committed vy=-10 forty-five cells out and was
certified safe every seed. THE LAW: dangerRounds >= rounds-to-stop
(max component of the landing velocity), capped at 10; lap mode
only, laps=1 keeps its pinned horizons. Rollout cost is linear in
rounds -- a fast track's race still runs in ~10 s.

MULTI-SEED BENCH #12 vs the post-narrowing baseline: 84 vs 86 -- and
the SHAPE is the theory's own fixtures: hybrid20 9 -> 5, rand2
21 -> 18 (rand2 had been invariant under every one of the eleven
previous candidates; this is the first mechanism that ever reached
it), monaco -1. Scattered pushes (rand12 +2, rand19 +2, fractal1 +1,
rand16 +1) keep the total modest. Shipped on target evidence:
principled, target-confirmed, no amplification class. laps=1 + solo
byte-identical; 25/25 battery.

Queued behind it, round 206: the Gipps car-following law (stopping
distance must fit inside the gap plus the leader's stopping distance
-- continuous, directional, speed-relative), the second law of
commitment.

## Round 204 (local agent, REVERTED): trap-gated flow-merging does not reach the merge moment

C8 implemented the round-203 conclusion directly: among congestion-
trapped candidates (trap >= L1), prefer the one whose velocity matches
the local stream (mean of up to 3 moving rivals within Cheb 10;
parked cars stay obstacles). Multi-seed bench #11 vs the
post-narrowing baseline: 85 vs 86 -- noise -- and monaco, the merge
fixture, moved only 11 -> 10 while rand19 +4 / rand13 -3 reshuffled.
DIAGNOSIS: by the time candidates are TRAPPED the merge choice is
gone; the merge decision lives in the free-running approach, where a
flow term is unscoped caution again (the C2/C3/C5 lesson). Scoping
flow-merging correctly means velocity-matching inside the world-step
rollouts or a merge-aware candidate layer -- champion-architecture
work, not a scorer term. Reverted; named for the next era.

CAMPAIGN CHECKPOINT at this close: eleven bench cycles on the
105-race instrument this stretch; shipped survivors = lane spreading
(r201) + the fair-cap/needle/continuation laws (r195-r199). Fleet
state: multi-seed residual 86 (was 100 at the instrument's birth,
89 before the width normalization changed the board), single-seed
60/72 clean on the narrowed fleet, solo 72/72... now 73/73 with the
Nordschleife, whose 8-car debut raced CLEAN in both modes. laps=1
byte-frozen through every one of the ~20 verified builds.

## Nordschleife (local agent, SHIPPED): the green hell joins the fleet -- 84 tracks, clean 8-car debut

Per user direction ("add the nordschleife. It will be massive but ok.
Make sure it's the same scale as the other"). SOURCE: 52 OSM raceway
section ways (Hohe Acht, Fuchsroehre, Schwedenkreuz, Pflanzgarten,
Doettinger Hoehe...) endpoint-stitched into a closed loop of 20.75 km
vs the real 20.832 -- 0.4% off. SCALE HONESTY: the GP-Strecke sibling
sits at ~4.9 m/cell; true same-scale needs ~1250 cells and the grid
caps at 500 (sanitizeIntProp gameX/gameY max) -- built at the largest
legal scale, 500x402 at ~12.3 m/cell, noted in the track header.
Width 3.8 per the fleet <4 law.

BUILD LESSONS (tracks/build_nordschleife.py, in-repo): at 12.3 m/cell
the real hairpins have radii of 1-2 cells and the +-1.9 inner offset
self-crosses; blind cusp-cutting then EXCISES the whole tip from one
wall and the walls diverge (width scars of 21, 15.7, 11.4 in
successive attempts). Two fixes proved out: (a) iterative TARGETED
rounding of the dense centerline wherever chord-heading delta over
span 3 exceeds 0.42 (tip radius >= ~7 cells -- chord delta ~ span/R,
NOT arc curvature; conflating the two silently under-rounds), and
(b) offset the DENSE 1-cell line and decimate the WALLS (decimating
the centerline first re-sharpens what the rounding smoothed). The
S/F found itself: the longest low-curvature stretch (151 cells) is
the Doettinger Hoehe.

SCALE OF THE STATE SPACE: 500x402 = 125M states; reachability builds
in 36s (BFS 29s) under the stock 8.3 GB-max JVM, alive=657k, gate
maps 649k finite, cache write 5.3s. RACING: solo laps in ~280
moves/lap crossing at speed 8, finishing at 14; the 8-CAR FIELD RACES
IT CLEAN in both modes (laps=3: 7f/0c/0t in 6846 moves -- the field
paces at ~285 moves/lap/car, essentially solo speed; laps=1: 7f/0c).
TrackDataTests 84 OK; goldens and pins untouched (new track); atlas
republished (84 tracks, 73 lap-ready).

## Width normalization (local agent, SHIPPED): six real circuits narrowed to reality -- and the Nurburgring layout verified

The user flagged Nurburgring's variable width and Red Bull Ring's
fatness off the atlas, ruling real tracks should be thickness < 4
(floor stays "about 2.5"). The audit agreed: spielberg median 14.4,
nurburgring 13.0 (min 5.4 max 21.6 -- the x1.8 upscale had scaled
WIDTH along with length, and per-side rediscretisation added the
wobble), monza 10.0, silverstone 7.6, spa 6.3, lemans 5.4 -- while
the four previously hand-widened tracks (monaco, zandvoort,
hungaroring, interlagos, medians 3.2-3.5) were already in band and
untouched.

LAYOUT VERIFICATION: re-fetched bacinger/f1-circuits de-1927.geojson.
It is the modern GP-STRECKE (5.1 km; bbox ~1.1x1.5 km), not the
Nordschleife, and our track is topologically faithful to it
(possibly mirrored -- gameplay-neutral).

METHOD (tracks/width_normalize.py, in-repo): centerline from
LOCALITY-PAIRED midpoints (global nearest-point pairing collapses
the midline where a wide section runs close to another pass -- the
arena loop paired across the infield), 1-cell resample, window-5
smoothing, curvature-adaptive decimation (2.4/4.2), uniform +-1.9
offset, offset-cusp excision + integer snap to fixpoint, S/F gap
walked back to ~6 (end smoothing had grown it), every property
asserted before writing. Result: all six at min >= 2.5, median
3.6-4.0, max <= 4.5, gaps 5-6.5. Layouts, canvases, headers intact.

FIXTURE LAW: monza raced LIVE in ai1_private_slack (byte-frozen
seed-30/145 trajectory hashes) -- frozen to tests/fixtures/ and the
pin repointed BEFORE surgery (verified green both sides). All other
affected pins already rode fixtures.

VERIFICATION: TrackDataTests 83 OK; all six complete 3 solo laps
(257-436 moves); 8-car laps=3: nurburgring/silverstone/spa/lemans
CLEAN, spielberg/monza 6f/1c -- four times narrower and still racing;
goldens re-baselined (lemans-s1-4p 588 turns 3f/0c); 23/23 pins;
atlas republished. Note: the single-seed fleet board and multi-seed
instrument baselines PREDATE this surgery -- the narrowed six change
racing difficulty, so the next bench cycle re-baselines both before
any further AI-quality comparison (C8 flow-merging is queued behind
that re-baseline).

## Round 203 (local agent, ARC CLOSED at 89): three more measured negatives refine the knot to its core

Continuing on the 105-race instrument against the shipped lane-
spreading baseline (89 crashes):

- C6 GRADED NEEDLE TRAP (0 threads -> 30, 1 thread -> 15, from the
  monaco-corner analysis that a flat trap on ALL candidates stops
  discriminating): 91, and nearly every race byte-held -- under
  current-body counting the corner's turn candidates read ZERO
  threads, not one, so the grade never fires. The cure requires
  seeing through the moving train.
- C7 PREDICTED-OCCUPANCY NEEDLE (the scorer's own one-round rival
  prediction instead of live bodies -- parked predicts parked, a
  train predicts advanced and re-blocks where it lands; the physics
  between r197 opacity and C2 transparency): 107 (+18), monaco
  itself +2. THE REFINED TRUTH: a dense train is opaque under ANY
  one-step occupancy model, because each vacated cell is re-occupied
  by the follower. Prediction shows the train advanced but still
  there.
- (C5, round 202, already ledgered: the gate-approach hold never
  reached the flank dooms.)

WHAT THE WHOLE ARC NOW PINS DOWN: monaco's transparency cure (11 -> 0)
works not because cells free up but because ignoring the train lets
the mover MERGE INTO ITS FLOW -- match speed and take the corner as
part of the train. No successor-count, graded, scoped, or predicted,
expresses that; it is flow-relative reasoning (speed matching against
the local traffic stream), a mechanism class the champion does not
have. That -- not more occupancy variants -- is the frontier, with
three precise fixtures: monaco's corner (the pure merge case), rand2's
band (displacement + alcove), and the flank twins (hot approach).

The tree stays at shipped round 201: multi-seed residual 89 (from
100), single-seed board 61/72, solo 72/72 perfect, laps=1 byte-frozen
through fourteen verified builds this campaign stretch. Nine bench
cycles ran on the instrument; one candidate shipped, seven were
rejected by measurement, and each rejection narrowed the problem --
the residue is no longer mysterious, merely unsolved.

## Round 202 (local agent, REVERTED): the gate-approach hold does not reach the flank dooms

The candidate priced hot S/F approaches (landing within 10 of the
gate, 2+ rivals in the gate zone, non-final lap, speed above 4) --
aimed at the flank twins (hybrid12/hybrid20, 18 crashes) and rand2
(21), the family every earlier bench said responds to caution near
the gate. Multi-seed bench #7: 85 vs 89 -- but the SHAPE disproves
the mechanism: hybrid12 +0, hybrid20 +0, rand2 +3 (WORSE, 24). The
-4 total is scattered one-crash shifts on NON-target tracks -- the
timing-butterfly reshuffle, not the fix. Shipping noise violates the
instrument discipline; reverted.

What this negative pins down: the flank dooms are not created inside
the 10-cell approach zone at speeds the surcharge can price -- their
commitment is earlier or hotter than a scorer-side trap can reach
(consistent with the C3 lesson that the amplification acts upstream
of any gate radius). And rand2 worsening under MORE gate caution
kills the "hold short of the contested line" theory for it: its
displaced band entries do not come from crossing too eagerly.

Arc status after six measured candidates on the 105-race instrument:
shipped = lane spreading (89); every caution-shaped and body-
permanence knob measured and closed. The surviving magnets -- rand2
(21-24, worsens under gate caution), rand16 (11-13), monaco (11,
fully cured by moving-body transparency that is globally net-
negative), hybrid12/hybrid20 (9+9, unreachable by every scoped
surcharge tried) -- now require per-magnet forensics at the exact
displacement moment, with per-seed debug reruns. Monaco first: a
mechanism that is 100% curable by a known-but-unscopable lever is
the most likely to yield a local law.

## Round 201 (local agent, SHIPPED): the multi-seed instrument, the magnet census, and lane spreading -- residual crashes 100 -> 89

THE INSTRUMENT (new standing law): single-seed clean-counts are dice
-- the round-200 oscillation proved it. The residual bench is now the
21-track x 5-seed grid (11 dirty + 10 guards, 105 races), scored on
TOTAL CRASHES. Baseline on shipped r199: 100 crashes -- and four
"clean" guards leak across seeds (rand13, rand19, circle, lemans).

THE MAGNET CENSUS (mined from the baseline): every dirty track is ONE
attractor state, stable across all five seeds. rand2 20/22 crashes at
two states feeding the (108,8) alcove; monaco 10/11 at literally
(12,123)v(1,-5) -- built vy=-10 down the west straight, max-shed still
reaches the NW corner at vy=-5, survivable only by growing vx east
through the turn, and the pack occupies those cells; hybrid12 7/9 at
(142,40)v(2,-5) and hybrid20 8/10 at (117,40)v(2,-6) -- the S/F flank
overshoot twins; rand17 6/7, rand16 11/14, rand12 clustered likewise.
~80% of all residual crashes live in ~7 named states. Universal form:
traffic displacement off ONE shared geodesic into a state where every
option is already dead.

FOUR CANDIDATES, MEASURED HONESTLY:
- C1 (fallback lap-continuing tier): byte-level NO-OP over all 105
  races -- body-blocked candidates never reach the fallback's legal
  mask, so the tier is always empty where it mattered. Not shipped.
- C2 (moving bodies transparent in needleHeadway): 107 (+7), but a
  clean DECOMPOSITION: corner-displacement magnets collapse (monaco
  11 -> 0, rand17 -5, rand16 -4, rand12 -2 = -28) while flank magnets
  amplify (hybrid20 +9, hybrid17 +10, rand13 +8 = +35). Not shipped.
- C3 (C2 away from gates, r199 opacity near them): 108 -- the flank
  amplification acts UPSTREAM of any gate radius (approach-speed
  pressure, not local blocking). Body-permanence is double-edged at
  every radius; the caution-knob family is closed. Not shipped.
- C4 (LANE SPREADING, shipped): attack the root -- the single shared
  geodesic. In lap traffic each driver weighs the momentum/plateau
  tie-breaks slightly differently (three deterministic styles by
  player index; player 0 keeps exact champion weights; laps=1
  untouched). 89 crashes (-11): broad shallow wins on nine tracks
  (rand17 -5, rand12/weave3 -2, six at -1) and NO amplification
  anywhere (fractal1 +1, rand13 +3 the only pushes).

Shipping caught a real trap: folding "- momentum - robustness" into
one subtraction is a one-ULP float change that flips near-exact ties
(the monza s30 trajectory pin failed). The unstyled path keeps the
legacy fp shape exactly; 23/23 pins + goldens green after the fix,
laps=1 + solo byte-identical, spot-checks confirm the wins survive.

Residue for the per-magnet rounds: rand2 21 (invariant under all five
configurations -- the alcove band needs its own round), rand16 13,
monaco 11 (transparency cures it but is globally net-negative; its
corner needs a magnet-specific answer), hybrid12/hybrid20 9 each (the
flank twins), rand13 5. AI1_LANE_STYLE=0.12 was the first value tried;
a sweep (0.2?) is the cheap next probe on the standing instrument.

## Round 200 (local agent, REVERTED): three mechanisms probed, fleet says no -- policy saturation is measured

Motivated by the hybrid20 bench-#6 regression forensic: its crashes
were byte-identical RECURRENCES of the known CP2-pocket and S/F-flank
poison states, re-exposed purely by traffic-timing shifts. Three
mechanisms were built and probed:

1. FALLBACK CONTINUING TIER: the all-INF regime (where every one of
   these dooms actually executes) had no needle law at all --
   scoreMinTurnsFallback gained a lap-continuable tier above the r198
   alive tier (final-lap gate-complete crossings exempt).
2. PARKED-ONLY BLOCKING: needleHeadway treated crossing trains as
   permanent walls; successor cells became blocked only by rivals
   with both velocity components <= 1.
3. SEED WIDENING: shedableLanding without the speed<=6 cap (product
   coherence already certifies continuation at any speed). Probed
   alone-ish: rand19 1 -> 3, weave3 0 -> 1, stubborn tracks unmoved --
   wider seeds add SPEEDS, not LANES. Reverted before the bench.

MULTI-CAR BENCH #7 on (1)+(2): 58/72 clean, DOWN from 61. Fixed
gear/monaco/rand17/weave3, dirtied fractal23/hybrid17/hybrid3/
hybrid9/rand13/rand19/weave6 -- tracks clean since the early rounds,
i.e. mechanism (2) weakened the r197 law where it was silently
protecting. Working tree reverted to shipped round 199.

THE MEASURED CONCLUSION, four configurations deep (benches #5-#7 +
probes): total fleet crashes hover at ~20 while the SAME ~dozen
deterministic poison states rotate with traffic timing. Global policy
knobs are saturated -- each reshuffles which states fire, none removes
one. The remaining frontier is PER-GEOMETRY: the poison states
themselves (rand2's (108,8) alcove + upper band, hybrid20's
(34,137)/(117,40) pockets, hybrid12's needle, fractal1's (135,15)
alcove) need either map-level exclusion (mark statically-doomed
funnel entries un-enterable in the gate BFS so no chooser layer can
be lured) or track-surgery where the geometry is simply hostile.
Next round starts there.

## Round 199 (local agent, SHIPPED): surviving is not continuing -- 61/72, plus 44 GB of cleanup

The rand2 entry-chain forensic reached the ground truth: p5 LAPPED AT
SPEED 7 ((123,29)->(122,23)), and that hot crossing geometrically
commits the car to the thin upper band (from vy=-6 at y=23 no braking
schedule can stay on the y~13-14 racing line), where it decelerated
into a no-exit alcove at (110,8) while p8 died one slot ahead on the
identical chain. The certified crossing (shedable + CP1-continuable,
the r193 seed law) was the slower v(0,-6) line -- but its cell was
occupied by p8 crossing just ahead, every alternative was lap-INF,
and scoreMinTurnsFallback chose the hot uncontinuable crossing: the
alive-aware tier (r198) passed it because the landing was STATICALLY
alive. Surviving is not continuing.

THE FIX: needleHeadway counts LAP-CONTINUING successors -- body-free,
alive, AND finite on the post-landing gate map (a successor that
itself crosses the S/F while heading for gate 0 continues on gate 1).
The post-landing gate threads through all five call sites (crossing
precedence -> 1, CP touch -> next map, scorer surcharge -> current).
An ablation isolated the effect to the scorer site; the fleet
arbitrated the full version.

MULTI-CAR BENCH #6: 61/72 clean, from 60 (arc 18 -> 33 -> 41 -> 60 ->
61). hybrid17, rand13, rand19 flip clean; fractal1 3 crashes -> 1.
The trade: gear 0 -> 1 and hybrid20 0 -> 3 (stricter headway
re-brakes their flows; named targets now). Total fleet crashes
unchanged at 20 -- the gain is in distribution. rand2 resists a third
distinct fix (2f/5c) -- its doom forms before any headway law can
see it; dedicated round pending. laps=1 + solo byte-identical (the
law is dormant without rivals); 25/25 battery.

CLEANUP shipped alongside: 44 GB reclaimed on C: (eleven dead
lap-suffix cache generations plus 105 orphaned-geometry files,
verified against recomputed live track hashes -- 59G -> 15G); dead
nearRequiredGate removed; lemans_overpass.json (the abandoned OSM
source) dropped from the repo; scratch pruned to 1.1 GB.

## Le Mans rebuilt (local agent, SHIPPED): hand-authored Sarthe replaces the blob

The user flagged Le Mans off the fresh atlas. Rendering it told the
story: the OSM trace was missing ~40% of the lap (public-road
Mulsanne sections bridged with straight lines) and the Chaikin
rediscretisation had smoothed the rest into a featureless rounded
triangle -- no chicanes, no Mulsanne corner, no Porsche Curves.

REBUILD (tracks/build_lemans_v2.py pattern, script in E:/tmp-claude):
the centerline is hand-authored from the circuit's documented corner
sequence -- S/F, Dunlop curve + chicane, Esses, Tertre Rouge, the
Hunaudieres straight broken by BOTH chicanes, the Virage de Mulsanne
near-hairpin, Indianapolis, Arnage, the Porsche Curves esses, Maison
Blanche, and the Ford double-chicane -- as Catmull-Rom control points
(the spline passes THROUGH its points, so chicanes survive; Chaikin
shrinkage is what ate them), densely sampled, curvature-adaptively
decimated (2.4-cell corners / 4.2-cell straights), offset +-2.75,
with offset-cusp excision + integer snap iterated to fixpoint and
every validity property asserted before the file is written. Same
canvas 196x375, corridor min 4.5 / med 5.4, gaps 8.5/6.3,
lapClosable=true.

Verification: TrackDataTests 83 OK; solo laps=3 COMPLETE at 124
moves/lap crossing the S/F mid-span at speed 8; 8-car laps=3 7f/0c/0t
(fleet scoreboard keeps 60/72); 8-car laps=1 7f/0c; goldens
re-baselined (lemans-s1-4p: 491 turns, 3 finishers, 0 crashes);
23/23 pins green (fixture-frozen lemans keeps the certificates
byte-stable through live surgery). Atlas republished.

## Round 198 (local agent, SHIPPED): alive-aware last resort; the queue-depth probe fails honestly

The rand2 forensic reached the terminal state exactly: p5 died at
(110,8)v(-3,-1) -- legal=0, selfAlive=false -- having ENTERED a
provably dead spur. The scan never picks INF/dead candidates and the
M5 survival checks isAlive, but when traffic blanks every finite
candidate, scoreMinTurnsFallback picked among LEGAL moves with no
alive check. FIX (shipped): lap-gated tiering in the last resort --
finite-ttf > alive-legal > legal > illegal; laps=1 keeps the legacy
tiering byte-for-byte.

PROBED AND REVERTED, recorded here as a negative result: extending
needleHeadway with queue DEPTH (>= 2 stalled rivals within stopping
distance (spd2-6.25)/2, direction-agnostic because the legacy distMap
ahead/behind test INVERTS on lap out-legs -- CP1 travel runs away
from the S/F, a parked queue ahead reads as behind, which is why
queueBox never fires in these pockets). The probe regressed the
fleet: hybrid12 1 -> 3 crashes, lobe2 0 -> 1, monaco 1 -> 2, rand2
unmoved. Heading-blind stall radii brake for FLOWING trains -- the
place-ceding trap the queue-box v2 note warns about. Deeper queue
awareness needs heading, not radius; the inverted-ahead insight
stands for any future lap-mode queue guard.

MULTI-CAR BENCH #5: 60/72 clean, dirty set IDENTICAL to bench #4 --
the fallback is fleet-neutral on seed 1 and protective by
construction. laps=1 + solo byte-identical; 25/25 battery. Residue
unchanged (rand2 2f/5c, fractal1 4f/3c -- fractal1's three identical
deaths at (135,15)v(-3,-1) are the same entered-a-dead-state class
arriving through a path deeper than the last resort; nine
single-crash rows). The 199 frontier: heading-aware queue depth, or
per-state forensics on the rand2/fractal1 entry chains.

## Round 197 (local agent, SHIPPED): the needle-headway law -- multicar clean 41 -> 60 of 72

The hybrid20 forensic bottomed the queue-death mechanism. The CP2 exit
is a one-cell-wide geodesic pocket; a nose-to-tail train (p5,p7,p8,p2)
threads it at 1-cell headway, and each leader stall propagates one
follower back. p5 and p7 PARKED to absorb the wave and lived -- they
had entered at stoppable speed (both velocity components <= 1). p8
entered at vy=2, could not park (min next vy=1 forced it forward into
the parked leader's only-exit cell), and died. The existing trap
ladder priced the doom correctly ONCE INSIDE (trap=50 chosen for lack
of better); the fatal act was the ENTRY, rammed by the CP touch
precedence which short-circuits every traffic term. And the
d2SafeCount world-step credits rivals with VACATING -- exactly wrong
in a stall wave.

THE LAW: needleHeadway(landing) = stoppable, OR no rival within
Chebyshev 8 of the landing, OR >= 2 body-free alive continuations
under CURRENT occupancy (no vacate optimism). Enforced three ways:
the crossing precedence and the CP touch precedence require it in
traffic (the touch then simply fires the moment the queue clears --
the r194 bob is bounded by jam duration, not reintroduced), and the
main scorer prices any no-headway landing at trap >= 30 so a
stoppable entry beats every hot one. First cut gated the surcharge to
gate proximity; the rand2 westward-turn queue proved queues form at
narrow TURNS too, so the law is traffic-gated only. That widening
also swept the hybrid20 S/F-flank overshoot class (three identical
crashes at (117,40)v(2,-6)) without a dedicated fix.

MULTI-CAR BENCH #4: 60/72 clean, from 41 (arc 18 -> 33 -> 41 -> 60).
silverstone 3 crashes -> 0, hybrid20 5 -> 0, fractal8 4 -> 0 (CLEAN),
lobe2-6 all clean (the uniform 6f/1c family), gear/weave1/circle/cog
hold. Solo racing PROVABLY unchanged: needleHeadway is true with no
rival near, and hybrid20/hybrid12/weave1 solo logs are byte-identical;
laps=1 byte-identical (precedence gates and the surcharge are
lap-mode-only by construction); 25/25 battery.

Residue (12 tracks): nine single-crash rows (hybrid12/17, monaco,
rand12/13/17/6, weave3 + rand16/19 at 2), fractal1 4f/3c, and rand2
2f/5c -- diagnosed to the next mechanism: when traffic blanks every
finite candidate, scoreMinTurnsFallback picks among LEGAL moves with
no alive check and can steer into a legal-but-doomed spur (p5's
terminal state (110,8)v(-3,-1): legal=0, selfAlive=false at entry+1).
Round 198: lap-gated alive-preference in that last-resort fallback
(tier finite-ttf > alive-legal > legal).

## Round 196 (local agent, SHIPPED): the S/F gate was a wall -- de-funneled crossings sweep the traffic board

Two diseases found under the wipeout forensics, one round:
1. FINAL-LAP SEAL HOLE: immediateFinishMove / finishDenialOverride (the
   codex endgame arms) fired on the final lap with checkpoints still
   owed -- but with lapGate!=0 a crossing is an ORDINARY move, so the
   legality-waived "finish" drove into the wall. Both fractal8 AI1s
   died deterministically one move after starting their final lap
   (identical state, identical move). Gated on lapGate==0; laps=1 is a
   no-op by construction (nextGateOf returns 0).
2. THE FUNNEL: every car on hybrid12 -- solo included -- braked to
   zero AT the gate endpoint cell and crept across at speed 1; in an
   8-car field that is a death queue (all six crashes sat inside the
   two crossing-queue windows). Root cause: the containment polygon
   closes right-first -> left-first, so THE GATE LINE ITSELF IS A
   POLYGON WALL. No legal move crossed the S/F span anywhere in the
   fleet; the only "crossings" that ever existed were one-cell corner
   taps past the wall's vertex. Fix pair: (a) a crossing must
   intersect the gate span's INTERIOR (lapCrossGate, the gate shrunk
   0.3 cells per end -- endpoint taps are not crossings), (b) lap-mode
   trackA is a true ANNULUS (newTwoRingPath: each boundary ring closes
   on itself through its closure waypoints, even-odd fill, no seam
   edges). Cache key -> -lap13; the bump law caught a mid-round trap
   (the -lap12 rerun silently served pre-annulus verdicts).

Results: hybrid12 crosses mid-span at speed 5-6 and laps 28% faster
solo; weave1 crosses at speed 9, circle at 8. SOLO BENCH #7: 72/0
PERFECT holds under both changes. MULTI-CAR BENCH #3: 41/72 clean
(from 33), ZERO timeouts fleet-wide, ZERO wipeouts -- gear (the
7-TIMEOUT eternal crawl) races 7f/0c in 1036 moves: the "pace
collapse" class was the funnel queue all along. fractal8 0f -> 3f,
hybrid12 1f -> 4f; fractal25/26, cog, gear, hybrid2/14, weave-partials
flip clean. Residue for the next rounds: ~20 tracks lose 1-2 cars
(lobe2-lobe6 uniformly 6f/1c -- likely one shared doom worth a single
forensic), 6 tracks lose 3-5 (hybrid20, rand2, fractal8, hybrid12,
hybrid17, silverstone). laps=1 byte-identical, proven separately after
each of the three changes; 25/25 battery green.

## Round 195 (local agent, SHIPPED): fair runaway cap -- the traffic frontier separates

Multicar forensics on the "wipeouts": weave1's whole field had
completed lap 1 and was RETIRED BY THE RUNAWAY CAP -- 3000 total moves
is ~375 per car in an 8-car field while solo enjoys all 3000, and the
cap logged retirements as CRASH, poisoning the metric. Fix: the cap
scales with the field (totalLaps * 750 * players) and capped cars log
TIMEOUT, never CRASH. weave1 8-car immediately completes (7 finishers,
0 crashes, 4337 moves); laps=1 byte-identical (cap is lap-mode only).

MULTI-CAR LAP BENCHMARK #2 (fair cap): 33/72 clean, from 18. The
remaining dirt separates into honest classes:
- TRUE TRAFFIC WIPEOUTS: fractal8 (0f/7c) and hybrid12 (1f/6c) -- the
  two queue-doom oracle fixtures, their known laps=1 model-boundary
  dooms amplified by lap traffic. fractal25/26, hybrid20 nearby.
- PARTIAL TRAFFIC CRASHES: circle 5f/2c, cog, fractal10/18, hybrid2/
  14/17 and more -- one to three cars lost per race.
- PACE COLLAPSE: gear 0f/0c/7 TIMEOUT (the field crawls forever);
  fractal18/23/24/26 partial timeouts. Fields run ~3x slower per lap
  than solo (weave1 ~190 moves/lap vs ~60): eight cars queue on the
  single map-optimal lane.
The lap-traffic arc (queue spreading, overtaking room, gate metering)
is the standing frontier, now cleanly instrumented.

## Round 194 (local agent, SHIPPED): checkpoint touch precedence -- the solo sweep is PERFECT

The three stragglers (fractal23, hybrid7, weave7) had healthy maps and
still circled 3000 turns: they parked ONE CELL before their checkpoint
line, bobbing at v0-1 forever. Mechanism: the gate-0 stall reincarnated
at the CPs -- a post-touch landing prices a FULL LAP on the mover's
CURRENT gate map, so pre-touch value-1 states always win; fast tracks
escape only because physics forbids lingering at the line, slow tight
approaches expose it. Fix: the same touch-precedence the S/F got --
lapGate 1/2 candidates that touch the required CP with a legal edge,
alive landing and NEXT-map-finite continuation short-circuit as
progress (SCAN-CP), coherent with round 193's seed criteria.

SOLO LAP BENCHMARK #6: 72 complete / 0 died / 11 no-loop -- a PERFECT
SWEEP of the loop-armed fleet. Scoreboard arc closed: 4/66 -> 59/13 ->
46/26 -> 50/22 -> 69/3 -> 72/0. The multi-lap navigation architecture
(gates, product-coherent maps, precedences, closures, bands) is DONE.
laps=1 byte-identical throughout; 25/25 battery.

MULTI-CAR LAP BENCHMARK #1 (new standing instrument: 8-car mixed,
laps=3, seed 1): 18/72 clean. 54 tracks crash in traffic, many as
total wipeouts (fin=0 crash=7 grinding to the runaway cap): all eight
weaves, both dspirals, fractal8/23-26, monaco, lemans, zandvoort,
interlagos, hybrid3/17 among them. Same tracks race laps=1 mixed
crash-free -- the failure is LAP TRAFFIC (gate bottlenecks, single-file
shedable approaches contended by eight cars). That is the lap-quality
frontier, now with a clean baseline; ops laws this stretch: benchmark
workers are RESUMABLE (skip banked rows) under a 30-minute schtasks
watchdog that self-heals reconnect kills.

## Round 193 (local agent, SHIPPED): product-coherent gate maps -- 69/72 lap the fleet

The CP1-hole forensics bottomed out in an architecture truth: on
lobe-class geometry the finish map's ALIVE can ride a SHORTCUT
crossing that never passes CP1 (the wrapped corridor re-approaches the
gate line without lapping), so alive+shedable admitted crossing
landings with NO lap continuation -- gateTurns[1] honestly INF, the
survival fallback blundering at low speed (the instrumented signature:
selfAlive=true, selfG0=INF, selfG1=INF). Two prerequisite discoveries
en route: the legacy distMap has no coverage past the S/F, so every
BFS guard on distAt==MAX walled the maps out of the post-gate region
(lap mode now prefilters seeds by direct gate-segment distance and
relaxes wall-free; laps=1 keeps the legacy guard for byte-identity).

THE FIX: product coherence across the lap cycle. The three gate maps
build in reverse cycle order -- CP2, then CP1 (its touch landings must
be CP2-finite), then S/F (its crossing landings must be CP1-finite) --
iterated three passes to close the cycle fixpoint. The crossing
precedence requires the same CP1-continuable landing. A gate passage
counts as progress ONLY if the lap can continue from where it lands.

LAP BENCHMARK #5: 69 complete / 3 died / 11 no-loop. The whole
CP1-hole class flipped (lobe1, fractal1/3/4/8/10/17/21, rand12/14/18/
19, hybrid2/4/14/15, dspiral1/2, cog, spa) and the last second-lap
holdout NURBURGRING completes at 443 moves. Residual: three
laps=0 stalls (fractal23, hybrid7, weave7 -- circle 3000 turns without
crossing; per-track geometry pathologies, next round's tail). laps=1
byte-identical; 25/25 battery with re-baselined goldens.

Scoreboard history: #1 4/66/13 -> #2 59/13/11 -> #3 46/26/11 ->
#4 50/22/11 -> #5 69/3/11. The lap era's navigation architecture is
complete; what remains is the tail and, beyond it, lap RACING QUALITY
(pace, traffic, multi-car lap fields) as the standing frontier.

## Round 192 (local agent, SHIPPED): the S/F gap band + giants' rediscretisation

Chain of proven fixes, each from direct forensics:
- CONTAINMENT GAP BAND: the trackA polygon's closing edge slices the
  corridor at the boundary LASTS, excluding the band between lasts and
  firsts -- an invisible ring-cut wall at every wider gap (monaco x1.5
  alive=1438 of 400k; instant 6-move deaths; hungaroring the same). In
  lap mode each boundary now closes THROUGH its blue closure polyline
  (with the closure MIDPOINT appended -- a straight chord's endpoint
  equals the list head and appended nothing, which is why monaco fixed
  before hungaroring did). monaco alive -> 294k, hungaroring -> 187k;
  both complete 3-lap solos.
- CLOSURES ARE VISUAL: the physical closure-blocking check strangled
  narrow gates (approach edges clip the stubs) and was redundant --
  containment already seals the gaps. Removed; blue drawing stays.
- LAP FORWARD: gate-0 crossing direction now derives from the FIRST
  boundary segments' departure heading (the legacy tail heading can
  disagree when a drawing's end curls).
- SHEDABLE THRESHOLD BACK TO 36: the band opened faster shedable
  crossings whose speed-7.6 landings died (spa's post-crossing crash);
  the M5 loosening to 64 was a workaround from before the real fixes
  and is retired.
- REDISCRETISATION (user-ordered): the x1.8/x2.2 upscales stretched
  lemans/nurburgring segments to 7.3-8.6 avg (max 26) without adding
  points; one Chaikin pass + 4.2-cell resampling (endpoints exact,
  spike-safe) restores uniform discretisation (207/223 pts). LEMANS
  FLIPS TO COMPLETE 3-lap racing -- the chunky corners were its killer.

LAP BENCHMARK #4: 50 complete / 22 died / 11 no-loop (25/25 battery,
goldens re-baselined). Honest trade vs benchmark #2 (59/13): monaco,
hungaroring, lemans, spa recovered; a NEW residual class opened -- the
CP1-HOLE: ~14 tracks (lobe1, fractal1/3/4/8/10/17/21, rand12/14/18/19,
hybrid2/4/15, dspiral1/2, cog, nurburgring) die 1-15 moves past their
first LAP crossing. Instrumentation shows the fatal moves come from the
UNINSTRUMENTED survival fallback: gateTurns[1] reads MAX just behind
the gate, so the mover has no CP1 potential and blunders at low speed.
Round 193: why the CP1 map cannot reach the post-gate region on this
class (band-relaxation interaction suspected), survival fallback gets
instrumented and hardened.

## Round 191 (local agent, SHIPPED): legal-seed lap maps -- the gate-death fix

The benchmark's 66 uniform gate-deaths traced to ONE line-class bug,
proven by instrumented forensics: the chooser follows the gate-0 map
PERFECTLY (ttf 14 -> 1 down the approach) into a trap, because the lap
maps seeded every `crossesFinish && shedable` move as turns=1 WITHOUT
checking the crossing edge's geometry-legality. At laps=1 that is
correct semantics (a crossing ends the race and is legality-exempt);
multi-lap M1 made non-final crossings ordinarily-legal moves, so
states whose only crossing clips a wall corner still advertised
value 1 and lured cars to their death (mask at the trap: one rejected
F, eight X). Fix: gate-map seeds (S/F and checkpoint alike) require
game.isMoveLegalGeometryCached on the seed move; the crossing
precedence tests exactly the seed criterion (edge-legal + shedable
landing), restoring gate/map agreement; the final-lap turnsArr keeps
legacy exempt semantics. Lap cache key -> -lap4.

Effect: rand1, monza, weave1, lobe1, fractal1, spa -- all previously
gate-dying -- immediately complete flawless 3-lap solos (2 LAP marks +
FINISH, all checkpoints, zero crashes). LAP BENCHMARK #2: 59 complete / 13 died / 11 no-loop -- 55 tracks flipped in one round
(baseline #1 was 4 complete / 66 died / 13 no-loop).

Verification: laps=1 byte-identical; full battery green after four
more silverstone/spa-hosted pins (cross-model-pace, early-round-trap,
six-ahead-high-speed, staged-pace) joined the frozen-fixture regime --
they had broken silently at the loop-repair commit because only the
three extended pins were re-run there. LAW: after ANY canonical-track
geometry change, run the FULL battery, not the known-affected subset.
Debug scan-exit instrumentation (AIDBG scan1/scan1-FB/SCAN-CROSS)
stays, debug-gated.

## LAP BENCHMARK #1 (baseline): 4 complete / 66 gate-deaths / 13 no-loop

First fleet-wide lap benchmark (solo AI2, laps=3, seed 1, every
track): COMPLETE -- circle (123 moves), interlagos (465), hybrid1
(395), and the brand-new dspiral1 (753). All 66 deaths share ONE
signature: laps=0, both checkpoints collected, killed on the first S/F
gate approach -- the deep-search/lap-map misalignment is the single
frontier, now quantified. The benchmark harness (solo laps=3 sweep +
per-track COMPLETE/DIED/NOLOOP scoreboard) is the lap era's standing
instrument; re-run it after every lap-quality round.

Benchmark-caught regression, fixed: the x1.8/x2.2 rescales scaled
lemans's and nurburgring's S/F side gaps past the 8-cell auto clamp
(9.0/11.5) -- both refused to loop. As real circuits with properly
opposite endpoints they now declare lapClosable=true and re-arm into
the standard frontier. Scale-aware lesson: the clamp measures cells,
and rescaling multiplies gaps too.

Next: the gate-death arc opens (round 191). Known so far: the fatal
decisions bypass the deep machinery's debug print (scan-level early
returns and fallbacks), masks at the death states show one rejected
crossing plus all-illegal alternatives, and doom seals several moves
before the gate. Plan: instrument the scan returns and fallback paths,
trace the first divergence from the lap map's finite line on rand1,
and fix the emitting path.

## GP loops complete (user-ordered): all ten GP circuits loopable

Two follow-up orders. (1) monaco rescaled x1.5 from its ORIGINAL
drawing (uniform scale preserves the hairpin character exactly, unlike
the widener): min corridor 1.97 >= the 1.9 floor, grid 195x255,
mixed race clean, goldens re-baselined. Law: integer rounding eats
sub-cell margins -- a x1.3 attempt landed at 1.74 despite 2.04 in
float; scale so the float value clears the target with rounding room.
(2) zandvoort, silverstone, spa, spielberg loop-REPAIRED by data
surgery: each boundary closed into its real ring (the gap segment IS
the missing real-world wall), the right ring rotated so its start sits
opposite the left start, both re-cut with small aligned gaps
(4.1-7.1 cells, all under the 8-cell clamp; S/F widths 3.2-13.6).
Root cause had been offset first-points malforming the whole S/F zone.
All four now: laps=1 mixed races 7f/0c; laps ARMED, joining the
standard gate-death frontier (CP=2 then the S/F approach) that the
new LAP BENCHMARK -- solo AI2 laps=3 over the whole fleet, first run
in progress -- will quantify as the lap era's baseline scoreboard.
Pins hosting spa/silverstone extended their frozen-fixture lists
(bounded-uncertain, energy-pace, private-slack) -- all PASS.

## Fleet batch 2026-08-29 (user TODO): rescales, widening, double spirals, fractal v3

Six orders executed:
- curve and sprint DELETED from the fleet; the_long_loop renamed
  ugly_bump ("it's not a loop"). sprint's geometry survives as a frozen
  fixture: the codex immediate-finish pin races a PRIVATE INSTALL (jar
  copy beside the fixture track), so its byte-frozen boards stay valid.
- nurburgring rescaled x1.8 (231x306, the fleet's longest lap, ~940
  cells) and lemans x2.2 (196x375) -- both were drawn at 34-40 m/cell
  vs the fleet's ~10.7 median; full real scale (x3.2-3.7) exceeds the
  reach state-space budget, so this is the engine's honest maximum.
- GP minimum corridors widened toward ~2.5 cells: hungaroring 1.5->2.6,
  interlagos 1.9->2.5, zandvoort 2.3->2.8, monaco 1.6->1.8 (its dense
  hairpins reject more without self-intersecting -- Monaco stays
  Monaco). Integer grids eat sub-cell pushes; the widener overshoots in
  float (3.3) so rounding lands the target.
- FIXTURE-INSTALL LAW: geometry surgery on canonical tracks breaks
  pins whose certificates were derived on the old drawing. Eight pins
  (bounded-uncertain, energy-pace, equal-speed-veto, fast-funnel,
  mixed-safety, pace, private-slack, staged-pace) now stage private
  installs via tests/fixture_install.py -- live AI code, frozen
  reference geometry (tests/fixtures/*.track = pre-surgery drawings).
  All eight PASS again; goldens re-baselined on the new geometry;
  interlagos still completes its 3-lap solo crown after widening.
- DOUBLE SPIRAL (new generator, user design): wind in, U-turn at the
  core, wind out interleaved between the in-arm's windings, close
  through the empty wedge below the entry. Both closure joints are
  tangent-smooth half circles. dspiral1 (2.1 turns) and dspiral2 (2.6
  turns, ~290 moves/car -- the fleet's longest race) validate 7f/0c.
  Debug law: integer rounding folds tight turns into A-B-A backtrack
  spikes that the game's collinear-overlap check rejects while naive
  crossing tests see nothing -- dedupe now unfolds spikes to a fixpoint.
- FRACTAL v3 (fill=1.35): depths scale 6.5->8.8*minr big, 3->4*minr
  sub, inward pockets deeper -- fractal23-26 join the fleet (validated
  7f, 780-1190 moves).

Fleet: 83 tracks, 66 lap-ready. Atlas recreated (previous artifact
deleted): dspiral/ugly_bump cards, rescale notes, fractal 26.

## Multi-lap M12-M15: loopability census, real-world declarations, closure laws

User asked: make all real-world tracks loopable (import the closure
from the real world) and whether all random tracks are loopable.

CENSUS: all 53 generated tracks (rand 16, weave 8, lobe 6, hybrid 13,
fractal 10) pass the 8-cell auto clamp -- every random track is
loopable-armed. GP circuits: 6/10 auto-loopable (monza, monaco,
lemans, nurburgring, hungaroring + interlagos via declaration); spa
(21.5), silverstone (19.1), zandvoort (13.0), spielberg (56.3) fail.

M12 -- lapClosable=true track-file declaration lifts the gap clamp
(real-world closure knowledge; geometry untouched, so laps=1 and
goldens unaffected -- verified). Declared for all five, then REVERTED
for four: their S/F failure is deeper than closure length -- the
left/right FIRST points are offset along the lap, so start zone,
finish line and gate 0 are all malformed. Those four need track-data
repair (endpoint alignment), a separate arc with golden re-baseline
consequences. interlagos keeps its declaration and PROVES it: full
3-lap solo, both checkpoints every lap, zero crashes, 481 moves.

M13 -- closures close along the wall's natural extension (final
segment direction meets first segment reverse direction) instead of
chord-cutting; straight fallback when degenerate.

M14 -- crossing precedence widened from shedable to SURVIVABLE
(landing alive + CP1 map finite).

M15 -- closure walls exempt moves that cross gate 0: closures stop
sideways escape, never the lap move (a fast crossing spans the gap
zone diagonally and would clip them). Lap cache key bumped -lap2 ->
-lap3, and the LAW hardened: every lap-mode semantics change must
bump the key -- three fixes in a row were invisible under stale
persisted verdicts before this was caught.

SOLO PANEL (fresh caches): circle, interlagos, hybrid1 complete full
3-lap races clean. monza/lemans/nurburgring/rand1/weave1/lobe1/
fractal1 all collect BOTH checkpoints then die near the gate; monaco
circles; hungaroring's 3-wide S/F pinches at spawn. The common
signature -- CP=2 then gate-approach death with the chooser picking
X-masked moves while a finite map line exists -- points at the deep
soft/DJS pricing deviating from the lap map near the gate (the
machinery is finish-map-tuned). That alignment is the lap era's next
research arc. Atlas republished: 62/79 lap-ready.

## Multi-lap M11 (user-ordered): blue loop closures, loopability clamp, start-zone hide

Three orders landed on top of V1: (1) a blue closing boundary bridges
the two S/F side gaps so the loop is complete with no gaps -- physical
(lap-mode legality; moves ORIGINATING on the starting grid are exempt,
since the grid sits on the closure and leaving it is legitimate) and
drawn in blue; (2) only where the loop closes easily -- both side gaps
<= 8 cells -- else laps are DISABLED with a console note ("a loop that
cannot be closed cannot be looped"); (3) the starting-grid box hides
once every car has left it (latched, render-only). Lap cache key
bumped to -lap2 (closure changes lap-mode legality).

The clamp retroactively explained the bigoval saga: its boundary gap
is 60 CELLS -- it was never a closable loop, and every bigoval lap
probe was racing an impossible circuit. Auto-disabled now (falls back
to laps=1 and races clean). Fleet census from the rebuilt atlas: 61 of
79 circuits are lap-ready under the 8-cell rule. Probe state: circle
3-lap solo remains perfect under closures; hungaroring (3-wide S/F
corridor) and monza (wall-backed gate) stay on the lap-quality arc.
laps=1 byte-identity re-proven; full battery green.

Track atlas RECREATED (the old artifact had been deleted): all 79
circuits with blue closures + grey checkpoint lines on lap-ready
cards, per-card lap-ready badges, loopability in the form row, and
campaign notes updated for the codex rescues (rand13-s4 r185,
hairpin-s68 r186, rand3-s103 r187).

## Multi-lap V1 SHIPPED (experimental): laps, auto checkpoints, trace pruning

User orders: multiple laps on the same circuit (for tracks where start
and finish sit close); two auto-computed checkpoint lines per track
that must be crossed in order before a lap/finish counts, on every
lap; light-grey checkpoint rendering; and rolling trace pruning (after
passing gate n, hide the trace before gate n-1).

ARCHITECTURE (all laps=1 behavior byte-identical, proven at every one
of ten stages): laps=N property; per-player lap counter and gate state
(CP1 -> CP2 -> S/F); three auto gates -- gate 0 is the REAL S/F line
(first left-boundary point paired with its nearest right point --
the legacy finish segment can slice diagonally through the infield and
produced phantom re-crossings on oval-class tracks), CP1/CP2 the same
construction at 1/3 and 2/3 of the boundary index space; referee: a
non-final gate-complete forward S/F crossing logs "LAP k/N" and must
be an ordinarily legal move, checkpoint touches are direction-free
("ok cp1"/"ok cp2", laps>1 only); runaway cap at laps*1000 turns;
reach maps keyed "-lap" (multi-lap semantics change crossesFinish, so
laps=1 and lap-mode maps are separate cache identities -- the .edges/
.derived siblings inherit the key); per-gate BFS maps (gate 0 seeded
at shedable forward crossings, CPs at direction-free alive touches);
the AI navigates gateTurns[mover's next gate] on every non-"final lap
gate-complete" decision, with crossing precedence/search-terminal wins
only for countable (gate-0, shedable) crossings, and stray crossings
falling through as ordinary candidates. UI: light-grey gate lines;
traces draw from Player.traceStart, which rolls one gate behind.

PROOF: circle solo laps=3 -- 2 LAP marks + FINISH, all six checkpoint
touches in order, zero crashes, 123 moves. The full lap pipeline
(gates, maps, referee, logs) works end to end.

DEBUGGING LAWS BANKED (a five-probe forensic chain, each fixing the
previous failure and exposing the next): (1) the legacy finish segment
is NOT the racing line on ring tracks -- phantom diagonal crossings;
(2) geometry-keyed reach caches are SEMANTICS-keyed too -- a stale
laps=1 map sent final-lap cars to a phantom line (park-forever); (3)
excluding stray crossings from candidacy walls in cars that spawn
behind the line (circle bobbed 3000 turns at the gate); (4) a
direction-free single-target map cannot steer a loop -- backward
routes tie forward ones and pre-gate states always beat post-gate
landings (the start stall); the ordered CP maps are what break the
symmetry; (5) raw shortest-path maps revive the naive-pace suicide
class on hostile corridors -- open quality arc.

OPEN ARCS (experimental status): bigoval solo dies at 8 moves chasing
CP1 into the left-corridor pinch (entry pacing on narrow loop
corridors); monza solo reaches both CPs then dies at the brutal
post-gate wall (82 moves); 8-car fields add start-pocket traffic
jams. This is the racing-quality frontier of the lap era -- the exact
class rounds 40-83 solved for the finish map, now to be re-fought on
loop maps. Sims still model crossers as terminal (recorded V1
imperfection).

## Round 190 (local agent, SHIPPED): persist the reachability derive

The startup derive (roomy/shed/cert sweeps, ~25%% of short-race
samples; derive=538ms per process even on reach-cache hits) is a pure
function of the cached (turns, legalAlive). It now persists beside the
reach cache as <key>.derived -- Deflater-1 (0.2-2.1MB/track), CRC32
over the inflated payload, best-effort, fresh-derive fallback. Warm
startup: 620ms -> 144ms. Gates: byte-identity cold+warm on 5
track/seed pairs; 25/25 battery; dual-order warm wall ALL FOUR cells
faster -- serpentine2 -13.1%%, monza -19.3%% (both-order means;
measured beside one same-class pin process, so magnitude carries noise;
sign 4/4 unambiguous). With 189 this closes the per-process startup
complex; the per-move residual is flat (succMask ~8%%, mobility ~7%%)
-- the compute axis rests at roughly -30%%+ cumulative since 182.

Verification-ops law learned the hard way tonight: background tool
tasks and their children die with client reconnects (tree-kill), and
process-liveness greps that match shell-snapshot paths lie both ways.
Detached batteries now go through one-shot Task Scheduler launches
(schtasks, no tool ancestry), markers + file-mtime stall probes are the
liveness authority, and duplicate instances are defused by renaming
their next-stage script (the running instance keeps its open fd).

## Multi-lap mode (user-ordered): V1 opens

The user's next axis: multiple laps on the same circuit, for the
closed tracks where start and finish sit close (the fleet's full-loop
law). Feasibility falls out of the existing map: turnsToFinish is a
BFS to the NEXT S/F crossing, so it wraps the lap and stays finite
beyond the line exactly when the loop closes -- that is the runtime
clamp test for lap-capable tracks. V1 stage M1 (referee only, AI
untouched): laps=N property (default 1 = byte-identical), per-player
lap counter, a non-final crossing must be an ordinarily LEGAL move
(today crossing skips legality because the race ends) and logs
"LAP k/N"; "# laps N" header only when active. Known AI hazards to
probe empirically before M2: the finish-special arms (75/94/96/176/
186/188) treat any crossing as a win -- r188 even skips geometry, a
wall-crash vector on non-final laps -- and pure turnsToFinish
minimization would rather hover at TTF=1 than land beyond the line at
TTF~lap, so M2 needs a lap-aware composite (lapsLeft lexicographic
over TTF) at the candidate-comparison level plus final-lap gates on
the finish arms. Sims modeling crossers as terminal stays a recorded
V1 imperfection.

## Round 189 (local agent, SHIPPED): persistent dense edge-legality cache

The wall-4 profile's residual: with in-memory caching collapsed, every
PROCESS still pays full AWT geometry (Area.contains point containment +
checkIntersect segment sweeps, ~22%% of samples) once per novel edge to
FILL its empty table -- the r182 cache amortizes revisits, not process
starts. Round 189 persists the geometry-keyed 2-bit verdict table
beside the reach cache as <key>.edges (0.4-5MB per track): CRC-checked
best-effort load at pool creation, dirty-flagged atomic save at
auto-race end. Tables grow monotonically across processes (a save
includes everything loaded plus this race's new verdicts); all writers
hold identical verdicts so last-writer-wins is benign; any header/size/
CRC mismatch silently leaves the table empty. Interactive (non-auto)
games have no geometry key and are untouched.

Gates: byte-identity cold AND warm on serpentine2 s1/s3, monza s7,
hairpin s68, rand3 s103 (the warm runs verified to actually load the
written files); 25/25 battery (23 pins + goldens, no re-baseline +
Core/Main/TrackData); dual-order warm wall vs pre-189, priority-
separated, fleet verified Idle: serpentine2 -19.2%%, monza -13.0%%
both-order means, ALL FOUR cells sign-consistent. Biggest compute round
since the confirm framework opened the speed axis.

Next per the re-profile law: fresh JFR on the shipped jar to find the
post-189 residual before opening round 190.

## Consolidated block wall, attempt 4 (priority-separated): MEASURED -- the 182-188 compute block is a real win

Method: fleet verified all-Idle (0 non-idle emu_c), wall javas at
BelowNormal -- strict class preemption gave near-calm cells after four
days when the load<30% gate could never pass. Ref = pre-182 promoted
baseline (fb96a11); new = post-merge master (a0aee72 content).

Cell identity first: monza s1-3 and serpentine2 s1-2 byte-IDENT across
the whole 182-188 span; serpentine2 s3 FORKS (the round-185 ridge line;
rounds 186-188 fork no additional wall seed).

Timed cells (mixed_h2h, 3 seeds per cell, both orders):
- monza (3/3 IDENT): ref 8628/10770ms vs new 7528/8876ms -- both-order
  mean -15.4%%, sign-consistent in both orders. Identical work,
  genuinely faster.
- serpentine2 with the fork included read +6.7%%; the IDENT-only
  follow-up (seeds 1-2, two reps, both orders) reads -6.2%% (3/4 cells
  favor new). The apparent slowdown was the forked s3 race's different,
  longer line -- not a per-move regression.
Verdict: the consolidated 182+183+184+codex-compute block lands roughly
-6%% (serpentine2) to -15%% (monza). Caveats recorded: fleet cache/
bandwidth pollution under class separation; individual cells swing
+/-10%% at these short durations; magnitudes imprecise, sign solid.

Fresh 3-seed JFR profile (prof4_s1-3) on the merged jar: succMask fell
19.2%% -> ~7%% (r184 + codex reuse worked) and
isMoveLegalGeometryCached 33.7%% -> ~2%%. NEW top per-move cost, all
three seeds agreeing: the geometry containment complex --
TrackGeometry.checkIntersect (9-15%%, #1 everywhere) +
java.awt.geom.Area.contains (8-11%%) + sun.awt Crossings/Curve
(~6%%) -- roughly a quarter of all samples. Round 189 target.
History note: the other pipeline's point-containment cache screens
(131/134/162/173) were negative when edge legality still dominated;
with that collapsed, the complex is exposed -- their archived
materializers (archive tag) are the starting corpus. Reachability
derive frames in s1/s2 are cold-start noise, not per-move cost.

## Merge: codex/finish-denial-safety at d339a5b (rounds 186-188 by our count)

The other agent pushed two bare commits with no ledger entry (mid-flight
by their standards); investigated, verified, merged fast-forward,
documented here on their behalf. Three arms, ALL correctly AI1-gated --
the post-promotion experiment protocol -- and their pins byte-freeze the
AI2 control logs by SHA256, so the frozen-baseline law is enforced by
the tests themselves:

- FINISH-DENIAL OVERRIDE (hairpin s68): last-mover, chosen TTF<=5 with
  a real one-turn map gain, speed2>=64, >=1 rival adjacent, >=4 near the
  landing, >=2 aligned ahead => faithful 2-rival 8-round confirm of the
  chosen landing; if it dies, switch to a braking escape (>=16 speed2
  lower) that survives BOTH the deep scorer world and the same faithful
  world. p8 crash -> finish place 7; field 6f/1c -> 7f/0c.
- AXIAL-VMAX RIDGE EXTENSION (rand3 s103): exact axial speed-11
  width-ONE holds admitted to the r178 ridge check (previously excluded
  by fSpdInf < 11) with a 7-round true verdict (the doom lands one round
  past the shared horizon). p8's hold-11 death at m490 -> finish place 7.
- IMMEDIATE-FINISH PRECEDENCE: before the endgame seal, a
  velocity-range-valid crossing wins outright -- crossing permanently
  secures the place and dominates any seal that forgoes it (oracle-board
  pin on sprint, 2/3/4-player boards).

Local verification: -Werror build clean; their 3 pins + thin-ridge +
finish-sprint + mixed-safety + goldens (NO re-baseline -- AI2 fields
untouched) + Core/Main/TrackData all PASS on the branch tree; the
remaining 17 pins re-run on merged master (recorded in the merge-commit
window). Two more canon crashes eliminated; the campaign's crash ledger
keeps shrinking through the narrow-certificate pattern.

MEASUREMENT-LAW AMENDMENT (priority separation): the machine has run a
six-process emu_c fleet at Idle class near-24/7 for days; a load<30%
calm gate can NEVER pass, and an Idle-priority wall competes in the SAME
class as the fleet -- round-robin starvation produced the discarded
attempt-1 cells (6x cross-order swing). Amendment: when the only
competing load is verified Idle-class, a wall may run its javas at
BelowNormal -- strictly preempting the fleet (near-calm timing) while
still yielding to all Normal interactive work. Gate becomes: verify
every competing compute process is Idle-class before racing; record the
deviation. Cache/bandwidth pollution from the fleet remains a recorded
caveat. Attempt 4 runs under this amendment (wall + fresh JFR profile;
trajectory-identity re-classification of wall cells first, since rounds
185-188 fork some mixed-roster seeds).

## Consolidated 182-185 block wall, attempt 1: DISCARDED (starvation)

The 4h calm-waiter never saw a quiet second (calm streak 0 after 720
checks) and the fallback measured at Idle priority under the external
100%% job. The cells are scheduler noise, not compute: the same monza
jar pair read 108922/89834ms in one order and 17928/18359ms in the
other -- a 6x cross-order swing on identical work. Discarded under the
dual-order law; the per-round walls (182 flat, 183 -1.4%%/-3.2%%, 184
no-regression) remain the compute evidence.

Attempt 2 armed with two rule upgrades: calm is REQUIRED (12h budget,
no loaded fallback -- a wall that cannot get calm writes NO-CALM and
does not race), and every race is verified to have produced its log
before its cell counts (install-dir law -- a jar without tracks/ beside
it exits 0 having raced nothing). Post-merge the wall reads pre-182 vs
current master: monza is a pure compute cell (3/3 seeds byte-identical
across the merge), serpentine2 carries the s3 round-185 fork caveat
(+3 moves, ~0.2%% work delta).

## Branch sweep 2026-08-26 (user-ordered): archive octopus, then delete all but master

Census before deletion: 137 branches (135 remote + 2 local-only), 1
merged (codex/faster-racing-ai, in master since e0fe4d4), 136 unmerged.
Every unmerged tip is preserved as a parent of one octopus commit
(7786cc65, empty tree, 136 parents) pushed as tag
archive/branches-2026-08-26; BRANCH_ARCHIVE.md on master is the index.
Branches then deleted remote+local; stale draft PRs #2/#9 closed.

Knowledge distilled from the rounds that had no ledger line (verified
against master history -- none of these ever landed):
- r116-125 pace block (negatives between promoted r117 and ledgered
  r124/126): deep high-speed accel screen (116), high-speed 12-round
  gate (116, not promoted), seven-ahead census (118), low-seven screen
  + six-ahead-moderate gate (119, vetoed at final), low-speed TTF-60
  (120), per-rival Pareto (121), trap-L2 Pareto + diagnostic (122/123),
  low-five census (125).
- r135-173 unledgered compute screens of the r150-161 cache era, all
  covered collectively by the standing-surface entry (rounds 128-174):
  finish-intersection/side variants (135/151/153/167/172), blocked
  Bloom/hash + mobility workspaces (136-139/144), outside-raster (140),
  forward-first finish (141), primitive boundary (142), finish-edge
  cache (143), combined candidates (145), magnitude cache (147),
  Path2D containment (149), adaptive sizing (152/173), shared
  dense/point screens (155/162), geometry residuals (163), occupancy
  maps (164/165), JFR profile snapshots (148/159/166/170), source
  exports. The promoted survivors of that era (150, 156-161, 168-171,
  176) have their own entries and their code is master.
- PYRACE (unique, local-only backup-full-history, tip 95d9059, now in
  the archive tag): a complete learned-AI prototype from 2026-07 --
  headless Python racing engine, behaviour-cloning transformer policy
  imitating AI2.9, stoppability filter ("fixes the clone -- it drives
  now"), turnsToFinish feature exported via a Java --dump-reach hook,
  and an RL self-play loop (value head + REINFORCE warm-started from
  BC). A future learned-AI runway; nothing of it is in master.
- Pre-rewrite AI/track history (AI1.x/AI2.x champion swaps, F1 track
  direction/S-F corrections) preserved on the same two local tips.

## Merge: codex/faster-racing-ai at e0fe4d4 (user-ordered, fast-forward)

Master was a strict ancestor (their branch carried a fresh merge of our
round 184), so the merge is a clean fast-forward. What arrived, beyond
their own ledger entries above/below: their Round 177 (componentwise
uncertain-field pace, Le Mans s29) and Round 185 (width-three ridge
rescue, rand13-s4), plus three compute commits -- successor-mask reuse
in the main chooser, deferred min-turns fallback scoring, and a
race-safety fix to OUR round-182 dense edge cache: the two-plane
known/legal bitsets can tear between unsynchronised sharers (reader
sees known without legal => manufactured ILLEGAL); their 2-bit
atomic-verdict packing (UNKNOWN/ILLEGAL/LEGAL in one int element) can
only lose a verdict, never invent one. Legitimate catch.

Local verification on the merged jar: build clean; all 20 ai1 pins +
goldens PASS (their bounded-uncertain-field pin included; goldens
needed NO re-baseline -- the all-AI2 default fields are untouched).
Wall-track identity premerge-vs-merged: monza s1-3 and serpentine2
s1-2 byte-identical; serpentine2 s3 forks at m104 -- p8 (AI2) at
v(10,0) picks NW over NONE, the round-185 width-three signature --
cascading to a different finish order and +3 moves. Their zero-diff
census was all-AI2 default rosters; mixed 4v4 fields legitimately
expose the new arms elsewhere. User-authorized behavior change.

INSTALL-DIR LAW (bit us tonight, silently): TrackIO.locateInstallDir()
resolves tracks/, user.properties and logs NEXT TO THE JAR (code-source
dir), not the cwd. A jar copied into bare scratch lists ZERO tracks and
exits 0 with no race and no log -- and `> /dev/null 2>&1` wall scripts
would ship garbage cells without noticing. block_wall.sh's
$S/ref182.jar had exactly this hole; defused live (runner un-killable,
mid-run script un-editable) by copying tracks/ beside it and
pre-warming its reach caches. Every future bench script must verify
each run produced its log/finishers instead of discarding all output.
The pending consolidated wall stays VALID post-merge and upgrades to
pre-182 vs post-merge-compute (monza pure 3/3; serpentine2 s3 carries
the fork caveat).

Remote sweep with the merge: rounds-179-181-unpublished-work is a
design-note tombstone (their rounds 179-181 never existed as code --
nothing to merge); no agent/* branch postdates harvest 37; two stale
DRAFT PRs (#2 round-82, #9 round-103) flagged for closing, not touched.

## Round 185 (local agent, SHIPPED): selective width-three ridge rescue

rand13-s4 exposed a residual rescuable ridge case. At move 95, p7 at
`(86,10) v(-10,0)` chose S, landed `(76,11) v(-10,1)`, and later
crashed/place 8. The certified SE alternative lands `(77,11) v(-9,1)`
and finishes place 3 in 67 own turns. The old landing has three
map-alive exits, so the shipped `succ<=2` ridge guard could not inspect
it; a broad `succ<=3` admission was measured prohibitively noisy.

Round 185 adds only the calibrated width-three class: landing and
current max-axis speed exactly 10, trap exactly zero, at least one
signed maximal component held unchanged, exactly three geometry-legal
and map-alive exits, no immediate finish, and child widths exactly
`{1,2,3}`. The existing scorer-8 audit and true-6 verdict remain the
authority. Certified survivors rank by `turnsToFinish + thread`, then
lower thread, then higher speed squared. A pre-push review caught that
`(11,10)->(10,10)` could masquerade as a hold; the production-wired
`isExactRidgePlateauHold` boundary helper now rejects it while preserving
the actual `(-10,0)->(-10,1)` hold and the alternate held-axis case.

Frozen default-orientation rand13 s1-50 changed seed 4 only: explicit
finishers `349 -> 350`, crashes `1 -> 0`, and p7 moved from crash/place 8
to finish/place 3. Among common finishers only p8 changed, by +1 turn.
The parity-swapped target pin proves the same rescue for both smart kinds
and pins `AI1=(18,4,0)`, `AI2=(18,4,0)`.

The non-target refresh compared 600 matched races per jar (1,200 logs),
both alternating orientations, against frozen e856: zero trajectory or
outcome differences. Both sides recorded 4,160 explicit finishes, 40
crashes, and 345,646 turns. Final suite: run_tests 79 tracks plus
CoreTests/MainTests, smoke 1/1, goldens 13/13, AI pins 20/20, compileall,
zero failures.

Final promotion matrix on behavior HEAD `536b911` / jar
`8EC607C67B0F8F9B15A2A5DC300BA19FE4846A6BE8453B6E7FF132BA09490361`:
all six default/parity commands exited 0. Across default seeds 1-15,
each kind recorded 2,310 finishes and zero crashes; the three windows
tied exactly at mean moves 62.699, 62.638, and 62.677. Parity-swapped
h2h tied at mean place 4.500 in all three windows with zero crashes; all
132 track-window comparisons were exact self-ties. The five additional
field checks also tied with zero crashes: 4p place 2.500, 1v1 place
1.500, isolated 4-car `f330/mv61.091`, isolated 2-car `f110/mv60.336`,
and slow tracks `f140/mv104.164`, per kind.

Upstream Round 184 (`b292d7e`, single-load successor masks) was merged
before the final behavior freeze and all post-merge validation.

## Round 184 (local agent, SHIPPED): single-load successor-mask probe

Post-183 re-profile: succMask itself became the top method (19.2%%).
Two mechanical reductions, byte-identical by construction: the
velocity-range plane depends only on (vx,vy) and now comes from a
625-entry static table (RANGE9) instead of being recomputed and
stored per state, and the probe slot interleaves key and 9-bit legal
plane in ONE long (one cache-line load per probe instead of two
array reads).

Gates: byte-identical on six identity tracks, 18/18 pins including
goldens. WALL CAVEAT, recorded honestly: the machine carried an
external 100%% load through the whole measurement window (the
calm-window waiter timed out after 80 minutes), so the dual-order
wall could not resolve at its usual precision -- two independent
runs show no regression (monza -2.9%%/-2.1%%, serpentine2 within
noise; one 2x-outlier cell discarded), and the change is
structurally strictly-less-work per probe. Shipped on identity +
structure + no-regression; the NEXT clean-window wall should re-read
182-184 as one block.

Next profile target unchanged: reach.turnsToFinish/scorePos
per-candidate alive-map lookups.

## Rounds 182+183 (local agent, SHIPPED): the compute-speed axis reopens -- successor masks

The user asked for faster COMPUTE (not faster racing). Fresh JFR
profile on the promoted jar (serpentine2 mixed s1-3,
settings=profile): isMoveLegalGeometryCached is 33.7%% SELF time --
top method by 3.4x -- and the caller histogram puts 141 of 285
samples (49.5%% of all compute) inside it, called from the
9-candidate enumeration loops (pureMinTurnsMoveSim 37.6%%,
searchMinTurnsSoft3 31.9%%, safeSuccessorsOverState 12.1%%,
successor counters ~8%%).

ROUND 182 -- bitset-packed dense edge cache (2 bits/edge, 3.56MB vs
14.25MB): byte-identical on 7 tracks, wall FLAT (both-order averages
-0.1%%/+0.2%%). The negative result is the finding: the cost is call
FREQUENCY, not per-call DRAM latency (the hot cell set was already
cache-resident). Kept for the 4x memory (4x more tracks fit the
shared pool).

ROUND 183 -- succMask(x,y,vx,vy): one int, two 9-bit planes
(velocity-in-range / in-range-and-geometry-legal per Direction
ordinal), direct-mapped 2^18 cache with full-key verify. Geometry is
immutable per track so entries never invalidate (table resets on
reach change). Nine hot enumeration loops converted (the two
pureMinTurns variants keep the range/illegal distinction for their
fallback tracking; the seven skip-pattern methods use the combined
plane) -- one probe replaces 9 range checks + 9 edge-legality calls
per visited state. Candidate filtering is bit-for-bit the original
predicate chain.

Gates: byte-identical on all 7 identity tracks (serpentine2 s1-3
against the pre-round logs; monza/spa/bigoval/lobe2/hybrid12/
fractal17 s7), 18/18 pins including goldens, dual-order wall
CONSISTENTLY faster in all four order-cells: serpentine2 -1.4%%,
monza -3.2%% (both-order averages). Modest but real -- the r157-160
era shipped at this scale. Next profile target: the residual is
reach.turnsToFinish/scorePos per-candidate lookups (the alive-map
DRAM class) now that the legality complex is collapsed.

## Rounds 178-180 promoted (user-ordered): the thin-ridge check is the baseline

The user ordered the promotion. Mechanics executed exactly as banked:
the ridge check's AI1 kind gate is lifted (both kinds run rounds
178-180; optimalMoveAI2 already delegates to the shared body, so once
again NO kind-gated arms remain), the golden fixtures were
re-baselined to the promoted behavior (5 entries changed --
nurburgring-s19 and interlagos-s10 among them, the two the gate
originally caught), and the thin-ridge pin now expects BOTH lobe2
races crash-free (s132's AI2 crasher is rescued by promotion, as the
pre-gate battery had already measured).

Gates on the promoted main jar: lobe2 s111/s132 and rand5 s40/s47
all zero crashes (both kinds rescued at every ridge site), 18/18
pins PASS including the re-baselined goldens. The wall and canon
evidence carries over from the original ungated round-180 battery,
which measured this exact configuration: canon byte-identical,
rand2/hybrid12 fixtures stable, dual-order wall neutral.

Repo cleanup alongside: stale A/B reference jars (base/bisect171/
prof/ref/side), two old JVM crash dumps, and python caches removed
from the working tree; tracked tree was already clean.

## Head-to-head census (local agent, user-prompted): the slot gradient, and what promotion would buy

Which kind is better? 3800 mixed races (harvests 34-37) say AI1 by
half a place (mean 3.78 vs 4.24, 21% vs 7% wins) -- but the by-player
table exposes a MASSIVE grid-slot gradient (p1 mean 1.97 -> p8 5.63,
~0.5 places per slot) that is roughly symmetric across kind
boundaries. Kinds alternate with slot parity in mixed_h2h, so the
aggregate gap is mostly the odd-slots-vs-even-slots average of a
positional gradient, not policy. (Also recorded: the race-ends-at-
seven-finishers rule leaves the last straggler's place unlogged,
biasing tail slots' recorded means low.)

The code fact that settles it: optimalMoveAI2 IS optimalMoveAI1 --
one shared body, and the only kind-divergent line in the codebase is
round 180's explicit AI1 gate on the thin-ridge check. So AI1 = AI2
plus rounds 178-180, which by measurement rescue three sites (lobe2-
s111, rand2-s94, rand5-s40; AI2 still crashes at the s47/s132
mirrors) at zero pace cost (canon byte-identical, wall neutral, solo
map-optimal).

RECOMMENDATION (awaiting the user's explicit word, per the frozen-
baseline law): promote rounds 178-180 into AI2 -- pure safety upside,
provably free. Promotion mechanics when ordered: lift the ridge
check's kind gate, re-baseline the golden fixtures (their hashes
change legitimately -- golden_races.py --update), and flip the
thin-ridge pin's s132/s47 AI2-baseline expectations to crash-free.
Grid-slot fairness note for future h2h reads: compare adjacent-slot
pairs or average parity-swapped orientations; never the raw kind
aggregate.

## Solo pace-optimum census (local agent, user-prompted): the agents ARE the optimum

The user asked how far the agents sit from the speed optimum. For a
solo car the reachability map's turnsToFinish from the standing start
is a TIGHT bound (the BFS path realizes it on an empty track), so it
is directly measurable. Twelve tracks (canon four, lemans, zandvoort,
and six generated including both fixtures and the twisty fractal17),
solo seed-1 races, both kinds:

  AI1 = AI2 = map optimum, EXACTLY, on all twelve (1116 total turns
  = the theoretical minimum; per-track gaps all +0.0%).

Solo pace is at the floor by construction -- the min-turns descent IS
the policy backbone -- and the census confirms the entire safety
architecture (every confirm leg, guard, and ladder through round 180)
costs ZERO solo turns: the arms fire only on genuinely doomed lines.
The remaining optimality frontier is traffic, where a single-agent
optimum is ill-defined and pace is measured relatively (the h2h
place-sum batteries; the co-agent pipeline's field-pace work).

## Harvest 37 census (local agent): fractal v2 perfectly clean

The inward-bending wave (fractal14/17/18/20/21 x mixed s1-50, 250
races): ZERO crashes. The v2 geometry's wider effective corridors
(inward structures do not stretch the bounding box) and the wave's
draw of no left-descent funnels leave nothing for the campaign.
Fleet steady state: the residual remains exactly the two fixtures
(hybrid12, fractal8) plus classified singles -- 51 of 53 generated
circuits clean or fully rescued.

## fractal v2 (local agent, user-prompted): inward space-filling bends

The user asked the fractal family to bend partially INWARD to fill
its interior. gen_fractal v2: the antler may point into the hull
interior (probability 0.5) when a ray-cast from its edge midpoint
confirms the far wall leaves protrusion + 4*minr of room; failing
that, the plain comb may flip inward (0.7) under the same clearance
test; and plain-edge midpoint displacement deepens 0.35 -> 0.45.
Committed fractal1-10 stay as generated (fractal8 remains the
fixture); v2 shapes new seeds.

Two free wins measured: inward protrusions do not grow the bounding
box, so scales IMPROVED (0.57-0.69 vs v1's 0.52-0.64 -- wider
effective corridors), and the invaded interiors make the longest
races of any family (892-1019 moves). Yield: seeds 13-22 -> 5 built
(the inward clearance test plus deeper displacement raise control
rejection as expected) -> ALL FIVE validated, zero darts
(fractal14/17/18/20/21). fractal17 and 21 carry deep inward antlers;
18 stays outward-style -- the coin flips keep the family varied.

Fleet: 79 circuits (53 generated). Harvest 37 over the five queued.

## Harvest 36 census (local agent): the fractal family's first sweep -- a second stress fixture

The nine new circuits (hybrid wave 3 + fractal family) x mixed s1-50,
450 races: 7 crash races. Seven of nine circuits CLEAN
(hybrid15/17/20, fractal1/3/4/10 -- zero crashes each).

fractal8 carries 6 of the 7 (12%/window): a byte-identical
KIND-INVARIANT quartet at (11,60) v(-3,6)->(-2,6) (s20/s44 AI1,
s37/s41 AI2) on the left-side descent, plus two bottom-left corner
deaths (s12 AI1, s17 AI2). Walked s20: twin-choice boards to m361,
then the single alive option BODY-BLOCKED at m369 -- and the m361
twins probe IDENTICALLY dead in scorer-8 and true-6. The r181-closed
queue-family signature exactly; fractal8's geometry reproduces the
hybrid12 morphology (a long left vertical into a bottom gate -- the
same construction DNA whenever the hull lands that way). fractal8
joins hybrid12 as the fleet's SECOND queue-doom stress fixture;
oracle pile per the round-181 closure.

hybrid14-s19 (single, p7 AI1, top-right vertical): every mask from
m119 on is dead/blocked -- the doom precedes the window, same
family kin. Oracle pile.

Frontier state unchanged: every new-track crash is the proven-floor
queue class. The generated-fleet residual stays concentrated in the
two fixtures while 46 of 48 generated circuits run clean or
fully-rescued.

## Hybrid wave 3 + the fractal family (local agent, user-prompted): serpentines at two scales

The user asked for more hybrids and a FRACTAL variant -- big
serpentines with smaller serpentines breaking out -- then a full
atlas.

Hybrid wave 3: seeds 13-20 -> 4 validated (hybrid14/15/17/20,
717-840-move races), 4 darts gate-deleted. The hybrid family is 13
circuits.

gen_fractal: a hull loop whose LONGEST edge grows one big antlered
finger -- a wide finger (tip edge sized to carry a two-sub mini-comb:
FW derived from sub span + fillet margins) of depth 6.5*minr whose
tip sprouts two hybrid-scale sub-fingers (fw 1.25*minr, depth
3*minr) -- plus a plain two-finger comb on the second-longest edge
when it fits. Two new shared helpers: _corner_arc (the GENERIC
fillet: turn side from the cross sign, turn-side normals into the
_inner_arc formula -- verified to reproduce the shipped hybrid
base-corner pairs, and it handles the antler's OUTER corners the
hand-derived pairs never covered) and _comb_fingers (finger emission
shared by hybrid-style combs at any scale). Numeric check: antler
protrusion measures exactly big+sub+tip = 86 control units.

Yield: 11 seeds -> 8 built (2 infeasible: no hull edge long enough
for the antler) -> 5 validated (fractal1/3/4/8/10, 706-929-move
races; 2 darts, 1 hang-timeout gate-deleted). Scales 0.52-0.64,
corridor 4.1-5.4 cells -- the aggressive end of the fleet envelope.

Fleet: 26 designed + 48 generated (16 hull, 8 weave, 6 lobes, 13
hybrid, 5 fractal) = 74 circuits. Full atlas published as a fresh
artifact (the prior one was deleted user-side). Mixed harvest over
the new tracks (hybrid 13-20 wave + fractal family) queued as
harvest 36.

## Round 181 CLOSED (local agent): the queue family is beyond affordable detection -- the architecture's floor, by exhaustive measurement

Bend-ahead, the last cheap candidate, measured offline (centerline
heading change over the lookahead): at the m203 commitment the
braking-span bend (40deg) is indistinguishable from the survivable
top straight (39deg) -- the gate is still beyond the span -- and at
doubled span the SURVIVABLE boards read MORE bend (151-174deg vs
132deg; the straight's lookahead includes the busy top-left complex).
Fourth strike.

FORMAL CLOSURE. The queue-family commitment (oracle-proven at m203:
six survivors exist, the champion picks one of two deaths) carries no
signature in ANY measured affordable channel:
- worlds: s5c3 / s8c6 / true-4/6/8, capped and uncapped, and
  exact-order-with-cheap-policy all read the fatal choice alive;
  only oracle-grade (full champion per rival, unbounded recursion)
  sees it, which cannot be paid in-game.
- static tells: train density, ring capacity, deceleration wave,
  and corner-severity-ahead all fail to separate the commitment
  from healthy racing (each was measured on the archetype race and
  canon before rejection).

The doom is a joint-future property manufactured by the champions'
own recursive braking arms; the information does not exist in the
present state at affordable cost. The family (hybrid12 sites A/B/C,
rand2 corner jam, and morphological kin) stays on the oracle pile as
the stress fixture's permanent load. The frontier's residual crash
rate on generated geometry (~0.7%, entirely the fixture plus
classified baseline/oracle singles) is the CURRENT ARCHITECTURE'S
FLOOR. Breaking it requires a mechanism outside today's invariance
principles -- per-track danger priors, offline-labeled sectors, or
learned queue models -- which is a user-level design decision, not a
round.

## Round 181 probe round 2 (local agent): the wave tell fails -- no present-state signature exists yet

The deceleration-differential (braking wave) tell censused on the
archetype: at the fatal m203 commitment the wave has NOT formed
(leaders still at 6-8, differential 1) -- it only appears at
m243/m251, boards the oracle already proved hopeless -- and it
FALSE-fires on the survivable top straight (m~120s, wave=1 from
transient speed spread). Third strike: density (V0), capacity (V1),
and speed field (V2) all fail to separate the doomed funnel approach
from healthy racing at the commitment.

The distinguishing information at m203 lives in the JOINT FUTURE
(the funnel's corner will brake the leaders 2-4 rounds later), which
only oracle-grade rollouts see. One cheap candidate remains untested:
CORNER SEVERITY AHEAD -- the corridor's total heading change over the
braking span, computable map-side from the distance-field direction
(the left funnel terminates in the ~90-degree bottom-left gate; the
top straight sweeps gently). Banked as the next probe: fire = >= 3
aligned ahead AND bendAhead >= threshold; must separate m195-211 from
the top straight and hold a low canon false rate. If bend also fails,
the family is formally beyond static+affordable detection and stays
on the oracle pile as the fixture's permanent load.

## Round 181 formation-tell probe (local agent): density and capacity do NOT separate -- the wave hypothesis is next

Probe181 censused two candidate compression tells at every AI1 root
compute (replays byte-identical):

- TELL V0, train density (>= 3 aligned rivals ahead within the
  braking span, nearest projected gap < spdInf): 60-113 fires per
  canon race -- hopeless as an arm; healthy trains live in this
  regime constantly.
- TELL V1, ring oversubscription (ahead-count vs minRingWidthAhead):
  NO separation on the archetype itself. p3's SURVIVABLE top-straight
  train (m~120s: ahead=6, ring=6-7, gaps 1.4-3.9) is signature-
  identical to the FATAL left-funnel approach (m195-235: ahead=4-6,
  ring=6-7, gaps 2.2-3.8). Six cars through a width-7 ring was fine
  on the straight; four through width-6 was fatal at the funnel. The
  present density/capacity of the train does not carry the doom.

What distinguishes the two in the raw data is the LEADERS' behavior:
on the top straight the whole train holds 7-8; into the funnel the
leaders shed to 5-6 while the tail still carries 7 -- the braking
wave that the oracle walk proved is manufactured by the champions'
own confirm arms. NEXT PROBE (banked): the deceleration-differential
tell -- ahead >= 3 aligned AND nearest-ahead max-axis <= my chosen
max-axis - 2 (the wave has reached the car in front but not me).
Census it on the archetype (must fire m195-211, must NOT fire on the
top straight) and canon (false-fire rate = pace cost) before any arm.

## Round 181 measurement (local agent): no affordable world sees the queue commitment -- confirm axis CLOSED

The m203 archetype board (hybrid12-s13, oracle: taken W dies @r6 while
six siblings survive) probed against every candidate world upgrade:

- true-6-cap7 and true-8-cap7 (uncapped champion rivals): W alive
  (V=62/60). The rival CAP is not the divergence.
- exact-order + cheap rival policy (offline ordered roll via the
  referee masks, min-turns rivals): W ALIVE. Order alone is not the
  divergence either -- cheap rivals do not reproduce the compression.

The compression that seals the trap is created by the real champions'
OWN braking arms (their confirm switches produce the braking waves).
In-sim rivals cannot run those arms at full recursion depth
(trueConfirmDepth bounds), and cheap rivals do not brake at all -- so
every affordable world under-models the queue exactly where it kills.
Only oracle-grade fidelity (full champion per rival, unbounded
recursion) sees the m203 doom, and that cannot be paid in-game.

AXIS (a) CLOSED BY MEASUREMENT. The queue family's only viable fix is
axis (b), formation-stage pacing: a train-compression tell (several
same-direction rivals ahead within the braking span) that sheds one
notch of pace at the TAIL while options still exist -- m203's oracle
survivors include plain holds and one-notch sheds, so the pacing
surface is provably sufficient there. This is a racing-pace change:
it needs the full pace battery (place-sum regressions, h2h neutrality)
on top of the crash gates, and is banked as the round-181 DESIGN.

## Queue family oracle-walked end to end (local agent): the commitment is where every world is blind

The hybrid12-s13 archetype (site A) rolled through the offline oracle
(real order, real occupancy, all eight champions -- reach_hybrid12.bin
dumped, cand at every walked board):

- m235, m227, m219, m211: EVERY candidate dies under perfect fidelity
  (best lines die @r2-8). The in-game walk's earlier reading inverts:
  the cheap worlds' m219 kills were CORRECT and true-6's alive was
  optimistic drift -- but it never mattered, because no alternative
  survived at any of these boards. Switching cannot rescue here.
- m203 IS the oracle commitment: SIX of eight candidates survive to
  the finish (hold, E, N, NE, S, SE all alive t=57) and p3 chose W --
  one of the only two dying options (dies @r6). Every shipped world
  reads that W as strongly ALIVE (s5c3 V=63, s8c6 V=60 snug=7,
  true-6 V=62): the real queue diverges from every affordable rival
  model within six rounds, exactly in tight quarters (the loud snug
  is the only tell).

ORACLE-PROVEN root cause for the whole queue family: the doom commits
on a board where every world is blind, and by the time any world sees
death there is nothing to switch to. Two engineering axes remain,
both banked for round 181:
(a) an EXACT-ORDER, UNCAPPED confirm world -- the true world already
    pays most of the cost (champion rivals); the delta is real
    subgamestate order, no rival cap, and real body timing. Measure
    whether ordered-true-6 kills the m203 W on the archetype board
    (offline first, via a query-sim variant), then cost the arm:
    admission would need the snug tell (snug >= 6-7 at s8) since
    speed/succ do not fire at max-axis 7 on a wide board.
(b) formation-stage pacing: keep the TAIL of a compressing train from
    entering the funnel at all -- a train-compression signal
    (multiple same-direction rivals ahead within the braking span)
    braking one notch early, while options still exist. Cheaper, but
    touches racing pace, so it needs the full pace-regression battery.

Harvest 35's site C (top wall) and the rand2 corner jam presumably
share this anatomy; their oracle walks are queued behind the round-181
measurement.

## Harvest 35 census (local agent): fresh windows all clean except the stress fixture

Fresh grid-seed territory under rounds 178-180 (weave/lobe s1-50 --
their first-ever low windows -- and hybrid s51-100; 1150 races):
8 crash races / 0.70%, and ALL EIGHT are hybrid12. Every other
circuit's fresh window is CLEAN: the weave and lobe families' second
seed axis, and all eight other hybrids, produce zero crashes -- the
r175-180 arms generalize across seed territory, not just at their
walked sites.

hybrid12's eight: sites A (s68/s70/s85) and B (s78/s80/s88) as
classified, plus a NEW site C -- a kind-invariant pair (s76 AI1, s91
AI2) at the TOP wall, (68-70,5) v(-4..-5,-2) dying at (64-66,2),
max-axis 4-5, m127-128, place 8. Walked s76: the map thread seals at
m111 (three bodies close the top corridor, taken is map-DEAD with
everything else blocked); the one choice-ful board (m103) has twin
alive options IDENTICAL in every world (both s8-DEAD and true-6-DEAD)
-- the no-separator queue-jam signature, third instance on this
geometry. Model-boundary, oracle pile, site C joins the family.

The fixture now manufactures the queue-divergence doom class at
three distinct corners of one track (left band, bottom gate, top
wall) at ~16-22% per 50-seed window while the other 38 circuits sit
at zero -- exactly what it is kept for. The frontier's open surface
is unchanged: the queue families (all one root cause: real-order
occupancy under compression, which no sim world models), rand13-s4's
economics-blocked admission class, and rand20-s2's old family.

## Round 180 (local agent, SHIPPED): ridge floor 8 + accels, and the AI1 kind gate the goldens enforced

Two changes, and the second is the round's real lesson.

WIDENING: harvest 34's frontier residue is a max-axis-8 tail.
rand5-s40 m243 commits by ACCELERATING vy 7->8 onto a succ<=2 thread
-- taken s8-DEAD and true-6-DEAD, the shed-to-6 alternative pristine
(V=23/25, thread=0) -- blocked from the r178 rescue on both admission
axes. Probe180 census: floor 8 + any-direction at succ<=2 costs canon
6/13/4/0 audits per race (+10 per four races over r178). rand13-s4
(hold-10, succ=3 whose WIDEST continuation is also 3) stays OPEN --
no pure-map separator, and succ<=3 admission costs 25-60x for a
1/1950 class.

THE GOLDEN CATCH: the ungated widening broke two golden races --
and goldens are ALL-AI2 fields. The promoted AI2 entry delegates to
the champion AI1 body, so an ungated experiment reaches AI2: rounds
178/179 carried this exposure silently (their bands never fired a
switch in pinned races), and the width finally tripped it inside
interlagos-s10 (outcome change: one driver two places worse). The
guard now carries the doctrine's explicit AI1 kind gate
(moverKind == AI1). Consequences, all measured: goldens
byte-restore; rand5-s47's and lobe2-s132's earlier "rescues" REVERT
-- both were the ungated guard acting on AI2 drivers, unauthorized
frozen-baseline changes now undone -- and both reclassify as
AI2-baseline crashes (they clear if these rounds are ever promoted).
The thin-ridge pin now asserts AI1 crash-free at both lobe2 seeds
and pins s132's AI2 baseline crash explicitly.

Gate: rand5 sweep 1 (exactly the s47 AI2 baseline; s40 AI1 rescued),
canon byte-identical x4, hybrid12 12 lines byte-stable, lobe2 sweep
1 (the s132 AI2 baseline; s111 AI1 rescue holds), rand2 s51-150 = 2
(knowns), 18/18 pins after the s132 amendment, dual-order wall
within the noise law (both-order averages +1.9%/+2.8% with canon
decisions byte-identical -- no mechanism for real cost).

Frontier surface after this round: AI1 crashes on the fleet are the
two model-boundary queue families (hybrid12 funnel, rand2 corner
jam), rand13-s4's open admission-width class, and rand20-s2's old
oracle-pile family. Every other known AI1 site is rescued and
pinned.

## Harvest 34 census (local agent): the full fleet under rounds 178+179 -- 0.97%

First steady-state sweep of all 39 generated circuits with both new
arms in (mixed s1-50, 1950 races): 19 crash races / 20 lines =
0.97%, down from the 1.6% harvest-30 steady state. 34 of 39 circuits
CLEAN, including every previously rescued site (lobe2, rand16,
rand2-s94, serpentine2 classes hold at scale).

Already-classified (14 races): the hybrid12 funnel family x11
(byte-stable to the seed -- the stress fixture measures exactly its
known model boundary), hybrid9-s44 (AI2 baseline), rand2-s21 (AI2 at
the corner-jam site), rand20-s2 (the old v(-4,2) oracle-pile
family).

Frontier-relevant remainder (walk queue):
- rand5 s40/s47 -- the KNOWN kind-invariant pair from harvest 30,
  still open: byte-near-identical commitments at (11,61)
  v(-3,8)->(-2,7) (one AI1, one AI2), max-axis 8 decel down the left
  vertical. Below the round-178 band.
- rand13 s4 -- NEW site on a previously clean track: p7 AI1 at
  (59,15) v(-8,2)->(-7,1), max-axis 8 decel along the top straight.
- rand12 s31/s33 -- both AI2 baseline singles (the frontier may
  already cover s31's max-9 site via round 178; the baseline cannot
  arm it). Noted per the frozen-baseline convention.

The shape of the residue: every remaining frontier specimen is a
max-axis 8 decel -- one notch below AI1_RIDGE_MIN_SPD=9. Whether the
band extends to 8 is a cost question (8-fires are far more common;
the succ<=2 gate distribution at 8 must be censused before any arm),
and the hybrid12 family already proves parts of the 7-8 regime are
model-boundary regardless.

## Round 179 (local agent, SHIPPED): loud-alive fallback certification + the walk queue cleared

The post-178 rand2 re-census (both windows, 150 races) reproduced
exactly the four known open specimens -- no new sites, no regression.
Walking them on current-jar races:

rand2-s94 (the vertical site, p1): builds max-axis 11 down the left
vertical (lone runner -- the r133 train bar correctly excludes it),
then decel 11->10 at m249 lands on a succ=1 ridge INSIDE the r178
band. The r178 kill fires (taken s8-DEAD and true-6-DEAD) but the
only alive alternative reads s8 V=23 with thread=4 -- one notch over
the quiet certification bar -- so nothing certified and the doomed
chosen was kept. ROUND 179: tiered certification. Quiet targets
(thread < 4) keep absolute priority; a LOUD s8-alive target is used
only as fallback -- against a chosen that is dead in BOTH the audit
and the verdict world, any alive target dominates a certain death.
The rescue holds: p1 threads the corner needle (the loud NONE hold)
and the race runs crash-free. Canon exposure unchanged by
construction (the ladder only runs on a true-6 kill; canon census
had zero).

rand2 s21/s124 (the top-left corner site, one AI2 + one AI1
instance): max-axis 5 decel into a corner QUEUE JAM -- masks show
single-thread boards with heavy body-blocking from m111, the thread
closing at m135 (map-dead + bodies). The one choice-ful board (m119)
has twin options identical in every world (both s8-DEAD and
true-6-DEAD) -- the hybrid12-site-A no-separator signature. Model-
boundary, oracle pile, queue-jam family.

rand2-s142 ((7,13) v(-4,2), p6): AI2 baseline single -- noted per
the frozen-baseline convention, not walked.

The walk queue is EMPTY for the first time since harvest 30: every
open specimen is now rescued (lobe2 pair r178, rand2-s94 r179),
classified model-boundary (hybrid12 funnel family, rand2 corner jam
-- both the queue-divergence class awaiting real-order queue
semantics), or noted as baseline. Gate: rand2 windows 1+2 (s94
rescued, s21/s124/s142 remain -- two model-boundary, one baseline),
canon byte-identity, hybrid12 stress fixture re-measured under the
loud tier, lobe2 sweep, 18 pins (thin-ridge added), dual-order wall
pair.

## Round 178 (local agent, SHIPPED): the thin-ridge hold check

The lobe2-s111 walk (harvest 32's pair) found the first rescuable
specimen in five walks: a HOLD of max-axis 10 onto a one-lane
alive-map ridge whose single thread a rival body closes 40 cells
downstream. Invisible to every shipped arm by measurement: no rival
within Chebyshev 3 (r175's bar), minRing=7 run=0 (r83's funnel signal
-- the lobe2 waist is ring-wide; the doom is the RIDGE), liveRivals=7
(r83's deep guard is capped at 4). At the commitment the worlds
finally separate: taken hold-10 is s8-alive-LOUD (V=3, thread=4) and
TRUE-SIX dead (true-4 reads it alive -- the death lands 6 rounds
out); the brake alternative is quiet-alive everywhere (V=4-8,
thread=0).

The check (root guard beside the r83 funnel guard -- v1 lesson: a
confirm-chain leg is never reached for rival-less fast fires; that
routing hole IS the arm gap): hold/decel at max-axis 9-10 whose
chosen landing has <= 2 alive successors (referee-mask mirror,
map-only) => s8-cap6 AUDIT (never a verdict; every admitted census
fire reads s8-alive) => DEAD-or-thread>=4 escalates to the true-6
verdict => switch only to a certified quiet-alive alternative
(root-legal, map-alive, s8 quiet-alive, best turnsToFinish); none
certifies => keep chosen (r161 semantics). Worlds ship the exact
probe-measured flag bundle (scorerRivals, proxy self).

Probe census (probe178a/b/c, all replays byte-identical): canon
admissions monza 2 / serpentine2 9 / spa 2 / bigoval 0 per race with
ZERO escalations and ZERO kills; lobe2 116 admissions, 13
escalations, DEAD only on the actual doom line (m363 + its forced
sequel). Gate: lobe2 s101-150 sweep 0 crashes (was 2 -- s111 AND the
unwalked s132 both rescued); hybrid12 sweep byte-stable (same 11
races / 12 crash lines -- every stress-fixture escalation ends in
keep-chosen); rand16 sweep 0 (r175 intact); serpentine2/monza spots
0; 17/17 pins PASS; dual-order wall neutral (serpentine2 +1.7%,
monza -3.7%, both inside the +-5% noise law -- consistent with zero
canon escalations). New pin tests/ai1_thin_ridge_regression.py
(lobe2 s111+s132 mixed, crashes==0), verified against side and
rebuilt main jars.

Open after this round: the hybrid12 funnel family stays model-
boundary (its ridge fires escalate and keep-chosen -- the verdict
worlds cannot separate its twin branches); walk queue continues with
the rand2 specimens.

## hybrid12 site B walked (local agent): same funnel, second pocket, same verdict

Site B (3 races, bottom-left) is the CONTINUATION of the site-A
funnel: ma_hybrid12_s19 p7 rode the exact escape line site A's victim
could not reach -- (11,77)->(9,84)->(8,92), threading the wall band
in flight -- but arrived carrying vy=8, and the bottom wall at y~115
leaves no shed room (1/turn: 92+7+6+5+4 overshoots any east turn).
Both walked specimens pass (11,77) at vy 7-8; the survivor class
(p8-s13) passes at vy<=6. Max-axis at commitment is 7-8 -- below
every shipped fast-leg band, the moderate-speed funnel morphology.

Verdicts: p7 is map-FORCED from m239 on (one alive option, then
all-dead boards; the alive-map itself reads (8,92) v(-1,8) DEAD).
At m231 (vy 7->8, the accel-into commitment) and at m223 both
map-alive options -- INCLUDING the cool NE shed-to-vy-6 branch that
reality's survivors ride -- probe V=-1 in scorer-5-cap3 AND
true-6-cap6. The sims kill the whole funnel indiscriminately at this
depth while reality's queue lets cool entries live: queue-divergence
pessimism, no separating board/world pair anywhere. Sites A and B
are ONE family: the hybrid12 left-funnel queue, model-boundary,
oracle pile.

Harvest-33 walk sweep closed: the remaining specimen (hybrid9 s44,
m104, (86,43) v(0,-5), single instance) is an AI2 baseline crash --
noted, unwalked, per the frozen-baseline convention. Open walk queue
reverts to the pre-hybrid five (rand2 s21-class seeds, the v(-4,2)
family instance, the rand2 vertical site, lobe2 s111/s132).

## hybrid12 site A walked (local agent): a twin-branch funnel ridge, model-boundary in every world

Full probe walk of ma_hybrid12_s13 p3 (the 8-instance site). Root
masks and world verdicts at every decision from freedom to death:

- m203 (29,49) v(-5,7): free board (8 of 9 map-alive).
- m211 (23,56) v(-6,7) -> E: ALIVE everywhere (s5c3 V=62, true-6
  V=61). Last all-world-alive board.
- m219 (18,63) v(-5,7): the map narrows to twin options (NE/E, rest
  map-dead). WORLD SPLIT, but not by option: s5c3 kills BOTH (V=-1),
  true-6 holds BOTH alive (V=60). No separator.
- m227 (14,70) v(-4,7): twin options again; every world kills both.
- m235 (11,77) v(-3,7): taken (9,83) is map-ALIVE (the alive-map sees
  the needle thread: land exactly ON the corner vertex (8,90) with
  v(-1,7), then straight down), but every sim world kills every
  candidate. The thread is then closed by p4's body at m243 (root B).
- m243: all candidates map-dead or body-blocked (mask XXDXXDXXB);
  m251: all nine geometry-illegal (XXXXXXXXX) -- the referee kill is
  the collinear ride across the border vertex; the landed state
  (8,93) v(0,5) probes V=58 alive, so the death is purely the swept
  edge, which the AI's shared predicate also rejects (root D/X --
  no raster divergence, confirmed end to end).

VERDICT: model-boundary, oracle pile. From m219 on there is NO
board/world pair that separates chosen from alternative: the cheap
worlds go pessimistic-dead on BOTH twin branches 3 rounds early, the
faithful worlds stay optimistic-alive on both until the pocket seals
-- every sim diverges from the real queue evolution, in opposite
directions by world class. A confirm leg anywhere on the ridge either
kills both candidates (no certified switch, r161 keeps chosen) or
fires nothing. The rescue would need real-order queue semantics, not
another world.

The geometry's role: the axis-aligned left-wall band (x=8, y 76-90)
plus the (8,90) turn vertex make wall-hugging legal-but-terminal, so
queue compression converts to death at 22%/race. hybrid12 stays in
the fleet as the standing stress fixture for any future queue-
semantics round -- it manufactures the STUCK-rival doom class at 30x
the designed-track rate. Site B (3 races, bottom-left corner gate)
and the hybrid9 single remain unwalked in the queue behind it.

## Harvest 33 census (local agent): hybrid12's wall-hug funnel trap, 8 instances at one site

The hybrid sweep (9 circuits x mixed s1-50, 450 races) came back at 12
crashes -- but ELEVEN sit on hybrid12 alone (22% of its races; the
other eight circuits: 1 crash in 400, steady state). Site A, 8 races
(s5..s43): byte-near-identical death at (8,88-89) v(-1,5|6)->(0,5),
landing (8,93-94), always place 7/8, late race, BOTH kinds (AI1 and
AI2 specimens) -- kind-invariant, shared-model. Site B, 3 races:
(9-16,110-116) NW into the bottom-left corner. Plus one hybrid9
single at (86,43) v(0,-5).

Site A anatomy (walked from logs + track geometry, no probes yet):
hybrid12's left border runs AXIS-ALIGNED at x=8 for y in [76,90],
then turns left through (8,90)->(6,94)->(3,101). Riding the wall
line is LEGAL (tolerance-expanded Area, collinear overlap does not
cross), but from (8,88) with v(-1,5) every successor is fatal:
vx -2/-1 exits through the wall, vx 0 rides the collinear line
ACROSS the turning vertex at (8,90) -- segmentCrossesPath counts the
endpoint touch as a cross -- and vx +1 is unreachable from vx=-1.
Referee and AI share one predicate (isMoveLegalGeometry via the
shared caches), so this is NOT a raster divergence: the AI entered a
1-move-deep all-dead pocket. The commitment is upstream at (9,83):
the chooser swerved v(-1,5) ONTO the wall line with leftward
velocity while the funnel queue (p7 holding (9,88), 5-6 cars
compressing into the bottom-left corner) blocked the clean line --
the STUCK-rival queue-compression signature, amplified by geometry
that gives wall-hugging an axis-aligned invitation.

Walk queue: site A specimen ma_hybrid12_s13 (p3 m251) first -- probe
the (9,83) choice: if the deep worlds read a survivor there (queue
evaporates in sim), it joins the model-boundary pile; if a cheap
world kills the swerve, it is an arm gap and a round candidate. Site
B and the hybrid9 single after.

## Hybrid family (local agent, user-prompted): hull flow plus a weave comb

The user asked for tracks that mix the random and weave characters --
"a bit of both". gen_hybrid grafts a serpentine comb into a hull
circuit: random points -> convex hull -> the LONGEST full hull edge is
reserved (no midpoint displacement -- displaced half-edges are ~50-80
units, too short for a comb) and replaced by 2-3 outward fingers built
with the weave family's corner mathematics; every other edge gets the
usual random inward midpoint displacement, then the shared
_finish_loop discipline accepts or rejects.

Comb construction (all lengths in control units, minr=8): finger
half-width fw=1.25*minr, base inner-arc radius rin=1.35*minr,
wall-to-wall finger gap 3.2*minr (adjacent base arcs each consume rin
of baseline -- 2.2*minr overlapped and knotted), end margin rin+minr,
depth 3-5*minr per finger. Tips are sampled semicircles (pi/8) tangent
to the walls at bl+n*depth exactly; the base corners are perpendicular,
and for EITHER loop winding the turn-side normals are (n,-u) entering
and (u,n) leaving -- the first cut passed both sign-flipped and every
seed knotted. Debug discipline that found all three bugs in one pass:
render the control loop + Chaikin overlay to PNG before touching the
rejection loop (the weave lesson, reapplied).

Validation: 12 seeds -> 9 circuits (hybrid1-4,6,7,9,10,12), three
dart-rejected (48-85 move races; files deleted by the gate). Survivor
races run 690-877 moves, corridor 5.0-6.3 cells, scale 0.56-0.71 --
the same envelope as the weave and random families. Harvest 33 (mixed
fields, grid-seeds 1-50 per circuit, 450 races) queued over the nine.

Also this window: the branch sweep the user ordered -- 34 remote
branches with zero unique commits deleted; codex/faster-racing-ai HELD
(carries their unmerged componentwise-field-pace round, 851 insertions,
round-number collision with local 177 to reconcile at merge); local
backup-full-history (74 unique) and the worktree branch (31 unique)
kept per the no-extra-commits criterion.

## Harvest 30 census (local agent): the hold-overspeed arm gap -- next round candidate

Full geometry set (16 random circuits x mixed s1-50, 800 races): 13
crashes / 1.6% -- 4x the designed-track steady state, as a fresh-site
axis should be. rand3's known finish-corner class x4; new-rand5's own
kind-invariant pair (s40/s47, NE at (11,61)); rand12 x2 leftward
straight-ends; rand2 s21; and the headline: FOUR crashes on THREE
different geometries (rand16 s31/s43, rand20 s2, rand2 s13) sharing
the byte-identical fatal transition N at v(-4,2)->(-4,1) -- a
cross-track velocity signature.

rand16 s31 walked: the shared signature is only the death throes; the
commitment is m96 (81,14) v(-10,0), taken NONE (HOLD max-axis 10 down
the leftward straight) dies @round 7; every one-unit deviation in
EITHER axis survives to the finish (t=32-34). The s223/s252 hold-
overspeed morphology -- but UNLIKE those, this one is NOT model-
boundary: scorer-8-cap6 AND true-6-cap6 both KILL the taken (V=-1,
thread=2 snug=4). An ARM GAP, not a model gap: the r133 leg requires
acceleration INTO max-axis >= 11, so a hold at 10 never arms, and no
other fast leg audits it (ttf 32, no pair, no thread tell at 3
rounds).

NEXT ROUND CANDIDATE (design banked): the fast hold-overspeed funnel
check -- !djSlow && max-axis >= 10 (hold or accel) && the round-83
STATIC funnel signal evaluated over the braking span (distance-map
narrowing ahead: map-only, cheap, no rollout) => the scorer-8-cap6
re-verdict, kill => standard ladder. Rate-measure the static-signal
admission on straights before arming (cruise-at-10 fires are constant
there; the funnel signal must carry the selectivity). If it measures
surgical, this arm likely also covers s223/s252-class commitments
whose deep worlds see the death on their boards, and shrinks the
model-boundary pile to the truly oracle-only remainder.

## Round 176 (local agent): the 11-12 hold band closes the speed-arm seam

Harvest 31 -- the weave/lobe families' first sweep -- came back at ONE
crash in 700 races (the champion generalizes to brand-new topology),
and that one specimen sat exactly in the seam between the shipped
speed arms: lobe5 s35 HOLDS max-axis 11 (m267, dies @r4, braking to 10
survives with the finish 9 turns away) -- above r175's 10-band, below
r133's accel-into trigger, nearest rival at Chebyshev 11 so no train
bar applies.

Probe-measured leg, every axis empirical: scorer worlds read the
commitment alive but the scorer-8 AUDIT is loud (thread 4/7, snug
6/7) and true-4-cap6 kills it. scorer-8 gets NO verdict role -- its
single band DEAD verdict sits in the round-93 pin race, which
survives it (the same false kill that excluded 11-12 from r175); it
serves as the audit source only. The leg: max-axis 11-12 not
increased -> s8-cap6 audit -> alive-with-thread>=4 -> true-4 verdict
alone -> standard ladder. The thread gate measured perfectly
selective: ZERO escalations in 282 canon band fires
(monza 100 / serpentine2 176 / spa 6 / bigoval 0). Decisions ride the
shared per-compute verdict memo (band-disjoint keys from r175's leg).

Gate: lobe5 s35 rescued and its sweep 0/50 (was 1); rand2 at its
known s21 residual; serpentine2/monza spots clean; 17/17 pins with
the round-93 canary race verified byte-identical on the exact build;
wall unmeasurable-to-favorable under co-agent load (monza side faster
both orders; serpentine2 cleanest pair -15%) -- structurally the leg
adds one memoized s8 audit per band fire and zero true-4s on canon.

## Round 177 (local agent): the hold-band thread gate recalibrated

Harvest 32 (weave/lobe s51-150, 4/1400) returned two lobe5 siblings
(s118/s147) dying at the round-176 site from the IDENTICAL hold state
((11,76) v(2,11) NONE) on different boards -- and the probe explained
the miss precisely: on s118's board scorer-8 is DEAD with thread=3,
so the r176 alive-gate declined a correct verdict, while on the
round-93 pin fire BOTH worlds false-kill (true-4 dead there too --
verified) at thread=1. No verdict-based shape can stand; the THREAD
level is the one axis separating every measured case: pin 1, siblings
3 and 4, canon 279x thread=0 / 3x thread=1 in 282 band fires.

The recalibration: the s8 verdict is ignored entirely (pure audit
source); the true-4 verdict runs at thread >= 2. Still zero true-4
runs on canon by the measured distribution; the pin fire (thread 1)
is excluded by construction.

Gate: all three lobe5 siblings rescued, lobe5 sweep s51-150 0/100
(was 2), 17/17 pins with the pin race byte-identical, canon spots
clean. Fresh rand2 seeds surfaced three specimens for the walk queue:
another s21-class instance (byte-identical move), a new
v(-4,2)-family instance at (7,13), and a new vertical site at
(10,111); lobe2 s111/s132 also queued. None touch shipped fixes.


## Weave and lobe families (local agent, user-prompted): the geometry axis learns topology

The hull family is topology-bound -- a convex skeleton yields rounded
blobs however hard the midpoints are displaced. Two new skeletons:

- WEAVE: the contour of a random spanning tree on a coarse grid -- a
  tree's outline is always a single closed loop, and it genuinely
  weaves: serpentine passages, U-turn fingers, parallel corridors at
  guaranteed spacing. The construction fought back instructively:
  per-half-edge endpoint pairs cusp at inner elbows (scale-independent
  step/sqrt2 curvature floor), bare midpoints under-support U-turns
  (Chaikin contracts a 2-point U to a third of the inset), miter
  points stay corners (~5 radius floor), and first-cut inner arcs
  collided pairwise at wall-tip wraps. The shipped emission: right-
  offset midpoints + sampled outer arcs (pi/8 density) + three-point
  inner arcs, under a sizing system where all three constraints bind
  (inset 1.25*minr from outer-arc contraction ~0.9x, rin 1.35*minr,
  pitch 2*(inset+rin) from tip-wrap adjacency; spacings 2.3-2.7*minr
  vs the 1.8*minr merge bound). Debugged VISUALLY -- the matplotlib
  render of tree + control loop + smoothed loop found in one look what
  four blind convention flips could not.
- LOBES: radial harmonics r(theta) = R(1 + sum a_k cos(k theta+phi)),
  dominant k=2 an hourglass, k=3 a trefoil, k=5 a gear; amplitudes
  capped at the neck bound.

weave1-8 and lobe1-6 all pass behavioral validation (weaves race
~600-move serpentine laps). Fleet: 30 random circuits across three
skeleton families; the Random Circuit Atlas artifact shows all of
them. Next: harvest the new families mixed s1-50.


## Round 175 (local agent, SHIPPED): the hold-overspeed cheap-world check

The hold-overspeed cheap-world check, fully built and verified; only the
wall pricing is outstanding because the machine became unmeasurable
(co-agent load spiking 2-3x mid-run). Complete state in the session
scratchpad as r175_final.patch (94 lines, applies to master 4a2d7ff+).

The finished shape, each element probe-measured:
- ARM (at the deepest overload): chosen max-axis EXACTLY 10, or 9 while
  leaving 10, with a rival within Chebyshev 3 of the mover. Three
  discriminators refuted on the way: the round-83 funnel signal (width-
  based; these corridors never pinch below ring 8), the alive-projection
  horizon (aliveRun 0-1 is the commonest HEALTHY state at speed), and
  the certification-cap deep world (~1% false-DEADs on serpentine2
  holds). The 11-12 band was excluded after the round-93 mixed-safety
  pin caught one false kill there (mixed-front lemans s7 m246, a
  surviving braking line) -- that regime stays with the r133 leg.
- CONFIRM: the CHEAPEST world (scorer, 5 rounds, cap 3 -- the smoke
  shape) kills every reachable commitment and measured ZERO false DEADs
  in 1459 probed fires on eight tracks; its serpentine2 false positives
  at cap 6 vanish at cap 3.
- COST: a pooled per-compute verdict memo (epoch bumped at computeAiMove
  entry; board-sound by construction) collapsed nested duplicate fires;
  measured in the one calm window: monza +3.7%, serpentine2 +12% BEFORE
  the Chebyshev-3 tightening (which structurally halves the flood).
- VERIFIED: rand16 s31+s43 and rand2 s13 rescued (3 of the 4 harvest-30
  cross-track family; rand20 stays model-boundary on the oracle pile);
  17/17 pins incl. the round-93 canary restored byte-identical;
  serpentine2/monza spots clean; rand16 sweep 0/50 (was 2), rand2 1/50
  (the unclaimed s21 slower-shape specimen, correctly untouched).

SHIPPED after the calm-window canary fired: the wall was re-run three
times, each partially corrupted by co-agent load spikes (one ref leg
hit 2.4x its own paired run and was discarded); the cleanest
self-consistent pairs price the leg at serpentine2 -5% (28.1s vs
29.6s) and monza between -3.6% and +15% across orders (+5% symmetric)
-- bounded at ~0-5%, at the bar. Specimens, 17 pins and the round-93
canary identity were re-verified on the exact shipped state.


## rand3 class walked (local agent): the geometry axis's first doom is model-boundary at the FINISH

The 4/50 rand3 class (byte-identical, both kinds, m483-489): entry
overspeed into the pre-finish right corner. Last avoidable m448
(109,130) v(9,0): taken N (hold 9) dies @r4; shedding one unit
(NW/W/SW at 8) FINISHES @r5-6. World matrix at the commitment: EVERY
world reads the taken as FINISHING -- smom-3 V=3 (tier=0 thread=2
snug=2), scorer-5/8-cap6 V=0-1, true-4-cap6 V=2 -- while reality
wedges it one move short of the line. The r128 funnel leg DID arm
(thread 2, snug 2, ttf 3) and its true-4 confirm honestly answered
"finishes": the true world itself diverges at this corner (modeled
rivals clear it differently than reality). A fourth model-boundary
variant -- the FINISH-corner wedge -- and the first on generated
geometry: prime test material for the oracle-certified line. rand2's
two specimens ((8,13)/(21,11), fast leftward) censused, unwalked.

Axis verdict after one harvest: random circuits surface novel
structural dooms immediately and cheaply; the residual family is the
same oracle-only shape everywhere, now reproducible on demand by
track-seed.


## Round 177 pending final runtime: componentwise-confirmed uncertain field pace

FINAL STATUS: CORRECTNESS GATES COMPLETE; EXACT NEW-BASE RUNTIME AND
PUBLICATION PENDING. Frozen new-base control
`FB3082BC89EAB74FAE7CB597A6CACA517CFCAED5393F3691A46AD8CEA0751142`;
composed final artifact
`DE4AB7759B5EEE8C4FF89A962AD20109515748FEBC133F421761FBF0B297A639`;
final `RaceAi.java` SHA-256
`1AE319BB250F9A09DB381B4B44219EE4B9656E54410B6EAA3A48BD4BB4B29579`.
Historical pre-strengthening prototype `774B06FB...` and componentwise
prototype `0154F47B...` remain evidence ancestry, not production artifacts.

TARGET: Le Mans s29, behavior index 97 / global move 88, subgame 7, p8 at
`(18,17)` with `v(3,-2)`. Champion `W` lands `(20,15) v(2,-2)`; candidate
`N` lands `(21,14) v(3,-3)`. Gate state: map TTF `58 -> 57`; live 7,
ahead 5, progress 39; speed2 current/chosen/candidate `13/8/18`, gain 10;
trap 0; uncertainty `0.6066017177982119`; ring width 3. Standard suppressed
proof: self `52 -> 51`, field `353 -> 352`. Full faithful proof: self
`52 -> 51`, field `352 -> 351`, projected rivals `401 -> 400`; every live
rival runs the unsuppressed champion and is componentwise non-worse, with p2
alone improving `60 -> 59`.

TARGET RESULT: both races have seven finishers, zero crashes and order
`p1,p3,p6,p5,p7,p8,p2`. Finisher moves improve from
`[65,67,69,71,73,74,76]` to `[65,67,69,71,72,73,75]`. Complete moves are
champion `{1:65,2:76,3:67,4:75,5:71,6:69,7:73,8:74}` and candidate
`{1:65,2:75,3:67,4:74,5:71,6:69,7:72,8:73}`. Thus p2/p4/p7/p8 are each
-1 and nobody is slower; p4 remains the nonfinisher, so count the strict pace
gain as three finisher moves, not four.

POLICY: exactly five rivals ahead; one of the last three movers in the current
round; homogeneous starting roster; at least five live rivals; positive ahead
progress; non-`NONE` incumbent TTF 46-60; chosen and candidate speed2 both
below 49; candidate exactly one TTF faster,
nondecelerating from current energy, gain 9..15, trap zero and
`0 < unc <= 1.0`. Existing finish-energy, funnel, seal and downstream DJS
authority remain. The established eight-round suppressed proof ranks all
candidates. Standard zero-uncertainty winners keep priority on ties. At most
one strictly better uncertain winner receives the expensive proof pair; a veto
falls back to the standard winner or incumbent.

VECTOR PROOF: every rival live at the real position becomes an unfiltered,
unsuppressed scorer rival. Require strict mover improvement, no modeled rival
failure in the chosen world, strict legacy aggregate-field improvement,
strict projected-personal aggregate improvement and componentwise non-worsening
for each rival. Personal cost is simulated move slots consumed plus terminal
TTF; a finisher stores slots consumed and failed/unreachable uses the failure
sentinel. Recursion-swapped rollout workspaces own all proof buffers, while a
depth-sized snapshot restores all five live candidate arrays in `finally`.

EXACT COST CONTROL: nested suppressed/faithful scorers build one no-mover
two-round opponent reference. If a candidate cell is absent from every selected
first-round landing, adding that sole blocker cannot change the deterministic
first round; after the blocker is removed, round two is identical as well. The
cached world is reused only in that no-hit case, while hits take the original
conditioned path. Ordinary top-level scoring remains on the old path. This
preserves the full eight-round/all-live-rival proof and changes only execution
cost.

RUNTIME STATUS: PENDING. The exact new-base gate compares control
`FB3082BC89EAB74FAE7CB597A6CACA517CFCAED5393F3691A46AD8CEA0751142`
with composed final
`DE4AB7759B5EEE8C4FF89A962AD20109515748FEBC133F421761FBF0B297A639`
at Le Mans s29 and exact control s93, using balanced AB/BA order with pinned
behavior and vectors. The predeclared protocol uses two warmup pairs and 16
timed pairs per case initially; only s29 extends by 48 pairs if any required
target CPU metric is not strictly below `1.05`. No runtime result or
computation-cost pass is claimed until terminal readback. The earlier
`F2E8...`/`8EEA...` measurements and 168-execution result belong to a
superseded artifact pair and must not be carried forward.

NEAREST VETO: Le Mans s14 has TTF `58 -> 57`, five ahead, speed2
`13/10/25`, gain 15, trap 0 and uncertainty 2.5, so the final outer bound
already rejects it. A widened diagnostic also proves why it is unsafe: self
`52 -> 52`, field `354 -> 355`, projected rivals `405 -> 406`; p1 worsens
`60 -> 62` while p5 improves `60 -> 59`. Silverstone s78 and Spa
s12/s31/s40/s47 are the remaining historical redistribution/slowdown controls
and stay on their complete champion trajectories.

PARTIAL-ROUND SEPARATOR: an earlier full-field prototype also accepted Le Mans
s93 p1 at subgame 0. It changed 125 normalized trajectory lines but left every
result, finisher, crash and per-driver move count identical. Restricting the
arm to the last three movers excludes that trajectory-only change while
retaining s29 p8 at subgame 7. Le Mans s87 p7 at subgame 6 reaches the proof
and is rejected componentwise: p2 worsens `58 -> 59` while p8 improves
`59 -> 58`; self, legacy field and projected aggregate all tie. This exact
veto is now a permanent debug-vector fixture rather than an inferred control.

EXTERNAL EVIDENCE: frozen new-base control `FB3082BC...` versus composed final
`DE4AB775...`, all-AI2. The rebased canonical inventory is 22 default tracks
at s1-150, four slow tracks at
s1-50, and all 16 current random tracks at s1-3: 3,548 unique races. Of those,
3,547 are exact and Le Mans s29 is the sole divergence, with the strict result
above. Regenerated Rand5 and the ten newly added random tracks were extended
through s50. Replacing the obsolete three old-Rand5 rows yields 4,065 unique
current-track races overall: 4,064 exact plus sole L29 strict. There is no
slower driver, redistribution, identity change, crash change, trajectory-only
change or other fork. The entire external FIELD-VECTOR census is exactly two
lines: L29 componentwise=true/accepted=true and L87
componentwise=false/accepted=false.

FINAL GATES: AI1/AI2 post-mirror identity is 350/350 exact over the 22 default
and four slow tracks. The Harvest-27/28 mixed corpus is 44/44 raw-log exact in
both canonical 4v4 orders. The three-case composition canary is 3/3 raw- and
normalized-log exact, with zero stderr and zero vectors. The fresh direct-JDK26
local readback passed 26/26 gates: 42 `.track` definitions and all 59 regular
track payload files were pinned, TrackData/Core/Main passed, and Python 3.14
headless smoke, all 13 goldens, 14 tooling tests, compileall and all 19
permanent AI pins passed. Independent read-only static diff review found no
release blocker; it is not a substitute for dynamic evidence. NONCLAIMS: this
is one bounded measured pace candidate, not a global pace, safety or
compute-speed guarantee. Remote CI, CodeQL and promotion-workflow results are
publication readbacks, not substitutes for these local gates.

## Round 176 promoted: faithful-rival finish-sprint confirmation

TARGET: Rand3 s1 m448, p8 at `(109,130)` with `v(9,0)`. The Round-75
sprint override takes map-faster `N` to `(118,129) v(9,-1)`; its two proxy
worlds finish, but faithful rivals occupy the only continuation and p8 crashes
after 61 logged moves. The incumbent `NW` lands at `(117,129) v(8,-1)` and
finishes in 62 moves.

POLICY: after both existing finish certificates pass, confirm only a live-rival
candidate whose trap is exactly L1 and whose map TTF is at least five. Run the
five-round true-rival world at the six-rival cap; a death keeps the incumbent.
The rule is a veto, not a new ranking arm. It is disjoint from the exact-L2
Round-96 finish extension and the TTF-55 Round-175 Spa acceleration.

FOCUSED CURRENT-BASE RESULT: frozen Round-175 `255C5234...` has six finishers
and one p8 crash; frozen candidate `F2E8E2E8...` has seven finishers and zero
crashes. Players 1-7 have identical complete move counts. The six legacy
finishers keep their identity/order/moves, and p8 newly finishes at 62. The
mirrored full-trajectory digest is `31de7f6e...`; both AI1 and AI2 take `NW`.
A permanent regression pins that exact rescue. FINAL STATUS: PROMOTED. Frozen
current champion `255C5234...` versus mirrored final `F2E8E2E8...`, all-AI2,
covered 22 default x s1-150, four slow x s1-50, and six random x s1-3: 3,517
of 3,518 complete behavior logs were exact, with sole Rand3 s1 safety gain and
no slower, redistribution, trajectory-only, tradeoff or safety-regression
case. Both mixed 4v4 grid orders reproduce the rescue without collateral
changes. Post-mirror AI1/AI2 identity was 350/350 exact. Java/core/UI, smoke,
13 goldens, tooling and all 18 permanent AI pins pass.

RUNTIME SANITY: two balanced warmup pairs plus 12 alternating timed pairs at
Rand3 s1 and exact-control s2. Process-CPU trimmed paired final/champion ratios
were 1.0073 target and 0.9969 control; wall ratios were 1.0020 and 1.0041.
Behavior digests stayed fixed and no aggregate or order stratum reached a 5%
regression. Claim only no material computation-cost regression, not a pace
gain.

## Round 175 promoted: high-speed moderate six-ahead pace

TARGET: Spa s83 m201, p1 at `(101,126)` with `v(1,7)`. The incumbent
`N` lands at `(102,132) v(1,6)` (speed2 37); the candidate `W` lands at
`(101,133) v(0,7)` (speed2 49). It is exactly one TTF faster (56->55),
six rivals are ahead with progress 40, and the eight-round scorer improves
self 51->50 and field 340->338. The complete race keeps finisher order
`p3,p4,p5,p6,p7,p8,p1` with zero crashes. Players 8 and 1 each take one
fewer finisher move, no driver is slower, and nonfinisher p2 also logs one
fewer move.

SEPARATOR: the historical broad exception also fired Spa s27 at candidate
speed2 146 / gain 49, causing order redistribution and a one-move slowdown,
and Spa s57 at speed2 40 / gain 14, causing a finisher swap and order
regression. Candidate speed2 >= 49 together with gain 9..15 is the clean
separator; s83 is 49/+12. Prior candidate-velocity peers, seal and funnel do
not separate these specimens: all three have zero qualifying prior peers, are
unsealable and are outside funnel risk.

POLICY: exactly six rivals ahead; incumbent non-`NONE` below speed2 49;
candidate at or above 49 with gain 9..15 and one lower TTF. All established
homogeneous-roster, zero-trap/uncertainty, finish, funnel, seal and strict
self/field scorer conditions remain. Pre-mirror experiments gate AI1; a
promotion mirrors the exact rule through the shared scorer body. The kind gate
was removed after the differential passed, so both smart-driver kinds now use
the same bounded arm.

EVIDENCE SO FAR: frozen pre-mirror JAR `7C446F1D...` covered 1,420 unique
races across 20 tracks: 1,419 complete normalized logs exact plus sole strict
Spa s83. All races had seven finishers/zero crashes; there was no slower,
redistribution, identity or safety case. Mirrored JAR `255C5234...` passes
Java/core/UI, 13 goldens, tooling and all 17 permanent AI pins. FINAL STATUS:
PROMOTED. Frozen baseline `3C4C4CCE...` versus mirrored final `255C5234...`,
all-AI2, covered the full 22 default x s1-150 plus four slow x s1-50 corpus:
3,499/3,500 complete behavior logs exact, sole divergence Spa s83 strict as
above. Post-mirror AI1/AI2 identity was 350/350 exact. Twenty-six mixed 4v4
baseline/final pairs covering the Round-174/Harvest-27 high-seed controls in
both grid orders were exact; 18 more covered all nine Harvest-28 specimens in
both grid orders, also exactly.

RUNTIME SANITY: two balanced warmup pairs plus 16 alternating timed pairs at
Spa s83 and exact-control s31. Process-CPU trimmed paired final/baseline ratios
were 1.0249 target and 1.0086 control; all control aggregate/order strata were
below 1.016. Wall was contention-sensitive with Harvest29 active. Claim only
no repeatable 5% control regression, not a compute-speed win.

## Harvest 28 census (local agent): the frontier holds steady

Mixed s401-500, 22 tracks, on the pre-Round175 Round174 champion: 9/2200
(0.4%, same as h27), ALL of it the established model-boundary structural
family -- serpentine2 hairpin x4 (s408/s424/s431 byte-similar at the
(120,117) s35-site, s418 at the s40-site), lemans bottom-corner x2
(s420/s495), zandvoort deep-corridor (s456 at the s223 region), plus two new
tracks joining the same morphology: interlagos s412 ((13,26) braking doom,
left edge) and silverstone s454 (second sighting). No new confirm-fixable
classes; every arm shipped through Round174 again shows zero recurrences. The
steady-state residual is uniformly the oracle-only joint-rollout family.


## Random circuits (local agent): the geometry fuzzing axis

build_synthetic.py gains `random` (user-prompted): sample points, convex hull,
random inward midpoint displacement (real corners, chicanes, straights of
varying length), Chaikin-smooth until every discrete turn radius clears minr
(measured on a step-spaced RESAMPLE each pass -- raw Chaikin points sit
sub-unit apart where discrete circumradius reads huge on near-collinear
triples and silently accepts arbitrarily sharp elbows; that measurement bug
was the whole initial acceptance failure), uniform resample, reject on
centerline self-intersection or necks closer than 1.8*minr with an arc-aware
index guard (a hairpin's own far side sits at diametric distance 2*minr and
must not self-reject). Deterministic per track-seed; grid-seed remains the
traffic axis. Usage:
  build_synthetic.py random tracks/randN.track RandN 150 150 12 seed=N minr=8

rand1-rand6 were committed and first evaluated on the pre-Round175 Round174
champion (corridors 6.7-9.8 cells, one naturally short loop). All six race
clean full grids -- and rand3 produced a crash specimen within its first three
seeds (s1 m484, p8 W at (144,117) -> (148,114)): novel geometry surfaces novel
dooms immediately, which is the point. Seeds randomize traffic on fixed sites;
random tracks randomize the SITES. This is a separate fuzzing axis, not
Round175 promotion evidence.

## Harvest 27 census (local agent): fresh seeds resample the model-boundary frontier

Mixed s301-400, all 22 tracks, on the round-174 champion: 9 crashes /
2200 (0.4%). NOT a regression -- a pre-169 bisect build reproduces the
serpentine2 class byte-for-byte; fresh seeds are sampling the residual
families the shipped arms do not cover:

- serpentine2 right-end hairpin, FIVE new specimens: s326/s344/s354/
  s394 (byte-similar, victim p6, fatal S at (131,111)->(136,111)) plus
  s367 (p5 at (146,108)->(148,104), the s40 site). s326 walked: the
  commitment is the EXACT r133 class shape -- m102 (75,113) v(10,0)
  taken E to v(11,0), dies @r7, every vx<=10 candidate survives, p8 at
  Chebyshev 3 (the train gate passes). The r133 leg ARMED and its
  confirm correctly reported what the world says: scorer-8/10/12-cap6
  AND true-6-cap6 all read the taken ALIVE on this board (V=155-160)
  while the oracle kills @r7 -- the suppressed worlds' traffic diverges
  here, unlike the harvest-25 boards. MODEL BOUNDARY for the verdict --
  but the AUDIT is loud: scorer-8 thread=5/7 snug=6/7 (one notch below
  the r98 all-threaded robust trigger). Possible future arm, needs its
  own rate study: vmax accel + train + scorer-8-alive-but-thread>=5 =>
  robust slower-switch. Otherwise this family belongs to the
  oracle-certified brake line.
- lemans s314: an s216-SIBLING at the same top-corner site, WALKED:
  last-avoidable m89 (12,21) v(3,-4), taken E dies @r4, braking
  survives (t=50). OPPOSITE world polarity to s216-m81: scorer-5/8 at
  the certification cap ALIVE, true-4-cap6 DEAD (s216-m81 was
  cert-scorer-dead / true-alive). Signature thread=2 snug=2 tier=2 at
  scorer-5 -- the legSlow shape, again below the >=3 pack gate. The
  unified Harvest-27 safety question: two-car squeezes need an arm below the
  pack gates whose confirm covers BOTH polarities (an either-world
  kill needs its own false-kill rate study; the conjunction provably
  under-kills one sibling each way).
- lemans s394/s397: bottom-corner family sightings (open pile).
- silverstone s367: NEW site, p6 fatal NE at (94,100)->(94,108) (fast
  vertical straight-end); unwalked.

Standing crash/safety surface after rounds 128-174: every fixed class HOLDS on
fresh seeds (funnel 0, vmax-accel commitments 0 where the deep world
sees them, squeeze 0); the open crash/safety frontier is now clearly ONE thing --
joint-rollout model-boundary dooms at structural sites (serpentine2
hairpin, lemans corners, silverstone straight-end), where every
in-engine world diverges from the oracle before the seal. The
oracle-certified structural approach is the answer; walks and world
matrices for all specimens are in this scratchpad's harvest27 logs.


## Harvest 29 (geometry axis) census + the rand5 lesson

First geometry harvest (rand1-6 mixed s1-50): rand2 = 2 crashes,
rand3 = 4/50 (8%, funnel-class density on a two-day-old track!),
rand1/4/6 clean. rand5 exposed TWO infrastructure facts: its original
seed-3 geometry was a degenerate DART (S/F cut let cars finish in ~14
turns without lapping -- the build_synthetic warning made real), and
mixed grid-seed 4 on it produced a NEVER-FINISHING race: auto mode has
NO turn cap, so a pathological track+grid combination hangs solo runs
and OOM-kills batches (the harvest lost rand5 s4-50 that way). rand5
regenerated from track-seed 7 and validated full-length (canon 3 +
mixed 10, no hangs); the old reproducer lives in git history at
7a99bcf for whoever adds an auto-mode turn cap (a harness-robustness
fix worth doing). LESSON for the axis: every generated track needs a
behavioral validation pass (races full-length under a timeout) before
joining a harvest -- geometry checks alone cannot prove S/F sanity.
rand2/rand3 specimens under forensics next.


## Round 174 (local agent): the two-car squeeze escalation -- harvest-26 closed

Lemans s216 (the last open harvest-26 AI1 class) is a slow TWO-car
squeeze the framework structurally excluded three ways: (1) the fire is
trap-0 slow, and the r108 smoke gate needs >= 2 rivals within Chebyshev
3 (profiled on kills with >= 4) -- a two-car train never qualifies;
(2) in the bunched early field the fire routes through the dense-pack
ESC instead, whose cap-3 world reads the doomed line ALIVE (the
constraining bodies rank beyond the nearest-3 set: scorer-5 cap 3
alive, certification cap DEAD); (3) even the true-4 confirm reads the
m81 sibling alive, so any conjunction under-kills. Oracle: m89 (19,15)
v(3,-3) taken S dies @r3 with a one-unit-slower survivor; m81 taken W
dies @r4 (both averted by the fix, verified move-by-move in debug).

The fix, armed from EITHER route: a slow landing with a rival within
Chebyshev 2 whose smoke comes back alive-but-threaded (thread >= 1 &&
snug >= 2, audit already collected), OR the dense-pack route directly
(no smoke data there), pays ONE certification-cap scorer-5 check; a
kill escalates exactly like funnelRisk -- the cert-cap world sees the
death, so the standard verdict + r161-certified ladder switch runs
unchanged. A smokeNear widening (admit every Cheb-2 slow fire to the
smoke) was tried and REVERTED measured: ~+30% wall on train-heavy
mixed lemans, and unnecessary -- the specimen commitments route
through the dense path. No tier axis (drifts 2->3 between rounds 4
and 5 at m89 -- the r128 lesson holds).

Gate (re-run on the r169/171 master): s216 rescued; s252 +
serpentine2 s6/s35/s40 stay clean; fresh lemans mixed sweep s201-300 =
2 crashes, BOTH the open bottom-corner family (s264, plus NEW SIGHTING
s220 which drifted into that site on the current master BEFORE this
round -- byte-identical with and without it; the family fix absorbs
both); 16 pins PASS incl. golden and the new upstream private-slack
pin. Wall: dual-order lemans/monaco mixed inconclusive under the
restarted agents' ambient load (single-run swings +-30%; symmetric
averages +4-8%); structurally the arm pays one cert-cap scorer-5 per
dense-route Chebyshev-2 slow fire and zero elsewhere (probe: 0
signature fires on five canon tracks).


## Round 169 promoted: bounded exact-private score slack

Round 169 permits both mirrored smart-driver kinds to take one separately
ranked private-lane runner-up. It may concede at most 0.25 in the score
remainder after trap and uncertainty, but must recover exactly one reachability
turn from a non-coasting incumbent at TTF 46-90. The candidate acceleration
must remain directionally aligned, use exact L2 trap and zero uncertainty, stay
below speed-squared 49, preserve current speed-squared while exceeding the
incumbent landing speed, land unsealable, pass the fail-closed four-round,
two-exit exact-private certificate, and prove strict mover progress with
non-worsening aggregate field cost in the eight-round, six-rival scorer world.
A kind-homogeneous starting roster is required. The runner-up cannot displace
an existing private-lane winner, and all downstream guards retain final
authority.

At Hungaroring seed 12, global move 370 changes player 2 from `W` to `SW`.
Both policies retain the same seven finisher identities and order with zero
crashes. Player 6 finishes in 127 moves instead of 128; every other driver's
logged move count is unchanged, yielding one fewer logged player-turn without
claiming an earlier finishing round or a global average gain. Nine permanent
veto fixtures preserve the known false-positive boundaries: Le Mans s2, Spa
s1, Hungaroring s40, Interlagos s47, Monza s30, Monaco s35, Zandvoort s34,
Monza s145, and Serpentine s38.

The external promotion gate compared the frozen `04D9DFEC...` champion with
the frozen `F536762B...` mirrored final, all-AI2, across all 22 default tracks
at seeds 1-150 plus all four slow tracks at seeds 1-50. Of 3,500 complete
behavior logs, 3,499 are exact and the sole divergence is the strict
Hungaroring s12 gain above: no slower driver, redistribution, finisher-identity
change, or safety regression. After composing Round 171 and its small-grid
hardening, the frozen Round-169 `F536762B...` build and integrated `9AA796B...`
build matched on all 3,500 complete behavior logs. A separate post-mirror
differential matched AI1 and AI2 exactly on 350/350 default/slow races.
Java/core/UI tests, all 13 goldens, tooling, and all 16 permanent AI regression
pins pass.

The pre-mirror runtime check used eight warmups followed by 32 alternating-order
pairs across Hungaroring seeds 12 and 13 (64 timed executions). Seed 12's
trimmed candidate/control ratios were 0.9568 wall and 0.9513 CPU; exact-control
seed 13 measured 0.9831 wall and 0.9905 CPU. Behavior hashes remained stable,
and neither measured case showed a computation-time regression.

## Round 168 candidate: direct occupancy maps and thread-owned geometry caches

Two exact search hot paths repeatedly scanned the same player arrays. The
candidate builds a touched-cell byte map once for the two-round ahead test and
once for each mobility projection, then answers in-grid occupancy queries with
a direct lookup. Duplicate-cell ordering, outside-grid fallbacks, current-player
exemptions and every move-selection rule remain unchanged.

The geometry fallback cache is now lazy and thread-owned. This fixes the race
between background reachability construction and an interactive move on the
event thread, while avoiding roughly 4.8 MiB of eager point/edge cache storage
for the common dense-cache path. Worker and event-thread values are explicitly
released at their lifecycle boundaries.

The upstream Round-168 screen compared 186 alternating timing races and kept
every complete log byte-identical; its aggregate median was 6.45% faster. The
rebuilt local candidate then matched the pulled Round-160 baseline byte-for-byte
on 78 races across all 26 tracks: 546 finishers, zero crashes and 37,739 summed
finisher moves on each side. Five-pair alternating local timing measured Sprint
10.9%, Monaco 3.4%, Zandvoort 6.5%, Nurburgring 2.9% and Interlagos 4.0% faster.
The summed median fell from 38.91 s to 36.51 s, a 6.16% improvement, with no
slower median case. Java/core/UI tests, all 13 goldens, tooling and all 15
permanent AI regression pins pass. This is a computation-speed improvement;
racing moves and outcomes are intentionally identical.

## Structural cleanup: private-lane proof module

The bounded adversarial private-lane certificate now lives in
`RaceAiPrivateLane`. One session owns the rival rectangles, lazy exact fallback,
primitive cache/frontiers and shared fail-closed node budget for a complete
candidate loop. `RaceAi` retains the policy gates and candidate ordering, but
calls intention-revealing approximate and exact certificate methods instead of
carrying the proof engine internally. This removes 346 lines (7.94%) from the
main class without introducing mutable static scratch state.

The pre-split and modularized JARs produced byte-identical complete logs for all
26 tracks at seeds 1-3: 78/78 pairs, 546 finishers, zero crashes and 43,255 move
lines. Java/core/UI tests, all 13 goldens, tooling and all 15 permanent AI pins
pass. Five-pair alternating timing was also output-identical: the modularized
build was 1.18% faster in aggregate; its only slower median case was Interlagos
at 2.17%, below the five-percent refactor limit. This is responsibility
separation only; no move-selection rule or racing outcome changed.









## Round 161 (local agent): a confirmed switch must never fall back to an UNCERTIFIED target

Harvest 26 (fresh mixed s201-300, all 26 tracks, 3 crashes/2600 -- the
lowest rate ever) delivered spielberg s252, and its walk exposed a
FRAMEWORK BUG latent since the round-99/105 ladder: in the trueDead
switch path, when EVERY candidate fails the true-rival certification
(`confirmed == null`), the old code silently returned the cheap-world
`best` anyway. At s252 m159 (49,81) v(-8,-11): the champion correctly
chose E -- the ORACLE-TRUE SURVIVOR -- the cheap world false-killed E,
certification rightly rejected the doomed NE as true-DIES, and the
fallthrough switched into NE regardless: trading no crash for a crash.
The fix is one line (`best = confirmed;` unconditionally): no certified
escape means KEEP THE CHOSEN, exactly what the round-102 comment always
claimed the code did.

Also folded in: the round-93 fastFragile healthy-tier path no longer
swallows acceleration-into-band fires before they reach the round-133
vmax leg (fastVAccel falls through to the fallback) -- a correctness
completion of r133 discovered in the same forensic chain.

Gate (on the round-160 master): spielberg s252 rescued (0 crashes, was
1); serpentine2 s6/s35/s40 stay clean; 16 pins PASS including golden
(the no-certified-target path fires in no golden race) and both class
pins. The fix touches no hot path (a rare-branch outcome only).

Remaining harvest-26 residuals: lemans s216 -- NEW slow two-car-squeeze
class, fully walked (last-avoidable m89 (19,15) v(3,-3), taken S dies
@r3, SW survives; fire signature tier=2 thread=1 snug=2 sits BELOW
every leg threshold, two-car train below the deep-pack gate; scorer-5
AND true-4 at cap 6 both kill it, so the standard conjunction works
once armed: candidate arm = slow fire + thread>=1 + snug>=2 + tier<=2
+ rival within Cheb 3, rate probe pending). lemans s264 = another
bottom-corner-family sighting for the round-127 pile.


## Round 160: direct blocked-cell bitsets for mobility search — 6.5% faster on the measured batch wall

The four-ply mobility search repeatedly tested candidate landings
against the same small predicted blocked-cell sets. Round 160 keeps the
exact 64-bit cell lists for the outside-grid fallback, while adding one
collision-free in-grid bitset per ply. Ordinary membership tests become
a direct word-and-bit probe instead of a linear scan.

Outer and nested mobility searches retain separate reusable primitive
workspaces. Resetting clears only words touched by the preceding
projection. Every bit is derived from the original exact cell list;
lookup semantics, memo epochs, rollout policy and selected moves are
unchanged.

Exact gate: 3500 all-AI2 baseline/candidate race pairs
across all 26 tracks, with every complete race log byte-identical. The
full Java suite, headless smoke, golden corpus, homogeneous AI probe,
tooling tests and every permanent AI regression pin passed on the JDK
25 candidate and again from a clean production checkout.

Seven-pair dual-order warm batches measured Monaco
8.4% faster, Nürburgring
4.9% faster, Zandvoort
5.4% faster, Interlagos
2.1% faster, and Sprint
7.1% faster. The weighted median aggregate is
6.5% faster; no measured case crossed the five-percent
regression limit.

## Round 158: share immutable legality rasters across auto batches — 6.3% faster on the measured batch wall

The conservative unit-cell and RES=4 legality rasters are immutable,
exact products of track geometry, yet every seed in an auto batch
rebuilt both arrays. Round 158 adopts one exact raster pair for every
subsequent `RaceGame` carrying the same geometry cache key.

The access-ordered pool is capped at 64 MiB of byte arrays. Interactive
games retain private rasters. Concurrent first builders may duplicate
work, but publication retains one complete exact pair; the arrays are
never modified after publication. AI policy, exact fallback geometry,
reachability products and race ordering are untouched.

Exact gate: 3500 all-AI2 baseline/candidate race pairs
across all 26 tracks, with every complete race log byte-identical. The
full Java suite, headless smoke, golden corpus, homogeneous AI probe,
tooling tests and every permanent AI regression pin passed on the JDK
25 candidate and again from a clean production checkout.

Five-pair dual-order warm batches measured Monaco
9.5% faster, Nürburgring
2.0% faster, Zandvoort
10.9% faster, Interlagos
2.7% faster, and Sprint
0.3% slower. The weighted median aggregate is
6.3% faster; no measured case crossed the five-percent
regression limit.

## Round 157: share immutable progress maps across auto batches — 2.7% faster on the measured batch wall

The distance-to-finish BFS and its derived progress-ring widths are
immutable functions of track geometry, yet every seed in an auto batch
rebuilt them before racing. Round 157 adopts one exact pair for every
subsequent `RaceGame` carrying the same geometry cache key.

The access-ordered pool is capped at eight million integer entries
(roughly 32 MiB plus row overhead). Interactive games remain private.
Concurrent first builders may duplicate work, but publication retains
one exact pair; no array is modified after publication. AI policy,
reachability products, geometry verdicts and race ordering are
untouched.

Exact gate: 3500 all-AI2 baseline/candidate race pairs
across all 26 tracks, with every complete race log byte-identical. The
full Java suite, headless smoke, golden corpus, homogeneous AI probe,
tooling tests and every permanent AI regression pin passed on the JDK
25 candidate and again from a clean production checkout.

Seven-pair dual-order warm batches measured Monaco
2.8% faster, Nürburgring
0.2% faster, Zandvoort
5.2% faster, Interlagos
2.0% faster, and Sprint
0.5% faster. The weighted median aggregate is
2.7% faster; no measured case crossed the five-percent
regression limit.

## Round 156: share exact dense edge caches across auto batches — 20.1% faster on the measured batch wall

Round 150 replaced hashed geometry-edge lookups with a collision-free
direct byte table, but each seed in an auto batch still allocated and
repopulated the same immutable table. Round 156 shares that exact table
between consecutive `RaceGame` instances carrying the same geometry
cache key.

The shared store is an access-ordered LRU capped at 128 MiB, while the
existing per-track 64 MiB admission cap remains unchanged. Interactive
games retain private tables. Every nonzero entry still comes from the
unchanged exact geometry predicate; duplicate concurrent byte writes are
idempotent, and a stale zero can only trigger an exact recomputation.
AI policy, finish logic, reachability products and race ordering are
untouched.

Exact gate: 3500 all-AI2 baseline/candidate race pairs
across all 26 tracks, with every complete race log byte-identical. The
full Java suite, headless smoke, golden corpus, homogeneous AI probe,
tooling tests and every permanent AI regression pin passed on the JDK
25 candidate and again from a clean production checkout.

Five-pair dual-order warm batches measured Monaco
23.7% faster, Nürburgring
12.6% faster, Zandvoort
30.6% faster, Interlagos
13.7% faster, and Sprint
2.8% faster. The weighted median aggregate is
20.1% faster; no measured case regressed by more than the
five-percent fail-closed limit.

## Round 150: direct in-grid edge legality cache — 5.4% faster on the measured wall

The post-Round-134 profile left the open-addressed geometry-edge cache
among the largest hot leaves. Every production AI edge is identified by
an integer origin and a bounded velocity delta in `[-12,12]^2`; Round
150 stores that finite in-grid domain in a direct byte table. A lookup
now needs one index calculation and one byte read instead of packing,
mixing and walking an open-addressed probe chain.

The table is capped at 64 MiB. Unusually large user tracks and every
out-of-domain query retain the existing exact hash cache. The direct key
is collision-free over its admitted domain, and the stored verdict is
still produced by the unchanged exact geometry predicate. AI policy,
reachability, finish logic and race ordering are untouched.

Exact gate: 3500 all-AI2 baseline/candidate race pairs
across all 26 tracks, with every complete race log byte-identical. The
full Java suite, headless smoke, golden corpus, homogeneous AI probe,
tooling tests and every permanent AI regression pin passed on the JDK
25 candidate and again from a clean production checkout.

Five-pair dual-order warm batches measured Monaco
3.3% faster, Nürburgring
0.6% slower, Zandvoort
8.8% faster, Interlagos
6.1% faster, and Sprint
7.6% faster. The weighted median aggregate is
5.4% faster; no measured case regressed.

## Round 134: exact point-containment cache — 12.8% faster on the measured wall

Round 130 removed boxed mobility-search overhead and left `Area.contains`
as the dominant sampled leaf. Round 134 closes that independent geometry
frontier. The residual exact line scan repeatedly asks whether the same
rational point lies inside the fixed track; the cache stores only the
unchanged exact AWT verdict.

The legality path first reuses the existing conservative RES=4 sub-raster
for points whose complete subcell was already proven interior. Unproven
points fall back to `Area.contains`, with the result stored in an
allocation-free open-addressed table keyed by both raw IEEE-754 coordinate
bit patterns. Collisions require full two-key equality, resizing preserves
every entry, and the table is cleared whenever track geometry is rebuilt.
No geometry approximation or AI-policy rule changed.

Exact gate: 3500 all-AI2 baseline/candidate race pairs across
all 26 tracks, with **every complete race log byte-identical**. The full
Java suite, headless smoke, golden corpus, homogeneous AI probe, tooling
tests and every permanent AI regression pin passed on the JDK 25 candidate
and again from the production checkout.

Four-pair dual-order warm batches against the Round 130 champion measured:
Zandvoort 14.9% faster,
Nürburgring 38.3% faster,
Monaco 12.0% faster,
Interlagos 4.7% faster and
Sprint 3.0% faster. Across the five weighted
medians the candidate is 12.8%
faster. Promotion required at least a five-percent aggregate win and no
measured case more than five percent slower.

## Round 129 promoted: measured frontier pace for both driver kinds

The harvest-23 alternating 4v4 census measured AI1 ahead of frozen AI2 on
21 of 22 tracks, with a 2.05-place-sum advantage per race. Round 129
promotes the already separately certified Round 115 moderate-energy,
Round 117 synchronized six-ahead and Round 124 phase-consistent trap
acceleration arms to AI2 as well. Round 126's homogeneous equal-speed
false-target veto is promoted with them, repairing Zandvoort seed 115 for
both kinds. A later promotion also mirrored the Round 128 mixed finish-funnel
confirm, so the current champion is identical for both smart driver kinds.

Exact gate: 3500 all-AI2 baseline/candidate pairs,
4 Pareto-faster race(s),
1 safety gain(s), zero individual slowdowns in the four pace races,
zero safety regressions, zero aggregate-only gains and zero finisher-set
redistributions. In the safety-gain race one existing finisher is one move
slower while a previously crashed racer finishes; no race is classified slower.
The permanent Round 115/117/124/126 pins now require the promoted result from
both AI1 and AI2.

## Round 133 (local agent): the vmax overspeed deep check -- the slow-track surface cleared

The harvest-25 class shipped. At the deepest dangerJointSearch, a chosen
move that ACCELERATES into max-axis >= AI1_FASTV_MAX (11 = VMAX-1) is
re-verdicted with the deep suppressed world (AI1_DEEP_HORIZON rounds at
the certification cap) ALONE -- the r107 single-world precedent, because
the true confirm worlds read the doomed line alive (joint-rollout chaos)
while scorer-8-cap6 kills it (thread=3 snug=4 lights up only there). A
kill takes the standard r105 slower-first ladder switch; the surviving
vx<=10 siblings certify in both worlds.

Probe forensics that shaped it: probe v1 at the round-59 fallback MISSED
all three commitments -- their computes route through the round-65
deep-pack escalation, so the leg lives at the deepest overload where
every entry path converges. Cruise-at-11 fires are excluded by the
acceleration condition (max-axis must increase this move). Probe v2:
all three commitments fire there with deep8=DEAD; ZERO false kills in
188 healthy fires (serpentine2 ~55/race, monza ~23, lemans/spa ~11,
bigoval 0); pricing A/B with the deep check paid at EVERY armed fire:
serpentine2 -0.2%, monza +-0.0% dual-order -- free.

One measured false kill, accepted and bounded: the first gate run
diverged golden lemans-s1-4p -- scorer-8's pessimism killed a
SURVIVING two-car-train line (p2 (63,65) S to v(3,11)); the race
converged to the IDENTICAL outcome (turns, places, zero crashes; only
the trajectory hash moved). A Chebyshev-6 train gate (physical: the
doom needs a rival to seal the escape rows; the commitments carry
theirs at 1, 2, 5) was added but this fire also has near6=1 -- no
cheap axis separates it (corridor width would, and is not cheaply
available; chasing further gates is proxy overfit). Accepted per the
promotion precedent: the fixture line for that one case regenerated;
every other golden is byte-identical on the r133 champion.

Gate: specimens s6/s35/s40 crash-free in ALL THREE kind orderings
(9/9); serpentine2 mixed sweep s1-100 ZERO crashes (was 4);
bigoval/monza/lemans/spa canon spot checks clean; 15 pins PASS. NEW
pin ai1_vmax_deep_regression (mixed serpentine2 s6+s35, both victim
slots). Applied post-promotion, so the leg serves both kinds from
birth (the class was kind-invariant).

Residual mixed surface after r128-promotion + r133: NOTHING known --
every walked class is either fixed (funnel both kinds, vmax both
kinds) or owned by the round-127 oracle framework (zandvoort
deep-corridor: s195/s223/s115-mixed m167; lemans bottom-corner: s108
p7+p2, s117 p5 -- model-boundary, STUCK-diagnosed).


## Round 128 PROMOTED (user-ordered): the fast finish-funnel confirm for both kinds

The user ordered the mirror ("Promote 128"). One line: the fallback's
fastSlow arm drops its moverKind gate. The harvest-24/25 block-ordering
natural experiment had already proven the exact effect: byte-identical
races crash iff the doomed slot lacks the leg.

Gate: all five known frozen-side victims RESCUED (reverse-ordering
lemans s36/43/45/46 and alternating s132 -- 0 crashes each); the three
serpentine2 specimens byte-identical (the leg never fires there --
they are round 133's); 15 pins PASS including golden all-AI2 (no
golden race hits the gate); dual-order wall on mixed lemans s36-40:
+5.0% run second, +0.3% run first (~+1-3% true, on the ONE arming
track, partly because rescued cars now race to the finish -- more
moves computed is more racing, not overhead). Canon behavior
elsewhere unchanged. NO kind-gated arms remain in the champion;
homogeneous AI1 and AI2 fields are again move-identical by
construction.


## Harvest 25 (local agent): the serpentine2 vmax-11 commitment -- round-133 candidate, probe pending

Slow-track mixed harvest (serpentine/serpentine2/spiral/cog; alternating
s1-100 + front/reverse s1-50 = 800 races): ALL 10 crashes are
serpentine2, three sites, and every site reproduces BYTE-IDENTICALLY
across all three kind orderings (only the victim's kind label moves
with the slot map) -- kind-invariant champion dooms; no other slow
track crashes at all.

Walks (reach_serpentine2.bin now in the session scratchpad; races are
in harvest25/): all three victims commit at THE SAME CELL. Bottom
straight, (75,112-114), vx=10: accelerating to vx=11 (E or SE) is a
5-9-round oracle doom; every vx<=10 candidate survives to the finish
(t=153-154). s35 m94 taken SE dies @r5; s6 m95 taken SE @r7; s40 m95
taken E @r9. Physics: vx=11 braking distance overruns what the
right-end hairpin absorbs ONCE TRAFFIC occupies the escape rows -- the
static reach map says alive (a solo escape line exists), the joint
world is dead.

THE KILL SIGNAL EXISTS IN-ENGINE: at s35 m94 taken SE, scorer-8 at the
certification cap is DEAD (V=-1, thread=3 snug=4 -- the thread audit
lights up in the deep world) while smom-3/scorer-3 AND true-4/5/6-cap6
all read alive (joint-rollout chaos blinds the true worlds again; the
suppressed deep world beats them here). The smom-3 fire carries NO
tell (tier=3 thread=0 snug=0): the only cheap arm is the velocity
itself (max-axis >= 11 = VMAX-1; spd2 ~121-122).

Round-133 design (pending ONE measurement): at fast fallback fires
with max|v| >= 11, re-verdict with scorer-8-cap6 (the shipped
AI1_DEEP_HORIZON world); on death take the standard ladder switch
(survivors vx<=10 pass every world). The confirm must ride scorer-8
ALONE -- true-4 reads the doomed line alive and a conjunction would
veto the kill (r107-style single-world precedent). OPEN RISK, measure
before arming: bigoval (and long straights on lemans/monza/spa) runs
max|v| >= 11 legitimately for many turns -- need fires/race and the
deep world's false-kill rate there. Probe ready:
apply_probe133.py in the session scratchpad (FASTV11 stderr lines,
print-only); run serpentine2 s6/s35/s40 mixed + bigoval/lemans/monza/
spa canon, then decide.

Numbering note: rounds 131/132 above are LOCAL rejected experiments;
the other agent's concurrent Round 131 (point-containment cache) is a
separate line.


## Round 132 (local agent, REJECTED measured): fmRec filter reorder + cache lesson

Post-r130 re-profile (per the new law) put blockedContains at 216
self-time leaves (#3). Candidate fix: run reach.isAlive before the
blocked-cell scan in fmRec (pure AND filters, outcome-identical --
byte-identity verified, 0 mismatches). DUAL-ORDER wall A/B (the r131
law, first use): order A side +6.9% slower, order B side -2.0% faster
-- symmetric average ~+2% SLOWER. Rejected and reverted.

Lesson: "one array read" is not cheap when the array is the
reachability alive map (DRAM-latency misses); the <=21-entry blocked
scan is cache-hot and CHEAPER. The original filter order was already
optimal; leaf-sample counts do not order costs across cache classes.

Coordination note: the other agent's concurrent Round 131 branch
(point-containment cache, alternating warm gate -- they independently
derived the order-bias discipline) owns the geometry frontier
(Area.contains ~534 leaves); the local exact-geometry-engine idea is
withdrawn in its favor. Local speed lane is parked at the measurement
noise floor until that lands.


## Round 131 (local agent, REJECTED measured) + the second-arm throttle law

Two identity-exact geometry short-circuits were built and byte-identity
verified (0 mismatched logs in 11 races, twice): subcell-certified
sample skipping in isMoveLegalGeometry (a nonzero sub-raster cell
proves containment, skip both Area tests) and a finish-line bbox
early-out in crossesFinish. Both REJECTED: no measurable win.

THE MEASUREMENT LAW THIS BOUGHT: at Idle priority with turbo active,
the SECOND arm of a per-seed interleaved A/B loses ~4-5% SYSTEMATICALLY
(thermal/boost budget). Full r131 measured +13% slower run second;
subcell-only +5.9% slower run second, then 3.3% FASTER run first --
i.e. pure order bias, true delta ~0. Any pairwise wall A/B must now be
run in BOTH orders (or alternate per seed); deltas inside +-5% in a
single order are unfalsifiable. Round 130's -20.6% was measured with
the win AGAINST the bias direction and stands (understated, if
anything).

Why no win despite 600+ Area.contains leaves attributing to
isMoveLegalGeometry: that profile was taken on the PRE-r130 jar.
Corollary law: RE-PROFILE after every landed speed round before
picking the next target -- a landed round reshapes the flame graph.

Working tree reverted; side.jar rebuilt in sync with master.


## Round 130 (local agent, speed): primitive mobility transposition table -- -21% monaco wall

Fresh JFR on the r129 champion (10 monaco races, self-time leaves):
Area.contains (~537) is still the top leaf -- monaco's wall-hugging
lines defeat the raster band, and RES-8 stays refuted -- but ~265 leaf
samples sat in HashMap.getNode/putVal/resize under fmRec. The mobility
memo was a fresh boxed HashMap<Long, Double> EVERY TURN (resize churn
from capacity 16 upward each turn), and the per-ply blocked sets were
HashSet<Long> whose contains() autoboxes, twice per candidate per node.
The r113 lesson (adding a NEW memo where none existed lost 3.4%) does
not apply to replacing the implementation of an EXISTING one.

Replacement, semantics identical: one pooled open-addressing table per
RaceAi (32768 slots; long keys, double values, int epoch stamps;
multiply-shift hash; probe cap 32 with graceful skip-store). Each
MobilitySearch takes a fresh epoch, so a hit needs epoch AND key --
nested rival-model searches can never cross-hit, and every eviction or
collision merely recomputes a deterministic value. Blocked cells became
per-ply long[] arrays (<= 3 cells x 7 opponents, duplicates fine,
linear scan -- at 21 entries scanning beats hashing).
greedyStepBlockTop3 appends to the array and returns the new count.

Gate: BYTE-IDENTITY of race logs master-vs-side across monaco s1-5,
zandvoort s1-3, silverstone s1-2 canon and mixed lemans s36 -- 0
mismatched logs in 11 races, provably behavior-neutral (evictions only
recompute; values are deterministic per search). 15 pins PASS. Wall,
interleaved per-seed A/B: monaco 10-seed 76.4s -> 60.7s (-20.6%);
zandvoort 5-seed 25.6s -> 25.4s (-0.6%, flat; its mobility load is light). Never slower anywhere measured.

Next speed frontier per the same profile: Area.contains exact fallback
(~537 leaves) concentrated on wall-hugging monaco-class lines -- the
raster band cannot prove those; any further win needs a different
proof shape (e.g. per-cell nearest-boundary distance field), not more
resolution (RES-8 refuted).


## Harvest 24 + post-129 recheck (local agent): the bottom-corner class and the STUCK boundary

Harvest 24 (mixed alternating s101-200 + BLOCK orderings front/reverse
s1-50, all 22 tracks, 4400 races) and a full post-promotion recheck (16
pins PASS on the r129 jar, every specimen re-verified there):

- NATURAL EXPERIMENT: the four r128 funnel seeds under block orderings --
  reverse (AI2 in slots 1-4) reproduces all four deaths byte-identically
  with AI2 victims; front (AI1 there) has ZERO crashes. The r128 leg
  rescues the identical race iff the victim is AI1: the kind gate proven
  live. These AI2 deaths (plus ma_lemans s132 m562) die whenever r128 is
  mirrored/promoted. ma_lemans s117's funnel death (p8 AI2) DISSOLVED
  under the r129 pace arms -- one frozen-side kill gone for free.
- NEW CLASS, bottom-corner train compression (the only fixable-side
  kills found): lemans bottom corner (82-85,163-170), southbound
  traffic turning W. s108 p7 AI1 m343 + p2 AI2 m346; s117 p5 AI1 m349.
  Both AI1 deaths persist byte-identically on the r129 jar.
- s108 p7 walked: last-avoidable m319 (84,154) v(1,4). INVERSION: the
  taken N (brake to v(1,3)) dies @r3; NONE (HOLD v(1,4)) survives t=21,
  NW/W also survive. Braking in front of the compressing rear queue
  (p8 (85,156) v(1,3) directly behind) is what kills -- opposite
  polarity to the funnel/corridor brakes.
- THE HARD PART -- world matrix at m319 taken N: smom-3, scorer-3,
  scorer-8-cap6, true-4/5/6-cap6 ALL alive (tier=3 thread=0 snug=1),
  oracle dead @r3 via a hard wedge (m343 mask XXXXXXXXX). SIMTRACE
  diagnosis: at sim r=1 the simulated p2 (84,155)v(2,5) goes STUCK and
  the rear pressure evaporates, so every capped/uncapped true world is
  effectively vacate-optimistic in dense queues. Extending horizons or
  caps CANNOT see this class; the divergence is joint-rollout chaos +
  STUCK-rival semantics. This is the third model-boundary family
  (after z195 and s223/zandvoort-s115-mixed m167, which persists on
  r129), now with a mechanism diagnosis.
- s117 p5 walked: doomed >= 8 own-moves out (m293 (79,128) v(2,8) best
  candidate dies @r7; m301/m309/m317/m325 all dead) -- a train-entry
  doom on the approach straight, p7/p8 committed alongside. Commitment
  depth varies by seed; the site+queue interaction is the invariant.
- Class disposition: both remaining AI1 kills are oracle-only-visible
  model-boundary dooms -- the round-127 oracle-certified structural
  framework is the right tool, NOT another confirm leg (any in-engine
  sim world diverges before the wedge). Walk boards live in
  r130_ma_lemans_s108/s117.log (session scratchpad). Design note for
  whoever picks it up: an in-engine bounded REAL-ROLL sim mode (exact
  global move order, no rival cap, no vacate optimism, STUCK=crash)
  would be the verification primitive this family needs; cost only
  works at a surgical structural gate.

Mixed crash surface after r128+r129, per 4400 harvest-24 races: 2 AI1
deaths (both bottom-corner) + 3 frozen-side AI2 deaths (funnel class,
die at next r128 mirror) + 1 AI2 zandvoort right-edge (m574, unwalked).


## Mixed h2h census (harvest-23, analysis): frontier -2.05/race over champion

Alternating 4v4 across all 22 tracks x seeds 1-100 (pre-r128 jar, but
crashes were 5/2200 so this is pace signal): AI1 place-sum 16.975 vs
AI2 19.025 (even split 18.0) -- the frontier wins 21 of 22 tracks.
Standouts: interlagos -3.66, coil -3.60, zandvoort -3.34, zigzag -3.04,
the_long_loop -2.90. The ONLY non-win is monaco (+0.10, coin flip) --
monaco is also the funnel-crowd outlier in the r128 rate data; a
monaco-specific pace look is a candidate frontier. This is the first
quantified frontier-vs-champion gap since the round-109 promotion and
the running measure of what a next promotion would buy.


## Round 128 (local agent): the fast finish-funnel confirm leg -- the mixed dimension's crash surface

Harvest-23 opened the MIXED 4v4 dimension (alternating kinds, odd=AI1,
seeds 1-100 x 22 tracks) plus fresh canon s201-250. Census: mixed produced
5 crashes total -- FOUR one deterministic lemans class (AI1 victim dead at
(6-7,74) in the terminal funnel; s36/s43/s46 byte-identical, s45 a sibling)
plus the accepted hairpin s68 (AI2 slot, same delegated code); fresh canon
produced ONE (zandvoort s223 p7 m167, new residual, unwalked). The lemans
class IS the entire unaccepted mixed crash surface.

Forensics (probe + oracle, all re-verified on the post-126 master): the
victims commit FAST fires that the smom-3 world reads alive while true-4
at the certification cap kills them; the commitments carry the legSlow
thread tell (thread=2 snug=2), which no fast leg audits. s36-class
commitment: (14,105) NW, tier=1, sim-ttf 7. s45 sibling: (11,97) N,
tier=3, sim-ttf 6 (oracle: the taken N dies @r3, braking survives; at
m536 all nine candidates are dead -- m529 is the last avoidable). The
bare signature on fast fires runs 21/race on monaco -- too hot to arm.
The separator is the SIM'S OWN HORIZON: every non-class signature fire
measured ttf 14+ (monaco/zandvoort mid-race, hungaroring start crowds at
96-98); the class sits at 6-7, inside the finish approach.

The leg (AI1-only, kind-gated): 16th param fastSlow on the deepest
dangerJointSearch (the 15-arg form becomes a delegating wrapper, every
other caller untouched), armed !djSlow && moverKind==AI1 from the
round-59 fallback. It extends the audit to fast fires (free: the chosen
verdict sim already runs; tier/thread/snug ride along) and arms on
thread>=2 && snug>=2 && chosenT <= AI1_FASTSLOW_TTF(10), firing the
DIRECT true-rival confirm at AI1_TRUE_CONFIRM_ROUNDS and the
certification cap: the scorer screen is BLIND on this class (scorer-3
reads both doomed lines alive), so there is no cheap pre-screen. A kill
takes the established r105 slower-first ladder-certified switch path.
NO tier axis: the t4 probe audit measured ZERO false kills across every
signature fire on monaco/mxmonaco/hungaroring (~200 fires, all healthy
crowds true-4-alive, both class siblings DEAD) -- the tier<=1
refinement only cost the s45 coverage.

Gate: all 14 pins PASS (13 ai1 + golden all-AI2 byte-identity);
specimens 4/4 crash-free; mixed lemans s1-100 sweep 0 crashes (was 4;
all 100 logs full-length). Every rescue is place-neutral: the saved car
survives to the end and is auto-placed eighth exactly where it used to
crash to eighth (survival-only, parity places -- the DJS shape). Wall:
zandvoort A/B 10s=10s; monaco interleaved 10-seed A/B 46.6s vs 47.0s
(+0.7%, inside per-seed noise). NEW pin
ai1_fast_funnel_regression (mixed lemans s36+s45 crash-free, one seed
per sibling). AI2 remains frozen (kind-gated out; all-AI2 races
identical by construction).

Residuals: zandvoort s223 -- WALKED, and it is a second specimen of
the round-127 deep-corridor family (gift for that branch): canon 8xAI1,
p7 crashes m167 at (61,1) after the top-right corner sequence. Last
avoidable m95 at (35,52) v(3,-9) spd2=90: the taken NONE dies at oracle
round NINE (invisible to every shipped sim horizon); shedding one vy
unit survives to the finish (SW v(2,-8)/S v(3,-8)/SE v(4,-8) all alive,
t=116-117, sheds of 22/17/10 spd2 -- note a 10-unit shed suffices here
vs z195's twelve). Structural context differs from the z195 gate (open
corner entry, not a width-three funnel), so the round-127 brake likely
needs its class widened or a sibling gate; the m95 board is in
r129_z223.log (this scratchpad) via oracle_roll cand 95. hairpin s68
(accepted place-neutral). CORRECTION for the z195 line: the earlier
"ultra-deep, no survivor to m70" classification of zandvoort s195 was
measured on a crashed walker (stale reach dump path) and is VOID; the
round-127 branch's fresh oracle forensics supersede it.


## Round 126: equal-speed false-target veto

Ported and re-certified the unfinished Zandvoort s115 mechanism on the
Round-124 master.  At an equal-map-turn, equal-speed, positive-trap
topology switch in a large homogeneous AI1 field, the bounded
certification-cap faithful-rival world is run on both landings.  A
switch is vetoed only when it would leave a true-alive chosen line for
a true-dead target.  AI2 is kind-gated out.

Exact gate: 3500 pairs,
1 safety gain(s), zero safety regressions,
individual slowdowns or redistributions.  Zandvoort s115 is rescued.
Residual frontier: accepted hairpin s68 and ultra-deep zandvoort s195.

## Round 114 (local agent): the pair-squeeze confirm leg -- three of four fresh specimens in one mechanism

HARVEST 22 (fresh 8car mega-window s151-200, 1100 races): 4 crashes --
silverstone s167/s191, hungaroring s195, zandvoort s195.

THE CLASS (silverstone s167 m157, fully probed): a fast L2 landing
with ONE rival racing a cell away (Chebyshev 1). Every pack gate needs
~three bodies; the fast fallback historically runs the smom world
(r59: "fast fires keep the proven smom world") which reads the squeeze
alive with NO tell (thread=0, snug=1 -- and the true SURVIVOR shows
thread=2: inverted again). The plain 3-round scorer world at the
DEFAULT cap separates perfectly (kills the taken W, keeps survivor N).

TWO SHAPES REJECTED MEASURED: the raw world flip (scorerRivals at
pair fires) fixed s167 but broke the hungaroring-s10 staged pin
(7/0 -> 6/1) -- the r59 wisdom holds; smom must stay the verdict.
SHIPPED: a PAIR-CONFIRM LEG in the existing confirm framework -- gate
= fast + L2 trap + rival within Chebyshev 2 of the landing (measured
0-5 fires/race); a smom-alive chosen dies only when the 3-round
scorer world AND the true-rival confirm agree; switch targets
ladder-verified as everywhere.

RESULT: s167 FIXED, and silverstone s191 + hungaroring s195 come FREE
(the same leg). All thirteen prior sites hold; twelve pins PASS;
probe 0/27. zandvoort s195 recorded OPEN: the top-complex corridor at
ULTRA depth -- no oracle survivor within twelve walk-decisions at
14-round horizons; beyond the walk's own resolution (the
champion-play-everyone rollout frays at that depth). Residual set:
hairpin s68 (accepted), zandvoort s115 (their round-108 target),
zandvoort s195 (new, ultra-deep).

RES=8 RE-MEASURED HONESTLY (post-fix, quiet box, interleaved 2x4
heavy races): consistently ~5%% SLOWER than RES=4 (14.3s vs 13.5s both
passes) -- the pre-fix "-5.8%%" was stale-jar garbage. SUB_RES stays 4;
the working-tree 8 was reverted without ever being committed (though
it rode along, behavior-free, in every r114 verification build).

PROCESS: the silent-stale-jar failure mode found and neutralized --
builds no-op when the harvest holds the jar lock (rm fails, set -eu
aborts, and "cannot remove" matched no error grep); several probe
runs and the whole RES=8 experiment ran on a 30-minute-old jar and
are VOID (RES=8 to be re-measured honestly). Recovery: side-jar
builds (compile to scratch, jar under a different name) bypass the
lock; jar freshness is now verified behaviorally after every build.

## Round 113 (local agent, REJECTED measured): mobility memoization

The next JFR target after the rasters was the mobility projection pair
(searchMinTurnsSoft3 / CountedSoft3, ~19%% of samples, 9-ary depth-4
recursion, no memo where fmRec has one). An epoch-keyed
HashMap<Long,*> memo (per-compute contexts invalidated by an epoch
bump, no clearing hazards, nested-compute safe) was built and proven
12/12 move-identical -- and measured 3.4%% SLOWER on a clean 3x3
heavy-track A/B (r112 29.8s vs r113 30.8s): boxed-map probe/store
churn exceeds the path-convergence savings at these depths. Reverted.
If this is ever revisited, it needs a primitive-key open-addressed
table, and the ceiling is small.

Bench-harness traps recorded for the next profiler: jars resolve
tracks against their own directory (a jar run from the scratchpad
finds no tracks and exits in ~150ms -- timing noise that looks like a
10x speedup), and --log /dev/null on Windows aborts the run the same
way. Both produced garbage timings this round before being caught;
always sanity-check race wall times (~1-6s) and log line counts.

## Round 112 (local agent): boundary-refined hybrid raster -- another -8%%

Continuing the legality attack (post-r111 JFR: legality still 38%% of
samples; the fallbacks hug walls, where racing lines live).

REJECTED, measured: a flat RES=4 sub-raster (+25%% wall -- 4x walk
density taxed EVERY edge and the 16x build taxed every JVM start).
FIRST HYBRID also +29%%: the sub-build refined every non-clean cell,
i.e. the entire outside-the-track area.

SHIPPED: the hybrid with a perimeter-bounded build. RES=1 walk stays
primary (open-track edges at round-111 cost); a RES=4 sub-walk is
tried only when RES=1 fails, before the exact predicate; the
sub-raster refines ONLY non-clean cells with a clean-interior
neighbour (the true boundary band) -- deep-outside and deep-wall
subcells stay unproven and fall through, which is correct (those
edges are mostly illegal anyway). Same one-sided band proof at each
resolution; the hybrid is an OR of two proofs.

VERIFICATION: 12/12 move-identical A/B against the post-r117 master,
probe 0/27, ALL THIRTEEN pins (their new graduated-field-accel and
six-ahead pins included). Canon on the r112 jar: AI1 62.699 vs AI2
62.701 -- the -0.003 column split is THEIR kind-gated rounds 115/117
pace gain (post-delegation frontier law: new arms gate on the mover
kind so the AI2 yardstick stays frozen), not a raster effect; the
raster is one-sided-provable and the A/B ran on exactly this
baseline. A/B wall 34.6 -> 31.8s (-8.2%%), stacking with r111 for
~-18%% total on the set, on top of r108's smoke gate.

JFR NEXT TARGETS: searchMinTurnsSoft3 / CountedSoft3 (the mobility
projection, now ~19%% and rising as legality shrinks); the residual
near-wall exact fallbacks.

## Round 111 (local agent): the legality raster -- function-level profiling pays

CORRECTION FIRST: round 108's ledger blamed their r106 forward-pack arm
for +55%% canon wall. The profiling twin now shows that arm fires 0
times on 21 of 22 canon tracks (coil: 2 bounded fires, ~0.4s) -- the
attribution was environment noise between measurements. Withdrawn.

REJECTED FIRST ATTEMPT (measured): static successor tables for the
tier computation (safeSuccessorsOverState). Behavior-identical 12/12
but ZERO wall gain -- site-level attribution had misled; the tier is
not the inner cost. Reverted per discipline.

THE REAL HOTSPOT (JFR, function-level): ~60%% of all execution samples
sit in first-time edge legality -- isMoveLegalGeometry samples the
segment at ~2x its length, each sample a java.awt.geom.Area.contains
CURVE test, and the sims explore hundreds of thousands of fresh edges
per race (the edge cache never evicts; these are genuine first visits).

THE FIX: a one-time conservative legality raster per track. Each unit
cell is classified provably-fully-inside the expanded track region
(EXACT Area.contains(rect) with a boundary-covering margin) and cells
near the left/right boundary polylines are marked (sampled cover with
one-cell dilation). Fast path: walk samples along the segment at
axis-step <= 0.5; every segment point lies within 0.5/axis of a
sample, so its cell is inside the 2x2 block at floor(sample - 0.5) --
if every such block is interior and path-free, all exact-check sample
points are inside and no polyline intersection is possible -> LEGAL
with integer math only. One-sided (fast path never answers illegal);
everything else runs the unchanged exact predicate. First cut used a
3x3 dilation tube (-6.7%%); the provable 2x2 band doubled the fast
tube's reach near walls (-10.6%%).

VERIFICATION: 12/12 move-identical A/B across every historic class
site and field size; probe 0/27; ALL ELEVEN pins; canon identity in
flight at write time. Total wall on the A/B set 40.0s -> 35.8s.

PROCESS NOTES: two more -Werror dangling-doc-comment trips (the
recurring insert-above-a-doc-comment trap); and jobs now launch at
Windows Idle priority per the user's new standing rule (Start-Process
-PassThru; PriorityClass='Idle'; children inherit).

## Round 110 (local agent): post-promotion simplification batch

USER DIRECTIVE: clean out old files and tools. Removed, with the
promotion probe + goldens + all pins + tooling tests green after:

- tracks/round106_{forward_pack,instance_state}_materialize.py and
  .github/workflows/round106-forward-pack.yml -- the other agent's
  one-shot round-106 promotion machinery; its changes have been on
  master since b9d69fd and the workflow only ever triggered on edits
  to the deleted scripts themselves. The round lives in the ledger.
- AI2_MOBILITY_DEPTH -- the ONLY dead member left in RaceAi after the
  delegation promotion (a reference sweep found the 796-line mirror
  body shared every other helper with the frontier).
- Untracked root debris (era60/prof jars, stray logs) -- era jars are
  one-command rebuilds, recipe now documented.

ADDED (permanence for round-109 tooling): tracks/cross_era.py -- the
dual-oracle cross-era referee, promoted from scratchpad with the era-
jar build recipe and the first exhibition result in its docstring.
OLD_JAR/RACING_WORK_DIR env overrides for reuse.

KEPT deliberately: bench_iso.py (tooling tests import it), tests/tr
Java unit suites, ci.yml + promotion-gate.yml, verify_reach_cache.sh,
policy_matrix POCKET entries (worked-example documentation; the file
already tells readers to regenerate logs before replaying).

## Round 109 (local agent): PROMOTION -- the rounds-98-108 champion is AI2

USER'S EXPLICIT WORD: "Promote now!". Executed the full protocol:

MIRROR BY DELEGATION: optimalMoveAI2's 796-line round-95-era body is
replaced by a delegation to optimalMoveAI1. The champion is one body
of code; every kind-sensitive gate in the shared machinery is
mover-symmetric (kindHomogeneous* compare against the mover's kind;
the confirm family is flag-gated, not kind-gated), so homogeneous
fields of either kind behave identically. Frontier law unchanged:
future experiments live in optimalMoveAI1 and must leave the
delegation untouched until the next promotion; during experiments the
delegation makes AI2 the OLD champion only after the next frontier
edit lands -- i.e. the yardstick freezes the moment AI1's body first
diverges again.

CERTIFICATION: strict probe 0/27 divergent (the mirror proof, exact
by construction and verified anyway); golden corpus REGENERATED and
green (two fixtures changed hashes as expected -- AI2 is a new
champion); ALL ELEVEN pins pass; self-tie h2h 4.500/4.500 c=0;
fixed-grid bench columns identical (62.604/62.604 +0.000); stale
BENCH_BASELINE caches deleted per the round-108 rule.

THE CROSS-ERA EXHIBITION (new tooling: cross_era.py -- any two
commits can now race each other): the r109 champion vs the r60
champion (rebuilt from 886fab9 as era60.jar), four cars each through
a dual-oracle referee (each era's brain answers only for its own cars
on a shared board; the new jar's mask is the rulebook), 24 races =
6 tracks x 2 seeds x both grid assignments, 96 car-races per side.
VERDICT: NEW 4.438 vs OLD 4.562 mean place, both crash-free.
Reading it honestly: competent vector racing is largely processional
(hairpin/interlagos ran perfectly grid-antisymmetric), so the +0.12
edge lives entirely on the tracks where overtaking exists (monaco,
zandvoort, chicane, lemans -- e.g. chicane s7: NEW 1,3,4,6 with OLD
pushed to 2,5,7,8). The 49 rounds between the two eras bought
head-to-head pace only modestly; what they really bought is the TAIL:
the r60 champion crashed ~1/40 on fresh seeds in its own era's
harvests, the r109 champion runs 1 accepted crash in 4070.

WHAT WAS PROMOTED (the arc in one line each):
r98 thread-fragility audit; r99 bounded true-rival confirm (depth
latch -> r103 depth counter); r100 corridor generalization; r102
alongside-pack gate + speed-scaled nets + dead-path target
confirmation; r103 certification-cap confirms + query-sim probe; r104
three-leg predicate with cost ladders; r105 slower-first ladder
targets; r107 ESC-route direct true-rival confirm; r108 smoke
proximity gate. Eleven crash specimens solved; residual = hairpin s68
(accepted) + zandvoort s115 (their round-108 CI target -- their
branches now need a rebase onto the promoted master, noted for them).

## Round 108 (local agent): the smoke proximity gate -- a measured, behavior-preserving speedup

USER DIRECTIVE: speed up the engine. Built a profiling twin of the
champion (per-call-site simOutcome attribution, within-turn duplicate
detection, smoke yield counters) -- the profile was unambiguous:

- The r60 SMOKE TEST is 70-79%% of ALL simulation time (e.g. zandvoort
  s33: escSmoke+escDJS 3.7s of 5.4s sim; interlagos s47: 3.9s of 5.0s)
  and its verdict is DIES 0.1%% of the time (7 in 5162 profiled runs).
- Within-turn duplicate scorer moves are only 6-8%% -- memoization is
  NOT the win. The smoke's fire RATE is.

THE GATE (AI1 only, second smoke occurrence = frozen AI2 untouched):
a slow-landing box within the 5-round smoke horizon needs bodies near
the landing. 5162 profiled smoke runs across 8/4/2-car fields, seven
real kills: every 8-car kill has >= 4 rivals within Chebyshev 3 of
the landing; the single sparse-field kill (monaco 4-car s9 m19 -- the
round-71 pin site, caught when the first near3>=2 gate broke its
move-identity) lives in a seal<=3 field. Gate:
  smokeNear = sealRivals <= 3 || near3 >= 2
(small fields exempt wholesale; 2x margin on the 8-car kills; debug
modes unchanged). Keeps 54%% of runs and 7/7 kills.

REJECTED SIBLING (measured): gating the funnel/dense ESC escalation by
proximity -- zandvoort s37 re-crashes (the r83 funnel arm's rare
switches fire with rivals FAR away; its fires are 0-switch in 4124
profiled cases on healthy races, but the rare switch IS the r83
zandvoort-band fix). The funnel arm stays ungated.

VERIFICATION: 18-race A/B (8/4/2-car, every historic class site) --
18/18 MOVE-IDENTICAL, total wall 118.2s -> 102.1s (-13.6%%; heavy
pack tracks -20-25%%: zigzag s76 3.5->2.0s, monza s80 6.6->5.6s,
zandvoort s33 6.4->5.1s). All ELEVEN pins pass on the candidate jar.
Canon numbers must be bit-identical (move-identity implies it);
window-1 verification in flight at write time.

UNIFIED CERTIFICATION (r107 champion, 4070 races -- 8car s46-150 x22
tracks, 4car+2car s26-65 x22): EXACTLY TWO crashes -- hairpin s68
(accepted place-neutral seal) and zandvoort s115 (documented open,
their round-108 target). The residual equals the documented frontier
across every window and field size ever raced; zero new specimens in
the widest sweep the campaign has run. Candidate canon window 1 on
the smoke-gated jar: 62.701 BIT-IDENTICAL to r107.

CANON IDENTITY COMPLETE: windows 1-3 all BIT-IDENTICAL on the gated
jar (62.701 / 62.640 / 62.678). BENCH WORKFLOW SPEEDUP banked
alongside: bench_ai's existing BENCH_BASELINE cache is now seeded per
canon window (scratchpad ai2_base_w{1,2,3}.json) -- AI2 is the frozen
champion, identical on every candidate run, so cached-baseline benches
run the AI1 column only and HALVE canon wall time on top of the smoke
gate. Caches invalidate at promotion (delete the files when AI2
changes) -- recorded here so both agents adopt the flow.

Also noted for the speed ledger: their r106 forward-pack arm moved
canon window-1 wall time 5m50 -> 9m05 (+55%%); this gate claws back
roughly a quarter of a window. The profiling twin (prof/ tree +
prof.jar pattern) is reusable for the next speed round.

## Round 107 (local agent): direct true-5 at the ESC route -- hungaroring s144 solved, canon -0.010

BUILT ON their promoted Round 106 (guarded forward-pack acceleration;
pulled, site-battery-verified: all nine solved sites hold, s115/s144
open as expected; their instance-field fixes for trueConfirmDepth /
simTrace are correct for batch mode).

THE FINDING (probe matrix, one command per cell): at hungaroring s144
m26 the taken SE is ALIVE in every suppressed world (scorer-5-cap3
V=113, scorer-8-cap6 V=112) and dead ONLY under true-5-cap6 (V=-1);
its signature is thread=2 snug=2 in a healthy tier -- exactly the
slice the round-104 cost ladder is BLIND to, because the ladder's
cheap scorer-8 pre-check reads alive and never reaches true rivals.
First trial (ESC-route confirm with the ladder) fired at m26 and said
"true rivals keep alive" -- the ladder never ran them.

MECHANISM: the r60 ESC call (dense-pack / scorer-dies / funnel-risk
escalation) gains trueConfirm with the corridor leg suppressed
(corrLeg=false); at that route the slow leg runs TRUE rivals DIRECTLY
for 5 rounds at cap 6 -- no cheap pre-check -- gated to the exact
s144 signature (thread==2, snug==2, tier>=3; 0-3 fires/race). legSlow
snug threshold 3->2 (both s144 and the round-104 monaco site pass).

COST, HONESTLY: canon window 1 wall time 9m35 vs 9m05 on their r106
baseline (+5%); NOTE their r106 forward-pack arm itself moved the
window from 5m50 to 9m05 -- the bulk of the recent slowdown is the
pace arm's scorerFieldOutcome rollouts, recorded for the speed ledger.
The wider slice (thread>=2 snug>=2 any tier) cost +70% and was
rejected.

RESULT: hungaroring s144 FIXED; all nine solved sites hold; ten pins
PASS; canon 62.701 / 62.640 / 62.678 -- window 2 at -0.010 vs the
frozen mirror is the LARGEST canon gain since parity (r105: -0.004);
h2h 4.494 vs 4.506 held; 4p/1v1 exact; slow identical. Residual
frontier: zandvoort s115 (equal-speed lane class -- their round 108
equal-speed-veto branch is gating it via CI; left to them, inspect-
before-merge) + accepted hairpin s68.

## Round 105 (local agent): slower-first switch targets; the shelf-rule refutation; harvest 16 census

HARVEST 16 (8car mega-window s106-150, 990 races): 4 crashes, all
depth-6-9 -- zandvoort s115 m111 / s128 m110 / s134 m98 (the corridor
shelves again, three new shapes) and hungaroring s144 m26 (start
funnel, @true-r4). Probe matrix banked the decisive negative: at
depth 7+ the class is TRAFFIC-COUPLED past every affordable world --
the state (44,28)v(2,-7) is oracle-ALIVE in s115 and oracle-DEAD in
s128; identical local state, opposite outcomes on field context. No
local verdict or static rule can decide these.

WHAT SHIPPED (pin-clean): dead-path ladder SWITCH TARGETS pick
SLOWER-FIRST (min spd-inf, then cheap ttf) -- the class invariant
applied where it is safe: only among candidates that already passed
the scorer-8 + true-4 ladder on an already-dead chosen. Fixes s128
AND s134. Canon 62.705/62.647/62.679 with windows 1-2 both faster
than the frozen champion, and H2H 4.494 vs 4.506 -- the FIRST
head-to-head EDGE over the mirror since parity: braking one unit
earlier at fragile shelves wins races.

WHAT WAS REFUTED (three pin-measured attempts): the SHELF SPEED
DISCIPLINE as an alive-branch rule. Gate tier<=1: breaks pace +
field-neutral + staged + energy pins (corridor fires with fragile
tiers are everywhere in packs). Gate tier<=1 AND thread>=1 AND
snug>=2: still breaks them. ESC-call confirm with the corridor leg:
breaks mixed-safety. Conclusion: the invariant is only safe where a
verdict ALREADY killed the chosen; as a preference on alive verdicts
it perturbs the pinned equilibrium at any gate the corridor fire-rate
offers. The corrLeg flag (suppress the corridor leg per call site)
stays as inert plumbing.

CERTIFICATION (r105): mega-window 2/990 -- EXACTLY the two documented
open sites (s115, s144), nothing else; harvest-9 windows 0/770. The
residual equals the documented frontier precisely, again.

OPEN (full anatomy): zandvoort s115 m111 -- survivors are
EQUAL-spd-inf lane changes (v(2,-7)/v(3,-7) vs taken v(4,-7)), outside
the slower-first vocabulary; scorer-8 reads all three alive
(thread 6/5/3 of 7 -- massively threaded yet verdict-alive), true-8
kills taken AND one true survivor (false kill) while keeping S: even
true-8 is only per-candidate right here. hungaroring s144 m26 --
tier-healthy (3) thread=2 snug=2 at every gate world, dies @true-r4,
five survivors; the one confirm that sees it (legCorr at the ESC
call, horizon 5) costs the mixed pin. Both are the residual frontier:
2 open in 990 fresh mega-window races, plus accepted hairpin s68.

## Harvest 15 (r104 champion): 0/770 ON NEVER-RACED SEEDS -- the family generalizes

The first zero-crash FRESH harvest in campaign history (fresh windows
8car s91-105, 4car/2car s56-65; all 3190 finishes present). Every
prior fresh exam found specimens (harvest 6: 2, harvest 9: 4); the
r104 champion's first fresh exam is perfect. The instrument family --
thread audit, bounded confirms, three fragility legs, cost ladders --
was built from seven specimens and holds on geometry it never saw.
Measured residual now: ONE accepted place-neutral site (hairpin s68)
in 3080 certified races, and 0 in 770 fresh. Next hunt widens to an
8-car mega-window (all seven specimens were 8-car; the 4/2-car
windows have been clean since harvest 3).

## Round 104 (local agent): three-leg confirm predicate -- EVERY HARVEST SPECIMEN SOLVED

The final two open specimens fall to one unified mechanism, every
number probe-measured before a line of Java:

THE THREE LEGS (all inside the dangerJointSearch confirm block, each
surgical by measurement):
1. CORRIDOR (r99/r100 unchanged): thread>=1 + neutral-grid body ->
   the proven true-4 certification-cap check.
2. SLOW-PACK (new): thread>=2 AND snug>=3 (snug = slots with <=2
   viable, counted free in outThreadRounds[1]) -- fires ~1/race at the
   threadPack fallback, and monaco-s88 m54's fire IS its one
   qualifying event (v=101 thread=2 snug=3; invisible to every other
   tell: no bodies, no pack proximity for the killers, trap-path
   route).
3. DEEP-TIER (new): finalTier<=1 with NO thread -- 1 fire across
   eight debug races, and it is zandvoort-s88 m96 itself.

THE COST LADDER for the new legs: the suppressed 8-round
certification-cap world FIRST (~100ms; probe: it alone kills both new
sites), true rivals only to verify a kill (true-4 for slow, true-6
for deep -- the s88 box seals at true round index 5, probe-measured:
true-4 V=124 alive, true-6 V=-1). Switch targets now pass the same
ladder (scorer-8 then true-4); all survivor targets probe-verified
alive in every ladder world before building.

KEY PROBE FACTS BANKED: scorer-8-cap6 kills BOTH new sites -- no true
rivals needed for detection, only for verification; cap matters at
depth (scorer-8-cap3 reads s88 alive with thread=5!); the query-sim
audit reply (V;tier;thread;snug) made every gate decision a
one-command measurement.

RESULT: all seven harvest specimens crash-free (chicane s51,
zandvoort s32/s74/s88, monza s80, zigzag s76, monaco s88); race times
unchanged (monaco 2.2s, zandvoort 3.0s); ten pins PASS; canon
62.706 / 62.649 / 62.679 with window 2 now 0.001 FASTER than the
champion mirror (a ladder switch found a marginally better line);
parities exact; slow identical. hairpin s68 remains the sole
accepted-open class (place-neutral finish-denial seal, correct
opposing play). Certification sweeps follow.

TRIPLE CERTIFICATION (r104): 2310 races across ALL harvest windows
(std 46-60/26-35, h6 61-75/36-45, h9 76-90/46-55) -- EXACTLY ONE
crash: hairpin s68, the accepted place-neutral finish-denial-seal
class. The champion's measured residual across every window ever
raced is precisely the one documented, correct-opposing-play site.
PROMOTION CASE NOW: AI1 leads the frozen AI2 by seven solved crash
classes at identical-to-marginally-faster pace (canon w2 -0.001);
h2h/1v1/4p exact parity; ten pins green. Execution awaits the user's
word, per the standing law.

ALSO: process note -- a multi-step patch script aborted mid-assert
BEFORE its single write, so five of six steps silently missed while
the sixth (applied separately) landed; the first r104 test ran on a
half-round build. Caught by the site battery reading 2 crashes.
Standing rule reaffirmed: write patch scripts to FILES, assert all,
write once, and always re-verify the diff stat after applying.

## Round 103 (local agent): the query-sim probe finds two structural truths; zigzag solved

THE INSTRUMENT: a `sim` command in the --query-moves protocol
(RaceGame.processQueries) runs the in-game joint rollout from an
installed board (me already AT the queried landing) with a chosen
world (smom | scorer | true) and cap, replying "V=<verdict>" with
SIMTRACE step lines on stderr -- the in-game rollout diffable LINE BY
LINE against the offline Python roll (sim_diff.py pattern). Permanent
tooling; simDepth guard keeps nested rollouts silent.

TRUTH 1 -- THE BOUNDARY REGENERATES: at zigzag m234 the latched
in-confirm rival vacated the kill cell the oracle champion claims.
First hypothesis: since round 99 the confirm IS champion behavior, so
a binary latch strips real arms from in-confirm rivals -- fixed by a
DEPTH counter (one nested confirm level allowed, depth 2 blocks).
Necessary but NOT sufficient here: the oracle on the EXACT same board
agreed with the latched move -- no channel infidelity existed.

TRUTH 2 -- THE CAP IS A WORLD PARAMETER: the real divergence was the
scorer-set cap. At cap 3 the un-set cars run smom, and their flow
hands the key rival a context where it vacates ((16,40)); at cap 6
the same rival closes the box ((15,39)) exactly like the all-champion
offline roll and the real race. V=34 alive at cap 3; V=-1 dead at cap
6 -- measured through the probe, single query. FIX: true-rival
confirms ALWAYS run the certification cap (max(scorerCap,
AI1_DEEP_CERT_RIVALS)); every cheap world keeps its pinned cap.
zigzag s76 FIXED; all five solved sites hold; ten pins PASS; canon
62.706/62.651 (w3 pending at write time) identical.

MONACO S88 RECORDED OPEN with a complete negative series: the m54
chosen routes through the trap-0 r60 smoke branch (trap ladder reads
healthy); measured invisible in EVERY cheap world -- python smom
viable 2,2 (no thread), in-game trap-path world thread=2 but the m54
route never reaches that gate, in-game SMOKE world thread=0 snug<=1,
no bodies on the neutral grid, pack gate closed (killers converge
from beyond Chebyshev 10: p8/p3 one-cell divergences seal @r2).
Affordability wall: threadPack fires 27-73/race, alive-smoke-thread
2-27/race -- every candidate gate is orders too hot for a cap-6 true
confirm. The kill exists ONLY at true fidelity with no cheap
signature. New debug diagnostics kept (THREADPACK, SMOKETHREAD,
snug counter in outThreadRounds[1]).

SWEEP VERDICT (r103 certified): dual 770-race sweeps -- harvest-9
windows 2/770, the two crashes being EXACTLY monaco s88 and zandvoort
s88 (the documented open set, nothing new); standard windows 0/770.
The residual equals the documented frontier precisely. Canon window 3
62.679 identical; 1v1/h2h/4p exact parity; slow 104.107.

OTHER AGENT CONVERGENCE NOTE: their speed-103 branches independently
reached the SAME zigzag site and the SAME cap conclusion
(six-rival-gate / full-roster-confirm). Their patch is a subset of
master 38e8595 (cap fix identical in effect; binary instance latch
where master has the depth counter; no query-sim). Their
six-rival-mirror-gate-v2 branch MIRRORS the confirm machinery into
AI2 with a joint AI1/AI2 zigzag pin -- promotion-shaped work, held on
the branch: per the standing law the AI2 mirror lands only on the
user's explicit promotion word.

ZANDVOORT S88 stays open (corridor class at depth 7 -- the deep
confirm at the funnel escalation remains the costed, unmeasured
candidate).

## Round 102 (local agent): monza solved via three composed fixes; a sim-fidelity puzzle isolated

HARVEST 9 (fresh windows: 8car s76-90, 4car/2car s46-55): 4/770 -- four
specimens, four different lessons.

MONZA 8car s80 m183 -- SOLVED, three composed fixes, each measured:
1. ALONGSIDE-PACK GATE: the chosen lands amid four rivals braking into
   turn 1 (Chebyshev <= 3 of the landing) yet ZERO pass the corridor
   ahead-dot test; the gate now also opens on landingAdjacent >= 3.
2. SPEED-SCALED CONFIRM NET: the true-rival membership radius
   (Chebyshev 10 of the landing) cannot contain the braking car 11
   cells downstream of a spd-inf-10 commitment; TRUE-RIVAL worlds now
   use max(10, 2*spdInf). A GLOBAL radius change was tried first and
   slowed the round-96 coil finish frontier by four moves (their pin
   caught it within minutes) -- suppressed worlds keep the pinned
   radius. The pin system is doing exactly its job.
3. DEAD-PATH TARGET CONFIRMATION: a cheap-dead chosen in a confirm
   context now true-confirms its switch targets (previously only the
   fragile-alive path did) -- zigzag s76 m234 showed the scorer world
   killing the TRUE survivor and switching onto the truly-dead
   alternative.
Result: monza s80 clean; all five prior sites clean; all ten pins
PASS; canon 62.706/62.651/62.679 IDENTICAL; parities exact; slow
104.107.

STILL OPEN, each characterized:
- zigzag s76 m234: THE SIM-FIDELITY PUZZLE. Python smom AND orivals
  (selfMove me) both kill alt NE @r2 -- reality agrees (the race
  crashed) -- yet the in-game 8-round scorer world reads NE simT=30
  alive and the in-game 4-round true-rival confirm (cap 3 at this call
  site) says true-ALIVE. The in-game rollout DISAGREES WITH ITS
  REPLICA on a decided state. Either the replica diverges from
  rivalMoveOverState in a detail, or the in-game board
  installation/move-order has a subtle infidelity -- either way this
  underlies multiple misses and wants a purpose-built probe: a
  --query-sim debug mode that dumps the in-game rollout trace for a
  given state, diffable line-by-line against the Python roll. THAT is
  round 103.
- monaco s88 m54: predicate-invisible rival-side kill (viable 2,2, no
  thread, no tier tell, no bodies at decision time). The scorerSelf
  escalation added this round fires one decision too late (m62). Needs
  either the query-sim answer or an affordable always-confirm gate.
- zandvoort s88 m96: the corridor class at depth SEVEN (true death
  @r7; survivors differ by ONE unit of entry speed). Beyond the
  4-round confirm; a deep confirm at the funnel escalation (8 true
  rounds, ~50 champion computes/fire at rare funnel fires) is the
  costed candidate, unmeasured.

Fresh-seed residual: 4/770 on never-raced windows vs 0/770 on all
regression windows -- the hunt-fix-pin engine converges per window;
fresh geometry keeps supplying the frontier.

## Round 101 (local agent, REJECTED after measurement): the survival-dual probe

The hairpin-s68 class got its first instrument attempt: a SURVIVAL DUAL
of the endgame win solver (egSurvRival/egSurvMy -- paranoid minimax
where I need only finish-or-stay-alive, horizon counts as survival),
run OBSERVE-ONLY behind -Dai.probe.survival at near-finish commits
(myT<=6, contesting rival = min-ttf live car within Cheb 10 with
rT<=myT, 13 plies, 50k-node budget).

MEASURED REFUTATION at the site itself:
- p8's real m104 commitment reads SURVIVABLE vs worst-case p5 alone:
  the 2-body model is TOO WEAK -- the real doom needs the multi-body
  pocket shaping (p4's earlier lane pressure), and multi-body
  adversarial search is intractable.
- p5 (the eventual WINNER) gets flagged PROVABLE-LOSS/NO-ALT vs p4,
  who in reality raced on and finished: the 2-body worst-case model is
  TOO STRONG against opponents who never play adversarially -- the
  insurance-premium law made quantitative.
- Budget blows (>50k nodes) at 13 plies on open approaches; the win
  solver survives the same depth only because win-proofs prune hard.

Code reverted per the r76/r77 discipline; the committed r100 champion
is unchanged. hairpin s68 STANDS as the open counterexample: place-
NEUTRAL crash (the victim places 8th finishing or crashing), rarest
class on record (1/1540 in the r100 dual sweep), requiring multi-body
adversarial fidelity no affordable instrument provides. Recorded
directions for whoever returns: (a) restrict to TRUE 2-live-car states
(where the 2-body proof is sound and the flagged real decisions at
m143+ are already all-dead -- needs the trigger EARLIER than 1v1
materializes, which is the hard part); (b) an asymmetric model: MY
moves paranoid-proven, rival constrained to its REAL policy envelope
(champion-reachable moves only) -- cost between confirm and solver,
unmeasured; (c) accept the class: the crash is place-neutral and the
sealer''s play is correct -- the loss is cosmetic in ranking terms.

## Round 100 (local agent): corridor-class generalized (zandvoort s74 solved); new open class recorded (hairpin s68)

HARVEST 6 (fresh windows: 8car s61-75, 4car/2car s36-45, 770 races) on
the r99 champion: 2 crashes -- the improvement queue refilled exactly as
the instruments were built to exploit.

SPECIMEN 1, zandvoort 8car s74 m109 -- SOLVED. The second corridor-class
site, one shape deeper than s32: last avoidable m109, survivor S, taken
SW dies; the fragile signature carries thread=1 but a HEALTHY final
tier (the r99 predicate's tier<=1 leg blocked the confirm), and the box
seals at round index 3 (s32: index 2), one past the 3-round confirm.
Round 100 tuning, both measured before building: predicate drops the
tier leg (thread>=1 + body on the neutral grid; 0 fires outside
zandvoort across the healthy sample, 3 on zandvoort s33),
AI1_TRUE_CONFIRM_ROUNDS 3 -> 4. s74 fixed; s32/s33/s51 all stay clean.

SPECIMEN 2, hairpin 8car s68 m146 -- NEW CLASS, RECORDED OPEN
(finish-denial seal). Six cars finish; p5 and p8 arrive at the finish
approach together with p8 at reach-ttf=1 -- ONE MOVE FROM WINNING. p5
moves first, denies the finish lane, brakes 6->0 into the top-right
pocket and PARKS at (77,14): the endgame forced-crash seal, executed
mid-pocket. p8 overshoots into the dead spur; from m112 on, its own
DJS reads every candidate dead (correct) with no survivor. The
commitment was m104 ((41,6) SE at spd^2=65): the deep smom-8 pre-screen
read the landing alive at ANY horizon (smom says t=1 -- in every cheap
world p8 simply WINS; the proxy p5 never parks), while full champions
kill @r7. Prevention needs ~7-round ADVERSARIAL fidelity or
finish-lane-contention modeling -- outside every current instrument,
including the 4-round confirm. Also outside the endgame paranoid
solver's scope (it acts on proven wins near the finish; this is the
LOSING side of a contested finish). Victim-side rate: first 2-car-
context crash in any harvest; all 1v1/4p/h2h batteries crash-free.
Note: p5's seal itself is CORRECT play (place-equivalent to finishing,
ends the race with zero own risk).

TOOLING: bench_ai.py seeded benches now run ONE JVM per track via
--seed A-B batching (contiguous windows auto-detected; singles
otherwise). Equivalence proven exact: batched canon window 1 reproduces
62.706/62.704 +0.003 to the last digit. Gain is modest on warm-cache
benches (JVM spin-up only); the harvest scripts already batch.

SWEEP VERDICT (r100 certified): canon windows 2-3 62.651/62.679
IDENTICAL to champion; 4p/1v1/h2h exact parity; slow 104.107. Dual
770-race sweeps: harvest-6 windows 1/770 -- the single crash IS hairpin
s68, the recorded open class, nothing else; harvest-4/5 windows 0/770.
The r100 champion's only known crash in 2310 swept races is the one
documented open specimen.

OTHER AGENT OBSERVED IN-FLIGHT (branches, not yet on master):
agent/ai-racing-speed-100-{seal-pace-screen,finish-probe,source-export}
carry a stored candidate patch (.github/round100-sealpace-refined.patch)
plus CI workflows. The candidate builds ON our r99 confirm machinery,
INVERTED: where our confirm uses true rivals to KILL cheap-alive lines,
theirs REVIVES sealGuard-demoted one-turn-faster finish lines when the
field-outcome cert AND a true-rival+scorerSelf confirm both pass
(finish band, trap-0, homogeneous, less-obstructive-field gates). It
also flips inTrueRivalConfirm from static to instance -- correct (one
RaceAi per game; instance isolates batch-mode races). NUMBERING NOTE:
master's Round 100 (this entry) landed first; their branches also say
Round 100 -- suggest they publish as Round 101 at merge time. Their
candidate patch still applies cleanly on r100 (their hunks avoid the
r100-tuned lines). Inspect-before-merge honored; branches left theirs
to land after their battery completes.

GATES: all ten pins PASS; canon window 1 62.706 IDENTICAL to
r98/r99/champion. Windows 2-3 + parities + both 770-race sweeps in
flight at write time; results recorded in the next entry.

## Round 99 (local agent): bounded true-rival confirm -- zandvoort s32 SOLVED, class closed

THE RECURSION BOUNDARY IS BREACHED -- affordably. Round 97 proved true
rivals correct but cost-prohibitive as a general world; round 99 makes
them a RARE CONFIRM: fire only where the suppressed corridor world says
alive AND its own outputs betray fragility. The observe probe measured
the signature at the two s32 doom decisions (verdict alive, finalTier=1,
threadRounds=1/2, body on the neutral grid) at ~0.25 false fires per
race elsewhere (2 in 8 healthy races, all zandvoort).

MECHANISM (all AI1-only): scorerMoveOverState gains a suppress flag;
suppress=false runs the rival's computeAiMove UNSUPPRESSED (pace arms
included). simOutcome gains trueRivals (scorer-set rivals at full
fidelity). dangerJointSearch gains trueConfirm: an alive corridor
verdict matching the fragility signature is re-verdicted with
AI1_TRUE_CONFIRM_ROUNDS=3 rounds of true rivals (the box seals at round
INDEX 2 -- a 2-round confirm provably misses it, measured). True-dead
falls into the normal switch, where each candidate is ALSO
true-confirmed (first true-alive by cheap simT wins; cheap-best
fallback). Wired at the r73/r74 corridor/queue certification only.

THE r97 COST/CORRECTNESS WALLS, ENGINEERED AROUND:
1. Workspace clobber (would have corrupted r97's results silently): an
   unsuppressed rival compute re-enters rolloutWorkspace(); the confirm
   swaps the field to null around computeAiMove so nested rollouts
   allocate fresh; outer arrays live on as locals.
2. Recursion runaway: static latch inTrueRivalConfirm -- rivals computed
   at full fidelity cannot fire their own confirms.
3. Cost: verdict-only + rare gate + 3-round bound = ~0.25s per fire,
   +0.7s on the crash race, +0 on most races (canon window 1 wall time
   unchanged).

AT THE SITE: m102 fires and true rivals KEEP S (death @r7 is not yet
sealed -- correctly not the decision point); m110 fires, true rivals
KILL @3r, alt walk finds SW simT=125 true-ALIVE, switch -> 0 crashes.
p8's one benign fire confirms alive. Debug-independent clean replay: 0.

ONE REAL BUG CAUGHT BY THE PINS: the confirm's audit arrays leaked the
r98 robust-switch into the corridor site ungated (a fully-threaded
alive corridor verdict ran the thread switch with threadCheck=false),
perturbing cog-s1 field-neutral by +2 moves. Fix: the robust switch
requires threadCheck explicitly. Lesson recorded: when two audits share
plumbing, each behavior needs its own explicit flag test.

GATES (all green): nine pins PASS (incl. field-neutral after the fix,
thread-fragility, golden corpus, headless smoke); canon
62.706/62.651/62.679 -- IDENTICAL to the r98/champion record, f=770 c=0
all windows, windows 2-3 exactly equal AI2; 4p 2.500/2.500, 1v1
1.500/1.500, h2h 4.500/4.500, all c=0; slow 104.107 both kinds.
Harvest 5 (same 770 races as harvests 3-4) = the certification sweep.

HARVEST 5 RESULT: **0/770, all 3190 finishes present** -- the second
consecutive zero-crash full sweep, now on the r99 champion. Confirm
fires across the sweep stayed rare enough to leave every previously
clean race untouched (the sweep is seed-identical to harvests 3-4).

CLASS LEDGER: chicane s51 (rival-side) solved by r98 thread audit;
zandvoort s32 (both-sided) solved by r99 true-rival confirm. NO KNOWN
OPEN CRASH SITES. The two instruments compose: cheap-world fragility
signals gate expensive fidelity exactly where model error is fatal.

## Round 98 (local agent): thread-fragility audit -- chicane s51 SOLVED

THE RECURSION-BOUNDARY CLASS HAS A MODEL-FREE ANSWER. Round 97 proved
no affordable rival model reproduces the pack's champion braking. Round
98 stops trying to predict the rivals and audits MY OWN certificate
instead: the chicane-s51 chosen rolls out alive in every cheap world,
but enters EVERY simulated move slot with at most ONE viable candidate
(viable=1,1,1,1) -- a single-file needle through live traffic. The two
oracle-proven survivors roll viable>=2 on every slot in the SAME cheap
world (W: 4,6,8,7; S: never below 2). "Alive but fully threaded" is the
death signature, and it is computable from the candidate enumeration the
sim already performs: zero extra simulations, zero rival fidelity.

MECHANISM: simOutcome gains an outThreadRounds channel (count of my move
slots entered with <=1 viable candidate: legal, unoccupied,
reachability-alive; a finish-crossing slot counts as open).
dangerJointSearch gains a threadCheck mode: an ALIVE verdict that
threaded rounds-1 of rounds-1 slots triggers a robust-alternative
search; switch only to an alternative BOTH alive and non-threaded
(survival-only asymmetry preserved -- no robust candidate, keep the
chosen). Enabled at ONE site: the AI1 slow fallback DJS, gated on
djSlow + >= AI1_DEEP_PACK rivals within AI1_DEEP_PACK_R of the landing.
AI2 untouched.

AT THE SITE: m121 fires "alive but viable<=1 on 4/4 slots", finds four
robust alternatives (W/NONE/SW/S, all simT=3 thread=0), switches to W --
the oracle-proven survivor -- and the race runs 0-crash with p1 alive in
P8 (was CRASH place=8).

NEGATIVE RESULTS BANKED (policy_matrix rows kept as instruments): smin
(tie->slower), strf (traffic-conditioned tie), punion (pessimistic
tie-set occupancy vs my successors) all still read SE alive -- the box
needs the exact multi-car configuration; occupancy pessimism cannot
reach BACKWARD from an over-fast rival flow. Divergence localization
(diverge.py pattern: roll smom vs orivals side by side) and candidate
autopsy identified the real signature: at score ties, back-of-pack
champions brake into the funnel (their own r83-style discipline,
stripped by inScorerSim); front-runners keep speed. Model-free
robustness beat model fidelity.

GATES (all green): nine pins PASS (7 ai1_* + golden corpus + headless
smoke); pace canon 62.706/62.651/62.679 vs champion 62.71/62.67/62.68,
f=770 c=0 every window (windows 2-3 EXACTLY equal AI2 -- zero perturbing
fires; window 1 +0.003 vs AI2 62.704); fixed-grid bench identical to
AI2 to the third decimal (62.604/62.604, +0.000 all 22 tracks); 4p
2.500/2.500, 1v1 1.500/1.500, h2h 4.500/4.500 parity, all c=0; slow
104.107 both kinds. New pin: tests/ai1_thread_fragility_regression.py
(chicane s51 8car must stay 7 finishers / 0 crashes).

CLASS STATUS: chicane s51 (rival-side) SOLVED. zandvoort s32 8car
(self-side) still crashes -- expected: threading is a rival-side
instrument; the self-side member needs sim-me to see its own future
pace arms. Harvest 4 (the exact harvest-3 770-race sweep, batch-mode)
in flight; pre-98 A/B on zandvoort s32 pending the jar lock.
HARVEST 4 (r98 champion, the exact harvest-3 770-race sweep, batch
mode): **0/770 -- the first zero-crash full harvest of the campaign**
(harvest 3: 1/770). 3190 finishes = the exact full-field count; every
race completed. The only known crash anywhere is zandvoort 8car s32
(outside the harvest windows), PROVEN pre-existing: zero THREAD fires
in that race, so the r98 champion raced it move-identically to r97's.

ZANDVOORT S32 DISSECTED (round-99 groundwork, POCKET entry added):
last avoidable move m110 (p6, pos (42,35) v(3,-8)); survivor SW
(oracle-alive t=118), taken S dies @r6 under full champions. In-game:
the r73 corridor check FIRED at m110 and its suppressed cap-6 world
read S alive; one move later everything is dead (DJS correctly says
"no survivor" @m118 -- detection one move late). Anatomy is BOTH-SIDED:
(a) death needs rival fidelity -- real p5 lands ON my only good r1
cell; the debug trace catches p5's PRIVATE-LANE PACE ARM firing right
there (SW -> W ttf 125->124): the killer move is literally a pace-arm
product, the class thesis verbatim; (b) escape needs self fidelity --
survivor SW lives ONLY by real-champion single-file threading
(viable=1 on six straight rounds under orivals-me). The r98 thread
audit correctly stays silent (chosen S reads viable=2,2 in cheap
worlds -- an inverted signature: here the SURVIVOR threads, the doomed
line does not). Corridor-world thread counts to be measured by an
observe-only probe; if the true in-game world also reads viable>=2,
threading cannot catch the self-side face and round 99 needs a
different instrument (bounded 2-round true-rival confirm at corridor
alive-verdicts is the costed fallback: the box seals @r2, so 6 rivals
x 2 rounds of full-fidelity moves per fire, fire-rate ~4/race/player
-- needs a fragility pre-gate to be affordable).
NEXT INSTRUMENT CANDIDATE: the thread audit generalizes -- the same
outThreadRounds channel could gate other DJS sites (deep corridor,
funnel) if new specimens appear; fire-rate so far is one site per 770.

## Round 97 (local agent, REJECTED after full forensics): chicane s51 and the pack-cohesion limit

THE LAST HARVEST-3 CRASH, fully classified -- and the definitive
specimen of the recursion-boundary class. Chicane s51, p1 dies m145;
**m121 is the last avoidable move**: three candidates FINISH @r7 and
one stands a turn from the flag, while the taken SE (the fastest line)
dies @r3. The matrix: smom=alive tier-3, orivals=DEAD@r2 -- yet no arm
fired: the chosen carries trap 0.5 and routes through the trap-path
DJS whose scorer world reads it alive.

THE REAL MECHANISM (from the race log): p1 is LAST; after SE the
entire six-car pack holds the lower racing-line corridor through
rounds 1-2, forcing p1 into the upper fork, which dead-ends at
(65,5). The kill is **pack-lane cohesion** -- the suppressed scorer
world under-predicts how firmly the real pack (running its full pace
stack) holds the line, so in-sim the lower lane opens and SE reads
alive.

THREE FIX ARMS BUILT AND REJECTED with measurements:
1. Depth-1 TRUE RIVALS (unsuppressed computeAiMove for scorer-set
   rivals): mutual recursion through nested contact gates ran ONE fire
   past five minutes; a depth latch capped it but the direct cost
   (~90 full champion computations per fire) still ran a 0.6s race
   past ten minutes. Cost-prohibitive at any useful fire rate.
2. Pessimistic-pursuit contact rival (zero recursion, fixed target,
   then live-target): fires correctly at m121 but cannot reproduce a
   six-car lane occupancy with one pessimistic pursuer -- the verdict
   stays alive. (Bonus finding: ringWidth is a BFS level set and wraps
   both legs of a switchback, so the static funnel signal reads a
   2-cell chicane gate as wide; the funnel instrument is sound for
   open funnels only.)
3. All code reverted per the r76/r77 discipline; the analysis is the
   deliverable.

THE CLASS LEDGER now reads: zandvoort s32 (self-side: my own future
pace arms invisible to sim-me), chicane s51 (rival-side: the pack's
pace arms invisible to sim-rivals). Champion fresh-seed tail-risk
stands at 1/770 (harvest 3) with these as the only known open sites.
VIABLE DIRECTIONS (recorded, unclaimed): bounded multi-true-rival
certification (needs a cost breakthrough -- e.g. memoized rival moves
or a 1-round-only full-fidelity pass), a static racing-line occupancy
prior (must solve horizon-sensitivity: static blocking kills waiting
lines too), or admission-level speed discipline inside the pace arms
themselves (the arms' own certificates are the only worlds that see
their own aggression).

## What this project is

theoreticRacing: Java Swing vector-racing game (grid, state = pos+vel, 9
accelerations/turn, |v| <= 12, up to 8 players, fully deterministic;
`--seed N` seeds start placement only). Modules: `tr.logic` split into
RaceGame (controller) / RaceAi / Reachability / TrackGeometry / TrackIO.
The AI rests on a precomputed reverse-BFS map `turnsToFinish(x,y,vx,vy)` =
EXACT min turns to finish on the empty track.

**Roles: `optimalMoveAI1` = experimental frontier, `optimalMoveAI2` =
frozen standard (champion). They are byte-identical twins at rest; work
happens on AI1; promotion = mirroring into AI2 after the full gate.**

Standing user rules:
- Never declare improvement impossible ("every time you say we can't
  improve you improve").
- NORMAL git now: incremental commits with real messages + plain `git push`
  (the old rolling-squash + force-push workflow is RETIRED).
- Commit + push as one unit. Aggression toward opponents is a FEATURE.

## Multi-agent coordination (2026-08-08)

Two agents now work this repo (one local with full bench hardware, one
GitHub-API-only that ships patches via one-off Actions workflows). Rules
of the road, learned from a mid-merge collision:
- racing-memory.md is the single shared ledger: every experiment, fix
  and gate result lands here BEFORE or WITH its push. Both agents
  already honor this -- it is what made the 37-commit merge reviewable.
- Prefer branches + PRs for multi-commit work; if pushing to master,
  keep each push self-contained and green (CI + golden corpus).
- The golden corpus pins AI2: regenerating fixtures IS a promotion
  action and must ship with the promotion commit.
- Champion caches (BENCH_BASELINE) and canonical numbers live on the
  LOCAL agent's side and are invalidated by ANY both-bodies behavioral
  change (e.g. the futureMobility4 fix) -- re-baseline before judging
  candidates against stale numbers.
- LESSON: the session scratchpad is volatile (a purge deleted the whole
  oracle toolchain, all 22 reach dumps and the archived champion logs
  between sessions). Durable tooling and reference races belong in the
  repo -- the toolchain now lives in tracks/, documented in
  AI_DEVELOPMENT.md.

## 2026-08-14 speedup: batch racing + in-process reachability memo

RE-PROFILING the r91+ champion (the old "AI search is 3% of CPU" was
stale): the AI hot path is now their search machinery (fmRec, mobility,
two-round world-step -- their actively-optimized territory), and the
BATTERY'S dominant fixed cost is per-race startup: ~1.3s reachability
cache load+derive plus ~0.4s JVM boot x ~2900 races/cycle = 80+ min of
pure overhead per campaign cycle.

THE FIX, two parts, behavior-invisible by construction:
1. **Batch racing**: `--seed A-B` races every seed in ONE JVM (Main
   loops fresh RaceGame instances over fresh Properties copies; a new
   autoRaceEndHook replaces the hard System.exit; per-seed logs get _sN
   inserted before the extension).
2. **In-process reachability memo** (Reachability.REACH_MEMO): the
   fully-derived products (turns, alive, roomy, shed, cert) are adopted
   instantly by later seeds of the same track -- all read-only after
   build.

PROOF: batch logs byte-identical to single-shot logs (monaco s1-3,
cmp); one cache-hit print for three races (the memo works); unit +
golden suites green. MEASURED: monaco s1-3 = 18.2s as three singles vs
**9.5s batched (-48%)**; projected 35-45% off full battery wall time.
Tooling (bench_ai/bench_iso batch wiring) is the follow-up; the game
side is complete.

POST-INTEGRATION HARDENING: range execution now terminates safely even
at `Long.MAX_VALUE`, always gives default as well as explicit logs an
`_sN` suffix, rejects a range without `--auto` and range/query mode
mixes, clears a superseded range end, reports interrupted batches as a
failure, and owns the one-shot completion hook per `RaceGame` rather
than process-wide. `MainTests` pins the parser boundaries; direct batch
versus single-log checks remain the behavior contract.

## PROMOTION 2026-08-14 (per user): the composition is the champion

Executed: AI1's body mirrored WHOLESALE into AI2 (the r79-r90 pace
stack + r83 funnel guards). The first strict probe found 6/27 divergent
-- their self-play pace gates were keyed on Kind.AI1 literals, so an
all-AI2 field deactivated its own arms; the promotion-correct
semantics is KIND-HOMOGENEITY WITH THE MOVER (mixed fields stay gated
off exactly as designed). After the fix: strict probe ALL IDENTICAL
0/27. Golden corpus fully regenerated (the champion is ~a move faster;
every fixture legitimately reflowed, 13 cases, ZERO crashes across the
corpus) with the new lemans-s1-4p fixture pinning the 4-car rescue.
All four AI1 pins green post-mirror (mixed-safety improved: places
22/14). The strict self-tie probe and champion goldens are the durable
post-mirror identity record; Round 91's expanded matrix below then used this
body as its comparison standard.

## Rounds 91-92 (PROMOTED): faster launch and runtime

CAUSE: stagedPaceOverride counted a rival as "ahead" with a velocity dot
product. For a zero-velocity starting-grid car every dot product is zero, so
the proof-gated pace arm could never open. The first broad experiment used the
reachability distance heuristic everywhere. Exact debugging then located the
only measured gain at Silverstone s15, p6's first move at (61,6): N -> NE,
empty-map TTF 81 -> 80. The promotion candidate was narrowed to that proven
class: use track-distance ordering only while velocity is (0,0) and the mover
is still in the start zone; moving cars keep the r90 dot-product rule. Equal
or unavailable distances fail closed. Both AI bodies now carry the narrowed
rule. Kind-homogeneity, exact private route, 8-round self/field comparison,
seal guard and final danger veto remain unchanged.

RESULT: canonical 22-track 8-car bands seeds 1-5, 6-10 and 11-15 are
770/0 in both columns with ZERO slower tracks. The only result change
is Silverstone s15: final finisher 86 -> 85, exact sum 585 -> 584.
An independent integer cross-version A/B then replayed all 22 tracks x seeds
1-15 (660 executions): both versions produced 2310 finishers / 0 crashes;
329/330 race tuples were identical, the sole delta was Silverstone s15, and
total finisher moves improved 144811 -> 144810. This closes the rounding gap
left by the earlier one-decimal reports.
Silverstone s16-30 is byte-identical. The Zandvoort s31-45 doom band is
byte-identical (s32 remains the accepted lone 6/1 race). Homogeneous
4-car = 330/0 exact tie, homogeneous 2-car = 110/0 exact tie, and slow
= 140/0 exact tie. Java/core, goldens, pace, mixed-safety,
field-neutral, staged and energy pins are green. The expanded pre-mirror matrix
also completed: h2h seeds 1-5 and 11-15 were exact 4.500/4.500 with zero
crashes; seeds 6-10 were 4.500/4.500 with one crash in each column; 2v2 was
2.500/2.500, 1v1 1.500/1.500, homogeneous 4-car 330/0, homogeneous 2-car
110/0, and slow 140/0. The two h2h crashes are the same Le Mans s7 p6
trajectory in reversed kind order, not a candidate asymmetry. Post-mirror,
the strict 27-race probe is 27/27 move-identical and all champion goldens pass.
The exact final-head parallel matrix also passed all 12 jobs: 8-car bands are
770/0 exact self-ties at 62.714, 62.668 and 62.683, with every reported
per-track delta +0.000; h2h is 4.500/4.500 at crashes 0/0, 1/1 and 0/0;
2v2 2.500/2.500, 1v1 1.500/1.500, homogeneous 4-car 330/0,
homogeneous 2-car 110/0, and slow 140/0. CI and CodeQL are green on the exact
promotion commit.

OPEN MIXED-FIELD SAFETY CLASS: both h2h crashes are Le Mans s7 p6/F and are
move-identical under reversed kind order. The last rescue is global move 502
at (13,101), v=(-2,-8): scorer S dies, SW finishes. The ordinary fast smom
model incorrectly keeps S alive even at eight rounds; the scorer-rival model
distinguishes S (dead at a four-round horizon) from SW (alive through eight).
A future arm should therefore test a four-round scorer-rival escalation only
for fast L2-or-worse, smom-fragile entries with a nearby rival. Merely raising
the global three-round smom horizon will not repair this class.

REJECTED FIRST: (1) reopening r90 zero-unc high-energy candidates only
under strict field improvement changed Zandvoort s17's line but no
finish result and did not repair s32; (2) staged minimum-turn sweeps
35 -> 30 -> 24 -> 16 changed a Le Mans line but produced no aggregate
pace; (3) ranking already-certified staged candidates by rollout final
state was inert on every pinned staged case. None of those policies
remain in source.

POST-PROMOTION REJECTIONS: the rollout-ranking arm was subsequently screened
exactly over 500 race pairs (ten tracks x seeds 1-50): all 500 were
move-identical, net delta zero. The stale-base private runner-up branch passed
its standard tests but had no active proof. A current-master AI1-only port was
therefore screened on 62 exact pairs across Sprint, Hairpin, Silverstone,
Zandvoort, Le Mans, Hungaroring and Monaco; every pair was move-identical.
Separate isolated instrumentation saw zero rank-1 attempts in Monaco s1,
Zigzag s1, Cog s1 and the mixed-safety pin. The fallback was removed: it can
pay for a second scorer rollout when rank 0 fails, but has no demonstrated
racing gain. The later stale-base progress-quorum branch was also rejected
without a current port: it had no differential, changed-race or timing
evidence, counted equal-progress and up-to-three-rings-behind rivals toward
its quorum, and could add exact-private plus deep scorer work.

HARNESS BUG FOUND/FIXED: bench_iso claimed full isolation but used
fixed system-temp filenames, so concurrent checkouts could overwrite
each other's props/logs; it also silently preferred user.properties
over the canonical benchmark config. Files are now PID-unique and the
default is tracks/bench.properties (RACING_PROPS remains an explicit
override). Promotion-gate now includes homogeneous all-AI 4-car and
2-car jobs; that missing class had previously let the Le Mans 4-car s1
crash escape the standard mixed-field matrix.

ROUND 92 CPU CLEANUP: dense-slow-pack and static-funnel risks already force a
scorer-rival danger search. The old code nevertheless paid for a separate
five-round smoke simulation first; its boolean could not change whether the
deeper search ran. Both bodies now skip that redundant smoke call when either
gate already mandates escalation, retaining it under every debug mode. Seven
targeted pre/post full logs are byte-identical (Silverstone s15, Hungaroring
s40, Le Mans s1, Zandvoort s32/s37/s44). Seven interleaved warm-cache
Hungaroring s40 runs measured 10678.1 -> 10550.5 ms median (1.2%) and
10638.6 -> 10564.8 ms trimmed mean (0.7%) for the narrowed-r91+r92 build.
The workflow now runs benchmark pipes
under explicit bash/pipefail so `tee` cannot mask a failed race, and regular
bench reports show three decimals so a one-move per-band regression is visible.

SELF-TIE CERTIFIED: probe 0/27 (twice), all stages column-identical --
8car 770/0 x3 at the NEW CANON 62.71/62.67/62.68, h2h 4.500 parity both
bands, 4car 330/0/61.10, 1v1 110/0/60.34, slow 28/0/104.11. Champion
baselines re-seeded. ONE new tail-risk site surfaced during
certification: a mixed 4v4 lemans crash in seeds 6-10, mirrored
identically in both columns (the mirror holds; the site is
new-champion territory -- this suite was clean when the composition
raced the OLD champion, so the all-new mixed field reaches a fresh
doom). Queued with zandvoort s32.

HARVEST 3 COMPLETE (2026-08-14, the r91 champion, 8car s46-60 + small
fields s26-35): **770 races, ONE crash** -- the campaign's best
fresh-seed tail-risk ever (harvest 1: 2/770 on r70; harvest 2: 5/770 on
r75), from the fastest champion ever fielded. Small-field phases (440
races) perfectly clean for the third consecutive harvest. The single
crash: **chicane s51** (8-car) -- chicane's first-ever crash entry.
Open counterexample queue: chicane s51, the mixed-lemans s6-10 site,
zandvoort s32 (the recursion-boundary class).

## Round 93 (PROMOTED): mixed Le Mans sparse fast-trap repair

CAUSE: mixed Le Mans s7 p6 reached g502 at (13,101), v=(-2,-8). Scorer `S`
lands (11,94), v=(-2,-7), trap exactly L2=0.5, with exactly one rival inside
Cheb10 (p7 at distance 3). The normal smom3 world reports ALIVE/finalTier=1
and therefore keeps it; the scorer-rival world reports S dead at a four-round
horizon while SW survives. Reality matches the latter: S crashes at g532;
SW lands (10,94), v=(-3,-7), and p6 finishes g563/place5. The same p6
trajectory existed in both reversed kind orderings, so both scorer bodies had
to change.

INSTRUMENT: after existing funnel/deep-pack handling and before ordinary fast
DJS fallback, only `!djSlow`, trap exactly L2, one or two rivals within
Cheb10, and a smom3 verdict that is alive but finalTier<=1 may escalate. The
chosen move is then re-verdicted with exact self/rivals, real scorer rivals,
four rounds, cap3, and scorerSelf=false. Switching stays death-only. Packs of
three or more remain owned by the existing eight-round deep path. On the
target there are two scorer-r4 checks, one benign earlier check and the g502
switch.

RESULT: both mixed s7 orderings become exact 18/18 place sums with crashes
0/0; mean place remains 4.500/4.500. Exact old-05de452 versus candidate A/B:
330 homogeneous 8-car pairs exact; 660 mixed 8-car pairs with 658 exact and
only the two symmetric target rescues changed; homogeneous 4/2-car 220/220
exact; mixed 2v2 220/220 exact; mixed 1v1 220/220 exact; slow 20/20 exact.
That is 1,670 pairs / 3,340 executions, 1,668 exact and two intended safety
repairs, with zero invalid races. Zandvoort s31-45 stays 104/1 in both
columns. A clean 15-pair warm Le Mans s6 control was byte-identical and showed
no child-JVM CPU regression; do not call the noisier wall result a speedup or
slowdown. The repaired s7 race naturally runs longer because p6 now survives.
The focused mixed regression pins both orderings, g502 SW and g563 FINISH.

## Round 94 (PROMOTED): homogeneous finish-sprint extension

SOURCE LEAD / HARNESS DEFECT: the stale-base `speed-93-finish20` experiment
changed only AI1's Round-75 dual-model finish cap from 15 to 20. Its workflow
reported 0/390 divergences because it searched for `DIVERGENT`; `ai_probe.py`
prints `DIVERGED`. Raw artifacts actually held 21 changes: 11 faster, nine
outcome-neutral and one slower. Net was -16 finisher moves, but Le Mans s12
regressed +4 when the new band selected `NONE`. Full mixed screens on the
current port stayed crash-free but shifted places on Gear/Big Oval/Spa/Long
Loop. The unrelated 111-line collective-field rescue was rejected without an
A/B target: it could worsen the mover, scored all rivals rather than the
activating forward pack, and added expensive eight-round rollout work.

INSTRUMENT: retain `AI1_FINISH_CERT_TTF=15` as the legacy all-field cap. The
new `AI1_FINISH_HOMOGENEOUS_TTF=20` band is admitted only when every live rival
shares the mover's kind and the candidate is not `NONE`. Every established
certificate remains: strict empty-map TTF improvement, trap<=L1, both the
score-shaped-rival and scorer-rival worlds finish at the candidate's lower
bound, then normal DJS remains an independent veto. Kind-relative homogeneity
keeps the mirrored AI2 body semantically identical.

RESULT: exact current-master A/B over the canonical 22 tracks x seeds1-15 was
2310/0 in both columns. Of 330 pairs, 312 were trajectory-identical, ten were
faster, eight changed line with the same finish list, none was slower; finisher
moves fell 144810 -> 144793. Cog s1-15 contributes another -3 at s14, so the
345-pair measured corpus is -20 overall (19 changed: 11 faster, 8 neutral).
An isolated old/current Nurburgring s19 replay adds -1 finisher move: identical
7/0/order, `[89,90,92,93,95,96,99]` -> `[89,90,92,93,95,96,98]`, with total
turns 752 -> 750. Its first difference is exactly `SPRINT ... W -> N ttf=16`,
so the 346-pair measured total is -21 and the golden is intentionally updated.
Big Oval s7 is the active pin: `[20,21,22,22,22,22,23]` becomes
`[20,20,21,21,22,22,23]` (move12 N -> NW). Homogeneous 4-car improves
330/0/61.103 -> 330/0/61.091; homogeneous 2-car is exact 110/0/60.336;
2v2 and 1v1 remain exact 2.500 and 1.500; slow s1-5 is exact 140/0/104.157;
Zandvoort s31-45 remains exact 104/1/142.167. After the homogeneity boundary,
mixed Gear/Big Oval/Spa/Long Loop/Le Mans s1-15 all return 4.500/4.500 c0.
The mirrored body passes the strict 27/27 identity probe. Permanent tests pin
the Big Oval gain, Le Mans s12 coast veto, and mixed Gear place neutrality.

## Round 95 (PROMOTED): strict cross-model pace retention

INSTRUMENT: when the topology-shaped eight-round model declares a fast-pack
choice dead and proposes a scorer-rival-surviving alternative, keep the
original choice only under the existing exact-L2 boundary, zero uncertainty,
at least five live rivals and a mover-kind homogeneous field. Its empty-map TTF
must be exactly one lower, and an eight-round six-rival scorer-field comparison
must make both the mover and aggregate field strictly better. Otherwise retain
the old survival switch. The rule was measured AI1-only and then mirrored.

RESULT: 22 regular tracks x seeds 1-60 gave 1,319/1,320 exact races. The sole
change was Silverstone s1: seven finishers, zero crashes, finisher moves
`[82,83,84,85,86,87,88] -> [82,83,84,85,85,86,88]`, sum 595 -> 593.
The 100 slow races were exact. The faster aggregate changes finisher identity /
order, so this is deliberately a racing-pace promotion, not a monotone-place
claim. Warm alternating target/control timing showed no material runtime
regression. `ai1_cross_model_pace_regression.py` pins the mirrored 593 result.

## Round 96 (PROMOTED): synchronized extended finish frontier

REJECTED PATHS: a raw TTF21-30 dual-finish extension found many Spa/Coil gains
but also made Coil s49 one move slower, changed finisher identities, and slowed
individual racers. Adding the old seal veto removed one Spa line but not those
field effects. Exact-L2 + zero uncertainty + strict eight-round mover/field
improvement narrowed Coil to s6 and s47; s47 still slowed one finisher. A
componentwise rival-cost rollout was rejected because its proxy accepted the
bad s47 line and rejected the clean s6 line. Cross-model gap>=2, staged
multi-turn zero/low-energy, and high-energy strict-field censuses were empty;
private-proof budget exhaustion had one Spa s8 event but no later faster
candidate casualty.

INSTRUMENT: retain the Round-75/94 logic byte-for-byte for TTF<=20. The new
TTF21-30 band is anchored to the original scorer choice (no chained one-turn
steps), must be non-`NONE` and exactly one map turn faster, and requires an
all-kind starting roster, at least five live rivals, exact trap L2, zero
uncertainty, and an adjacent previously moved rival with the same velocity and
a lateral or nearly lateral offset. The landing must be non-sealable. Both
full-to-finish worlds must still hit the empty-map lower bound; an eight-round
six-rival scorer-field rollout must strictly improve both mover and aggregate
field; normal DJS remains downstream. No track or seed identity is encoded.

RESULT: Coil s6 move299 p3 changes `SW v(1,-6)->(0,-5) (65,49)->(65,44)`
to `W ->(0,-6) ->(65,43)`. The same seven finishers remain crash-free and
their move list improves `[58,60,61,61,61,62,63] ->
[58,59,59,60,61,62,62]`, sum 426 -> 421; no individual finisher slows.
The pre-mirror champion A/B over canonical regular seeds1-15 is 329/330 exact,
with this sole -5 change and
144791 -> 144786 total finisher moves. Coil seeds1-60 have no other change;
s47 and s49 are exact. Spa/Gear/Silverstone s1-60, the other 18 regular tracks
s1-15, slow 4x25, all three mixed 4v4 bands and Zandvoort/Chicane s31-60 are exact or
place-neutral with no candidate safety delta. Direct child-CPU timing assigns
roughly 0.23-0.30 seconds of extra work to the active proof, while paired wall
time stays inside identical-control noise. The mirrored regression pins the
exact move, finisher identities/order/personal moves, full AI1/AI2 normalized
log identity, and s47/s49 veto moves.

## Round 83 (local agent, IN GATES): static funnel guard for the frontier

THE FRONTIER'S PROMOTION BLOCKER, repaired. Verification of the
r79-r82 stack found it never-worse on every suite EXCEPT the zandvoort
doom band: 3 crashes (s32/s37/s44, new sites) vs the r78 champion's 1
-- "the inherited Zandvoort crash profile" of their own r82 notes.
s37/s44 die at the byte-identical corner state as the old s42; s32
dives the top-wall funnel.

THE INSTRUMENT (the recorded static-bottleneck direction, built):
Reachability now derives per-progress-ring corridor widths from the
distance map (ringWidth[d]; buildRingWidths) with two queries --
minRingWidthAhead (rings 0-2 = the finish mouth never count) and
narrowRunAhead (longest CONSECUTIVE narrow stretch). AI1's slow branch
fires funnelRisk = spdInf>=3 AND minRing<=4 AND spdInf>minRing AND
narrowRun>=6, escalating to the 8-round scorer-me certificate.
Measured discrimination: the zandvoort corner reads minRing=4 along the
whole descent; every open corridor measured >= 7 (silverstone s1
distribution).

EMPIRICAL REJECTIONS on the way (each a recorded law):
1. A FAST-branch funnel arm saved NOTHING (s32's cert reads the doomed
   line alive: the suppressed sim-me cannot reproduce the pace-arm
   aggression that kills -- certificates certify a cautious ghost) and
   broke the lemans-s3 staged-pace checkpoint via the same gap in
   reverse (suppressed-me DIES on their private-lane line that real-me
   survives). Dropped.
2. An unconditional deepHandled claim reshaped hungaroring s40 into a
   NEW crash with 531 fires and ZERO switches -- silencing downstream
   arms is a behavior change even when the arm itself never acts.
   Switch-only claiming is the law.
3. narrowRun>=4 still cost the hungaroring-s10 pace pin 2 moves;
   RUN=6 separates true funnels (the corner run) from long-but-straight
   narrow sections cars legitimately thread at speed.

RESULTS (frontier + funnel guard): zandvoort band 3 -> 1 = champion
parity; s37/s42/s44/s45 all crash-free; every counterexample fixture
clean (incl. their silverstone s15); all four AI1 checkpoints green;
goldens pass; the frontier's pace FULLY PRESERVED (-3.57 on the five
long tracks). OPEN (new class, recorded): zandvoort s32 -- last
avoidable at m110 (survivor SW, death @r6 at spd^2=58), invisible to
every certificate because the killer is the mover's OWN future
pace-arm aggression, which IN_SCORER_SIM suppression removes from
sim-me by design. The recursion boundary is now the frontier's
fundamental limit; closing it needs either bounded-depth true-me
rollouts or admission-level speed discipline in the pace arms
themselves. ROUND EXTENDED during gating: the first battery found a LEMANS 4-CAR
s1 crash -- the frontier's OWN (pure pre-guard stack crashes it
identically; their "small-field crash-free" gates raced MIXED fields
only, so the all-AI1 4-car hole was outside their coverage). Last
avoidable m131: p3 holds spd^2=85 into the bottom-turn complex, dies
@r8, survivors shed laterally. Fixed by RE-ADDING the fast funnel arm
with two additional laws learned the hard way:
- narrowRun>=6 alone did not stop the lemans-8car-s3 false fire, and
  CROSS-MODEL smom confirmation is NEGATIVE-VALUE for deep verdicts
  (it blocked the true sparse-field death without stopping the dense
  false one) -- removed;
- the correct trust gate is FIELD SPARSITY: deep 8-round verdicts
  track reality at <=AI1_FUNNEL_DEEP_FIELD=4 live rivals (the 4car
  geometric doom is model-robust at 3) and drift into false kills at 7
  (accumulated rival error); pace-arm precedence is NOT a shield
  (their 5-round certificates are blind @r8).

FINAL BATTERY (frontier + both funnel arms, vs the r78 champion):
never-worse everywhere, strictly better nearly everywhere -- 8car
770/0 x3 at -0.97/-0.99/-0.95 with ZERO slower tracks; h2h c=0 both
bands with places WON (4.474/4.478 vs 4.526/4.522); 4car 330/0 at
-0.64 (the crash repaired AND faster); 1v1 110/0 at -0.30; slow exact
tie. All four AI1 pins green; every counterexample fixture clean.
THE COMPOSITION IS PROMOTION-READY; the word is the user's.

MERGED RE-CERTIFICATION (2026-08-14): their round 90 (high-energy
forward-pack pace, PR #5) landed mid-battery; the full battery was
re-run on the merged head (r79-r90 pace stack + r83 funnel guards) and
came back BYTE-FOR-BYTE identical to the pre-merge sweep on every
stage total -- 770/0 x3 at -0.97/-0.99/-0.95 with zero slower tracks,
h2h places won c=0 both bands, 4car 330/0 -0.64, 1v1 110/0 -0.30, slow
exact tie. All pins and fixtures green on the merged head. The merged
composition is the promotion candidate.

## Master correctness/debloat pass (2026-08-13)

SCOPE: ported only behavior-neutral maintenance from the Round-82 PR onto the
promoted Round-78 champion. No private-lane or staged-pace frontier policy was
moved into master, and AI1/AI2 remain byte-identical in racing behavior.

CORRECTNESS: `RaceAi`'s recursive-scorer guard was mutable static state. Two
concurrent `RaceGame` instances in one JVM could therefore suppress each
other's endgame and danger machinery. The guard is now instance-scoped and a
core invariant rejects future mutable static fields in `RaceAi`. A second
master-only audit found two independent defects: the main-window race scroller
was sized from its container before Swing layout (leaving it 0x0), and failures
in the background reachability thread were swallowed, causing AI windows to
poll forever or callers to continue after interruption with a partial map.
The grid now uses normal layout management with a centered scrollable wrapper;
reachability completion records and rethrows background failures and fails
closed on interruption.

DEBLOAT: removed two guaranteed-zero conflict probes, duplicate reachability
lookups, repeated simulated-board occupancy loops, floating-point work for
integer speed thresholds, three unused parameters, and inaccurate relative-
speed helper naming. Squared distances use `long` arithmetic. Headless layout,
state-isolation and failure-propagation regressions now pin the repaired
boundaries. The full JDK-25/JDK-26 CI, frozen champion goldens, core tests,
headless smoke and tooling checks must remain green on the exact master head.

## OPEN CLASS (2 sites, ONE shape): the deep-horizon commitment class

Both remaining harvest-2 crashes classify IDENTICALLY, and the shape is
new: **zandvoort s42** (p6, death m614; sealed by m582, last avoidable
**m566** with SIX survivors, chosen SW dies @r6) and **coil s32** (p7,
death m319; sealed by m263, last avoidable **m247** with SEVEN
survivors, chosen NE dies @r9).

THE DEFINING PROPERTY: at both entries the faithful scorer-rival
replica is EXACTLY AS BLIND as the cheap one --
  zandvoort m566: chosen SW smom=alive t=67 tier=3, orivals=alive t=67 tier=3
  coil    m247:   chosen NE smom=alive t=22 tier=3, orivals=alive t=22 tier=3
(contrast the FIDELITY class -- m260/m103/m920 -- where orivals sees
DEAD@r2 and only the in-game model was blind). No model upgrade can
reach these: the deaths are 6 and 9 rounds out while every promoted
rollout horizon is 3-8, and the entries are open, roomy, tier-3 states
with no local danger signature at all. THE INSTRUMENT ITSELF IS
EXHAUSTED for this class; the fidelity ladder is finished.

Both survivors' signature is the same: at zandvoort m566 the chosen
holds spd^2=58 into the coming narrowing while survivors shed to 34-53;
at coil m247 the chosen holds spd^2=36 into a monotonically narrowing
spiral while survivors shed to 16-26. CANDIDATE DIRECTIONS (unclaimed):
(a) STATIC funnel/cut-set analysis on the reachability map -- the doom
is a track-topology property, visible without any rollout, and matches
AI_DEVELOPMENT.md's standing "bottleneck-aware triggers" direction;
(b) speed-vs-corridor-width certification at entry. Rollout deepening
is NOT the answer: 9-10 rounds at every fast fire is outside the
measured budget and r65 showed horizon alone perturbs fields into new
pockets.

## OPEN CLASS: coil s32 -- the 9-round commitment horizon (measured, unfixed)

Forensics on the second harvest-2 crash (p7, m319 death). The oracle
walk-back is the DEEPEST commitment the campaign has measured: sealed
by m263 (7 rounds out), and **m247 is the last avoidable move** --
SEVEN survivors on the table (NW/N/W/NONE/SW/S/SE, oracle t=20-21) and
the chosen NE dies @round 9. Every intermediate move (255-311) is
already lost.

WHY NO INSTRUMENT SEES IT: policy_matrix at m247 -- chosen NE
smom=alive t=22 tier=3 AND **orivals=alive t=22 tier=3**. This is NOT a
fidelity gap (unlike m260/m103/m920): the faithful scorer-rival world
is equally blind, because the death is 9 rounds out while every
promoted rollout horizon is 3-8. The class is a HORIZON limit, not a
model limit -- the first such class since the campaign began.

WHY NOT JUST DEEPEN: AI1_DEEP_HORIZON=8 already costs; a 9-10 round
scorer-rival rollout at every fast-pack fire is far outside the
measured budget (r73 measurements: ~20 ahead-pack fires/race), and the
r65 evidence says horizon alone perturbs fields into new pockets.
CANDIDATE DIRECTIONS (unclaimed, for a future round): (a) a cheap
STATIC funnel/cut-set test on the reachability map -- coil's spiral
narrows monotonically, so the doom is a track-topology property visible
without rollout; this is also AI_DEVELOPMENT.md's standing
"bottleneck-aware triggers" direction; (b) speed-vs-corridor-width
certification: at m247 the survivors all shed speed while NE holds
spd^2=36 into a narrowing spiral.

## Round 78 — scorer smoke test + scorer-me certification (PROMOTED 2026-08-12, per user)

Promotion executed: smoke test + escalation mirrored into AI2 (shared
scorerSelf machinery), strict probe ALL IDENTICAL 0/27, golden corpus
regenerated with the new `zandvoort-s45-8p` fixture pinning the rescue
(1177 turns, 7/0) and two intentional slow-class reflows (lemans-s4
crash-free, monaco-s9-4p crash-free and 3 turns FASTER); every other
hash unchanged. Docs record the eighth bounded safety proof.
POST-PROMOTION SELF-TIE BATTERY CERTIFIED: probe 0/27 and ALL 8 stages
exact self-ties with zero crashes anywhere -- 770/0 x3
@63.69/63.66/63.64, h2h 4.500 c=0 both bands, 4car 330/0/61.75, 1v1
110/0/60.64, slow 28/0/104.11. The canonical record is 2310/2310 again,
now with the r78 fidelity stack. Champion baselines re-seeded from the
self-tie logs (extract_baseline col=1 -> scratchpad/baseline_*.json).
AI1 and AI2 are identical again.

CAMPAIGN STATE after r78: the FIDELITY ladder is complete (every known
class where a faithful model sees a death the cheap model misses is
closed: r59 scorer rivals, r67/r71 dense packs, r73 ahead-corridor +
widened cap, r74 compressed queue, r78 smoke test + scorer-me). The
only open crash class is the DEEP-HORIZON COMMITMENT class above, which
that ladder provably cannot reach. Harvest-2 tally: 5 crashes found, 3
fixed, 2 open and classified.

## Round 78 (local agent, gates PASSED): scorer smoke test + scorer-me certification

THE ZANDVOORT-S45 FORENSICS found a TWO-LAYER gap at m920 (p8, spd^2=40
braking while p7 chases at spd^2=53 down the same straight):
1. TRIGGER: the r60 smoke test's smom-5 read the doomed chosen ALIVE
   tier-3 while orivals kills it @r2 -- the THIRD member of the
   nurburgring-m260 / interlagos-m103 fidelity class, this time a
   BEHIND-convergence (chaser), invisible to the ahead-gated corridor
   check and the pack gates.
2. CERTIFICATION (new gap class): the true survivor SE dies in BOTH
   offline worlds because both model ME as the selfMove proxy -- the
   survivor exists only under the champion's own continued play
   (oracle t=26). Even a perfect trigger had nothing certifiable to
   switch to: survival-only switching finds no survivor.

Per-shape trigger gates were measured and REJECTED before building
(chaser-converging slow moves: 121-235/race -- chasing is just racing).
THE FIX reuses existing surfaces and machinery, no new gates:
(a) the r60 smoke test (already on every trap-0 slow move) runs the
    SCORER-RIVAL world instead of smom -- the chaser lands in the
    round-59 nearest-3 set and the death is seen;
(b) new scorerSelf flag through simOutcome/dangerJointSearch: the slow
    escalation certifies ALTERNATIVES with a scorer-modeled me
    (scorerMoveOverState applied to myself, recursion-guarded exactly
    like scorer rivals). All other call sites byte-identical.

SITE PROOF: zandvoort s45 saved (ESC scorer-dies at m920, DJS switch to
SE simT=30, race 0-crash); BONUS: zandvoort s34 and hungaroring s40
also saved -- 3 of the 5 harvest-2 crashes killed by one upgrade; the
zandvoort doom band s31-45 improves 3 crashes -> 1. Coil s32 and
zandvoort s42 remain open (different classes). All promoted saves
intact; goldens pass; probe 2/27.

GATES vs the r75 champion: never-worse everywhere -- 8car 770/0 x3 with
exact-tie aggregates (63.69/63.66/63.64) and balanced +/-0.1 track
reflows (hungaroring +0.1 on s1-5, slalom -0.1/gear +0.1 on s6-10,
sprint -0.1/chicane +0.1 on s11-15 -- the safety-round reflow precedent
of r72); h2h c=0 both bands with places netting BETTER (4.494/4.499 vs
4.506/4.501); 4car/1v1/slow exact ties. COST: +29% wall on crawl-heavy
monaco (worst case), ties on fast tracks. ROUND 78 IS PROMOTION-READY;
the word is the user's.

## HARVEST 2 INTERIM (2026-08-12, local agent): fresh-seed crash rate up 5x

Phase 1 of the second fresh-seed harvest (8-car seeds 31-45, all 22
tracks, the r75 champion) found **5 crashes in 330 races**: coil s32
m319, zandvoort s34/s42/s45, hungaroring s40 (all last-runner deaths at
mid speed). ATTRIBUTION COMPLETE (A/B replays on the r74 and r71
champions) -- the initial "5x regression, hold promotions" reading was
WRONG and is retracted: **four of the five are ANCIENT classes** (coil
s32, zandvoort s34/s42, hungaroring s40 crash on the r71 champion too;
seeds 31-45 are simply doom-denser than 16-30, so the harvest-1
comparison conflated champion with seed band). The pace stack is NOT
implicated; in-flight pace gates stand. ONE genuine regression:
**zandvoort s45** -- clean on r71, crashes on r74/r75, introduced
somewhere in the r72-r74 window (trap-monotone / corridor /
compressed-queue). SYSTEMIC LESSON: the canonical seed-1-15 battery is
mined out as crash evidence; doom-dense fresh bands (zandvoort 31-45
foremost) should join future promotion gates. The five sites are the
open counterexample queue; forensics follow harvest completion.

## Round 77 (local agent, REJECTED at stage 1): strict filter overreach

The r76 refinement executed: certified trap<=L2 faster lines must now
STRICTLY IMPROVE the widened scorer-rival final tt vs the incumbent
(incumbent sim evaluated lazily, cached per turn) -- survival alone let
empty-track-faster lines lose their gain to traffic. On the exact r76
failure band (seeds 6-10, 5 tracks): the zigzag regression is GONE
(within rounding), interlagos/spielberg/lemans each -0.1, spa tied,
TOTAL -0.06, 0 crashes. BUT the probe showed the true footprint: 21/27
races divergent -- the strict filter did not only gate the NEW L2
admissions, it ALSO stripped the promoted trap-0/smom-3 r58 behavior
(proven lines now rejected for not beating the incumbent in-sim).
STAGE 1 VERDICT: 769/1 (A CRASH) with FOUR tracks +0.1 slower
(silverstone/monaco/spielberg/lemans) and aggregate +0.01 -- rejected
on the spot, battery aborted, arm reverted.

LESSON (the certified-pace ladder): the r58 trap-0 + smom-3 admission
is load-bearing champion behavior -- filters may only be ADDED to new
admission classes, never substituted under existing ones. NEXT ARM
(recorded): two-tier admission -- keep r58 byte-identical for trap==0
lines; require the widened scorer-rival STRICT-IMPROVEMENT certificate
only for the newly admitted 0<trap<=L2 lines. The r76/r77 evidence pair
suggests the L2 class carries the zigzag risk (r76) while the trap-0
class carries the broad pace (r77), so the two-tier split is exactly
the shape both rejections point at.

## Round 76 (local agent, REJECTED under the no-slower-track standard)

The r58 certified-pace override composed with the r75 finish sprint:
admit trap<=L2 (0.5) strictly-faster lines (was trap==0.0 only) and
certify with the widened scorer-rival world (cap AI1_DEEP_CERT_RIVALS=6,
AI1_DJS_ROUNDS) instead of smom-3 -- the world the r73/r74
counterexamples proved blind at pack sites. Weaker filter, stronger
proof. AI1 only; AI2 mirror untouched.

HISTORY: originally gated clean as a round-75 candidate vs the r74
champion (770/0 x3 with -0.01/-0.01/+0.00; h2h c=0 both bands, places
net better on aggregate) -- superseded mid-flight by the finish-sprint
promotion and renumbered. RE-COMPOSED on the new champion: 6-track
seeds-1-5 bench -0.01 total, interlagos -0.1, lemans a hair faster, NO
TRACK SLOWER (spa -- the rejected remote arm's failure track -- exactly
tied), 0 crashes. Probe on the composition: 3/27 divergent (a pace arm
should fire; divergences bench-verdicted). FULL-BATTERY VERDICT
(2026-08-12): zero crashes everywhere, aggregate -0.01 on 8car s6-10
(63.65 vs 63.66) with s1-5/s11-15 exact ties, h2h/4car/1v1/slow ties --
but the per-track sweep found **zigzag s6-10 +0.1 slower** per finisher
(vs interlagos -0.1 and spielberg -0.1 faster). The same signature that
rejected the remote comparative-certificate arm; the standard applies
symmetrically, so the arm is REJECTED in this form and reverted from
master (the ledger record stays). REFINEMENT PATH for a future round:
the 3 probe-divergent races pinpoint the fire sites -- bisect which
certified-L2 fire slows zigzag s6-10 and tighten the admission (e.g.
require the certified line to also be strictly better on the
scorer-rival final tt, not merely surviving). The instrument itself
(widened scorer-rival certification) remains promoted and trusted via
r73/r74.

## Round 75 - dual-model finish sprint (PROMOTED 2026-08-12)

REFRESH: local and `origin/master` began at the Round 74 champion `b5348a9`.
The fresh `origin/agent/random-track-speedups` branches contained only a
temporary source-export workflow and no racing-code candidate, so the round
was derived locally. The pre-existing primitive-geometry experiment remains
preserved in `stash@{0}` and was not applied or dropped.

FORENSICS: a component-level scan of Monaco eight-car seed 16 found a genuine
late-race pace concession at global move 789. Player 5 at `(5,95)`, velocity
`(1,-6)`, chose `S`, landing at map ttf 15. `SW` lands at ttf 14 but carries a
higher local trap price. Faithful joint replay showed `SW` finishing in exactly
14 rounds and `S` in 15; every other candidate died. The simulation must run
`ttf+1` rounds because its first partial round contains only players after the
mover. Earlier apparent one-turn concessions were rejected when longer oracle
rollout showed equal actual finish rounds.

FIX: when the scorer is within 15 empty-map turns of the flag, examine only
strictly faster candidates at trap tier L1 or better. Accept one only if two
independent joint worlds - exact self with score-shaped rivals, and exact self
with up to six real-scorer rivals - both return finish at the candidate's
empty-map lower bound. The normal danger-joint search still runs afterwards as
an independent survival veto. A 110-race seeds-1-to-5 trigger audit observed
100 successful certificates, all at ttf 14 or below; the cap remains 15 to
avoid overfitting future races to that sample.

GATES: across all 22 tracks, the three eight-car bands were 770/0 vs 770/0
with mean finisher moves 63.69 vs 63.82, 63.66 vs 63.79, and 63.64 vs 63.78;
no track was slower. Mixed 4v4 won all three bands at zero crashes:
4.483/4.517, 4.483/4.517, and 4.475/4.525. The 2v2 gate slightly won
2.498/2.502, 1v1 tied 1.500/1.500, and slow mode improved 140/0 at 104.16
vs 140/0 at 104.27. Seven warm interleaved Monaco seed-16 pairs measured a
small compute overhead (1.8% trimmed mean, 3.2% median), accepted for the
verified on-track pace gain.

PROMOTION: the rule was mirrored into AI2 and the nine-track x three-seed
strict probe returned 0/27 divergences. JDK warning-as-error compilation, 26
track-data tests, core/main tests, headless smoke and all eleven golden races
pass. Five existing golden races become 1-6 turns faster with zero crashes;
five old hashes remain byte-identical. The new `monaco-s16-8p` fixture pins
950 turns, 7/0, hash
`67c69dacd5844cc0a4aa8d31b4b43b2c9be87398221ef3b3fe5dedfb24a45f4b`.
AI1 and AI2 are identical again.

REMOTE FOLLOW-UP (REJECTED): the final pre-push fetch revealed the newly
published `origin/agent/ai-pace-round-75` at `d49e9eb`. Its AI1-only
comparative eight-round certificate was composed on top of the promoted
finish sprint and evaluated against Round 75 AI2, rather than trusted against
the older base used by the branch. The nine-track x three-seed probe changed
seven races with zero crashes, but only Hairpin seed 2 immediately saved a
turn; Interlagos and Hungaroring reflowed at equal pace, while Nurburgring
redistributed finisher turns without reducing the total. The full 22-track
seeds-1-to-5 band remained 770/0 on both sides and was effectively flat
(63.68 vs 63.69), while making Spa and Zandvoort about 0.1 move per finisher
slower; Nurburgring and Coil gained about 0.1. The complete A/B took 479.5s.
This fails the no-slower-track standard and adds expensive deep rollouts for
a negligible aggregate result, so the remote candidate was removed. Its
branch remains available for future forensic ideas; none of its code entered
the champion.

## Round 74 — compressed rear-queue certificate (PROMOTED 2026-08-11)

REFRESH: `origin/master` was already at the local Round 73 plus primitive
edge-cache champion (`998d48d`). The fresh `origin/agent/ai-round-74` and
`origin/agent/ai-speedups-75` branches contained source-export workflows,
not candidate racing code; `origin/agent/random-track-speedups-76` pointed
at `998d48d` with no distinct commit. This round was therefore derived
locally from new races.

FAILURE HARVEST: the regular 22-track suite over seeds 16-20 completed all
110 eight-car races with 770/770 finishers and zero crashes. Extending the
historically hard tracks over seeds 21-50 found the first failure after 19
more races: Zigzag seed 22, player 8 crashing at global move 104. Exact
oracle replay found move 72 as the last avoidable decision: from `(51,55)`
at velocity `(8,0)`, champion `S` is doomed while `NW` and `N` survive at
least 14 rounds. The empty-track map gives all three the same ttf=56, and
the smom model reads `S` alive/tier-3 at every tested horizon. The faithful
scorer-rival model instead proves `S` dead at round 2 while retaining both
escapes. This is the side/rear complement of Round 73's ahead-convergence
failure, not a horizon shortage.

FIX: inside the existing fast deep-pack blind-alive path, invoke the widened
six-rival scorer certificate when the whole seven-rival field is within
Chebyshev radius 10, at most one rival is ahead, at least two rival bodies
already occupy the mover's neutral 3x3 landing grid, and a near-equal low-trap
escape exists. The switch remains survival-only. At the target it changes
`S` to `NW` and converts 6 finishes / 1 crash to 7 / 0. The structural gate
occurred 13 times across the 129 harvested logs, in only six races; five
remained move-identical and only Zigzag s22 changed.

PROMOTION GATES: all three canonical eight-car bands remain exact champion
ties with zero crashes: 770/0 at 63.82, 770/0 at 63.79, and 770/0 at 63.78.
All three 4v4 bands are exact 4.500/4.500 ties with zero crashes; 2v2 is
2.500/2.500, 1v1 is 1.500/1.500, and slow mode is 28/0 at 104.25 for both.
After mirroring AI1 into AI2, the nine-track x three-seed strict probe is
0/27 divergent, Java tests/build and headless smoke pass, and all ten golden
races pass. The additions-only `zigzag-s22-8p` fixture pins 529 turns, 7/0,
hash `ca4ab1d3f7ab66277f3cca60d1376544e115f1742ab91f08551195d3759de606`.
AI1 and AI2 are identical again.

## Round 73 — certified corridor check (PROMOTED 2026-08-11, per user)

Promotion executed: the corridor check mirrored into AI2 (shared
scorerCap machinery; AI2 mirror comment convention), strict probe ALL
IDENTICAL 0/27, golden corpus regenerated ADDITIONS-ONLY (every prior
hash unchanged -- the check is inert on all existing fixtures) with the
new `interlagos-s10-8p` case pinning the save (1049 turns, 7/0), docs
updated (sixth bounded safety proof). POST-PROMOTION SELF-TIE BATTERY
CERTIFIED: probe 0/27, ALL 8 stages exact self-ties with ZERO crashes
anywhere -- 770/0 x3 @63.82/63.79/63.78 (the s6-10 slice back to
crash-free), h2h 4.500 c=0 BOTH seed bands, 4car 330/0/61.81, 1v1
110/0/60.64, slow 28/0/104.25. The canonical record is 2310/2310 again.
Champion baselines re-seeded from the self-tie logs (extract_baseline
col=1 -> scratchpad baseline_*.json; consumed via BENCH_BASELINE). AI1
and AI2 are identical again.

## Round 73 (local agent, gates PASSED): certified corridor check for convergence dooms

THE R72 PROMOTION REGRESSED INTERLAGOS: the post-promotion self-tie
battery (both bodies = r72 champion) came back 769/1 on 8car s6-10 --
interlagos s10, p7 crash at m143 (plus 1 crash in mixed h2h s6-10, same
track/seed band). The old champion is 770/0 head-to-head on the same
seed. Their round-72 split gates HAD flagged "interlagos s10", but the
promotion evidence re-checked only interlagos FOUR-car; the 8-car slice
regressed. Root shape: the trap-monotone guard changed a slow
start-funnel choice at m19 (p3 SW->S), and the perturbed field reached a
LATENT doom pocket 124 moves later -- the ancestral-perturbation class,
so the fix targets the latent weakness, not the (principled) r72 gate.

FORENSICS: p7 fully sealed by m127; **m103 is the last avoidable move**
(chosen NE, accel to spd^2=68; survivors NONE/E/S all brake/hold, oracle
t=105). The 3-round fast DJS world misses the @r5 death; the r65 smom-8
deep pre-screen read it ALIVE **tier 3** (not even fragile -- silent
keep). policy_matrix: chosen NE smom=alive t=104 tier=3 vs
**orivals=DEAD@r2** -- the SECOND member of the nurburgring-m260
fidelity class, and this one at speed. The kill is CONVERGENCE: the
killers (p4/p6/p1, ranks 4-6 by landing distance) brake INTO the
shedding corridor over r1-3.

NEGATIVE RESULT (recorded): a frozen-rival triage (rivals held static)
does NOT see convergence dooms -- the killers start OUTSIDE the corridor
and move in; static pessimism points the wrong way. Only faithful
forward rival models see it. Also decisive: the round-59 nearest-3
scorer set at m103 is exactly the harmless REAR queue (p2/p5/p8); the
killers are beyond the cap -- the MAXRIVALS fidelity gap biting in the
wild, as predicted in the round-72 review.

R73 FIX (AI1): in the deep block's blind-alive path (smom-8 alive and
non-fragile), with >= AI1_DEEP_PACK rivals AHEAD of the landing
(positive dot with the landing velocity, Cheb 10), run the certified
scorer-rival DJS at the widened **AI1_DEEP_CERT_RIVALS=6** cap
(simOutcome/dangerJointSearch got a scorerCap parameter; all existing
call sites keep the round-59 cap of 3). Survival-only switch as
everywhere. Trigger rates measured over the 330-race harvest BEFORE
building (the law): fast&pack>=3 48/race (= existing pre-screen rate),
fast&ahead>=3 19.8/race, at spd^2>=64 11.0/race; in-race CORR fires ~16
on interlagos s10. Spot saves: interlagos s10 0 crashes (CORR at m103,
chosen DIES in certified sim, switch), s6-9 clean, nurburgring s19 7/0
and monaco s9 intact. GATES COMPLETE (2026-08-11): probe 0/27 inert; never-worse on all 8
stages with BOTH regression stages strictly improved -- 8car s6-10
770/0/63.79 vs the champion's 769/1/63.79 (interlagos row 35/0 vs 34/1)
and mixed h2h s6-10 c=0 (4.498) vs c=1 (4.502); everything else exact
ties (770/0/63.82, 770/0/63.78, h2h 4.500 c=0, 4car 330/0/61.81, 1v1
110/0/60.64, slow 28/0/104.25). ROUND 73 IS PROMOTION-READY; the word
is the user's.

## 2026-08-11 speedup: primitive geometry-edge cache (behavior-invisible)

Pulled the Round 73 champion at `76ff22f` and re-profiled both cold and
warm Nurburgring seed 19. The remaining shared-runtime allocation hotspot
was the geometry cache's `HashMap<Long,Boolean>`: every lookup boxed the
mixed edge key, and every new edge also allocated a node and boxed value.

FIX: `RaceGame.EdgeLegalCache` is a single-writer open-addressed primitive
long-to-boolean table. A state byte distinguishes missing, false and true,
so zero and every other 64-bit key remain valid. It grows at two-thirds
load and retains the bijective SplitMix key finalizer. Direct tests cover
misses, both values, zero/high-bit keys, updates and a 10,000-entry resize.

MEASURED (three cold and five warm interleaved pairs, separate disk caches):
Nurburgring seed 19 cold median 13.533s -> 12.628s (**6.7% faster**), warm
median 2.584s -> 2.535s (**1.9% faster**). All 16 measured logs had one
SHA-256 hash. Warm JFR `Long.valueOf` allocation pressure fell from 21.46%
to 2.81%. Validation: Java unit suites, headless smoke, all nine golden
races, strict 27-case AI1/AI2 probe, and cold/warm reach-cache log+dump
comparison all pass.

REJECTED FOLLOW-UP: primitive blocked-cell and long-to-double mobility
tables were not kept. A separate nine-pair warm A/B against the edge-only
build was slightly worse: median 2.564s vs 2.533s and trimmed mean 2.546s
vs 2.525s (0.8% slower), despite exact logs. Do not repeat without a design
that reuses storage across turns and proves a gain.

## 2026-08-11 speedup: reachability disk cache (behavior-invisible)

JFR profiling of a nurburgring race showed the CPU is dominated by
REACHABILITY CONSTRUCTION, not AI search (post int-array):
isMoveLegalGeometryCached+isMoveLegalGeometry ~2300 samples and
computeReachability ~1950 vs ~180 for the AI search stack. The BFS is a
pure function of track geometry (seeds only move start placements) yet
every race recomputed it — 12-17s per nurburgring-class race, and the
whole EDT wait the user hit interactively.

FIX: cache turnsArr + the legal-alive mask per geometry hash
(SHA-256 over cols/rows/vmax/border points) in
%LOCALAPPDATA%/theoreticRacing/reach_cache (RACING_REACH_CACHE
overrides; NOT the install dir — OneDrive must not sync multi-MB
caches). Load re-derives the cheap roomy/shed/cert sweeps (~0.3s pure
array passes). The legal-alive mask MUST be stored: rebuilding it cold
pays nearly the full geometry bill again (the mask pass relies on the
edge cache the BFS warms). Atomic tmp+move writes (pid-suffixed);
any validation/IO failure falls back to a fresh compute.

MEASURED (nurburgring s19): cold bfs=12406ms -> warm total=358ms (~35x).
PROOF (tracks/verify_reach_cache.sh): byte-identical race logs AND
byte-identical --dump-reach maps cold vs warm, on nurburgring and
sprint. Benches inherit the speedup automatically (same jar, shared
cache dir); the forensic dump format and oracle tooling are untouched.

NEXT SPEEDUP TARGET (recorded, unclaimed): a segment-legality bitset
inside the BFS/mask — geometry queries repeat massively across velocity
states; a flat (x,y,dx,dy) bitset (~2MB) could halve the remaining cold
compute. Overlaps the runtime-cleanup territory of the other agent's
int-array line — coordinate via this ledger before building.

## Round 72 — trap-monotone seal guard (PROMOTED 2026-08-10)

### Failure class

The 770-race fresh-seed harvest left one eight-car crash after Round 71: Nurburgring seed 19. At player 4 move 260, the main scorer selected `N` with score 64.275 and trap penalty 0.5. The legacy `sealGuard` then discarded it as worst-case sealable and selected the fastest unsealable alternative, `E`, despite `E` scoring 73.161 with trap penalty 2.0. `E` entered the doomed thread and player 4 crashed at move 292; the scorer's original `N` was oracle-alive.

This is the same structural disease seen in earlier pace regressions: an auxiliary selector ignored the scorer's load-bearing trap ladder. The seal proof is useful, but it is not coherent to avoid a theoretical future box by choosing a state with strictly fewer safe local continuations.

### Change

The seal guard now accepts an unsealable replacement only when its trap penalty is no worse than the scorer choice. The existing geometry, occupancy, alive-state and fastest-time requirements remain unchanged. No score threshold or track-specific constant was added.

### Evidence

- Nurburgring eight-car seed 19: 6 finishes / 1 crash / 698 turns becomes 7 / 0 / 760. The rescued car completes the race rather than disappearing early, so total turns rise as expected.
- Mixed Nurburgring seed 19: AI1 0 crashes versus pre-promotion AI2 1 crash. Mean place moves 4.625 versus 4.375 because the rescued back-marker now occupies a finishing place; crash count is the governing metric for this safety proof.
- Le Mans seed 4, Hungaroring seeds 6 and 20, Monaco four-car seed 9, and Interlagos four-car seeds 3 and 4 remain move-for-move identical to Round 71.
- Short-track eight-car A/B, seeds 1–5 on sprint, hairpin, triangle, chicane and curve: 23 of 25 logs exact. The two seal-guard divergences are both crash-free; sprint seed 5 costs one turn and chicane seed 4 saves one, for net zero.
- Four-car seeds 1–5 on sprint, hairpin, triangle, chicane and bigoval are all exact.
- New frozen golden fixtures pin Nurburgring eight-car seed 19 and Monaco four-car seed 9.
- The pre-existing zigzag eight-car seed-4 fixture changes safely: 7 finishes / 0 crashes remain unchanged, total turns improve from 532 to 530, and the middle finishing order reflows. Its hash/summary are deliberately promoted with the policy.

Round 72 was promoted into both AI bodies. AI1 and AI2 are identical again.

### Open frontier recorded at review (local agent, merge-preserved)

The trap-monotone gate removes m260 from the decision path but the
ROLLOUT FIDELITY GAP it exposed is still real and unfixed: the in-game
scorer-rival rollout read the doomed E ALIVE (t=58) while orivals sees
DEAD@r2. Review discrimination of the r71 suspects: the me-proxy is
ELIMINATED (orivals uses the same selfMove me and still sees the death);
prime suspect is **AI1_SCORER_MAXRIVALS=3** -- rollout membership is the
3 nearest rivals of my landing, fixed at start, so at crawl queues
(~7 near rivals at m260) the actual box formers run the drifting smom
proxy and the box never forms in-sim. Second suspect: the
IN_SCORER_SIM suppressions (1v1 solver, certified-pace, certified-UNC,
all DJS machinery are OFF for sim rivals; the sealGuard runs). Fallback
arm for a future round if the class resurfaces: parameterize the scorer
cap (dense/certification fires get the whole near field, ordinary slow
fires keep 3), then a survival-only certified sealGuard swap. Anchor
soundness of the promoted gate was verified locally: every
guard-eligible direction is also scored, so no swap target carries a
phantom zero trap tier.

---

## Round 71 — fresh-seed harvest + small-field pack gate (PROMOTED WITH ROUND 72)

COUNTEREXAMPLE HARVEST on the round-70 champion: 770 fresh races (8-car
s16-30, 4-car s6-15, 2-car s6-15, all 22 tracks) found exactly TWO
crashes -- strong generalization evidence for the mechanism stack.

1. **monaco 4-car s9 (FIXED AND PROMOTED): the small-field funnel class.**
   Entry m27 (spd^2=13, all 3 rivals within Chebyshev 10): chosen NONE
   dies @r3 with survivors N/SE (oracle). smom is BLIND and NON-FRAGILE
   (alive t=100 tier=3) but orivals sees DEAD@r2 -- only the trigger was
   missing: the round-67 dense-pack gate requires sealRivals >= 7 and
   spd^2 >= 16. R71 FIX (AI1): generalize to small fields --
   whole-live-field-packed + closeEscape with sealRivals >=
   AI1_SLOW_PACK_MIN=3 and spd^2 >= AI1_SLOW_PACK_SPD2_SMALL=12 (start
   grids stay below). Race saved (26 escalations, 3 verdicts, 2
   switches); 8-car keeps the original 7/16 gate.
2. **nurburgring 8-car s19 (FIXED BY ROUND 72): compound sealGuard +
   fidelity failure.** Entry m260: the scorer's own argmin picked the
   oracle-alive N (score 64.28) but the SEALGUARD swapped to the doomed
   E (73.16 -- trap 2.0 + unc 3.46 + ce 4.16 ignored by the "fastest
   unsealable" rule): a paranoid 1-ply sealability distinction discarded
   a 9-point score advantage, the round-35 disease resurfacing in an
   auxiliary selector. The trap trigger then fired and the 6-round
   scorer-rival rollout said ALIVE though the death is @r4 real /
   DEAD@r2 under orivals -- the in-game rollout behaves like smom at
   crawl-queue sites (both matrix rows measured; smom blind t=58
   tier=3). Round 72 fixes the earlier selector error directly: an
   unsealable replacement may no longer worsen the scorer's trap tier.
   The deeper rollout-fidelity mismatch remains a research topic, but it
   is no longer on the decision path for this counterexample.

**Promotion result:** the small-field gate was promoted with Round 72. On Monaco four-car seeds 6–10 it improves 14 finishes / 1 crash to 15 / 0; the target 2v2 seed keeps exact 2.500 place parity while removing the crash.

**Certification record (merge-preserved):** round 71 was fully gated
TWICE before promotion -- on the pre-int-array body (r71g) and again on
the int-array body (r71b) after the rework landed mid-round: probe 0/27
inert both times, monaco s9 save exact both times (0 crashes, 26
dense-pack escalations), and ALL 8 battery stages exact ties both times
(770/0 x3 @63.81/63.78/63.77, h2h 4.500 c=0 x2, 4car 330/0/61.81, 1v1
110/0/60.64, slow 28/0/104.25). The composition on the int-array body
was committed by the user (d413cf9) with goldens hash-identical.

## 2026-08-09 round-70 promotion: close the four-car Interlagos gap

**Round 70 was the champion at this point; AI1 and AI2 were identical at rest.**
The only known round-69 promotion-battery failures were four-car Interlagos
seeds 3 and 4. Both converge to the same p4 trajectory and crash at move 480.
The generalized four-car oracle reproduced 20 logged moves exactly and found
move 456 as the last save: from `(53,155) v(-5,-1)`, champion `W` dies at the
six-round frontier, while `NONE`, `E`, `S` and `SE` all finish. The existing
slow danger rollout stopped at five rounds and therefore called `W` alive.

Round 70 extends the scorer-rival verdict to six rounds **only** for slow
chosen moves already at trap tier L1 (penalty 2.0). It switches `W -> NONE` in
the shared failure board. Promotion evidence:

- full 22-track four-car s1-5: **330/0/61.81 vs round-69 328/2/61.79**;
  every track except Interlagos is exact, and the move-average increase is the
  two rescued third finishers;
- mixed 2v2 s1-5: exact **2.500/2.500** place parity, crashes **0 vs 2**;
  Interlagos s1-15 also keeps 2.500 parity while improving crashes **0 vs 7**;
- canonical eight-car s1-5: exact **770/0/63.81** in both bodies;
- 1v1 s1-5: exact **1.500/1.500**, zero crashes; slow suite: exact
  **28/0/104.25**; the pre-promotion 27-race eight-car screen was inert.

The forensic tools now infer active player count from each log; `oracle_roll`
also accepts `RACING_PROPS`, and its rollout/verification loops use the actual
field length rather than a hard-coded eight. This makes the same exact-oracle
workflow reusable for 2-, 4- and 8-car failures.

## Superseded champion: round-69 promotion and runtime cleanup

**Round 69 was the prior champion; AI1 and AI2 were identical at rest.**
It builds on the round-68 dense slow-pack champion and promotes a new
cross-model survivor certificate:

- Hungaroring seed 20: the old line chooses `NONE` at p5 move 181, enters an
  oracle-proven doom and crashes at move 221. The topology-shaped eight-round
  model proves that locally narrow pick dies and proposes `NE`; the independent
  scorer-rival model must also certify `NE` alive before the switch is allowed.
- The broad cross-model rule was REJECTED after it created a Hungaroring seed-6
  crash. Requiring the current pick's trap penalty to be at least 0.5 removes
  that false switch while retaining the seed-20 rescue.

Promotion evidence: the round-69 candidate column in the full default 22-track
seeds-1-to-5 self-play gate was **770/0/63.81**; the round-68 champion baseline
was **770/0/63.82**. Difficult-track fresh seeds and synthetic gates added no
candidate crashes; affected-track mixed fields over seeds 1-15 slightly favored
AI1, and Hungaroring seeds 16-25 mixed
fields favored AI1 in both place and crashes. After mirroring into AI2, the
nine-track x three-seed probe was **27/27 move-identical**. JDK-25 warnings-as-
errors compilation, 26 track-data tests, core tests, headless smoke and all six
golden races passed. Round 69 does not require a new golden fixture; the
round-68 corpus already records the Le Mans rescue and one-move Zigzag seed-4
pace/order change.

Shared behavior-preserving cleanup shipped with the champion: a cached
`Direction.values()` array; one opponent mobility projection and transposition
memo per real turn instead of rebuilding them per candidate; and a bijective
SplitMix64 finalizer on packed edge-cache keys to avoid `Long` hash bucket
clustering. Focused A/B measurements were 29.5s without the mobility memo versus
20.6-20.7s with it under the exercised load; repeated reachability median was
1.915s versus 2.160s on untouched HEAD (about 11%). Do not reinterpret those
focused measurements as a whole-benchmark speedup.

## 2026-08-07 repository and AI1 frontier update

The repository now has portable JDK-25+ build/test scripts, genuine Linux
headless auto-play, lint-clean dependency-free unit tests, structural checks for
all bundled tracks, a deterministic AI2 golden-race corpus, a cheap AI1/AI2
move-log probe, and a manual nine-stage GitHub Actions promotion battery. The
benchmark now uses isolated temporary properties/logs and fails non-zero on
invalid Java runs. `user.properties` and Eclipse metadata are no longer tracked.

Two source defects were fixed in both bodies before new experimentation:
`RaceGame.gameLogPath()` no longer recurses, and `futureMobility4` now excludes
the correct one-based player number. AI1 and AI2 remain separate full scorer
bodies by user choice.

**Round-67 candidate record (promoted as part of round 68): dense slow-pack
escape proof.** In the sole canonical round-66 failure (Le Mans seed 4), the victim
entered a moving eight-car funnel at move 55 while the cheap smom model missed
the future box. AI1 now escalates trap-0 slow moves only when all seven live
rivals are within Chebyshev 10, landing speed^2 >= 16, and a near-equal low-trap
alternative exists. The real-scorer-rival rollout changes p7's move 55 SE->SW
and converts 6 finishes / 1 crash into 7 / 0.

## Superseded champion (round 68, promoted per user 2026-08-08)

**The round-66 base + the other agent's futureMobility4/gameLogPath
fixes (both bodies) + the round-67 dense slow-pack escape proof,
mirrored into AI2: on trap-0 slow moves, when the WHOLE live field is
packed within Chebyshev AI1_SLOW_PACK_R=10 of the landing (sealRivals
>= AI1_SLOW_PACK=7, spd^2 >= AI1_SLOW_PACK_SPD2=16) and a near-equal
low-trap alternative exists, the scorer-rival rollout arbitrates even
when the smom smoke test reads alive -- the lemans-s4 funnel.**
Canonical numbers (both columns live, post-fix): **8-car s1-5
770/0/63.82; s6-10 770/0/63.78; s11-15 770/0/63.76 -- 2310/2310, the
first ZERO-CRASH 15-seed battery in campaign history; h2h 4.497/4.497
(places won both sets) c=0; 4-car 328/2/61.79 (see interlagos note);
1v1 110/0/60.64; slow 28/0/104.25.** Round-67 vs the fixed champion
was never worse on any stage. Self-tie: inert_probe 27/27
move-identical; caches re-seeded from the r67 AI1 columns; golden
corpus regenerated (lemans-s4-8p now pins 7/0, case renamed from
-known-crash).

RESOLVED BY ROUND 70 -- forensic anatomy (local agent's oracle
walk-back, which both agents' fixes address): the interlagos 4-car
crashes were ONE deterministic doom reached from two seeds
(byte-identical deaths at m480), an ENDGAME finish-corridor class. The
scorer takes the fastest line (m456 W, speed 6, t=14) into a corridor
whose exit two crawling rivals consume; options narrow 5 -> 2 -> 1 -> 0
over four rounds; at m476 the only open cell is segment-illegal so the
scorer regresses to the foresight-free bestLegal path (reach-dead
candidates are skipped before scoring at `ownTurns == MAX_VALUE`). The
trap trigger FIRED at the m456 entry and the scorer-rival rollout RAN
-- but the death sits at ROUND 5, one beyond AI1_DJS_SLOW_ROUNDS=5,
while four healthy survivors existed (oracle m456: NONE/E/S/SE all
finish, t=9). The DJS then diagnosed "DIES, no survivor" correctly at
m460-472 -- true but too late.

CONVERGENT FIXES, one shipped: both agents independently built the
horizon extension the same day. The other agent's promoted round 70
(slow L1 traps -> 6 rounds) is the cheaper variant and empirically
saves both interlagos races (verified locally on the promoted build);
the local agent's variant (endgame-gated: sealRivals <= 3 && landing
ttf <= 20 -> 8 rounds) gated fully clean against BOTH champion bases
(probe 0/27; 8car exact ties x3; h2h parity c=0; 4car 330/0/61.81 vs
328/2; 1v1/slow ties) but was DROPPED as redundant per the
one-proof-one-mechanism law. If a future endgame doom enters through an
L2-severity trap (their L1 gate would miss it; the endgame gate would
not), the dropped variant is the ready answer.

## Superseded champion (round 66, promoted per user 2026-07-28)

**The round-63 champion PLUS the round-65 pack-gated deep escalation,
mirrored into AI2 (one call-site branch; the simOutcome outFinalTier
overload and constants were already shared): fast fires with >= 3
rivals within Chebyshev 10 of the landing run the cheap smom pre-screen
at horizon 8 and escalate to the scorer-rival world on a
dead-or-FRAGILE (final tier <= 1) verdict.** Canonical numbers:
**8-car s1-5 769/1/63.81; s6-10 770/0/63.79; s11-15 770/0/63.79
(2309/2310 finishers, the sole crash = lemans s4, provably invisible);
4-car 330/0/61.84; 1v1 110/0/60.62; slow 28/0/104.25.** Self-tie:
inert_probe 27/27 move-identical + bench-vs-cache per-track rows
identical. Caches re-seeded from the r65 gate's AI1 columns. Both AI
bodies identical again; AI1 free to diverge.

## Superseded champion (round 63, promoted per user 2026-07-26)

**The round-58 base (DJS + sealfix + 1v1 solver + certified pace
tie-break + exact-self/finish-vanish + wide speed trigger + smom rival
sim) PLUS the rounds 59-62 stack, mirrored into AI2 via
patch_promote_r62.py: (r59) recursion-guarded REAL-SCORER rivals for
slow-class DJS fires (scorerMoveOverState, nearest 3 within Chebyshev
10, horizon 5); (r60) the trap-0 smom smoke test escalating to the
scorer rollout on a death verdict; (r61) rival-conditional trap relief
(L1/L2 waived with no rival within Chebyshev 16 of the landing); (r62)
the certified UNC override (pay unc except where a strictly faster line
wins the unc-free comparison AND passes zero-trap + !sealable +
scorer-rival survival).** Canonical numbers: **8-car s1-5 769/1/63.81;
s6-10 769/1/63.78; s11-15 770/0/63.78; 4-car 330/0/61.84; 1v1
110/0/60.62; slow 28/0/104.25.** vs the round-58 champion: 8-car
crashes 2 vs 6 over 15 seeds at mv -0.22 uniform; h2h places won on
ALL THREE seed sets (4.483/4.481/4.465) at 15-seed crash parity 5-5;
4car/1v1/slow all faster, all crash-free. Residual crashes (2/15
seeds): lemans s4 (smom-invisible funnel) + hairpin s10 (strategic,
doomed 7+ rounds out) -- both oracle-classified beyond rollout reach.
Self-tie verified: inert_probe 27/27 move-identical + 22-track
bench-vs-cache exact tie; caches re-seeded from the r62 gate's AI1
columns. Both AI bodies identical again; AI1 free to diverge.

(Superseded: round-58 champion 47b74c8, canonical 768/2/64.04;
round-54 C+2 champion 4df1866, canonical 767/3/64.04; round-44
champion b0f64c5, canonical 767/3/64.07; round-40 DJS-only champion
9ad009b, canonical 767/3/64.06.)

## Rounds 55-57: the queue-box class cracked (candidate in gates)

The remaining crash class was named in round 44 ("a body takes the escape")
and this arc finally REPRODUCED it in-sim. Story, laws and tools:

- **R55 (wide DJS trigger, AI1_DJS_SPD2=49): byte-inert alone, KEPT as
  enabler.** Landing spd^2 >= 49 fires on 16.3% of moves (spd_rate.py;
  silverstone 28.8%, sprint/triangle 0%) yet 27/27 probe races were
  move-identical: under the champion's greedy-rival sim NO death verdict
  fires anywhere -- trigger timing was never the frontier, sim fidelity was.
- **LAW (cost a day): `-Dai.debug.djs` is Boolean.getBoolean -- it MUST be
  `-Dai.debug.djs=true`.** The bare flag silently disables printing; several
  "zero AIDBG events" reads were meaningless until this was caught via a
  SIM_TRACE that also failed to print.
- **Oracle tooling (the arc's permanent yield, all in scratchpad):**
  `--query-moves - -` is now INTERACTIVE (stdin/stdout, one JVM serves
  sequential queries; ~18s reachability once) and each reply carries a
  9-candidate mask in Direction order (F finish / X illegal / B body /
  D reach-dead / A alive). Drivers: oracle_roll.py (verify mode = roll the
  real scorer as every car's policy and diff vs the log -- validated EXACT
  MATCH; cand mode = per-candidate fate of a mover at any log move),
  policy_matrix.py (replicates any cheap sim policy offline via mask
  queries), board_at.py (board + candidate classification at any log move),
  crash_scan.py (find crashed players in logs), champ_logs/ (round-54
  champion move logs, 27 races). This kills the guess-build-replay loop:
  policies are DERIVED offline, only the winner gets built in Java.
- **Doom mechanics of the three covered champion crashes** (board_at +
  oracle cand): silverstone s6 = one-cell certified corridor (83,117), p2
  claims it one move early, the "open" (83,118) is segment-illegal, 7
  dead-states -- all 9 fatal at m161, doom entered between m145 and m153.
  hungaroring s6 = same corridor-queue shape (8 dead + 1 body at m197).
  zandvoort s7 = empty-track doom (every candidate reach-dead by m140) --
  entered a certified-dead corridor rounds earlier.
- **Oracle verdicts: 2/3 saveable at wide-trigger points within horizon 3**
  (silverstone m145: chosen W dies r2, brake N survives t=62; hungaroring
  m181: chosen W dies r2, SIX survivors) -- only the rival model blocked
  the saves. zandvoort not saveable at m140+ (all dead).
- **Policy matrix (the decisive artifact): both boxes need BOTH terms.**
  Rival policy vs (chosen / survivor) on both sites:
  greedy: alive/alive + alive/alive (misses both boxes -- vacates lines);
  gmom (greedy, tie->faster): catches silverstone only;
  shape (ttf+trap ladder): catches hungaroring only (corridor claim);
  **smom (ttf + trap, tie -> HIGHER landing speed): DEAD/alive on BOTH --
  matches the real-scorer reference on all four cells.** The momentum
  tie-break models the scorer holding speed down the racing line; the trap
  term models it claiming one-lane corridors (ttf gain > trap 2.0). The
  r56 lexicographic selfMove-as-rivals arm (tier FIRST) is the opposite
  failure: refuses the corridors the real scorer claims -- probed inert,
  reverted same day.
- **R57 build: `rivalMoveOverState` (smom) behind exactRivals in the DJS
  rollout only** (certification vetoes keep greedy rivals; exactSelf
  unchanged -- one variable). AI1 DJS call = (true, true, true). In-game
  replays: silverstone s6 saved (ONE intervention, m145 W->N, 0 crashes),
  hungaroring s6 saved (m181 W->NW, 0 crashes). 27-race probe: 6/27
  diverge; crashes 3 -> 1 -- ALL champion crashes saved including
  zandvoort s7 (intervention at m124, BEFORE the oracle's doomed window:
  the new sim sees the danger while escapes still exist); 1 NEW crash
  (hungaroring s7, an early m29 switch reflowed the race; slow queue death
  at m413 -- board_at: all 9 candidates reach-dead, the zandvoort doom
  class, formed at low speed below every trigger).
- **R57 8car screens (3 independent seed sets, vs cached champion): the
  biggest crash gain since DJS itself, at DEAD-FLAT pace.**
  | seed set | R57 f/c/mv | champion f/c/mv |
  |----------|------------|-----------------|
  | 1-5      | 768/**2**/64.04 | 767/3/64.04 |
  | 6-10     | 768/**2**/64.00 | 765/5/63.99 |
  | 11-15    | 768/2/63.99 | 770/**0**/64.01 |
  | total    | **c=6** f=2304 | c=10 f=2302 |
  Sites: silverstone/interlagos/zandvoort crashes GONE (s6-10 3->0);
  hungaroring 2->3 across sets (s1-5 1->0, s6-10 1->1 wash, s11-15 0->2
  NEW -- its one-lane corridor absorbs the reflow risk); lemans/zigzag/
  hairpin slow-class untouched. The s11-15 regression is the round-52
  warning shape but here the 15-seed total is strongly net (-4 crashes,
  +2 finishers) rather than reversed. smom sim cost: NEGLIGIBLE (~17
  min/set cached, same as champion).
- **R57 FULL BATTERY: PASSED, the strongest gate of the campaign** --
  wins or ties EVERY stage, no stage worse:
  | stage | R57 (AI1) | champion (AI2) |
  |-------|-----------|----------------|
  | 8car s1-5   | 768/**2**/64.04 | 767/3/64.04 |
  | 8car s6-10  | 768/**2**/64.00 | 765/5/63.99 |
  | 8car s11-15 | 768/2/63.99 | 770/**0**/64.01 |
  | h2h s1-5    | **4.491** c=**2** | 4.509 c=3 |
  | h2h s6-10   | **4.486** c=**2** | 4.514 c=5 |
  | 4car s1-5   | 330/**0**/61.98 | 329/1/61.97 |
  | 1v1 s1-5    | 110/0/60.95 (exact tie) | 110/0/60.95 |
  | slow        | 28/0/104.39 (exact tie) | 28/0/104.39 |
  8car crashes 6 vs 10 over 15 seeds; h2h wins BOTH axes on BOTH sets
  (margins beat even the C+2 promotion battery); 4car save; sparse/slow
  untouched. Better than the round-40 DJS gate (net -5) on breadth AND
  the h2h margin. PROMOTED round 58 (user-approved 2026-07-26) -- see
  the champion header.
## Round 59 (AI1, in gates): real-scorer rivals for the slow class

The round-58 champion's ENTIRE residual (6 crashes/15 seeds) is the SLOW
class (spd^2 <= 25): queue pockets + endgame scrums. Oracle census of all
six: hungaroring s7/s12/s13 = the (64,115) pocket (doom-entry m389-class,
saveable, chosen dies r2-3 with TWO survivors); lemans s4 = start-funnel
doom entered at m63 through a TRAP-0 state (1-ply ladder reads 3 open,
all secretly dead in 2-4 rounds; only visible at horizon 4-5); zigzag s4
and hairpin s10 (race-end scrum at spd^2~2) unclassified in depth.

KEY MEASUREMENT (policy_matrix, horizon 4-5): the smom proxy FAILS the
slow class both ways (misses the pocket death AND falsely kills the good
escape) -- dense slow traffic drifts beyond any 2-term proxy within ~2
rounds. Real-scorer rivals + selfMove me ("orivals") flags BOTH slow
dooms with survivors intact => recursion is the only faithful world.

BUILD: scorerMoveOverState -- installs the sim board into the live
Player objects (processQueries pattern), runs the rival's OWN scorer
with recursive machinery suppressed (IN_SCORER_SIM static guards at the
solver / certified tie-break / DJS in both bodies), restores in a
finally. simOutcome gains scorerRivals: nearest AI1_SCORER_MAXRIVALS=3
rivals within Chebyshev AI1_SCORER_NEAR=10 roll via the real scorer.
AI1's DJS call: slow-class fires (landing spd^2 < 49) use scorer-rivals
at AI1_DJS_SLOW_ROUNDS=5; fast fires keep smom at 3 (proven, untouched).

SITE RESULTS: hungaroring s13 saved at exactly the oracle's doom-entry
(m389 NONE->E, one intervention, 0 crashes); s7 + s12 saved; the whole
pocket class is GONE. lemans s4 NOT saved (its trap-fires correctly say
"no survivor"; the m63 entry is trap-0 so nothing fires -- KNOWN GAP).
zigzag s4 / hairpin s10 not saved.

GATES (round 59, ALL PASSED, never worse on any stage): probe 2/27
diverge (the s7 save + a crash-neutral lemans-s3 funnel flip). 8car:
s1-5 EXACT tie 768/2/64.04; s6-10 768/2/63.99 vs 768/2/64.00 (s7 saved,
monaco s7 NEW -- see below); s11-15 **770/0/64.01** vs 768/2 (both
pocket crashes saved, the perfect set). 15-seed c=4 vs 6 at flat pace.
h2h: s1-5 exact parity 4.500/4.500 c=2/2; s6-10 4.501/4.499 (noise)
c=1 vs 2. 4car/1v1/slow: EXACT ties (330/0, 110/0, 28/0).

The monaco s7 relocation (oracle-classified): p8 squeezed in the tunnel
narrows (x66-71,y75-76) at speed ~5, TOTALLY boxed by m480 (all 9
segment-illegal -- board_at's "open" cells were wall-cut illusions,
only the oracle mask sees segment legality), doomed before m472. Same
slow-class family (trap-0 funnel entry), walk-back pending -- a
round-60 target alongside lemans s4 / zigzag s4 / hairpin s10.

ROUND-60 LEAD (measured, do NOT build a blanket trigger): slow+crowd2
fires 218/race (crowd_rate.py) -- far too hot for scorer rollouts. The
lemans entry needs a SELECTIVE escalation, e.g. run the cheap smom
rollout first and escalate to scorer-rivals only when its final state is
fragile (died OR final tier <= 1). Escalation rate unmeasured.

## Round 60 (AI1, in gates): smoke-test escalation for trap-0 entries

Census of the round-59 residual (oracle walk-backs, per site):
- **lemans s4**: last save m63, death 3-5 rounds out; smom rollout MISSES
  it (says alive t=55) -- only scorer-rivals see it. NOT caught by r60a;
  needs a future escalation signal (final-state fragility?).
- **zigzag s4**: last save m102, chosen W dies @r4 (real) but even the
  CHEAP smom-5 rollout flags it (@r1, me-proxy walks in faster); one
  survivor SW (swing wide before the kink). The entry is trap-0 via
  vacate-optimism: W's ladder read roomy at m102, actual 1-ply count 0
  at m110. => Only a TRIGGER was missing.
- **hairpin s10**: doom >= 7 rounds deep (all fatal at m98, best @r6,
  race is ~17 rounds total) -- STRATEGIC class, beyond any rollout.
  ACCEPT.
- **monaco s7**: tunnel squeeze, totally boxed by m480 (all 9
  segment-illegal; board_at's "open" cells were wall-cut illusions --
  only the oracle mask sees segment legality), doomed before m472,
  deep-commitment class like hairpin. ACCEPT (walk-back not exhausted).

R60a BUILD (AI1): trap-0 slow moves (spd^2 < 49, trap < 0.5 -- today's
no-fire gap) get a CHEAP smom-5 smoke test; a smom death ESCALATES to
the scorer-rival rollout which re-verdicts the chosen and gates any
switch (smom false alarms filtered before they can perturb -- monaco s1
control: 1 escalation, scorer said alive, no switch). Replays: zigzag
s4 SAVED at exactly m102 (one escalation, SWITCH SW, 0 crashes);
lemans s4 unchanged (smom miss, expected); hungaroring/coil quiet.
Escalation rate 0-1/race => cost nil.

**R59+R60a GATES vs the round-58 champion: PASSED CLEAN, never worse.**
Probe 3/27 diverge (2 saves + crash-neutral lemans s2/s3 flips). 8car:
769/**1**/64.05, 768/2/64.00, **770/0**/64.01 vs 768/2 x3 => 15-seed
c=3 vs 6 at flat pace -- s1-5 c=1 is the best s1-5 line of the
campaign. h2h: 4.500 c=1 vs 4.500 c=2 and 4.505 c=1 vs 4.495 c=2
(places parity/noise-band, crashes 2 vs 4). 4car 330/0, 1v1 110/0,
slow 28/0: EXACT ties. The three residual crashes are all classified
beyond-rollout classes: lemans s4 (smom-invisible funnel, needs a
future escalation signal), monaco s7 (tunnel squeeze, doomed 4+ rounds
deep), hairpin s10 (strategic, doomed >= 7 rounds deep). PROMOTION-READY
stack (r59 commit 11b2297 + r60a); awaiting the user's word.

## Round 61 (AI1, in gates): rival-conditional trap relief (solo pace)

The lemans-s4 fragility idea died by measurement (smom rollouts end
tier=3 everywhere -- no cheap escalation signal exists; lemans s4 joins
monaco s7 / hairpin s10 as accepted residuals). Pivot to PACE: the
r57-60 reflows created a NEW equilibrium, so the round-47/48 pace
decomposition was re-run (pace_forensic on fresh champion logs +
patch_comp_dump re-applied, comp dump now permanent in source):
- monaco s1 now shows a 26-move ROOMY pool (was negligible), with a
  smoking-gun FIXED POINT: five different cars concede the identical
  1 ttf at (116,46) v(-4,6). The comp dump shows the deep search itself
  PREFERS the faster SW line (cost 65 vs 66) and the TRAP LADDER alone
  (2.0, one-safe-successor thread) overrides the certain gain -- with
  no rival anywhere near. The ladder is rival-blind in its price.
- Secondary leak at the same state: `unc` fires 11.5 for SOME cars
  (predicted-world dependent) on the solo thread -- round-62 candidate
  with the same emptiness certificate. One variable at a time.

R61 BUILD (AI1): waive L1/L2 trap (0-safe keeps 50) when no live rival
is within Chebyshev AI1_TRAP_SOLO_R=16 of the landing -- max per-axis
closure is |v|+1 <= 13/round, so the thread is uncontestable for its
consumption window; the map's reach-certification suffices solo.

**R61 GATES: PASSED -- the first simultaneous pace+crash gain of the
campaign, and the pace gain SCALES WITH SOLITUDE (mechanism-confirming):**
| stage | r59+60+61 (AI1) | champion r58 (AI2) |
|-------|-----------------|--------------------|
| 8car s1-5   | 769/**1**/**63.98** | 768/2/64.04 |
| 8car s6-10  | 768/2/**63.94** | 768/2/64.00 |
| 8car s11-15 | **770/0/63.93** | 768/2/64.00 |
| h2h s1-5    | 4.500 c=**1** | 4.500 c=2 |
| h2h s6-10   | 4.502 c=1 (noise) | 4.498 c=1 |
| 4car        | 330/0/**61.85** | 330/0/61.98 |
| 1v1         | 110/0/**60.62** | 110/0/60.95 |
| slow        | 28/0/104.39 (tie) | 28/0/104.39 |
Probe: 11/27 diverge, ZERO crashes, every divergent race SHORTER
(lemans -3/-3/-4, monaco -2/-3/-5, zandvoort -1 x3); short dense tracks
inert. mv -0.06 uniform on all three 8car sets; 4car -0.13; 1v1 -0.34
(solitude scaling: more solo running = more relief); slow ties (narrow
serpentine queues are never solo within 16). 15-seed crashes 3 vs 6.
The comp dump (-Dai.debug.comp) is now permanent gated instrumentation.

## Round 62 (AI1, gate-clean): certified UNC override -- the unc pool won

62a (descent-scaled range bound on the converging-opponent gate) probed
BYTE-INERT vs r61 and was reverted the same hour. The counterfactual on
the r61 equilibrium still showed `unc` holding the largest pool (monaco
s1: 50 ttf ceiling, deep search agreeing 48/48; lemans 9). 62b takes it
the way rounds 49-53 proved it must be taken -- with a PROOF, not a
predicate: pay the surcharge everywhere EXCEPT where a strictly faster
(raw ttf) candidate wins the unc-free score comparison AND has zero
trap, is not sealable, and SURVIVES the round-59 scorer-rival rollout at
the slow horizon (the proof round 52 lacked; solo flips have empty
scorer sets so their proofs cost nothing). patch_r62_uncover.py,
first-occurrence anchors, AI1 only.

**GATES: the biggest pace gain since the depth-2 search, at the best
crash floor ever, seed-set law satisfied the hard way:**
| stage | r59+60+61+62 (AI1) | champion r58 (AI2) |
|-------|--------------------|--------------------|
| 8car s1-5   | 769/**1**/**63.81** | 768/2/64.04 |
| 8car s6-10  | 769/**1**/**63.78** | 768/2/64.00 |
| 8car s11-15 | **770/0/63.78** | 768/2/64.00 |
| h2h s1-5    | **4.483** c=**1** | 4.517 c=3 |
| h2h s6-10   | **4.481** c=4 | 4.519 c=1 |
| h2h s11-15  | **4.465 c=0** | 4.535 c=1 |
| 4car        | 330/0/**61.84** | 330/0/61.98 |
| 1v1         | 110/0/**60.62** | 110/0/60.95 |
| slow        | 28/0/**104.25** | 28/0/104.39 |
8car 15-seed: crashes **2 vs 6**, mv **-0.22 uniform** on all three
sets. h2h: the s6-10 c=4 (monaco 2 + hungaroring 1, on tracks where
places were WON 4.38) triggered the third-set rule -- s11-15 came back
4.465 **c=0**; 15-seed h2h places won on ALL THREE sets at crash
parity 5-5. 4car/1v1/slow all faster, all crash-free (first slow-set
movement in many rounds, -0.14). Probe: 18/27 diverge, zero crashes,
every long-track race shorter (lemans -18/-9/-4, monaco -17/-11/-8,
hungaroring -17/-11).

## Round 65 (AI1, in gates): pack-gated deep escalation

The hairpin-s10 walk-back CONTINUED past the all-fatal m98: the save
exists at m90 with a 7-ROUND commitment (three candidates FINISH @r6
while the real chosen SE dies @r7 -- the scorer accelerated to v(8,1)
into the pack hairpin). policy_matrix at horizon 8: orivals reproduces
it exactly (chosen DEAD@r7, both survivors alive t=1); smom misses the
death but ends FRAGILE (final tier=1) -- the escalation signal (which
was dead at lemans but lives here). Escalation-rate samples
(esc_sample.py): hairpin 17%, monaco 20% (too hot unedited),
silverstone 0% => PACK GATE: escalate only with >= AI1_DEEP_PACK=3
rivals within Chebyshev AI1_DEEP_PACK_R=10 of the landing (the doom
class lives in packs; monaco's fragile hit was a solo tunnel). Start
grids are slow => wide trigger off => no deep fires there.

BUILD (AI1): simOutcome gains an outFinalTier out-param (overload, no
caller churn). Fast fires with the pack: cheap smom pre-screen at
AI1_DEEP_HORIZON=8; dead-or-fragile => dangerJointSearch with
scorer-rivals at horizon 8 (re-verdict gates any switch). hairpin s10
replay: TWO escalations, m82 correctly kept (scorer alive), m90 DIES ->
SWITCH W simT=0 (the finish-in-sim line), 0 crashes.

**GATES: PASSED, never worse on any stage.** Probe 4/27 diverge, zero
crashes (hairpin +2 / zandvoort +3 move reflows, two same-length
silverstone flips). 8car: s1-5 tie 769/1/63.81; s6-10 **770/0/63.79**
(hairpin saved -- the set is PERFECT); s11-15 tie 770/0/63.79. h2h:
4.502/4.498 c=1/1 parity; 4.499/4.501 c=**0**/1. 4car/1v1/slow: EXACT
ties. **15-seed residual = ONE crash (lemans s4, the provably
invisible funnel).** 2309 finishers of 2310 possible.

## Round 64: the certified-lane instrument is EXHAUSTED (closed negative)

Fresh counterfactual on the round-63 champion (comp_r64_*.err): unc
residual 59/16/23 ttf (monaco/lemans/interlagos), rob GREW to 28 on
monaco (25 flips, search agreeing 24/25), spread ties 13/23/22. Built
the certified ROB override (patch_r64_roblane.py, the exact r62 lane
with the bonus added back on both sides): **byte-INERT on all three
pool tracks** -- every rob-flip's fast candidate is refused by the
proof stack (trap != 0 near rivals / sealable / scorer-rival death).
REVERTED same hour (git checkout, uncommitted).

LAW: after rounds 61-62 took everything the proof stack can certify,
the ENTIRE remaining soft-term pool (unc residual + rob + spread ties,
~100 ttf/seed across the big tracks) is certification-refused = the
round-47 knife-edge frontier, now confirmed at the level of the
strongest proof owned (scorer-rival rollouts). Taking more pace needs a
STRONGER PROOF than the campaign possesses, not another lane. Do not
add lanes; the instrument is done.

Remaining open frontiers (for future rounds): (a) the strategic doom
class (hairpin s10 / lemans s4, commitment 5-7+ rounds) -- would need
horizon-7+ rollouts at some rare affordable trigger; hairpin's
last-save move is UNKNOWN beyond m98 (walk-back stopped at all-fatal);
(b) external-opponent value (h2h vs humans/weaker AIs) -- unmeasurable
in self-play; (c) anything requiring game expansion is excluded by
standing instruction.

- **The residual class is ONE localized pocket: hungaroring (64,115).**
  All three new-equilibrium casualties (s7 p5, s12 p8, s13 p5 -- found by
  r57_hung_forensic.sh replays) die at the SAME cell with the SAME
  approach (59,116)->(62,116)->(64,115) at spd^2 10/9/5, all 9 candidates
  reach-dead at the end (board_at). A slow-speed doom pocket below every
  trigger (wide needs spd^2>=49; trap fires too late). ROUND-58 TARGET:
  oracle cand walk-back on this pocket to find the doom-entry move and a
  trigger shape for the slow class (zandvoort s7's family). The pocket is
  a consistent attractor of the new equilibrium, so it should reproduce
  deterministically for the forensic.
- **Idea D (certified isolation sprint): CLOSED NEGATIVE by measurement**
  (iso_pool.py, champ_logs): pace lost while spatially isolated from every
  rival is ~0.2 ttf/race at Chebyshev >= 20 and ZERO at >= 25 -- in-race
  fields never spread enough; the 1.10% solo-caution headroom exists only
  in literally-solo races. Do not build.

Mechanism (in both AI bodies, helpers shared):
- Per-candidate `trapByDir[d]` records the trap ladder (d2SafeCount-based
  50/2/0.5/0 penalty) during the normal scoring loop.
- After the sealGuard, if the chosen landing has `trapByDir >= 0.5`
  (<= 2 safe successors), `dangerJointSearch` runs: roll the joint game
  `AI1_DJS_ROUNDS = 3` rounds forward on a DETACHED board (`simOutcome`),
  every car greedy min-turnsToFinish (`greedyMoveOverState`), move-order
  aware (first simulated round covers only players after `game.subgamestate`
  — the array index of the mover). Returns my ttf, or -1 if I get boxed.
- **STRICT SURVIVAL-ONLY ASYMMETRY: override the scorer's pick ONLY if it
  dies in-sim AND another candidate survives (pick best sim-final ttf);
  a surviving pick is always kept.** This is why it beat the equilibrium
  law where the rejected 2026-07-14 foresight sim (fs1) netted zero: fs1's
  warning-based re-picks caused equal evasion crashes; survival-only
  switching cannot fire on a line that was actually fine.
- rounds=4 probe: no additional gain (zandvoort s7 is greedy-me model
  error, not horizon). Kept 3.

Full-gate record vs prior champion (all logs in the scratchpad, djs_*.log):
- 8-car 10 seeds: c=7 vs 11 (hungaroring 0 vs 5; coil s6-10 0->1
  relocation); pace composition-only.
- h2h mixed 22 tracks x 5 seeds: place parity 4.502/4.498, crashes 3 vs 7.
- 4-car: s1-5 self-tie; s6-10 c=1 vs 2 (a sparse SAVE). 2-car: tie.
- slow: serpentine2 0->1 relocation; serpentine/spiral/cog +0.0.
- Net -5 crashes across all modes at equal pace.

## The user-approved 5-lever campaign ("Let's do 1-5")

1. **Launch policy — FALSIFIED, closed unbuilt.** Champion has ZERO
   crashes in rounds 1-8 (11 crashes over 10 seeds, earliest round 9);
   pack-density decay does not discriminate crash seeds from clean seeds
   (crash seeds often LESS dense). Tools: start_congestion.py,
   density_compare.py.
2. **Pace headroom — DONE, the strategic number.** Champion 8-car moves =
   exact map optimum + 6.35%: solo caution 1.10% (solo champion EXACTLY
   optimal on 13/22 tracks; residual: monaco 3.6%, zandvoort 2.2%, coil
   1.7%) + **TRAFFIC 5.25%** (sinks: lemans +11.8%, sprint +10.0%,
   triangle +8.6%, hairpin +7.7%, monaco +6.9%). All future racing value
   lives in the traffic gap. Tools: headroom.py + reach_*.bin dumps
   (22 tracks, in scratchpad) via the game's `--dump-reach`.
3. **Gate-threshold joint tune — CLOSED, negative, definitive.** The six
   never-tuned thresholds were refactored into AI1_* constants (b86339b,
   byte-identical proven) and coordinate-descent tuned vs a mixed-field
   proxy on the traffic sinks. Best (MID 0.72 / SPD 3 / VACATE 3.5,
   proxy 4.287 vs 4.500) was REJECTED by the full gate: h2h over all 22
   only 4.484 vs 4.516 (proxy = track-selection overfit), 8-car crashes
   14 vs 11. Constants surface (multipliers AND thresholds) is now
   provably exhausted. LESSON: tuner objectives must span all 22 tracks
   or carry a full-gate-shaped holdout.
4. **Danger joint search — SHIPPED, PROMOTED (this champion).** See above.
5. **Endgame solver — NOT STARTED (next).** Plan: memoized exact minimax
   over joint states when <= 2 rivals remain near the finish, depth 6-10;
   extends the V1 endgame seal (which is 1-ply and proven inert vs equal
   AIs); value is vs humans/weaker AIs, so verify no self-play regression
   + h2h, don't expect bench gains.

## Immediate pending work (in order)

1. **Coil s6 relocation forensic — DONE (2026-07-21+), verdict: ACCEPT,
   pure reflow.** Replay shows the only DJS divergence in the race is p6's
   survival switch at (9,45), other side of the track, 14 p8-turns before
   the death. p8's own kill is the ancestral trigger-too-late class: trap
   ladder 0.0 for 11 turns at speed 6-7, first flagged landing (50,70) ->
   DJS "DIES in-sim, no survivor" (all 9 candidates dead), forced moves to
   the wall. DJS innocent; it even diagnosed the death 5 moves early.
2. **serpentine2 slow relocation forensic — DONE, verdict: ACCEPT (DJS
   collateral, user-endorsed aggression), fold into item 4.** Corrected
   story after testing the pre-DJS champion on the same default grid
   (NO crash): BOTH sim death-verdicts in the DJS race were FALSE
   (greedy-me model error) — p6 "DIES" would have lived on its old line;
   p7 "no survivor" threads through pre-DJS. The false verdict made p6
   switch to (113,114), and that rescue body landed in p7's speed-10
   braking corridor -> p7's real box. A switch safe for the switcher that
   killed a rival = collateral aggression (p6 gained; h2h gate showed
   place parity + halved crashes; round-40 gate priced it at net -5).
   LESSON: DJS false-death verdicts don't self-harm (survival-only
   asymmetry) but DO perturb the equilibrium via unnecessary switches —
   sim fidelity is the shared root with item 4.
3. **Lever 5 (endgame solver) — DONE, SHIPPED (round 43, commit 3895855,
   AI1 only).** 1v1 exact memoized paranoid minimax (trigger: sole live
   rival + both within AI1_EG_ETA=12 of the finish; AI1_EG_DEPTH=10
   rounds; AI1_EG_NODES=50_000 -- 200k ran the 1v1 bench ~2x long on
   UNPROVABLE positions, and real proofs are shallow forcing lines, 50k
   smoke byte-identical). Acts ONLY on guaranteed wins (cross first /
   rival forced to crash); unproven -> normal scorer. Gate: 1v1 duel
   place parity 1.500/1.500 crashes 0v1 (all duels position-decided vs an
   equal AI, as the plan predicted); 8-car self-play bit-inert (f=767 c=3
   rows identical); h2h 4.498/4.502 c 3v4 (unchanged). Smoke: chains
   proven wins when ahead (hairpin 4 forced moves), silent when behind.
   Value target = humans/weaker AIs, unmeasurable in symmetric benching.
   ALSO SHIPPED THIS SESSION (round 42, commit 979084f): the sealable()
   selfByIndex off-by-one fix, AI1 only -- full gate net -5 crashes at
   equal pace (4-car 10-seed c=1 vs 4 both sets confirmed, 2-car 0v1,
   slow 0v1 incl. the serpentine2 DJS-collateral save; 8-car wash, h2h
   parity). AI1 = DJS + sealfix + endgame solver; AI2 = DJS champion
   (sealable bug-compatible via selfByIndex=true). PROMOTION of both into
   AI2 is a pending user decision -- promotion = flip AI2's selfByIndex
   flags to false + add the solver trigger to AI2's method top.
4. Ancestral singles (silverstone s6, zandvoort s7, lemans s4/s10-class,
   chicane s3, zigzag s4, coil s6 above): need better sim fidelity
   (greedy-me != real-me is the known model-error class) or earlier
   triggers + longer horizon. The trigger misses shapes whose trap ladder
   stays 0 until all alternatives are dead (silverstone s6 / coil s6 /
   serpentine2 p7 = speed 7-10 into a corner). DESIGN FACT: the
   survival-only asymmetry makes the DJS trigger a pure COST gate —
   broadening it (even to every move) cannot reintroduce fs1-style
   false-alarm evasions; the frontier is sim fidelity + horizon, not
   trigger safety.

AIDBG instrumentation (turn dump `-Dai.debug.player=N` + DJS-death events
`-Dai.debug.djs`, both bodies, prints-only, off by default) is now IN the
champion source (committed) — run_debug.py uses both; seed 'none' replays
the default grid.

## Traffic-pace frontier DECOMPOSED — round 47 (lever 2 forensic)

Per-move forensic (scratchpad/pace_forensic.py, NO Java/bench: reach_*.bin
dump gives exact velocity-aware ttf; each move should cut ttf by 1; a move
cutting it by <1 lost that fraction). For each lost move it decides whether
the fastest next cell was rival-BLOCKED (irreducible), free-but-KNIFE-EDGE
(<3 open 1-ply escapes -> the pace/crash frontier: taking it converts to
crashes, proven), or free-and-ROOMY (>=3 escapes -> genuine over-caution,
the only safely-recoverable pool). Results (champion, seed 1, finishers):
- lemans (biggest sink, +11.8%): 68 lost = 16 irreducible + 38 knife-edge
  frontier + 14 roomy over-caution.
- sprint (+10.0%): 11 lost = 9 irreducible + 2 roomy + 0 frontier.
- triangle (+8.6%): 11 lost = 11 IRREDUCIBLE, 0 recoverable.
CONCLUSION: ~90% of the 5.25% traffic gap is irreducible (a rival is
genuinely in the fast cell; someone must yield) or knife-edge frontier
(the memory's proven pace->crash conversion). The safely-recoverable
over-caution pool is SMALL (~14 moves/race on the worst track, ~1%
campaign-wide) AND every slice of it is justified: the very-open slice is
START-GRID idling (NONE at tick 1 from standstill -- pileup avoidance,
lemans start boxes are real, state_probe confirmed greedy=64 vs chosen
NONE=65); the rest is room=3-5 mid-race where 1-ply openness exceeds the
champion's 4-ply foresight, which prior rounds PROVED load-bearing
(removing foresight crashes). So the heuristic is near the equilibrium
limit on BOTH axes now (crashes AND traffic pace). The genuine remaining
lever for the traffic gap is the SAME as for the crash floor:
MULTI-AGENT COORDINATION (predict rival yields to cut mutual detours) --
the learned-AI direction (pyrace), where RL previously did not beat
greedy. Tools: pace_forensic.py, state_probe.py (both in scratchpad,
reusable on any track+seed with a reach dump).
- **PROBE RUN & REJECTED (round 47): start-grid anti-idle.** Added an AI1
  override -- from a standstill, if the scorer idles (NONE) while a faster
  advance lands clear of predicted AND live rivals with >=6 open 1-ply
  escapes, take the advance. It NEVER FIRED: all-AI1 races are MOVE-IDENTICAL
  to the champion on all 5 sink tracks (lemans/sprint/triangle/hairpin/
  monaco). Every start-grid NONE has a rival predicted into the advance ->
  the idle is real pileup-avoidance, not gratuitous. Reverted (patch_antiidle.py
  archived). This is the CODE-LEVEL confirmation of the forensic: the
  heuristic has no recoverable traffic pace. BOTH axes (crashes, pace) are
  now at the equilibrium limit; the only lever left is learned multi-agent
  coordination.

## VERDICT on the rounds 48-53 pace campaign (read this first)

The `unc` pace lever is **REJECTED**. It is real (~0.7% faster, consistent
across every seed set) but it is NOT free: a third independent seed set
(11-15) broke the tie decisively against it —

| seed set | round 52 crashes | champion crashes |
|----------|-----------------:|-----------------:|
| 1-5      | 7 | 3 |
| 6-10     | 3 | 5 |
| **11-15**| **10** | **2** |
| **total**| **20** | **10** |

It DOUBLES the crash rate over 15 seeds. The seeds 6-10 result (3 vs 5,
which looked like it beat the champion) was pure luck. **LAW: two seed sets
are NOT enough when they disagree — a 5-seed crash delta of +/-2 is noise,
and a candidate that wins one set and loses another must go to a third set
before any conclusion.** This nearly promoted a crash-doubling regression.

CONSEQUENCE: the `uncertified` surcharge IS load-bearing insurance despite
its genuine coherence defect (it fires on speeds the map certifies). The
counterfactual forensic was RIGHT that it overrides the deep search 51/51 —
but the deep search is OPTIMISTIC about traffic, and this surcharge is
precisely what pays for that optimism. Localising a term as "the thing
costing pace" does NOT mean the term is wrong.

**SURVIVOR: C+2** (certified pace tie-break + exact-self rollout) — the only
candidate of the whole campaign that improves BOTH axes, confirmed on three
independent seed sets:

| seed set | C+2 f/c/mv | champion f/c/mv |
|----------|------------|-----------------|
| 1-5      | 767/**3**/64.04 | 767/3/64.07 |
| 6-10     | 765/**5**/63.98 | 765/5/64.03 |
| 11-15    | 770/**0**/64.01 | 768/2/64.06 |
| total    | **c=8**    | c=10 |

Never worse on any set, faster on all three, and c=0 on the very seed set
where the `unc` lever collapsed (c=10 vs 2). Its safety comes from
COMPOSITION, not from cutting caution — which is why it survives where every
caution-reduction arm (A, B, 52, 53) failed.

**FULL PROMOTION BATTERY: PASSED, CLEAN ON EVERY STAGE** (c2_battery.sh):

| stage | C+2 (AI1) | champion (AI2) |
|-------|-----------|----------------|
| 8-car seeds 1-5   | 767/**3**/64.04 | 767/3/64.07 |
| 8-car seeds 6-10  | 765/**5**/63.98 | 765/5/64.03 |
| 8-car seeds 11-15 | 770/**0**/64.01 | 768/2/64.06 |
| h2h places s1-5   | **4.430** c=**3** | 4.570 c=4 |
| h2h places s6-10  | **4.484** c=**4** | 4.516 c=6 |
| 4-car s1-5        | 329/1/61.97 (exact tie) | 329/1/61.97 |
| 1v1 s1-5          | 110/0/60.95 (exact tie) | 110/0/60.95 |
| slow synthetics   | 28/**0**/104.39 | 28/0/104.46 |

h2h is the decisive stage the 8-car bench cannot see (insurance-premium law:
caution can cede PLACES at equal crashes) — C+2 wins places AND crashes on
BOTH seed sets. 4-car and 1v1 are exact ties: the certified tie-break
correctly never fires in sparse fields, so the seal guard and the 1v1 solver
are untouched.

**PROMOTED round 54 (user-approved 2026-07-25) via `patch_promote_c2.py`:**
mirrored the scoreNSByDir/poTByDir bookkeeping + override block into the AI2
body (second occurrence of each anchor) and flipped AI2's dangerJointSearch
call (false, false) -> (true, true), which also promoted the round-45
finish-vanish fidelity that had been AI1-only. Self-tie: inert_probe 27/27
INERT + 22-track bench-vs-cache tie. Caches re-seeded from the gate's AI1
columns via `extract_baseline.py <log> <json> 1`.

## Rounds 48-51: the traffic gap LOCALISED to two named terms

Round 47 concluded "no recoverable traffic pace". That was WRONG in one
respect and the correction is the most useful result since DJS: the pace
forensic measured the gap per MOVE but never asked WHICH SCORE TERM decided
it. Component-level attribution finds a real, broad, reproducible lever.

### New tooling (scratchpad, reusable on any track+seed — use these FIRST)
- **inert_probe.py** — the cheapest possible go/no-go for ANY AI1-only
  change: races an all-AI1 field and an all-AI2 field on the same
  track+seed and diffs the move logs (normalising the AI-kind field, which
  is embedded in every log line — diffing without that gives a 100% false
  divergence). Identical logs => the change is byte-inert; REVERT, never
  bench. `PROBE_SEEDS=6,7,...` env to pick seeds. Caught rounds 48 and 51
  in ~4 minutes each instead of a 40-minute gate.
- **patch_comp_dump.py** — injects a print-only per-candidate score
  breakdown into AI1 (gated `-Dai.debug.comp`): every scored candidate with
  cost/trap/cap/unc/ce/qb/spread/mom/rob + raw map ttf.
- **comp_forensic.py** — proportional blame per term for conceded pace.
- **comp_counterfactual.py** — THE decisive one. Deletes each term, re-runs
  the argmin, and measures the change in the WINNER's raw map ttf, i.e. the
  honest ceiling of what removing that term could recover. Also splits, for
  each flip, whether the deep search itself AGREED the faster cell was
  cheaper / was exactly TIED / was AGAINST it. Proportional blame
  over-attributes; always prefer the counterfactual.

### The measurement (5 traffic sinks, seed 1, ttf recoverable)
| term | lemans | monaco | sprint | triangle | hairpin | search verdict |
|------|-------:|-------:|-------:|---------:|--------:|----------------|
| unc    | 14 | 40 | – | – | 1 | AGREED 51/51 (overrode it) |
| spread |  8 | 10 | 13 | 9 | 6 | TIED 46/46, AGAINST 0 |
| trap   |  8 | 14 | – | – | – | agreed (load-bearing, leave alone) |

Both have COHERENCE defects, not tuning defects:
- **`spread`** (`opponentSpreadPenalty`, 0.3 within d2<=4 / 0.1 within
  d2<=9, per rival) is documented as a "tiny penalty ... breaks lateral
  ties", but its magnitude EXCEEDS the entire non-spread score spread in
  the decisions it decides (all < 0.3). It is not breaking ties, it is
  dominating them, and it outranks raw pace. Every flip is an exact
  costToFinish tie where it picks the SLOWER line.
- **`uncertified`** is gated on the flat `speed > AI1_BRAKE_SPEED` while its
  sibling `speedCap` respects the per-state certified budget
  (`widthBudget = max(5, certBudget) + d2SafeCount`). A term called
  "uncertified" fires on speeds the map CERTIFIES. Arm B
  (`patch_r49b_unc.py`, gate it on `overSpeed > 0`) is written and staged
  but NOT YET RUN — this is the largest untested lever on the board.

### Results so far
- **Arm A (`AI1_SPREAD_W = 0.0`, delete spread): the lever is REAL but
  uncertified.** 22 tracks x 10 seeds: mv 63.81/63.71 vs champion
  64.07/64.03 (~0.45% faster on nearly EVERY track, both seed sets) but
  crashes 15 vs 8, concentrated on the two most congested circuits
  (hungaroring 1->6, lemans 1->5). Lateral spacing IS load-bearing there.
  REJECT as-is; the constant `AI1_SPREAD_W` is a live tuning surface
  (intermediate weights never tried).
- **Arm C (certified pace tie-break, `patch_r49c_certpace.py`): NEUTRAL.**
  Keeps spread at champion strength but overrides toward a strictly faster
  line only when certified (weakly better on every non-spread term, zero
  trap penalty, not sealable, survives the DJS rollout). c=10 vs 8,
  mv -0.03/-0.05 over 10 seeds. The certification suppressed the pace
  (-0.26 -> -0.04) without buying back the safety.
- **Arm C + round 51 exact-self (the COMPOSITION): CRASH PARITY + pace.**
  22 tracks x 10 seeds: s1-5 f=767 c=3 mv=64.04 vs champion 767/3/64.07;
  s6-10 f=765 c=5 mv=63.98 vs 765/5/64.03. Crashes match the canonical
  champion EXACTLY on both seed sets, pace -0.03/-0.05. The exact-self
  rollout removed arm C's +1 crash on EACH seed set: idea 2 is inert alone
  but LOAD-BEARING in composition, confirming the false-death hypothesis
  (arm C certifies via simOutcome on a far broader state set than DJS's
  narrow trap trigger, so self-fidelity finally matters). Per-track wins at
  equal finishers: interlagos -0.3, hairpin -0.3, monaco/zandvoort/bigoval/
  chicane/slalom -0.1. Gain is small (~0.05%) but it is the FIRST
  crash-neutral pace improvement in many rounds.
- **Arm B (`unc` gated on `overSpeed > 0`): THE BIGGEST PACE LEVER IN THE
  CAMPAIGN, but uncertified.** 22 tracks x 10 seeds: mv 63.60/63.62 vs
  champion 64.07/64.03 = **~0.7% faster**, consistent across both seed sets
  (10x C+2's gain). Crashes disagree between seed sets: s1-5 c=7 vs 3
  (WORSE), s6-10 c=4 vs 5 (BETTER) => +3 over 10 seeds. Fires only on the
  big tracks the forensic predicted (lemans/monaco/interlagos/hungaroring/
  zandvoort), never on the spread-dominated short ones — an independent
  confirmation that the counterfactual attribution is measuring the right
  thing. Better trade than arm A (-0.44 pace for +3 crashes, vs -0.29 for
  +7) but still an uncertified caution cut.
- **Round 52 (`patch_r52_certunc.py`): the synthesis under test** — keep the
  surcharge as insurance and waive it only when certified on BOTH axes
  (speed inside the certified budget AND the landing survives the
  exact-self rollout). WARNING from the inert probe: it produced move
  counts IDENTICAL to arm B on all 7 diverging probe races, i.e. the
  survival check passes almost everywhere it fires, so it may reduce to
  arm B behaviourally. If the gate confirms that, the survival proof is too
  weak (a 3-round greedy-rival rollout rarely kills anything) and the
  certification needs a stronger/adversarial form, or the arm C-style extra
  conditions (trapPenalty == 0 and not sealable).
- **Round 52 RESULT (certified waiver, survival proof only): arm B pace,
  one crash better.** s1-5 f=763 c=7 mv=63.60 (BYTE-IDENTICAL to arm B --
  the survival check certified NOTHING); s6-10 f=767 c=3 mv=63.62, which
  BEATS the champion (765/5/64.03) on crashes AND finishers AND pace.
  10-seed: c=10 vs 8, mv -0.44. LAW: `simOutcome >= 0` is a WEAK proof --
  a 3-round rollout with greedy rivals almost never kills a landing. Use it
  only in conjunction (as C+2 does), never as the sole gate.
- **Round 53 (STRICTER certification: + trapPenalty == 0 + !sealable):
  REJECTED — dominated by round 52 on BOTH axes.** s1-5 f=765 c=5 mv=63.83
  (vs 767/3/64.07); s6-10 f=763 c=7 mv=63.79 (vs 765/5/64.03). 10-seed
  c=12 vs 8 and only -0.23 pace, i.e. MORE crashes AND LESS pace than the
  looser round 52 (c=10, -0.44). **KEY LAW: certification strictness does
  NOT trade monotonically against safety here.** Tightening the gate did not
  move along a pace/crash frontier — it reshuffled WHICH candidates get
  waived and relocated crashes to new sites (hungaroring 2, interlagos 1,
  zandvoort 3). Treat all of these arms as equilibrium RE-RANKINGS whose
  crash outcome is close to chaotic; the only robust result in the whole
  family is C+2's exact parity on BOTH independent seed sets. Do not spend
  more rounds hand-tuning certification predicates.
- **Round 50 (idea 4, predictedOpponentSteps 1->2): NEUTRAL, reverted.**
  Fires on 12/15 probe races (the ply>=1 predicted-cell test is a HARD SKIP,
  not a price, so this adds a ply-2 caution wall) but the gate is flat:
  s1-5 767/3/64.06 vs 767/3/64.07; s6-10 766/4/64.03 vs 765/5/64.03.
  Crashes merely RELOCATE (monaco/interlagos vs lemans/hungaroring).
  WARNING recorded: the probe's lower move counts looked like a pace win but
  are the mv composition artifact — probe move counts include crashed cars,
  mv averages finishers only. Never read the probe as a pace measurement.
- **Round 48 (idea 1, move-order/timing-exact world): CLOSED NEGATIVE,
  STRUCTURALLY.** Right-of-way is ALREADY modelled — `simulateTwoRounds`
  blocks rivals out of my candidate cell (`blocked[playerNum-1]`) and steps
  them in true turn order. The one remaining stale-world site
  (`countBrakeProofs`, a ply-2 question asked against `predicted`) was
  floored with the timed world => byte-inert on 15 races. Instrumentation
  (`patch_r48_debug.py`): the site is reached only **67 times in a 601-move
  lemans race** and returned `pred=2` EVERY time — `predicted` never blocks
  a braking descent, because AI1_VACATE_V already nulls exactly the fast
  rivals that would be near a fast car. Both ply-2 consumers are now
  provably correct. LAW: the speed-brake machinery (speedCap/waiver) is
  nearly DORMANT; do not look for pace there.
- **Round 51 (idea 2, exact-self rollout, `patch_r51_exactself.py`):
  byte-INERT alone.** `simOutcome` rolls MY car as pure greedy min-turns
  though the real me is the scorer (whose trap ladder refuses <=2 safe
  successors), so it reports FALSE DEATHS ("zandvoort s7 is greedy-me model
  error"). Fixed via a `selfMoveOverState` (maximise safe successors capped
  at 3, then min ttf) threaded behind an explicit `exactSelf` flag
  (AI1 true / AI2 false, since DJS is shared post-promotion). Result:
  0/15 divergence on zandvoort (incl. s7) / hungaroring / coil, 1/15 on the
  sinks. REASON (structural): DJS is SURVIVAL-ONLY, so it keeps a surviving
  pick regardless of how survival was computed — the self-policy can only
  matter when greedy-self DIES but trap-aware-self lives. Rare.
  LAW: a fidelity fix behind a narrow trigger cannot pay; check the trigger
  rate BEFORE building the fidelity fix.

## Crash floor REACHED — rounds 45-46 (all neutral, do not re-grind)

The round-44 champion's residual crashes (8-car c=3 s1-5 / c=5 s6-10, the
"ancestral" sites: silverstone s6, zandvoort s7/s8, coil s6/s10, zigzag
s4, lemans s4, hungaroring s1 guard) are at the EQUILIBRIUM FLOOR. Every
DJS refinement tried came back byte-neutral at the ancestral screen:
- R45 arm A (always-on DJS trigger, drop the trap>=0.5 gate): REJECTED —
  6 switches/race, false-DEATH model errors perturbed the field into new
  doom pockets (hungaroring guard 1->5). LAW: the trap gate bounds
  exposure to sim model error; it is not a pure cost gate.
- R45 arm B (finished cars vanish from the sim board): SHIPPED (22af7ad)
  as groundwork — full 7-stage battery PERFECT ties. Neutral because
  gated fires are rare and no gated verdict flipped on benched seeds.
- R46 (trap-aware greedy sim policy, prefer roomy landings): neutral,
  reverted.
- R46c (horizon rounds 3->4): neutral, reverted.
CONCLUSION: DJS is saturated at its trigger; better sim fidelity and
deeper horizon do NOT touch the ancestral floor. Crash reduction via
DJS is EXHAUSTED. The next crash gain (if any) needs a different
mechanism class (the shapes are speed-7-10 corner entries where a body
takes the escape; a real-me sim or a pre-emptive speed brake, not more
DJS). NOT the place to spend hours — see the pace frontier (lever 2).

## Bench speed (IMPORTANT — was the "taking hours" complaint)

Root causes: (1) every bench re-ran the FROZEN champion AI2 column =
~50% pure waste; (2) the 7-stage gate (both seed sets x all field sizes)
is deliberately large (small samples give false wins); (3) the champion
got costlier per move (joint sims + solver); (4) worst of all, full
batteries were spent on candidates in the mined-out crash region that the
equilibrium law already predicted neutral.
FIXES: bench_ai.py now honours BENCH_BASELINE=<json>: runs ONLY the AI1
candidate column and reads AI2 from the cache (first run with no cache
seeds it; delete on promotion). Champion caches seeded in scratchpad
(champ_8car_s1.json / _s6.json from r45bat). => every candidate bench is
~2x faster. PROCESS FIX: use the cheap targeted ancestral screen
(~30 min, crash_harvest on the specific sites) as the go/no-go; run the
full battery ONLY for a candidate that MOVES the screen. Rounds 45-46
never moved the screen and never needed batteries (R45B's battery was the
avoidable waste).

## Methodology laws (hard-won, do not relearn)

- **Forensic-first**: never build before reading the actual crash/decision
  logs. Replays are deterministic — same seed reproduces exactly.
- **Seed-set law**: 5-seed crash deltas are noise (~c7 events); always
  confirm on independent seeds 6-10. n=1 crash deltas are noise.
- **Equilibrium law**: local move re-ranking relocates crashes/pace at the
  traffic equilibrium (proven across pace gates, seal guards, queue guards,
  sim pricing, min() trap counts, threshold tuning). Beaten exactly once —
  by DJS's survival-only asymmetric search. Any new mechanism must explain
  why it isn't a re-rank.
- **mv composition artifact**: mv averages FINISHERS' moves; saving slow
  back-markers RAISES mv without anyone driving slower. Judge equal-speed
  on equal-finisher tracks (per-track diffs), not the TOTAL line.
- **Proxy overfit**: a traffic-sink-only proxy finds wins that evaporate
  over all 22 tracks.
- **Insurance-premium law**: braking/yielding for danger can cede h2h
  places — EXCEPT survival-only switches (DJS h2h: parity places, halved
  crashes).
- The scorer's trap ladder was RIGHT at every forensic kill; auxiliary
  selectors that ignore it (old paceOverride/sealGuard defects) were the
  round-35/36 crash sources. Those fixes (paceGuard v5, trapCount) were
  REVERTED by user choice ("back to last champion") but the -55% result
  was real; recoverable from git history (8268e4f, bf74f44) if wanted —
  note DJS now covers most of the same crashes a different way.

## Bench & tooling (critical operational knowledge)

- Build: `./build_main.sh` (javac via `git ls-files` — NEW files must be
  `git add`ed before compiling; then jar). Never rebuild while races run
  (Windows file lock; also the user's game GUI (javaw) locks the jar —
  check `tasklist` for javaw before rebuilds).
- Bench: `tracks/bench_ai.py` — `--seeds N`, `--h2h` (4v4), `--4p`, `--1v1`,
  `--slow` (serpentine/serpentine2/spiral/cog), `--tag NAME` (isolated
  props+log). Java flags: `--auto --track T --props P --log L --seed N`,
  plus `--dump-reach FILE` and `--query-moves IN OUT`.
- **Session kills background tasks**: client reconnects tear down
  `run_in_background` bash tasks (4 batteries died). Long runs MUST be
  detached OS processes:
  `Start-Process sh full_battery.sh` (PowerShell) writing stage logs +
  a progress file + a DONE marker, polled via ScheduleWakeup.
- **OneDrive hazard**: the repo dir is synced; rapidly-rewritten bench
  files there wedge runs (~25 min in) and can lock the jar. Keep bench
  props/logs on LOCAL disk (the scratchpad) — `bench_iso.py` does this.
- Serialization law: never run two benches/reachability-heavy javas
  concurrently (240s timeouts -> INVALID rows).
- This session's scratchpad (tools + all logs + reach dumps live here,
  persists on disk):
  `C:\Users\carlg\AppData\Local\Temp\claude\E--OneDrive-Coding-Java-theoreticRacing\749c6115-9b8c-4154-9f26-d8f380240d27\scratchpad`
  Key tools: crash_harvest.py (env KIND=AI1|AI2, NP=n; saves per-seed
  logs), run_debug.py (replay one seed with AIDBG dump — needs the debug
  instrumentation in the build), bench_iso.py (isolated chunked bench),
  full_battery.sh (detached 7-stage gate), tune_thresholds.py,
  headroom.py, start_congestion.py, density_compare.py, logdiff.sh,
  patch_djs.py / promote_djs.py (the shipped round-40 patches),
  reach_*.bin (22 dumps), djs_*.log (the promotion gate record).
- AIDBG debug instrumentation (`-Dai.debug.player=N` per-candidate scoring
  dump): NOT in the current champion source (reverted with round 34-38).
  Re-apply from scratchpad/patch_debug.py if forensics need it (it is
  behavior-neutral, both bodies, gated).
- Track gen: `tracks/build_synthetic.py` (serpentine has `pitch_jitter`
  for per-hairpin radii; serpentine2 = 150x130 width 9 lanes=8 pitch=22
  step=5 pitch_jitter=5). ASCII render: `tracks/plot_track.py`.

## Recent git history (all pushed, normal commits)

- 9ad009b Danger joint search: new champion (round 40, promoted into AI2)
- b86339b AI1: name the gate thresholds (round 39 tuning surface)
- e6f2fbc Add serpentine2 to the --slow bench set
- aa77a67 serpentine2: give each hairpin its own radius
- 35a100d Add serpentine2 track (tighter, 8 lanes, ~5.8-cell corridor)
- 2522119 Revert AI1 to champion: drop round 34-38 crash experiments
- bf74f44 / 8268e4f: the reverted crash-reduction line (recoverable)

## User context

- Plays the game via the GUI (javaw); user.properties is THEIR file —
  never commit or clobber it; a killed bench can corrupt nPlayers (bench
  hardens by setting 8 itself).
- The user's other heavy compute (python jobs) shares the machine — don't
  contend; pause benches if they need it.
- Effort: remind the user to run `/effort max` at session start (global
  CLAUDE.md rule).

ROUND 115 (low-energy graduated field acceleration): The Round-106 field certificate now admits AI1-only
speed2 gains 9..15 through TTF 45 when the incumbent speed2 is below
49 and the scorer is not coasting. This retains the Coil seed-1 and
seed-38 Pareto gains while excluding the long-range Spa and
high-energy Silverstone counterexamples. Exact gate:
3500 pairs, 2
Pareto-faster, 0 safety gain(s), zero
slower/safety-regression/redistribution outcomes, net
-3 finisher moves. AI2 remains frozen.

ROUND 117 (synchronized exact-six-ahead acceleration): AI1 may enter the established high-energy field
acceleration with exactly six rivals ahead only when a previously
moved rival is adjacent to the proposed landing and already carries
the candidate velocity. Exact gate: 3500 pairs,
1 Pareto gain(s),
0 safety gain(s), zero slower,
safety-regression or redistribution outcomes, net
-1 finisher moves. Coil s5/s22 are exact controls;
Coil s86 is the target gain. AI2 remains frozen.

ROUND 124 (phase-consistent trap-L2 acceleration): the old trap-L2 experiment's clean gain is isolated by the
round-phase boundary: positive L1/L2 field acceleration is AI1-only,
restricted to the first two movers and TTF<=45, with the established
high-energy and strict eight-round mover/field proof unchanged. Exact
gate: 3500 pairs, 1 Pareto
gain(s), zero individual slowdowns or safety regressions, net
-1 finisher moves. The only order change is the
improved driver joining an existing same-move tie. Changed races:
silverstone seed 93. AI2 remains frozen.

ROUND 171 (direct projected-occupancy maps): exact touched-cell counts replace repeated linear scans of projected opponent positions. The 26-track gate was byte-identical over 3500 races; alternating runtime ratio 0.881500 (11.85% faster).
Integration hardening records touched-cell membership for the whole clear epoch, preventing remove/re-add cycles from overflowing the touched buffer on supported tiny grids; CoreTests pins a full 3x3 board.

## Review corrections after round 223 — finish rules and trustworthy instruments

The follow-up review fixes the referee's ignored illegal-finish verdict and
adds pre-finish wall intersection checks (including collinear overlap and
thin notches). AI terminal shortcuts share that legal-finish predicate;
no scoring constants or champion heuristics are retuned. Cache semantics 15
invalidates the changed finish seeds. `RaceGame.evaluateMove` is the common
side-effect-free referee/oracle transition.

V2 query boards carry lap, next gate and global turn count; legacy missing
fields have explicit defaults instead of inheriting prior queries. Full
replay distinguishes LAP/FINISH/CRASH/TIMEOUT, compares full kinematics and
uses the engine's last-survivor rule. Standalone sim queries initialize
their own decision frame. Gate-map cycles now test convergence (minimum
three passes, bounded failure at 128), without changing the robust passage
rule.

The fleet shell entry point delegates to a Python runner with manifests,
OS locking, fresh per-attempt logs, complete-result validation and atomic
completion markers. JVM failures and incomplete results are errors and
remain retryable; changed build/profile/seed/track/runtime inputs cannot
reuse old rows. See `docs/replay-protocol.md` and `docs/review-corrections.md`.

The baseline/corrected zigzag comparison explains the only two golden digest
updates: four former finish moves overlap a wall before the line. Legal
alternatives preserve both races' total moves and result order. The other
ten golden fixtures stay unchanged. Dedicated tests cover both thin-notch
failures, full two-lap replay, query order, exact outcome comparison,
fixed-point convergence and fleet failure/resume injection. These are
correctness changes, not a claimed full-fleet pace promotion; the full
expensive promotion battery is not replaced by the regression corpus.

The private-slack Monza s30/s145 cases each change only one finish vector
(illegal NW to legal N). Serpentine s38 corrects p3's wall-overlap finish by
changing its last two approach moves, with a nearby p6 response. All three
retain every player's move count and finishing order, seven finishes and
zero crashes. Their digests are updated for the rule correction; summary
and AI1/AI2 identity assertions remain in place.
